/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
public class b {
    public static /* synthetic */ int a(long l) {
        return (int)(l ^ l >>> 32);
    }
}

