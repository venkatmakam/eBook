/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.IBinder
 *  android.os.IBinder$DeathRecipient
 *  android.support.customtabs.ICustomTabsCallback
 *  androidx.browser.customtabs.CustomTabsService
 *  androidx.browser.customtabs.CustomTabsService$1
 *  androidx.browser.customtabs.CustomTabsSessionToken
 *  androidx.collection.SimpleArrayMap
 *  java.lang.Object
 *  java.util.NoSuchElementException
 *  java.util.Objects
 */
package c.a.a;

import android.os.IBinder;
import android.support.customtabs.ICustomTabsCallback;
import androidx.browser.customtabs.CustomTabsService;
import androidx.browser.customtabs.CustomTabsSessionToken;
import androidx.collection.SimpleArrayMap;
import java.util.NoSuchElementException;
import java.util.Objects;

public final class a
implements IBinder.DeathRecipient {
    public final /* synthetic */ CustomTabsService.1 a;
    public final /* synthetic */ CustomTabsSessionToken b;

    public /* synthetic */ a(CustomTabsService.1 var1_1, CustomTabsSessionToken customTabsSessionToken) {
        this.a = var1_1;
        this.b = customTabsSessionToken;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final void binderDied() {
        IBinder iBinder;
        CustomTabsService.1 var1_1 = this.a;
        CustomTabsSessionToken customTabsSessionToken = this.b;
        CustomTabsService customTabsService = var1_1.a;
        Objects.requireNonNull((Object)customTabsService);
        try {
            SimpleArrayMap simpleArrayMap;
            SimpleArrayMap simpleArrayMap2 = simpleArrayMap = customTabsService.a;
            // MONITORENTER : simpleArrayMap2
            ICustomTabsCallback iCustomTabsCallback = customTabsSessionToken.a;
            iBinder = iCustomTabsCallback == null ? null : iCustomTabsCallback.asBinder();
        }
        catch (NoSuchElementException noSuchElementException) {
            return;
        }
        if (iBinder == null) {
            // MONITOREXIT : simpleArrayMap2
            return;
        }
        iBinder.unlinkToDeath((IBinder.DeathRecipient)customTabsService.a.get((Object)iBinder), 0);
        customTabsService.a.remove((Object)iBinder);
        // MONITOREXIT : simpleArrayMap2
    }
}

