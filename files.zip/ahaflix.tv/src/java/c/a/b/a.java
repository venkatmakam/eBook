/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.browser.trusted.ConnectionHolder
 *  androidx.concurrent.futures.CallbackToFutureAdapter
 *  androidx.concurrent.futures.CallbackToFutureAdapter$Completer
 *  androidx.concurrent.futures.CallbackToFutureAdapter$Resolver
 *  java.lang.Object
 */
package c.a.b;

import androidx.browser.trusted.ConnectionHolder;
import androidx.concurrent.futures.CallbackToFutureAdapter;

public final class a
implements CallbackToFutureAdapter.Resolver {
    public final /* synthetic */ ConnectionHolder a;

    public /* synthetic */ a(ConnectionHolder connectionHolder) {
        this.a = connectionHolder;
    }

    public final Object attachCompleter(CallbackToFutureAdapter.Completer completer) {
        return this.a.a(completer);
    }
}

