/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 *  androidx.browser.trusted.TrustedWebActivityServiceConnectionPool
 *  java.lang.Object
 *  java.lang.Runnable
 */
package c.a.b;

import android.net.Uri;
import androidx.browser.trusted.TrustedWebActivityServiceConnectionPool;

public final class c
implements Runnable {
    public final /* synthetic */ TrustedWebActivityServiceConnectionPool a;
    public final /* synthetic */ Uri b;

    public /* synthetic */ c(TrustedWebActivityServiceConnectionPool trustedWebActivityServiceConnectionPool, Uri uri) {
        this.a = trustedWebActivityServiceConnectionPool;
        this.b = uri;
    }

    public final void run() {
        this.a.a(this.b);
    }
}

