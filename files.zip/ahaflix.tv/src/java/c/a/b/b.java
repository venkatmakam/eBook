/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.browser.trusted.TokenContents
 *  java.lang.Object
 *  java.util.Comparator
 */
package c.a.b;

import androidx.browser.trusted.TokenContents;
import java.util.Comparator;

public final class b
implements Comparator {
    public static final /* synthetic */ b a;

    public static /* synthetic */ {
        a = new b();
    }

    public final int compare(Object object, Object object2) {
        return TokenContents.c((byte[])((byte[])object), (byte[])((byte[])object2));
    }
}

