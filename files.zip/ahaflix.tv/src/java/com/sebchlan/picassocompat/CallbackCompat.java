/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.sebchlan.picassocompat;

public interface CallbackCompat {
    public void onError();

    public void onSuccess();
}

