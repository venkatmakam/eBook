/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  java.lang.NoSuchFieldError
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.util.Locale
 */
package com.sebchlan.picassocompat;

import android.content.Context;
import com.sebchlan.picassocompat.LibDetector;
import com.sebchlan.picassocompat.PicassoCompat;
import com.sebchlan.picassocompat.PicassoCompat252;
import com.sebchlan.picassocompat.PicassoCompat271828;
import java.util.Locale;

public class PicassoBridge {
    private static LibDetector.ImgLib PICASSO_VERSION;

    public static PicassoCompat.Builder builder(Context context) {
        int n = PicassoBridge.detectLib().ordinal();
        if (n != 0) {
            if (n == 1) {
                return new PicassoCompat271828.Builder(context);
            }
            throw new RuntimeException("Add Picasso to your project");
        }
        return new PicassoCompat252.Builder(context);
    }

    private static LibDetector.ImgLib detectLib() {
        if (PICASSO_VERSION == null) {
            PICASSO_VERSION = LibDetector.a();
            Locale locale = Locale.ENGLISH;
            Object[] arrobject = new Object[]{PICASSO_VERSION};
            String.format((Locale)locale, (String)"Picasso detected: '%s'", (Object[])arrobject);
        }
        return PICASSO_VERSION;
    }

    public static PicassoCompat init(Context context) {
        int n = PicassoBridge.detectLib().ordinal();
        if (n != 0) {
            if (n == 1) {
                return new PicassoCompat271828();
            }
            throw new RuntimeException("Add Picasso to your project");
        }
        return new PicassoCompat252(context);
    }

}

