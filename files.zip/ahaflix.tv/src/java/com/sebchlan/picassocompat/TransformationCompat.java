/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  java.lang.Object
 *  java.lang.String
 */
package com.sebchlan.picassocompat;

import android.graphics.Bitmap;

public interface TransformationCompat {
    public String key();

    public Bitmap transform(Bitmap var1);
}

