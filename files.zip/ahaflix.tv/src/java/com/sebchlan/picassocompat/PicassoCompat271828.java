/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Notification
 *  android.content.Context
 *  android.graphics.Bitmap
 *  android.graphics.Bitmap$Config
 *  android.graphics.drawable.Drawable
 *  android.net.Uri
 *  android.widget.ImageView
 *  android.widget.RemoteViews
 *  androidx.annotation.NonNull
 *  androidx.annotation.Nullable
 *  com.sebchlan.picassocompat.CallbackCompat
 *  com.sebchlan.picassocompat.PicassoCompat
 *  com.sebchlan.picassocompat.PicassoCompat$Builder
 *  com.sebchlan.picassocompat.PicassoCompat$Listener
 *  com.sebchlan.picassocompat.PicassoCompat$LoadedFrom
 *  com.sebchlan.picassocompat.PicassoCompat$Priority
 *  com.sebchlan.picassocompat.PicassoCompat271828$1
 *  com.sebchlan.picassocompat.RequestCreatorCompat
 *  com.sebchlan.picassocompat.TargetCompat
 *  com.sebchlan.picassocompat.TransformationCompat
 *  com.squareup.picasso.Callback
 *  com.squareup.picasso.Downloader
 *  com.squareup.picasso.OkHttp3Downloader
 *  com.squareup.picasso.Picasso
 *  com.squareup.picasso.Picasso$Builder
 *  com.squareup.picasso.Picasso$Listener
 *  com.squareup.picasso.Picasso$LoadedFrom
 *  com.squareup.picasso.Picasso$Priority
 *  com.squareup.picasso.RequestCreator
 *  com.squareup.picasso.Target
 *  com.squareup.picasso.Transformation
 *  java.io.File
 *  java.io.IOException
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 *  java.util.concurrent.ExecutorService
 *  okhttp3.Call
 *  okhttp3.Call$Factory
 *  okhttp3.OkHttpClient
 */
package com.sebchlan.picassocompat;

import android.app.Notification;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.widget.ImageView;
import android.widget.RemoteViews;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.sebchlan.picassocompat.CallbackCompat;
import com.sebchlan.picassocompat.PicassoCompat;
import com.sebchlan.picassocompat.PicassoCompat271828;
import com.sebchlan.picassocompat.RequestCreatorCompat;
import com.sebchlan.picassocompat.TargetCompat;
import com.sebchlan.picassocompat.TransformationCompat;
import com.squareup.picasso.Callback;
import com.squareup.picasso.Downloader;
import com.squareup.picasso.OkHttp3Downloader;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.RequestCreator;
import com.squareup.picasso.Target;
import com.squareup.picasso.Transformation;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import okhttp3.Call;
import okhttp3.OkHttpClient;

public class PicassoCompat271828
implements PicassoCompat {
    private final Picasso picasso;
    private final Map<TargetCompat, Target> targetMap = new HashMap();

    public PicassoCompat271828() {
        this(Picasso.get());
    }

    private PicassoCompat271828(Picasso picasso) {
        this.picasso = picasso;
    }

    public /* synthetic */ PicassoCompat271828(Picasso picasso, 1 var2_2) {
        this(picasso);
    }

    public void cancelRequest(@NonNull ImageView imageView) {
        this.picasso.cancelRequest(imageView);
    }

    public void cancelRequest(@NonNull TargetCompat targetCompat) {
        if (this.targetMap.containsKey((Object)targetCompat)) {
            this.picasso.cancelRequest((Target)this.targetMap.get((Object)targetCompat));
        }
    }

    public void cancelTag(@NonNull Object object) {
        this.picasso.cancelTag(object);
    }

    public boolean getIndicatorsEnabled() {
        return this.picasso.areIndicatorsEnabled();
    }

    public void invalidate(@Nullable Uri uri) {
        this.picasso.invalidate(uri);
    }

    public void invalidate(@NonNull File file) {
        this.picasso.invalidate(file);
    }

    public void invalidate(@Nullable String string) {
        this.picasso.invalidate(string);
    }

    public boolean isLoggingEnabled() {
        return this.picasso.isLoggingEnabled();
    }

    public RequestCreatorCompat load(int n) {
        return new RequestCreatorCompat271828(this.picasso, n);
    }

    public RequestCreatorCompat load(@Nullable Uri uri) {
        return new RequestCreatorCompat271828(this.picasso, uri);
    }

    public RequestCreatorCompat load(@Nullable File file) {
        return new RequestCreatorCompat271828(this.picasso, file);
    }

    public RequestCreatorCompat load(@Nullable String string) {
        return new RequestCreatorCompat271828(this.picasso, string);
    }

    public void pauseTag(@NonNull Object object) {
        this.picasso.pauseTag(object);
    }

    public void resumeTag(@NonNull Object object) {
        this.picasso.resumeTag(object);
    }

    public void setIndicatorsEnabled(boolean bl) {
        this.picasso.setIndicatorsEnabled(bl);
    }

    public void setLoggingEnabled(boolean bl) {
        this.picasso.setLoggingEnabled(bl);
    }

    public void shutdown() {
        this.picasso.shutdown();
    }

    public static class Builder
    implements PicassoCompat.Builder {
        private Picasso.Builder builder;

        public Builder(Context context) {
            this.builder = new Picasso.Builder(context);
        }

        public PicassoCompat build() {
            return new PicassoCompat271828(this.builder.build(), null);
        }

        public PicassoCompat.Builder callFactory(@NonNull Call.Factory factory) {
            this.builder.downloader((Downloader)new OkHttp3Downloader(factory));
            return this;
        }

        public PicassoCompat.Builder client(@NonNull OkHttpClient okHttpClient) {
            this.builder.downloader((Downloader)new OkHttp3Downloader(okHttpClient));
            return this;
        }

        public PicassoCompat.Builder defaultBitmapConfig(@NonNull Bitmap.Config config) {
            this.builder.defaultBitmapConfig(config);
            return this;
        }

        public PicassoCompat.Builder executor(@NonNull ExecutorService executorService) {
            this.builder.executor(executorService);
            return this;
        }

        public PicassoCompat.Builder indicatorsEnabled(boolean bl) {
            this.builder.indicatorsEnabled(bl);
            return this;
        }

        public PicassoCompat.Builder listener(final @NonNull PicassoCompat.Listener listener) {
            this.builder.listener(new Picasso.Listener(this){

                public void onImageLoadFailed(Picasso picasso, Uri uri, Exception exception) {
                    listener.onImageLoadFailed(uri, exception);
                }
            });
            return this;
        }

        public PicassoCompat.Builder loggingEnabled(boolean bl) {
            this.builder.loggingEnabled(bl);
            return this;
        }

    }

    public static class CallbackConverter
    implements Callback {
        private final CallbackCompat callbackCompat;

        private CallbackConverter(CallbackCompat callbackCompat) {
            this.callbackCompat = callbackCompat;
        }

        public /* synthetic */ CallbackConverter(CallbackCompat callbackCompat, 1 var2_2) {
            this(callbackCompat);
        }

        public void onError(Exception exception) {
            CallbackCompat callbackCompat = this.callbackCompat;
            if (callbackCompat != null) {
                callbackCompat.onError();
            }
        }

        public void onSuccess() {
            CallbackCompat callbackCompat = this.callbackCompat;
            if (callbackCompat != null) {
                callbackCompat.onSuccess();
            }
        }
    }

    public class RequestCreatorCompat271828
    implements RequestCreatorCompat {
        private final RequestCreator requestCreator;

        public RequestCreatorCompat271828(Picasso picasso, int n) {
            this.requestCreator = picasso.load(n);
        }

        public RequestCreatorCompat271828(Picasso picasso, Uri uri) {
            this.requestCreator = picasso.load(uri);
        }

        public RequestCreatorCompat271828(Picasso picasso, File file) {
            this.requestCreator = picasso.load(file);
        }

        public RequestCreatorCompat271828(Picasso picasso, String string) {
            this.requestCreator = picasso.load(string);
        }

        public RequestCreatorCompat centerCrop() {
            this.requestCreator.centerCrop();
            return this;
        }

        public RequestCreatorCompat centerInside() {
            this.requestCreator.centerInside();
            return this;
        }

        public RequestCreatorCompat config(Bitmap.Config config) {
            this.requestCreator.config(config);
            return this;
        }

        public RequestCreatorCompat error(int n) {
            this.requestCreator.error(n);
            return this;
        }

        public RequestCreatorCompat error(Drawable drawable) {
            this.requestCreator.error(drawable);
            return this;
        }

        public void fetch() {
            this.requestCreator.fetch();
        }

        public void fetch(CallbackCompat callbackCompat) {
            this.requestCreator.fetch((Callback)new CallbackConverter(callbackCompat, null));
        }

        public RequestCreatorCompat fit() {
            this.requestCreator.fit();
            return this;
        }

        public Bitmap get() throws IOException {
            return this.requestCreator.get();
        }

        public void into(ImageView imageView) {
            this.requestCreator.into(imageView);
        }

        public void into(ImageView imageView, CallbackCompat callbackCompat) {
            this.requestCreator.into(imageView, (Callback)new CallbackConverter(callbackCompat, null));
        }

        public void into(RemoteViews remoteViews, int n, int n2, Notification notification) {
            this.requestCreator.into(remoteViews, n, n2, notification);
        }

        public void into(RemoteViews remoteViews, int n, int[] arrn) {
            this.requestCreator.into(remoteViews, n, arrn);
        }

        public void into(TargetCompat targetCompat) {
            if (PicassoCompat271828.this.targetMap.containsKey((Object)targetCompat)) {
                this.requestCreator.into((Target)PicassoCompat271828.this.targetMap.get((Object)targetCompat));
                return;
            }
            TargetConverter targetConverter = new TargetConverter(targetCompat, null);
            PicassoCompat271828.this.targetMap.put((Object)targetCompat, (Object)targetConverter);
            this.requestCreator.into((Target)targetConverter);
        }

        public RequestCreatorCompat noFade() {
            this.requestCreator.noFade();
            return this;
        }

        public RequestCreatorCompat noPlaceholder() {
            this.requestCreator.noPlaceholder();
            return this;
        }

        public RequestCreatorCompat onlyScaleDown() {
            this.requestCreator.onlyScaleDown();
            return this;
        }

        public RequestCreatorCompat placeholder(int n) {
            this.requestCreator.placeholder(n);
            return this;
        }

        public RequestCreatorCompat placeholder(Drawable drawable) {
            this.requestCreator.placeholder(drawable);
            return this;
        }

        public RequestCreatorCompat priority(PicassoCompat.Priority priority) {
            int n = priority.ordinal();
            Object object = n != 0 ? (n != 1 ? (n != 2 ? null : Picasso.Priority.HIGH) : Picasso.Priority.NORMAL) : Picasso.Priority.LOW;
            this.requestCreator.priority(object);
            return this;
        }

        public RequestCreatorCompat resize(int n, int n2) {
            this.requestCreator.resize(n, n2);
            return this;
        }

        public RequestCreatorCompat resizeDimen(int n, int n2) {
            this.requestCreator.resizeDimen(n, n2);
            return this;
        }

        public RequestCreatorCompat rotate(float f) {
            this.requestCreator.rotate(f);
            return this;
        }

        public RequestCreatorCompat rotate(float f, float f2, float f3) {
            this.requestCreator.rotate(f, f2, f3);
            return this;
        }

        public RequestCreatorCompat stableKey(String string) {
            this.requestCreator.stableKey(string);
            return this;
        }

        public RequestCreatorCompat tag(Object object) {
            this.requestCreator.tag(object);
            return null;
        }

        public RequestCreatorCompat transform(TransformationCompat transformationCompat) {
            this.requestCreator.transform((Transformation)new TransformationConverter(transformationCompat));
            return this;
        }

        public RequestCreatorCompat transform(List<? extends TransformationCompat> list) {
            ArrayList arrayList = new ArrayList(list.size());
            Iterator iterator = list.iterator();
            while (iterator.hasNext()) {
                arrayList.add((Object)new TransformationConverter((TransformationCompat)iterator.next()));
            }
            this.requestCreator.transform((List)arrayList);
            return this;
        }
    }

    public static class TargetConverter
    implements Target {
        private final TargetCompat targetCompat;

        private TargetConverter(TargetCompat targetCompat) {
            this.targetCompat = targetCompat;
        }

        public /* synthetic */ TargetConverter(TargetCompat targetCompat, 1 var2_2) {
            this(targetCompat);
        }

        public void onBitmapFailed(Exception exception, Drawable drawable) {
            TargetCompat targetCompat = this.targetCompat;
            if (targetCompat != null) {
                targetCompat.onBitmapFailed(drawable);
            }
        }

        public void onBitmapLoaded(Bitmap bitmap, Picasso.LoadedFrom loadedFrom) {
            int n = loadedFrom.ordinal();
            Object object = n != 0 ? (n != 1 ? (n != 2 ? null : PicassoCompat.LoadedFrom.NETWORK) : PicassoCompat.LoadedFrom.DISK) : PicassoCompat.LoadedFrom.MEMORY;
            TargetCompat targetCompat = this.targetCompat;
            if (targetCompat != null) {
                targetCompat.onBitmapLoaded(bitmap, object);
            }
        }

        public void onPrepareLoad(Drawable drawable) {
            TargetCompat targetCompat = this.targetCompat;
            if (targetCompat != null) {
                targetCompat.onPrepareLoad(drawable);
            }
        }
    }

    public static class TransformationConverter
    implements Transformation {
        private final TransformationCompat transformationCompat;

        public TransformationConverter(TransformationCompat transformationCompat) {
            this.transformationCompat = transformationCompat;
        }

        public String key() {
            return this.transformationCompat.key();
        }

        public Bitmap transform(Bitmap bitmap) {
            return this.transformationCompat.transform(bitmap);
        }
    }

}

