/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.annotation.NonNull
 *  androidx.annotation.Nullable
 *  java.lang.Class
 *  java.lang.Enum
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Method
 */
package com.sebchlan.picassocompat;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.lang.reflect.Method;

public class LibDetector {
    private static final String PICASSO = "com.squareup.picasso.Picasso";
    private static final String PICASSO_INIT_252 = "with";
    private static final String PICASSO_INIT_271828 = "get";

    public static ImgLib a() {
        Class<?> class_ = LibDetector.getClass(PICASSO);
        if (class_ != null) {
            for (Method method : class_.getDeclaredMethods()) {
                if (method.getName().equals((Object)PICASSO_INIT_252)) {
                    return ImgLib.Picasso252;
                }
                if (!method.getName().equals((Object)PICASSO_INIT_271828)) continue;
                return ImgLib.Picasso271828;
            }
        }
        return ImgLib.None;
    }

    @Nullable
    private static Class<?> getClass(@NonNull String string2) {
        try {
            Class class_ = Class.forName((String)string2);
            return class_;
        }
        catch (Exception exception) {
            return null;
        }
    }

    public static final class ImgLib
    extends Enum<ImgLib> {
        private static final /* synthetic */ ImgLib[] $VALUES;
        public static final /* enum */ ImgLib None;
        public static final /* enum */ ImgLib Picasso252;
        public static final /* enum */ ImgLib Picasso271828;

        public static {
            ImgLib imgLib;
            ImgLib imgLib2;
            ImgLib imgLib3;
            Picasso252 = imgLib2 = new ImgLib();
            Picasso271828 = imgLib3 = new ImgLib();
            None = imgLib = new ImgLib();
            $VALUES = new ImgLib[]{imgLib2, imgLib3, imgLib};
        }

        public static ImgLib valueOf(String string2) {
            return (ImgLib)Enum.valueOf(ImgLib.class, (String)string2);
        }

        public static ImgLib[] values() {
            return (ImgLib[])$VALUES.clone();
        }
    }

}

