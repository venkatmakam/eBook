/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  android.graphics.drawable.Drawable
 *  java.lang.Object
 */
package com.sebchlan.picassocompat;

import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import com.sebchlan.picassocompat.PicassoCompat;

public interface TargetCompat {
    public void onBitmapFailed(Drawable var1);

    public void onBitmapLoaded(Bitmap var1, PicassoCompat.LoadedFrom var2);

    public void onPrepareLoad(Drawable var1);
}

