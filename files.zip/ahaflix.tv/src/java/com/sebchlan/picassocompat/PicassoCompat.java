/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  android.graphics.Bitmap$Config
 *  android.net.Uri
 *  android.widget.ImageView
 *  androidx.annotation.DrawableRes
 *  androidx.annotation.NonNull
 *  androidx.annotation.Nullable
 *  java.io.File
 *  java.lang.Enum
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.util.concurrent.ExecutorService
 *  okhttp3.Call
 *  okhttp3.Call$Factory
 *  okhttp3.OkHttpClient
 */
package com.sebchlan.picassocompat;

import android.graphics.Bitmap;
import android.net.Uri;
import android.widget.ImageView;
import androidx.annotation.DrawableRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.sebchlan.picassocompat.RequestCreatorCompat;
import com.sebchlan.picassocompat.TargetCompat;
import java.io.File;
import java.util.concurrent.ExecutorService;
import okhttp3.Call;
import okhttp3.OkHttpClient;

public interface PicassoCompat {
    public void cancelRequest(@NonNull ImageView var1);

    public void cancelRequest(@NonNull TargetCompat var1);

    public void cancelTag(@NonNull Object var1);

    public boolean getIndicatorsEnabled();

    public void invalidate(@Nullable Uri var1);

    public void invalidate(@NonNull File var1);

    public void invalidate(@Nullable String var1);

    public boolean isLoggingEnabled();

    public RequestCreatorCompat load(@DrawableRes int var1);

    public RequestCreatorCompat load(@Nullable Uri var1);

    public RequestCreatorCompat load(@Nullable File var1);

    public RequestCreatorCompat load(@Nullable String var1);

    public void pauseTag(@NonNull Object var1);

    public void resumeTag(@NonNull Object var1);

    public void setIndicatorsEnabled(boolean var1);

    public void setLoggingEnabled(boolean var1);

    public void shutdown();

    public static interface Builder {
        public PicassoCompat build();

        public Builder callFactory(@NonNull Call.Factory var1);

        public Builder client(@NonNull OkHttpClient var1);

        public Builder defaultBitmapConfig(@NonNull Bitmap.Config var1);

        public Builder executor(@NonNull ExecutorService var1);

        public Builder indicatorsEnabled(boolean var1);

        public Builder listener(@NonNull Listener var1);

        public Builder loggingEnabled(boolean var1);
    }

    public static interface Listener {
        public void onImageLoadFailed(@NonNull Uri var1, @NonNull Exception var2);
    }

    public static final class LoadedFrom
    extends Enum<LoadedFrom> {
        private static final /* synthetic */ LoadedFrom[] $VALUES;
        public static final /* enum */ LoadedFrom DISK;
        public static final /* enum */ LoadedFrom MEMORY;
        public static final /* enum */ LoadedFrom NETWORK;

        public static {
            LoadedFrom loadedFrom;
            LoadedFrom loadedFrom2;
            LoadedFrom loadedFrom3;
            MEMORY = loadedFrom2 = new LoadedFrom(-16711936);
            DISK = loadedFrom3 = new LoadedFrom(-16776961);
            NETWORK = loadedFrom = new LoadedFrom(-65536);
            $VALUES = new LoadedFrom[]{loadedFrom2, loadedFrom3, loadedFrom};
        }

        private LoadedFrom(int n2) {
        }

        public static LoadedFrom valueOf(String string2) {
            return (LoadedFrom)Enum.valueOf(LoadedFrom.class, (String)string2);
        }

        public static LoadedFrom[] values() {
            return (LoadedFrom[])$VALUES.clone();
        }
    }

    public static final class Priority
    extends Enum<Priority> {
        private static final /* synthetic */ Priority[] $VALUES;
        public static final /* enum */ Priority HIGH;
        public static final /* enum */ Priority LOW;
        public static final /* enum */ Priority NORMAL;

        public static {
            Priority priority;
            Priority priority2;
            Priority priority3;
            LOW = priority2 = new Priority();
            NORMAL = priority3 = new Priority();
            HIGH = priority = new Priority();
            $VALUES = new Priority[]{priority2, priority3, priority};
        }

        public static Priority valueOf(String string2) {
            return (Priority)Enum.valueOf(Priority.class, (String)string2);
        }

        public static Priority[] values() {
            return (Priority[])$VALUES.clone();
        }
    }

}

