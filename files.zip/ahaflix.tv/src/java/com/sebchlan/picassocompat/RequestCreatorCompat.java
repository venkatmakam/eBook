/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Notification
 *  android.graphics.Bitmap
 *  android.graphics.Bitmap$Config
 *  android.graphics.drawable.Drawable
 *  android.widget.ImageView
 *  android.widget.RemoteViews
 *  java.io.IOException
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 */
package com.sebchlan.picassocompat;

import android.app.Notification;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.widget.ImageView;
import android.widget.RemoteViews;
import com.sebchlan.picassocompat.CallbackCompat;
import com.sebchlan.picassocompat.PicassoCompat;
import com.sebchlan.picassocompat.TargetCompat;
import com.sebchlan.picassocompat.TransformationCompat;
import java.io.IOException;
import java.util.List;

public interface RequestCreatorCompat {
    public RequestCreatorCompat centerCrop();

    public RequestCreatorCompat centerInside();

    public RequestCreatorCompat config(Bitmap.Config var1);

    public RequestCreatorCompat error(int var1);

    public RequestCreatorCompat error(Drawable var1);

    public void fetch();

    public void fetch(CallbackCompat var1);

    public RequestCreatorCompat fit();

    public Bitmap get() throws IOException;

    public void into(ImageView var1);

    public void into(ImageView var1, CallbackCompat var2);

    public void into(RemoteViews var1, int var2, int var3, Notification var4);

    public void into(RemoteViews var1, int var2, int[] var3);

    public void into(TargetCompat var1);

    public RequestCreatorCompat noFade();

    public RequestCreatorCompat noPlaceholder();

    public RequestCreatorCompat onlyScaleDown();

    public RequestCreatorCompat placeholder(int var1);

    public RequestCreatorCompat placeholder(Drawable var1);

    public RequestCreatorCompat priority(PicassoCompat.Priority var1);

    public RequestCreatorCompat resize(int var1, int var2);

    public RequestCreatorCompat resizeDimen(int var1, int var2);

    public RequestCreatorCompat rotate(float var1);

    public RequestCreatorCompat rotate(float var1, float var2, float var3);

    public RequestCreatorCompat stableKey(String var1);

    public RequestCreatorCompat tag(Object var1);

    public RequestCreatorCompat transform(TransformationCompat var1);

    public RequestCreatorCompat transform(List<? extends TransformationCompat> var1);
}

