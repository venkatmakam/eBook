/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.sebchlan.picassocompat.twofivetwo;

public final class BuildConfig {
    public static final String APPLICATION_ID = "com.sebchlan.picassocompat.twofivetwo";
    public static final String BUILD_TYPE = "release";
    public static final boolean DEBUG = false;
    public static final String FLAVOR = "";
    public static final int VERSION_CODE = 1;
    public static final String VERSION_NAME = "1.2.1";
}

