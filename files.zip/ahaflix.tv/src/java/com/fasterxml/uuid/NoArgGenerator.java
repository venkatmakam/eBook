/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.fasterxml.uuid.UUIDGenerator
 *  java.util.UUID
 */
package com.fasterxml.uuid;

import com.fasterxml.uuid.UUIDGenerator;
import java.util.UUID;

public abstract class NoArgGenerator
extends UUIDGenerator {
    public abstract UUID generate();
}

