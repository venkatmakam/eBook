/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.fasterxml.uuid.UUIDGenerator
 *  java.lang.String
 *  java.util.UUID
 */
package com.fasterxml.uuid;

import com.fasterxml.uuid.UUIDGenerator;
import java.util.UUID;

public abstract class StringArgGenerator
extends UUIDGenerator {
    public abstract UUID generate(String var1);

    public abstract UUID generate(byte[] var1);
}

