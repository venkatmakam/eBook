/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.fasterxml.uuid.TimestampSynchronizer
 *  com.fasterxml.uuid.ext.LockedFile
 *  e.a.a.a.a
 *  java.io.File
 *  java.io.IOException
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 *  java.lang.Throwable
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package com.fasterxml.uuid.ext;

import com.fasterxml.uuid.TimestampSynchronizer;
import com.fasterxml.uuid.ext.LockedFile;
import e.a.a.a.a;
import java.io.File;
import java.io.IOException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class FileBasedTimestampSynchronizer
extends TimestampSynchronizer {
    private static final Logger logger = LoggerFactory.getLogger(FileBasedTimestampSynchronizer.class);
    public long a = 10000L;
    public final LockedFile b;
    public final LockedFile c;
    public boolean d = false;

    public FileBasedTimestampSynchronizer() throws IOException {
        this(new File("uuid1.lck"), new File("uuid2.lck"));
    }

    public FileBasedTimestampSynchronizer(File file, File file2) throws IOException {
        this(file, file2, 10000L);
    }

    public FileBasedTimestampSynchronizer(File file, File file2, long l) throws IOException {
        this.a = l;
        this.b = new LockedFile(file);
        try {
            this.c = new LockedFile(file2);
            return;
        }
        catch (Throwable throwable) {
            this.b.deactivate();
            throw throwable;
        }
    }

    public void deactivate() throws IOException {
        LockedFile lockedFile = this.b;
        LockedFile lockedFile2 = this.c;
        if (lockedFile != null) {
            lockedFile.deactivate();
        }
        if (lockedFile2 != null) {
            lockedFile2.deactivate();
        }
    }

    public long initialize() throws IOException {
        long l;
        long l2 = this.b.readStamp();
        if (l2 > (l = this.c.readStamp())) {
            this.d = true;
        } else {
            this.d = false;
            l2 = l;
        }
        if (l2 <= 0L) {
            logger.warn("Could not determine safe timer starting point: assuming current system time is acceptable");
            return l2;
        }
        long l3 = System.currentTimeMillis();
        if (l3 + this.a < l2) {
            logger.warn("Safe timestamp read is {} milliseconds in future, and is greater than the inteval ({})", (Object)(l2 - l3), (Object)this.a);
        }
        return l2;
    }

    public void setUpdateInterval(long l) {
        if (l >= 1L) {
            this.a = l;
            return;
        }
        throw new IllegalArgumentException(a.b1((String)"Illegal value (", (long)l, (String)"); has to be a positive integer value"));
    }

    public long update(long l) throws IOException {
        long l2 = l + this.a;
        if (this.d) {
            this.c.writeStamp(l2);
        } else {
            this.b.writeStamp(l2);
        }
        this.d = true ^ this.d;
        return l2;
    }
}

