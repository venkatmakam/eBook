/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.fasterxml.uuid.UUIDType
 *  com.fasterxml.uuid.impl.UUIDUtil
 *  java.lang.Object
 *  java.lang.String
 *  java.nio.charset.Charset
 *  java.security.MessageDigest
 *  java.util.UUID
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package com.fasterxml.uuid.impl;

import com.fasterxml.uuid.StringArgGenerator;
import com.fasterxml.uuid.UUIDType;
import com.fasterxml.uuid.impl.UUIDUtil;
import java.nio.charset.Charset;
import java.security.MessageDigest;
import java.util.UUID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class NameBasedGenerator
extends StringArgGenerator {
    public static final UUID NAMESPACE_DNS;
    public static final UUID NAMESPACE_OID;
    public static final UUID NAMESPACE_URL;
    public static final UUID NAMESPACE_X500;
    public static final Charset _utf8;
    private static final Logger logger;
    public final UUID a;
    public final MessageDigest b;
    public final UUIDType c;

    public static {
        logger = LoggerFactory.getLogger(NameBasedGenerator.class);
        _utf8 = Charset.forName((String)"UTF-8");
        NAMESPACE_DNS = UUID.fromString((String)"6ba7b810-9dad-11d1-80b4-00c04fd430c8");
        NAMESPACE_URL = UUID.fromString((String)"6ba7b811-9dad-11d1-80b4-00c04fd430c8");
        NAMESPACE_OID = UUID.fromString((String)"6ba7b812-9dad-11d1-80b4-00c04fd430c8");
        NAMESPACE_X500 = UUID.fromString((String)"6ba7b814-9dad-11d1-80b4-00c04fd430c8");
    }

    public NameBasedGenerator(UUID uUID, MessageDigest messageDigest, UUIDType uUIDType) {
        this.a = uUID;
        if (uUIDType == null) {
            String string = messageDigest.getAlgorithm();
            if (string.startsWith("MD5")) {
                uUIDType = UUIDType.NAME_BASED_MD5;
            } else if (string.startsWith("SHA")) {
                uUIDType = UUIDType.NAME_BASED_SHA1;
            } else {
                uUIDType = UUIDType.NAME_BASED_SHA1;
                logger.warn("Could not determine type of Digester from '{}'; assuming 'SHA-1' type", (Object)string);
            }
        }
        this.b = messageDigest;
        this.c = uUIDType;
    }

    @Override
    public UUID generate(String string) {
        return this.generate(string.getBytes(_utf8));
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public UUID generate(byte[] arrby) {
        MessageDigest messageDigest;
        MessageDigest messageDigest2 = messageDigest = this.b;
        synchronized (messageDigest2) {
            this.b.reset();
            UUID uUID = this.a;
            if (uUID != null) {
                this.b.update(UUIDUtil.asByteArray((UUID)uUID));
            }
            this.b.update(arrby);
            byte[] arrby2 = this.b.digest();
            return UUIDUtil.constructUUID((UUIDType)this.c, (byte[])arrby2);
        }
    }

    public UUID getNamespace() {
        return this.a;
    }

    public UUIDType getType() {
        return this.c;
    }
}

