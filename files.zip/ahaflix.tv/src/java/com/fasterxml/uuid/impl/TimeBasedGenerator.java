/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.fasterxml.uuid.EthernetAddress
 *  com.fasterxml.uuid.UUIDTimer
 *  com.fasterxml.uuid.UUIDType
 *  com.fasterxml.uuid.impl.UUIDUtil
 *  java.util.UUID
 */
package com.fasterxml.uuid.impl;

import com.fasterxml.uuid.EthernetAddress;
import com.fasterxml.uuid.NoArgGenerator;
import com.fasterxml.uuid.UUIDTimer;
import com.fasterxml.uuid.UUIDType;
import com.fasterxml.uuid.impl.UUIDUtil;
import java.util.UUID;

public class TimeBasedGenerator
extends NoArgGenerator {
    public final EthernetAddress a;
    public final UUIDTimer b;
    public final long c;

    public TimeBasedGenerator(EthernetAddress ethernetAddress, UUIDTimer uUIDTimer) {
        byte[] arrby = new byte[16];
        if (ethernetAddress == null) {
            ethernetAddress = EthernetAddress.constructMulticastAddress();
        }
        this.a = ethernetAddress;
        ethernetAddress.toByteArray(arrby, 10);
        int n = uUIDTimer.getClockSequence();
        arrby[8] = (byte)(n >> 8);
        arrby[9] = (byte)n;
        this.c = UUIDUtil.initUUIDSecondLong((long)UUIDUtil.gatherLong((byte[])arrby, (int)8));
        this.b = uUIDTimer;
    }

    @Override
    public UUID generate() {
        long l = this.b.getTimestamp();
        int n = (int)(l >>> 32);
        int n2 = (int)l;
        return new UUID((long)(4096 | -61441 & (n << 16 | n >>> 16)) << 32 >>> 32 | (long)n2 << 32, this.c);
    }

    public EthernetAddress getEthernetAddress() {
        return this.a;
    }

    public UUIDType getType() {
        return UUIDType.TIME_BASED;
    }
}

