/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.fasterxml.uuid.UUIDType
 *  com.fasterxml.uuid.impl.RandomBasedGenerator$LazyRandom
 *  com.fasterxml.uuid.impl.UUIDUtil
 *  java.security.SecureRandom
 *  java.util.Random
 *  java.util.UUID
 */
package com.fasterxml.uuid.impl;

import com.fasterxml.uuid.NoArgGenerator;
import com.fasterxml.uuid.UUIDType;
import com.fasterxml.uuid.impl.RandomBasedGenerator;
import com.fasterxml.uuid.impl.UUIDUtil;
import java.security.SecureRandom;
import java.util.Random;
import java.util.UUID;

/*
 * Exception performing whole class analysis ignored.
 */
public class RandomBasedGenerator
extends NoArgGenerator {
    public final Random a;
    public final boolean b;

    public RandomBasedGenerator(Random random) {
        if (random == null) {
            random = LazyRandom.sharedSecureRandom();
            this.b = true;
        } else {
            this.b = random instanceof SecureRandom;
        }
        this.a = random;
    }

    private static final long _toInt(byte[] arrby, int n) {
        int n2 = arrby[n] << 24;
        int n3 = n + 1;
        int n4 = n2 + ((255 & arrby[n3]) << 16);
        int n5 = n3 + 1;
        return n4 + ((255 & arrby[n5]) << 8) + (255 & arrby[n5 + 1]);
    }

    private static final long _toLong(byte[] arrby, int n) {
        long l = RandomBasedGenerator._toInt(arrby, n);
        long l2 = RandomBasedGenerator._toInt(arrby, n + 4);
        return (l << 32) + (l2 << 32 >>> 32);
    }

    @Override
    public UUID generate() {
        long l;
        long l2;
        if (this.b) {
            byte[] arrby = new byte[16];
            this.a.nextBytes(arrby);
            l = RandomBasedGenerator._toLong(arrby, 0);
            l2 = RandomBasedGenerator._toLong(arrby, 1);
        } else {
            l = this.a.nextLong();
            l2 = this.a.nextLong();
        }
        return UUIDUtil.constructUUID((UUIDType)UUIDType.RANDOM_BASED, (long)l, (long)l2);
    }

    public UUIDType getType() {
        return UUIDType.RANDOM_BASED;
    }
}

