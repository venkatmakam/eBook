/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.common.annotations.Beta
 *  com.google.common.annotations.GwtCompatible
 *  e.a.a.a.a
 *  java.lang.Enum
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 */
package com.google.thirdparty.publicsuffix;

import com.google.common.annotations.Beta;
import com.google.common.annotations.GwtCompatible;
import e.a.a.a.a;

@Beta
@GwtCompatible
public final class PublicSuffixType
extends Enum<PublicSuffixType> {
    private static final /* synthetic */ PublicSuffixType[] $VALUES;
    public static final /* enum */ PublicSuffixType PRIVATE;
    public static final /* enum */ PublicSuffixType REGISTRY;
    private final char innerNodeCode;
    private final char leafNodeCode;

    public static {
        PublicSuffixType publicSuffixType;
        PublicSuffixType publicSuffixType2;
        PRIVATE = publicSuffixType = new PublicSuffixType(':', ',');
        REGISTRY = publicSuffixType2 = new PublicSuffixType('!', '?');
        $VALUES = new PublicSuffixType[]{publicSuffixType, publicSuffixType2};
    }

    private PublicSuffixType(char c, char c2) {
        this.innerNodeCode = c;
        this.leafNodeCode = c2;
    }

    public static PublicSuffixType fromCode(char c) {
        PublicSuffixType[] arrpublicSuffixType = PublicSuffixType.values();
        for (int i = 0; i < 2; ++i) {
            PublicSuffixType publicSuffixType = arrpublicSuffixType[i];
            if (publicSuffixType.getInnerNodeCode() != c) {
                if (publicSuffixType.getLeafNodeCode() != c) continue;
                return publicSuffixType;
            }
            return publicSuffixType;
        }
        throw new IllegalArgumentException(a.U0((String)"No enum corresponding to given code: ", (char)c));
    }

    public static PublicSuffixType fromIsPrivate(boolean bl) {
        if (bl) {
            return PRIVATE;
        }
        return REGISTRY;
    }

    public static PublicSuffixType valueOf(String string2) {
        return (PublicSuffixType)Enum.valueOf(PublicSuffixType.class, (String)string2);
    }

    public static PublicSuffixType[] values() {
        return (PublicSuffixType[])$VALUES.clone();
    }

    public char getInnerNodeCode() {
        return this.innerNodeCode;
    }

    public char getLeafNodeCode() {
        return this.leafNodeCode;
    }
}

