/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.longrunning.Operation$1
 *  com.google.longrunning.Operation$ResultCase
 *  com.google.longrunning.OperationOrBuilder
 *  com.google.protobuf.AbstractMessageLite
 *  com.google.protobuf.Any
 *  com.google.protobuf.Any$Builder
 *  com.google.protobuf.ByteString
 *  com.google.protobuf.CodedInputStream
 *  com.google.protobuf.CodedOutputStream
 *  com.google.protobuf.ExtensionRegistryLite
 *  com.google.protobuf.GeneratedMessageLite
 *  com.google.protobuf.GeneratedMessageLite$Builder
 *  com.google.protobuf.GeneratedMessageLite$DefaultInstanceBasedParser
 *  com.google.protobuf.GeneratedMessageLite$MergeFromVisitor
 *  com.google.protobuf.GeneratedMessageLite$MethodToInvoke
 *  com.google.protobuf.GeneratedMessageLite$Visitor
 *  com.google.protobuf.InvalidProtocolBufferException
 *  com.google.protobuf.MessageLite
 *  com.google.protobuf.Parser
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 *  java.util.Objects
 */
package com.google.longrunning;

import com.google.longrunning.Operation;
import com.google.longrunning.OperationOrBuilder;
import com.google.protobuf.AbstractMessageLite;
import com.google.protobuf.Any;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.CodedOutputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.MessageLite;
import com.google.protobuf.Parser;
import com.google.rpc.Status;
import java.io.IOException;
import java.io.InputStream;
import java.util.Objects;

/*
 * Exception performing whole class analysis ignored.
 */
public final class Operation
extends GeneratedMessageLite<Operation, Builder>
implements OperationOrBuilder {
    private static final Operation DEFAULT_INSTANCE;
    public static final int DONE_FIELD_NUMBER = 3;
    public static final int ERROR_FIELD_NUMBER = 4;
    public static final int METADATA_FIELD_NUMBER = 2;
    public static final int NAME_FIELD_NUMBER = 1;
    private static volatile Parser<Operation> PARSER;
    public static final int RESPONSE_FIELD_NUMBER = 5;
    private boolean done_;
    private Any metadata_;
    private String name_ = "";
    private int resultCase_ = 0;
    private Object result_;

    public static {
        Operation operation;
        DEFAULT_INSTANCE = operation = new Operation();
        operation.makeImmutable();
    }

    private Operation() {
    }

    private void clearDone() {
        this.done_ = false;
    }

    private void clearError() {
        if (this.resultCase_ == 4) {
            this.resultCase_ = 0;
            this.result_ = null;
        }
    }

    private void clearMetadata() {
        this.metadata_ = null;
    }

    private void clearName() {
        this.name_ = Operation.getDefaultInstance().getName();
    }

    private void clearResponse() {
        if (this.resultCase_ == 5) {
            this.resultCase_ = 0;
            this.result_ = null;
        }
    }

    private void clearResult() {
        this.resultCase_ = 0;
        this.result_ = null;
    }

    public static Operation getDefaultInstance() {
        return DEFAULT_INSTANCE;
    }

    private void mergeError(Status status) {
        this.result_ = this.resultCase_ == 4 && this.result_ != Status.getDefaultInstance() ? ((Status.Builder)Status.newBuilder((Status)this.result_).mergeFrom((GeneratedMessageLite)status)).buildPartial() : status;
        this.resultCase_ = 4;
    }

    private void mergeMetadata(Any any) {
        Any any2 = this.metadata_;
        if (any2 != null && any2 != Any.getDefaultInstance()) {
            this.metadata_ = (Any)((Any.Builder)Any.newBuilder((Any)this.metadata_).mergeFrom((GeneratedMessageLite)any)).buildPartial();
            return;
        }
        this.metadata_ = any;
    }

    private void mergeResponse(Any any) {
        this.result_ = this.resultCase_ == 5 && this.result_ != Any.getDefaultInstance() ? ((Any.Builder)Any.newBuilder((Any)((Any)this.result_)).mergeFrom((GeneratedMessageLite)any)).buildPartial() : any;
        this.resultCase_ = 5;
    }

    public static Builder newBuilder() {
        return (Builder)DEFAULT_INSTANCE.toBuilder();
    }

    public static Builder newBuilder(Operation operation) {
        return (Builder)((Builder)DEFAULT_INSTANCE.toBuilder()).mergeFrom((GeneratedMessageLite)operation);
    }

    public static Operation parseDelimitedFrom(InputStream inputStream) throws IOException {
        return (Operation)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static Operation parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (Operation)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Operation parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
        return (Operation)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString);
    }

    public static Operation parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (Operation)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Operation parseFrom(CodedInputStream codedInputStream) throws IOException {
        return (Operation)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream);
    }

    public static Operation parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (Operation)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Operation parseFrom(InputStream inputStream) throws IOException {
        return (Operation)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static Operation parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (Operation)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Operation parseFrom(byte[] arrby) throws InvalidProtocolBufferException {
        return (Operation)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby);
    }

    public static Operation parseFrom(byte[] arrby, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (Operation)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Parser<Operation> parser() {
        return DEFAULT_INSTANCE.getParserForType();
    }

    private void setDone(boolean bl) {
        this.done_ = bl;
    }

    private void setError(Status.Builder builder) {
        this.result_ = builder.build();
        this.resultCase_ = 4;
    }

    private void setError(Status status) {
        Objects.requireNonNull((Object)status);
        this.result_ = status;
        this.resultCase_ = 4;
    }

    private void setMetadata(Any.Builder builder) {
        this.metadata_ = (Any)builder.build();
    }

    private void setMetadata(Any any) {
        Objects.requireNonNull((Object)any);
        this.metadata_ = any;
    }

    private void setName(String string2) {
        Objects.requireNonNull((Object)string2);
        this.name_ = string2;
    }

    private void setNameBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.name_ = byteString.toStringUtf8();
    }

    private void setResponse(Any.Builder builder) {
        this.result_ = builder.build();
        this.resultCase_ = 5;
    }

    private void setResponse(Any any) {
        Objects.requireNonNull((Object)any);
        this.result_ = any;
        this.resultCase_ = 5;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke var1_1, Object var2_2, Object var3_3) {
        var4_4 = var1_1.ordinal();
        var5_5 = false;
        switch (var4_4) {
            default: {
                throw new UnsupportedOperationException();
            }
            case 7: {
                if (Operation.PARSER != null) return Operation.PARSER;
                var35_6 = Operation.class;
                // MONITORENTER : com.google.longrunning.Operation.class
                if (Operation.PARSER == null) {
                    Operation.PARSER = new GeneratedMessageLite.DefaultInstanceBasedParser((GeneratedMessageLite)Operation.DEFAULT_INSTANCE);
                }
                // MONITOREXIT : var35_6
                return Operation.PARSER;
            }
            case 2: {
                var18_7 = (CodedInputStream)var2_2;
                var19_8 = (ExtensionRegistryLite)var3_3;
lbl17: // 5 sources:
                do {
                    if (var5_5 != false) return Operation.DEFAULT_INSTANCE;
                    var23_10 = var18_7.readTag();
                    if (var23_10 == 0) ** GOTO lbl38
                    if (var23_10 == 10) ** GOTO lbl36
                    if (var23_10 == 18) ** GOTO lbl34
                    if (var23_10 == 24) ** GOTO lbl32
                    if (var23_10 == 34) ** GOTO lbl31
                    if (var23_10 != 42) {
                        if (var18_7.skipField(var23_10)) continue;
                    } else {
                        var31_16 = this.resultCase_ == 5 ? (Any.Builder)((Any)this.result_).toBuilder() : null;
lbl31: // 1 sources:
                        var28_14 = this.resultCase_ == 4 ? (Status.Builder)((Status)this.result_).toBuilder() : null;
lbl32: // 1 sources:
                        this.done_ = var18_7.readBool();
                        continue;
lbl34: // 1 sources:
                        var24_11 = this.metadata_;
                        var25_12 = var24_11 != null ? (Any.Builder)var24_11.toBuilder() : null;
lbl36: // 1 sources:
                        this.name_ = var18_7.readStringRequireUtf8();
                        continue;
                    }
lbl38: // 2 sources:
                    var5_5 = true;
                    continue;
                    catch (IOException var22_18) {
                        throw new RuntimeException((Throwable)new InvalidProtocolBufferException(var22_18.getMessage()).setUnfinishedMessage((MessageLite)this));
                    }
                    catch (InvalidProtocolBufferException var20_19) {
                        throw new RuntimeException((Throwable)var20_19.setUnfinishedMessage((MessageLite)this));
                    }
                    break;
                } while (true);
            }
            case 6: {
                return Operation.DEFAULT_INSTANCE;
            }
            case 1: {
                var6_20 = (GeneratedMessageLite.Visitor)var2_2;
                var7_21 = (Operation)var3_3;
                this.name_ = var6_20.visitString(true ^ this.name_.isEmpty(), this.name_, true ^ var7_21.name_.isEmpty(), var7_21.name_);
                this.metadata_ = (Any)var6_20.visitMessage((MessageLite)this.metadata_, (MessageLite)var7_21.metadata_);
                var8_22 = this.done_;
                var9_23 = var7_21.done_;
                this.done_ = var6_20.visitBoolean(var8_22, var8_22, var9_23, var9_23);
                var10_24 = var7_21.getResultCase().ordinal();
                if (var10_24 != 0) {
                    if (var10_24 != 1) {
                        if (var10_24 == 2) {
                            var16_25 = this.resultCase_;
                            var17_26 = false;
                            if (var16_25 != 0) {
                                var17_26 = true;
                            }
                            var6_20.visitOneofNotSet(var17_26);
                        }
                    } else {
                        var14_27 = this.resultCase_;
                        var15_28 = false;
                        if (var14_27 == 5) {
                            var15_28 = true;
                        }
                        this.result_ = var6_20.visitOneofMessage(var15_28, this.result_, var7_21.result_);
                    }
                } else {
                    var11_29 = this.resultCase_;
                    var12_30 = false;
                    if (var11_29 == 4) {
                        var12_30 = true;
                    }
                    this.result_ = var6_20.visitOneofMessage(var12_30, this.result_, var7_21.result_);
                }
                if (var6_20 != GeneratedMessageLite.MergeFromVisitor.INSTANCE) return this;
                var13_31 = var7_21.resultCase_;
                if (var13_31 == 0) return this;
                this.resultCase_ = var13_31;
                return this;
            }
            case 5: {
                return new Builder(null);
            }
            case 3: {
                return null;
            }
            case 0: {
                return Operation.DEFAULT_INSTANCE;
            }
            case 4: {
                return new Operation();
            }
        }
        var32_9 = var18_7.readMessage(Any.parser(), var19_8);
        this.result_ = var32_9;
        if (var31_16 != null) {
            var31_16.mergeFrom((GeneratedMessageLite)((Any)var32_9));
            this.result_ = var31_16.buildPartial();
        }
        this.resultCase_ = 5;
        ** GOTO lbl17
        var29_15 = var18_7.readMessage(Status.parser(), var19_8);
        this.result_ = var29_15;
        if (var28_14 != null) {
            var28_14.mergeFrom((GeneratedMessageLite)((Status)var29_15));
            this.result_ = var28_14.buildPartial();
        }
        this.resultCase_ = 4;
        ** GOTO lbl17
        this.metadata_ = var26_13 = (Any)var18_7.readMessage(Any.parser(), var19_8);
        if (var25_12 == null) ** GOTO lbl17
        var25_12.mergeFrom((GeneratedMessageLite)var26_13);
        this.metadata_ = (Any)var25_12.buildPartial();
        ** while (true)
    }

    public boolean getDone() {
        return this.done_;
    }

    public Status getError() {
        if (this.resultCase_ == 4) {
            return (Status)this.result_;
        }
        return Status.getDefaultInstance();
    }

    public Any getMetadata() {
        Any any = this.metadata_;
        if (any == null) {
            any = Any.getDefaultInstance();
        }
        return any;
    }

    public String getName() {
        return this.name_;
    }

    public ByteString getNameBytes() {
        return ByteString.copyFromUtf8((String)this.name_);
    }

    public Any getResponse() {
        if (this.resultCase_ == 5) {
            return (Any)this.result_;
        }
        return Any.getDefaultInstance();
    }

    public ResultCase getResultCase() {
        return ResultCase.forNumber((int)this.resultCase_);
    }

    public int getSerializedSize() {
        boolean bl;
        int n = this.memoizedSerializedSize;
        if (n != -1) {
            return n;
        }
        boolean bl2 = this.name_.isEmpty();
        int n2 = 0;
        if (!bl2) {
            n2 = 0 + CodedOutputStream.computeStringSize((int)1, (String)this.getName());
        }
        if (this.metadata_ != null) {
            n2 += CodedOutputStream.computeMessageSize((int)2, (MessageLite)this.getMetadata());
        }
        if (bl = this.done_) {
            n2 += CodedOutputStream.computeBoolSize((int)3, (boolean)bl);
        }
        if (this.resultCase_ == 4) {
            n2 += CodedOutputStream.computeMessageSize((int)4, (MessageLite)((Status)this.result_));
        }
        if (this.resultCase_ == 5) {
            n2 += CodedOutputStream.computeMessageSize((int)5, (MessageLite)((Any)this.result_));
        }
        this.memoizedSerializedSize = n2;
        return n2;
    }

    public boolean hasMetadata() {
        return this.metadata_ != null;
    }

    public void writeTo(CodedOutputStream codedOutputStream) throws IOException {
        boolean bl;
        if (!this.name_.isEmpty()) {
            codedOutputStream.writeString(1, this.getName());
        }
        if (this.metadata_ != null) {
            codedOutputStream.writeMessage(2, (MessageLite)this.getMetadata());
        }
        if (bl = this.done_) {
            codedOutputStream.writeBool(3, bl);
        }
        if (this.resultCase_ == 4) {
            codedOutputStream.writeMessage(4, (MessageLite)((Status)this.result_));
        }
        if (this.resultCase_ == 5) {
            codedOutputStream.writeMessage(5, (MessageLite)((Any)this.result_));
        }
    }

    public static final class Builder
    extends GeneratedMessageLite.Builder<Operation, Builder>
    implements OperationOrBuilder {
        private Builder() {
            super((GeneratedMessageLite)DEFAULT_INSTANCE);
        }

        public /* synthetic */ Builder(1 var1_1) {
            this();
        }

        public Builder clearDone() {
            this.copyOnWrite();
            ((Operation)this.instance).clearDone();
            return this;
        }

        public Builder clearError() {
            this.copyOnWrite();
            ((Operation)this.instance).clearError();
            return this;
        }

        public Builder clearMetadata() {
            this.copyOnWrite();
            ((Operation)this.instance).clearMetadata();
            return this;
        }

        public Builder clearName() {
            this.copyOnWrite();
            ((Operation)this.instance).clearName();
            return this;
        }

        public Builder clearResponse() {
            this.copyOnWrite();
            ((Operation)this.instance).clearResponse();
            return this;
        }

        public Builder clearResult() {
            this.copyOnWrite();
            ((Operation)this.instance).clearResult();
            return this;
        }

        public boolean getDone() {
            return ((Operation)this.instance).getDone();
        }

        public Status getError() {
            return ((Operation)this.instance).getError();
        }

        public Any getMetadata() {
            return ((Operation)this.instance).getMetadata();
        }

        public String getName() {
            return ((Operation)this.instance).getName();
        }

        public ByteString getNameBytes() {
            return ((Operation)this.instance).getNameBytes();
        }

        public Any getResponse() {
            return ((Operation)this.instance).getResponse();
        }

        public ResultCase getResultCase() {
            return ((Operation)this.instance).getResultCase();
        }

        public boolean hasMetadata() {
            return ((Operation)this.instance).hasMetadata();
        }

        public Builder mergeError(Status status) {
            this.copyOnWrite();
            ((Operation)this.instance).mergeError(status);
            return this;
        }

        public Builder mergeMetadata(Any any) {
            this.copyOnWrite();
            ((Operation)this.instance).mergeMetadata(any);
            return this;
        }

        public Builder mergeResponse(Any any) {
            this.copyOnWrite();
            ((Operation)this.instance).mergeResponse(any);
            return this;
        }

        public Builder setDone(boolean bl) {
            this.copyOnWrite();
            ((Operation)this.instance).setDone(bl);
            return this;
        }

        public Builder setError(Status.Builder builder) {
            this.copyOnWrite();
            ((Operation)this.instance).setError(builder);
            return this;
        }

        public Builder setError(Status status) {
            this.copyOnWrite();
            ((Operation)this.instance).setError(status);
            return this;
        }

        public Builder setMetadata(Any.Builder builder) {
            this.copyOnWrite();
            ((Operation)this.instance).setMetadata(builder);
            return this;
        }

        public Builder setMetadata(Any any) {
            this.copyOnWrite();
            ((Operation)this.instance).setMetadata(any);
            return this;
        }

        public Builder setName(String string2) {
            this.copyOnWrite();
            ((Operation)this.instance).setName(string2);
            return this;
        }

        public Builder setNameBytes(ByteString byteString) {
            this.copyOnWrite();
            ((Operation)this.instance).setNameBytes(byteString);
            return this;
        }

        public Builder setResponse(Any.Builder builder) {
            this.copyOnWrite();
            ((Operation)this.instance).setResponse(builder);
            return this;
        }

        public Builder setResponse(Any any) {
            this.copyOnWrite();
            ((Operation)this.instance).setResponse(any);
            return this;
        }
    }

}

