/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.longrunning.ListOperationsRequest$1
 *  com.google.longrunning.ListOperationsRequestOrBuilder
 *  com.google.protobuf.AbstractMessageLite
 *  com.google.protobuf.ByteString
 *  com.google.protobuf.CodedInputStream
 *  com.google.protobuf.CodedOutputStream
 *  com.google.protobuf.ExtensionRegistryLite
 *  com.google.protobuf.GeneratedMessageLite
 *  com.google.protobuf.GeneratedMessageLite$Builder
 *  com.google.protobuf.GeneratedMessageLite$DefaultInstanceBasedParser
 *  com.google.protobuf.GeneratedMessageLite$MethodToInvoke
 *  com.google.protobuf.GeneratedMessageLite$Visitor
 *  com.google.protobuf.InvalidProtocolBufferException
 *  com.google.protobuf.MessageLite
 *  com.google.protobuf.Parser
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 *  java.util.Objects
 */
package com.google.longrunning;

import com.google.longrunning.ListOperationsRequest;
import com.google.longrunning.ListOperationsRequestOrBuilder;
import com.google.protobuf.AbstractMessageLite;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.CodedOutputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.MessageLite;
import com.google.protobuf.Parser;
import java.io.IOException;
import java.io.InputStream;
import java.util.Objects;

public final class ListOperationsRequest
extends GeneratedMessageLite<ListOperationsRequest, Builder>
implements ListOperationsRequestOrBuilder {
    private static final ListOperationsRequest DEFAULT_INSTANCE;
    public static final int FILTER_FIELD_NUMBER = 1;
    public static final int NAME_FIELD_NUMBER = 4;
    public static final int PAGE_SIZE_FIELD_NUMBER = 2;
    public static final int PAGE_TOKEN_FIELD_NUMBER = 3;
    private static volatile Parser<ListOperationsRequest> PARSER;
    private String filter_ = "";
    private String name_ = "";
    private int pageSize_;
    private String pageToken_ = "";

    public static {
        ListOperationsRequest listOperationsRequest;
        DEFAULT_INSTANCE = listOperationsRequest = new ListOperationsRequest();
        listOperationsRequest.makeImmutable();
    }

    private ListOperationsRequest() {
    }

    private void clearFilter() {
        this.filter_ = ListOperationsRequest.getDefaultInstance().getFilter();
    }

    private void clearName() {
        this.name_ = ListOperationsRequest.getDefaultInstance().getName();
    }

    private void clearPageSize() {
        this.pageSize_ = 0;
    }

    private void clearPageToken() {
        this.pageToken_ = ListOperationsRequest.getDefaultInstance().getPageToken();
    }

    public static ListOperationsRequest getDefaultInstance() {
        return DEFAULT_INSTANCE;
    }

    public static Builder newBuilder() {
        return (Builder)DEFAULT_INSTANCE.toBuilder();
    }

    public static Builder newBuilder(ListOperationsRequest listOperationsRequest) {
        return (Builder)((Builder)DEFAULT_INSTANCE.toBuilder()).mergeFrom((GeneratedMessageLite)listOperationsRequest);
    }

    public static ListOperationsRequest parseDelimitedFrom(InputStream inputStream) throws IOException {
        return (ListOperationsRequest)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static ListOperationsRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (ListOperationsRequest)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static ListOperationsRequest parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
        return (ListOperationsRequest)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString);
    }

    public static ListOperationsRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (ListOperationsRequest)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static ListOperationsRequest parseFrom(CodedInputStream codedInputStream) throws IOException {
        return (ListOperationsRequest)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream);
    }

    public static ListOperationsRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (ListOperationsRequest)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static ListOperationsRequest parseFrom(InputStream inputStream) throws IOException {
        return (ListOperationsRequest)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static ListOperationsRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (ListOperationsRequest)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static ListOperationsRequest parseFrom(byte[] arrby) throws InvalidProtocolBufferException {
        return (ListOperationsRequest)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby);
    }

    public static ListOperationsRequest parseFrom(byte[] arrby, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (ListOperationsRequest)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Parser<ListOperationsRequest> parser() {
        return DEFAULT_INSTANCE.getParserForType();
    }

    private void setFilter(String string2) {
        Objects.requireNonNull((Object)string2);
        this.filter_ = string2;
    }

    private void setFilterBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.filter_ = byteString.toStringUtf8();
    }

    private void setName(String string2) {
        Objects.requireNonNull((Object)string2);
        this.name_ = string2;
    }

    private void setNameBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.name_ = byteString.toStringUtf8();
    }

    private void setPageSize(int n) {
        this.pageSize_ = n;
    }

    private void setPageToken(String string2) {
        Objects.requireNonNull((Object)string2);
        this.pageToken_ = string2;
    }

    private void setPageTokenBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.pageToken_ = byteString.toStringUtf8();
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke var1_1, Object var2_2, Object var3_3) {
        var4_4 = var1_1.ordinal();
        var5_5 = false;
        switch (var4_4) {
            default: {
                throw new UnsupportedOperationException();
            }
            case 7: {
                if (ListOperationsRequest.PARSER != null) return ListOperationsRequest.PARSER;
                var20_6 = ListOperationsRequest.class;
                // MONITORENTER : com.google.longrunning.ListOperationsRequest.class
                if (ListOperationsRequest.PARSER == null) {
                    ListOperationsRequest.PARSER = new GeneratedMessageLite.DefaultInstanceBasedParser((GeneratedMessageLite)ListOperationsRequest.DEFAULT_INSTANCE);
                }
                // MONITOREXIT : var20_6
                return ListOperationsRequest.PARSER;
            }
            case 2: {
                var13_7 = (CodedInputStream)var2_2;
                (ExtensionRegistryLite)var3_3;
                while (var5_5 == false) {
                    var18_8 = var13_7.readTag();
                    if (var18_8 == 0) ** GOTO lbl36
                    if (var18_8 == 10) ** GOTO lbl34
                    if (var18_8 == 16) ** GOTO lbl32
                    if (var18_8 == 26) ** GOTO lbl30
                    if (var18_8 != 34) {
                        if (var13_7.skipField(var18_8)) continue;
                    } else {
                        this.name_ = var13_7.readStringRequireUtf8();
                        continue;
lbl30: // 1 sources:
                        this.pageToken_ = var13_7.readStringRequireUtf8();
                        continue;
lbl32: // 1 sources:
                        this.pageSize_ = var13_7.readInt32();
                        continue;
lbl34: // 1 sources:
                        this.filter_ = var13_7.readStringRequireUtf8();
                        continue;
                    }
lbl36: // 2 sources:
                    var5_5 = true;
                    continue;
                    catch (IOException var17_10) {
                        throw new RuntimeException((Throwable)new InvalidProtocolBufferException(var17_10.getMessage()).setUnfinishedMessage((MessageLite)this));
                    }
                    catch (InvalidProtocolBufferException var15_11) {
                        throw new RuntimeException((Throwable)var15_11.setUnfinishedMessage((MessageLite)this));
                    }
                }
                return ListOperationsRequest.DEFAULT_INSTANCE;
            }
            case 6: {
                return ListOperationsRequest.DEFAULT_INSTANCE;
            }
            case 1: {
                var6_12 = (GeneratedMessageLite.Visitor)var2_2;
                var7_13 = (ListOperationsRequest)var3_3;
                this.name_ = var6_12.visitString(true ^ this.name_.isEmpty(), this.name_, true ^ var7_13.name_.isEmpty(), var7_13.name_);
                this.filter_ = var6_12.visitString(true ^ this.filter_.isEmpty(), this.filter_, true ^ var7_13.filter_.isEmpty(), var7_13.filter_);
                var8_14 = this.pageSize_;
                var9_15 = var8_14 != 0;
                var10_16 = var7_13.pageSize_;
                var11_17 = false;
                if (var10_16 != 0) {
                    var11_17 = true;
                }
                this.pageSize_ = var6_12.visitInt(var9_15, var8_14, var11_17, var10_16);
                this.pageToken_ = var6_12.visitString(true ^ this.pageToken_.isEmpty(), this.pageToken_, true ^ var7_13.pageToken_.isEmpty(), var7_13.pageToken_);
                return this;
            }
            case 5: {
                return new Builder(null);
            }
            case 3: {
                return null;
            }
            case 0: {
                return ListOperationsRequest.DEFAULT_INSTANCE;
            }
            case 4: 
        }
        return new ListOperationsRequest();
    }

    public String getFilter() {
        return this.filter_;
    }

    public ByteString getFilterBytes() {
        return ByteString.copyFromUtf8((String)this.filter_);
    }

    public String getName() {
        return this.name_;
    }

    public ByteString getNameBytes() {
        return ByteString.copyFromUtf8((String)this.name_);
    }

    public int getPageSize() {
        return this.pageSize_;
    }

    public String getPageToken() {
        return this.pageToken_;
    }

    public ByteString getPageTokenBytes() {
        return ByteString.copyFromUtf8((String)this.pageToken_);
    }

    public int getSerializedSize() {
        int n;
        int n2 = this.memoizedSerializedSize;
        if (n2 != -1) {
            return n2;
        }
        boolean bl = this.filter_.isEmpty();
        int n3 = 0;
        if (!bl) {
            n3 = 0 + CodedOutputStream.computeStringSize((int)1, (String)this.getFilter());
        }
        if ((n = this.pageSize_) != 0) {
            n3 += CodedOutputStream.computeInt32Size((int)2, (int)n);
        }
        if (!this.pageToken_.isEmpty()) {
            n3 += CodedOutputStream.computeStringSize((int)3, (String)this.getPageToken());
        }
        if (!this.name_.isEmpty()) {
            n3 += CodedOutputStream.computeStringSize((int)4, (String)this.getName());
        }
        this.memoizedSerializedSize = n3;
        return n3;
    }

    public void writeTo(CodedOutputStream codedOutputStream) throws IOException {
        int n;
        if (!this.filter_.isEmpty()) {
            codedOutputStream.writeString(1, this.getFilter());
        }
        if ((n = this.pageSize_) != 0) {
            codedOutputStream.writeInt32(2, n);
        }
        if (!this.pageToken_.isEmpty()) {
            codedOutputStream.writeString(3, this.getPageToken());
        }
        if (!this.name_.isEmpty()) {
            codedOutputStream.writeString(4, this.getName());
        }
    }

    public static final class Builder
    extends GeneratedMessageLite.Builder<ListOperationsRequest, Builder>
    implements ListOperationsRequestOrBuilder {
        private Builder() {
            super((GeneratedMessageLite)DEFAULT_INSTANCE);
        }

        public /* synthetic */ Builder(1 var1_1) {
            this();
        }

        public Builder clearFilter() {
            this.copyOnWrite();
            ((ListOperationsRequest)this.instance).clearFilter();
            return this;
        }

        public Builder clearName() {
            this.copyOnWrite();
            ((ListOperationsRequest)this.instance).clearName();
            return this;
        }

        public Builder clearPageSize() {
            this.copyOnWrite();
            ((ListOperationsRequest)this.instance).clearPageSize();
            return this;
        }

        public Builder clearPageToken() {
            this.copyOnWrite();
            ((ListOperationsRequest)this.instance).clearPageToken();
            return this;
        }

        public String getFilter() {
            return ((ListOperationsRequest)this.instance).getFilter();
        }

        public ByteString getFilterBytes() {
            return ((ListOperationsRequest)this.instance).getFilterBytes();
        }

        public String getName() {
            return ((ListOperationsRequest)this.instance).getName();
        }

        public ByteString getNameBytes() {
            return ((ListOperationsRequest)this.instance).getNameBytes();
        }

        public int getPageSize() {
            return ((ListOperationsRequest)this.instance).getPageSize();
        }

        public String getPageToken() {
            return ((ListOperationsRequest)this.instance).getPageToken();
        }

        public ByteString getPageTokenBytes() {
            return ((ListOperationsRequest)this.instance).getPageTokenBytes();
        }

        public Builder setFilter(String string2) {
            this.copyOnWrite();
            ((ListOperationsRequest)this.instance).setFilter(string2);
            return this;
        }

        public Builder setFilterBytes(ByteString byteString) {
            this.copyOnWrite();
            ((ListOperationsRequest)this.instance).setFilterBytes(byteString);
            return this;
        }

        public Builder setName(String string2) {
            this.copyOnWrite();
            ((ListOperationsRequest)this.instance).setName(string2);
            return this;
        }

        public Builder setNameBytes(ByteString byteString) {
            this.copyOnWrite();
            ((ListOperationsRequest)this.instance).setNameBytes(byteString);
            return this;
        }

        public Builder setPageSize(int n) {
            this.copyOnWrite();
            ((ListOperationsRequest)this.instance).setPageSize(n);
            return this;
        }

        public Builder setPageToken(String string2) {
            this.copyOnWrite();
            ((ListOperationsRequest)this.instance).setPageToken(string2);
            return this;
        }

        public Builder setPageTokenBytes(ByteString byteString) {
            this.copyOnWrite();
            ((ListOperationsRequest)this.instance).setPageTokenBytes(byteString);
            return this;
        }
    }

}

