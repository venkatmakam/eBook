/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.longrunning.ListOperationsResponse$1
 *  com.google.longrunning.ListOperationsResponseOrBuilder
 *  com.google.longrunning.OperationOrBuilder
 *  com.google.protobuf.AbstractMessageLite
 *  com.google.protobuf.ByteString
 *  com.google.protobuf.CodedInputStream
 *  com.google.protobuf.CodedOutputStream
 *  com.google.protobuf.ExtensionRegistryLite
 *  com.google.protobuf.GeneratedMessageLite
 *  com.google.protobuf.GeneratedMessageLite$Builder
 *  com.google.protobuf.GeneratedMessageLite$DefaultInstanceBasedParser
 *  com.google.protobuf.GeneratedMessageLite$MergeFromVisitor
 *  com.google.protobuf.GeneratedMessageLite$MethodToInvoke
 *  com.google.protobuf.GeneratedMessageLite$Visitor
 *  com.google.protobuf.Internal
 *  com.google.protobuf.Internal$ProtobufList
 *  com.google.protobuf.InvalidProtocolBufferException
 *  com.google.protobuf.MessageLite
 *  com.google.protobuf.Parser
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Class
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 *  java.util.Collections
 *  java.util.List
 *  java.util.Objects
 */
package com.google.longrunning;

import com.google.longrunning.ListOperationsResponse;
import com.google.longrunning.ListOperationsResponseOrBuilder;
import com.google.longrunning.Operation;
import com.google.longrunning.OperationOrBuilder;
import com.google.protobuf.AbstractMessageLite;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.CodedOutputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.Internal;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.MessageLite;
import com.google.protobuf.Parser;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

public final class ListOperationsResponse
extends GeneratedMessageLite<ListOperationsResponse, Builder>
implements ListOperationsResponseOrBuilder {
    private static final ListOperationsResponse DEFAULT_INSTANCE;
    public static final int NEXT_PAGE_TOKEN_FIELD_NUMBER = 2;
    public static final int OPERATIONS_FIELD_NUMBER = 1;
    private static volatile Parser<ListOperationsResponse> PARSER;
    private int bitField0_;
    private String nextPageToken_ = "";
    private Internal.ProtobufList<Operation> operations_ = GeneratedMessageLite.emptyProtobufList();

    public static {
        ListOperationsResponse listOperationsResponse;
        DEFAULT_INSTANCE = listOperationsResponse = new ListOperationsResponse();
        listOperationsResponse.makeImmutable();
    }

    private ListOperationsResponse() {
    }

    private void addAllOperations(Iterable<? extends Operation> iterable) {
        this.ensureOperationsIsMutable();
        AbstractMessageLite.addAll(iterable, this.operations_);
    }

    private void addOperations(int n, Operation.Builder builder) {
        this.ensureOperationsIsMutable();
        this.operations_.add(n, (Object)((Operation)builder.build()));
    }

    private void addOperations(int n, Operation operation) {
        Objects.requireNonNull((Object)((Object)operation));
        this.ensureOperationsIsMutable();
        this.operations_.add(n, (Object)operation);
    }

    private void addOperations(Operation.Builder builder) {
        this.ensureOperationsIsMutable();
        this.operations_.add((Object)((Operation)builder.build()));
    }

    private void addOperations(Operation operation) {
        Objects.requireNonNull((Object)((Object)operation));
        this.ensureOperationsIsMutable();
        this.operations_.add((Object)operation);
    }

    private void clearNextPageToken() {
        this.nextPageToken_ = ListOperationsResponse.getDefaultInstance().getNextPageToken();
    }

    private void clearOperations() {
        this.operations_ = GeneratedMessageLite.emptyProtobufList();
    }

    private void ensureOperationsIsMutable() {
        if (!this.operations_.isModifiable()) {
            this.operations_ = GeneratedMessageLite.mutableCopy(this.operations_);
        }
    }

    public static ListOperationsResponse getDefaultInstance() {
        return DEFAULT_INSTANCE;
    }

    public static Builder newBuilder() {
        return (Builder)DEFAULT_INSTANCE.toBuilder();
    }

    public static Builder newBuilder(ListOperationsResponse listOperationsResponse) {
        return (Builder)((Builder)DEFAULT_INSTANCE.toBuilder()).mergeFrom((GeneratedMessageLite)listOperationsResponse);
    }

    public static ListOperationsResponse parseDelimitedFrom(InputStream inputStream) throws IOException {
        return (ListOperationsResponse)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static ListOperationsResponse parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (ListOperationsResponse)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static ListOperationsResponse parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
        return (ListOperationsResponse)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString);
    }

    public static ListOperationsResponse parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (ListOperationsResponse)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static ListOperationsResponse parseFrom(CodedInputStream codedInputStream) throws IOException {
        return (ListOperationsResponse)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream);
    }

    public static ListOperationsResponse parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (ListOperationsResponse)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static ListOperationsResponse parseFrom(InputStream inputStream) throws IOException {
        return (ListOperationsResponse)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static ListOperationsResponse parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (ListOperationsResponse)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static ListOperationsResponse parseFrom(byte[] arrby) throws InvalidProtocolBufferException {
        return (ListOperationsResponse)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby);
    }

    public static ListOperationsResponse parseFrom(byte[] arrby, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (ListOperationsResponse)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Parser<ListOperationsResponse> parser() {
        return DEFAULT_INSTANCE.getParserForType();
    }

    private void removeOperations(int n) {
        this.ensureOperationsIsMutable();
        this.operations_.remove(n);
    }

    private void setNextPageToken(String string2) {
        Objects.requireNonNull((Object)string2);
        this.nextPageToken_ = string2;
    }

    private void setNextPageTokenBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.nextPageToken_ = byteString.toStringUtf8();
    }

    private void setOperations(int n, Operation.Builder builder) {
        this.ensureOperationsIsMutable();
        this.operations_.set(n, (Object)((Operation)builder.build()));
    }

    private void setOperations(int n, Operation operation) {
        Objects.requireNonNull((Object)((Object)operation));
        this.ensureOperationsIsMutable();
        this.operations_.set(n, (Object)operation);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke var1_1, Object var2_2, Object var3_3) {
        switch (var1_1.ordinal()) {
            default: {
                throw new UnsupportedOperationException();
            }
            case 7: {
                if (ListOperationsResponse.PARSER != null) return ListOperationsResponse.PARSER;
                var15_4 = ListOperationsResponse.class;
                // MONITORENTER : com.google.longrunning.ListOperationsResponse.class
                if (ListOperationsResponse.PARSER == null) {
                    ListOperationsResponse.PARSER = new GeneratedMessageLite.DefaultInstanceBasedParser((GeneratedMessageLite)ListOperationsResponse.DEFAULT_INSTANCE);
                }
                // MONITOREXIT : var15_4
                return ListOperationsResponse.PARSER;
            }
            case 2: {
                var6_5 = (CodedInputStream)var2_2;
                var7_6 = (ExtensionRegistryLite)var3_3;
                var8_7 = false;
                while (var8_7 == false) {
                    var12_8 = var6_5.readTag();
                    if (var12_8 == 0) ** GOTO lbl31
                    if (var12_8 == 10) ** GOTO lbl27
                    if (var12_8 != 18) {
                        if (var6_5.skipField(var12_8)) continue;
                    } else {
                        this.nextPageToken_ = var6_5.readStringRequireUtf8();
                        continue;
lbl27: // 1 sources:
                        if (!this.operations_.isModifiable()) {
                            this.operations_ = GeneratedMessageLite.mutableCopy(this.operations_);
                        }
                        this.operations_.add((Object)((Operation)var6_5.readMessage(Operation.parser(), var7_6)));
                        continue;
                    }
lbl31: // 2 sources:
                    var8_7 = true;
                    continue;
                    catch (IOException var11_10) {
                        throw new RuntimeException((Throwable)new InvalidProtocolBufferException(var11_10.getMessage()).setUnfinishedMessage((MessageLite)this));
                    }
                    catch (InvalidProtocolBufferException var9_11) {
                        throw new RuntimeException((Throwable)var9_11.setUnfinishedMessage((MessageLite)this));
                    }
                }
                return ListOperationsResponse.DEFAULT_INSTANCE;
            }
            case 6: {
                return ListOperationsResponse.DEFAULT_INSTANCE;
            }
            case 1: {
                var4_12 = (GeneratedMessageLite.Visitor)var2_2;
                var5_13 = (ListOperationsResponse)var3_3;
                this.operations_ = var4_12.visitList(this.operations_, var5_13.operations_);
                this.nextPageToken_ = var4_12.visitString(true ^ this.nextPageToken_.isEmpty(), this.nextPageToken_, true ^ var5_13.nextPageToken_.isEmpty(), var5_13.nextPageToken_);
                if (var4_12 != GeneratedMessageLite.MergeFromVisitor.INSTANCE) return this;
                this.bitField0_ |= var5_13.bitField0_;
                return this;
            }
            case 5: {
                return new Builder(null);
            }
            case 3: {
                this.operations_.makeImmutable();
                return null;
            }
            case 0: {
                return ListOperationsResponse.DEFAULT_INSTANCE;
            }
            case 4: 
        }
        return new ListOperationsResponse();
    }

    public String getNextPageToken() {
        return this.nextPageToken_;
    }

    public ByteString getNextPageTokenBytes() {
        return ByteString.copyFromUtf8((String)this.nextPageToken_);
    }

    public Operation getOperations(int n) {
        return (Operation)((Object)this.operations_.get(n));
    }

    public int getOperationsCount() {
        return this.operations_.size();
    }

    public List<Operation> getOperationsList() {
        return this.operations_;
    }

    public OperationOrBuilder getOperationsOrBuilder(int n) {
        return (OperationOrBuilder)this.operations_.get(n);
    }

    public List<? extends OperationOrBuilder> getOperationsOrBuilderList() {
        return this.operations_;
    }

    public int getSerializedSize() {
        int n = this.memoizedSerializedSize;
        if (n != -1) {
            return n;
        }
        int n2 = 0;
        for (int i = 0; i < this.operations_.size(); ++i) {
            n2 += CodedOutputStream.computeMessageSize((int)1, (MessageLite)((MessageLite)this.operations_.get(i)));
        }
        if (!this.nextPageToken_.isEmpty()) {
            n2 += CodedOutputStream.computeStringSize((int)2, (String)this.getNextPageToken());
        }
        this.memoizedSerializedSize = n2;
        return n2;
    }

    public void writeTo(CodedOutputStream codedOutputStream) throws IOException {
        for (int i = 0; i < this.operations_.size(); ++i) {
            codedOutputStream.writeMessage(1, (MessageLite)this.operations_.get(i));
        }
        if (!this.nextPageToken_.isEmpty()) {
            codedOutputStream.writeString(2, this.getNextPageToken());
        }
    }

    public static final class Builder
    extends GeneratedMessageLite.Builder<ListOperationsResponse, Builder>
    implements ListOperationsResponseOrBuilder {
        private Builder() {
            super((GeneratedMessageLite)DEFAULT_INSTANCE);
        }

        public /* synthetic */ Builder(1 var1_1) {
            this();
        }

        public Builder addAllOperations(Iterable<? extends Operation> iterable) {
            this.copyOnWrite();
            ((ListOperationsResponse)this.instance).addAllOperations((Iterable<? extends Operation>)iterable);
            return this;
        }

        public Builder addOperations(int n, Operation.Builder builder) {
            this.copyOnWrite();
            ((ListOperationsResponse)this.instance).addOperations(n, builder);
            return this;
        }

        public Builder addOperations(int n, Operation operation) {
            this.copyOnWrite();
            ((ListOperationsResponse)this.instance).addOperations(n, operation);
            return this;
        }

        public Builder addOperations(Operation.Builder builder) {
            this.copyOnWrite();
            ((ListOperationsResponse)this.instance).addOperations(builder);
            return this;
        }

        public Builder addOperations(Operation operation) {
            this.copyOnWrite();
            ((ListOperationsResponse)this.instance).addOperations(operation);
            return this;
        }

        public Builder clearNextPageToken() {
            this.copyOnWrite();
            ((ListOperationsResponse)this.instance).clearNextPageToken();
            return this;
        }

        public Builder clearOperations() {
            this.copyOnWrite();
            ((ListOperationsResponse)this.instance).clearOperations();
            return this;
        }

        public String getNextPageToken() {
            return ((ListOperationsResponse)this.instance).getNextPageToken();
        }

        public ByteString getNextPageTokenBytes() {
            return ((ListOperationsResponse)this.instance).getNextPageTokenBytes();
        }

        public Operation getOperations(int n) {
            return ((ListOperationsResponse)this.instance).getOperations(n);
        }

        public int getOperationsCount() {
            return ((ListOperationsResponse)this.instance).getOperationsCount();
        }

        public List<Operation> getOperationsList() {
            return Collections.unmodifiableList(((ListOperationsResponse)this.instance).getOperationsList());
        }

        public Builder removeOperations(int n) {
            this.copyOnWrite();
            ((ListOperationsResponse)this.instance).removeOperations(n);
            return this;
        }

        public Builder setNextPageToken(String string2) {
            this.copyOnWrite();
            ((ListOperationsResponse)this.instance).setNextPageToken(string2);
            return this;
        }

        public Builder setNextPageTokenBytes(ByteString byteString) {
            this.copyOnWrite();
            ((ListOperationsResponse)this.instance).setNextPageTokenBytes(byteString);
            return this;
        }

        public Builder setOperations(int n, Operation.Builder builder) {
            this.copyOnWrite();
            ((ListOperationsResponse)this.instance).setOperations(n, builder);
            return this;
        }

        public Builder setOperations(int n, Operation operation) {
            this.copyOnWrite();
            ((ListOperationsResponse)this.instance).setOperations(n, operation);
            return this;
        }
    }

}

