/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.protobuf.ByteString
 *  com.google.protobuf.CodedInputStream
 *  com.google.protobuf.CodedOutputStream
 *  com.google.protobuf.ExtensionRegistryLite
 *  com.google.protobuf.GeneratedMessageLite
 *  com.google.protobuf.GeneratedMessageLite$Builder
 *  com.google.protobuf.GeneratedMessageLite$DefaultInstanceBasedParser
 *  com.google.protobuf.GeneratedMessageLite$MethodToInvoke
 *  com.google.protobuf.GeneratedMessageLite$Visitor
 *  com.google.protobuf.InvalidProtocolBufferException
 *  com.google.protobuf.MessageLite
 *  com.google.protobuf.Parser
 *  com.google.type.TimeOfDay$1
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 */
package com.google.type;

import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.CodedOutputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.MessageLite;
import com.google.protobuf.Parser;
import com.google.type.TimeOfDay;
import com.google.type.TimeOfDayOrBuilder;
import java.io.IOException;
import java.io.InputStream;

public final class TimeOfDay
extends GeneratedMessageLite<TimeOfDay, Builder>
implements TimeOfDayOrBuilder {
    private static final TimeOfDay DEFAULT_INSTANCE;
    public static final int HOURS_FIELD_NUMBER = 1;
    public static final int MINUTES_FIELD_NUMBER = 2;
    public static final int NANOS_FIELD_NUMBER = 4;
    private static volatile Parser<TimeOfDay> PARSER;
    public static final int SECONDS_FIELD_NUMBER = 3;
    private int hours_;
    private int minutes_;
    private int nanos_;
    private int seconds_;

    public static {
        TimeOfDay timeOfDay;
        DEFAULT_INSTANCE = timeOfDay = new TimeOfDay();
        timeOfDay.makeImmutable();
    }

    private TimeOfDay() {
    }

    private void clearHours() {
        this.hours_ = 0;
    }

    private void clearMinutes() {
        this.minutes_ = 0;
    }

    private void clearNanos() {
        this.nanos_ = 0;
    }

    private void clearSeconds() {
        this.seconds_ = 0;
    }

    public static TimeOfDay getDefaultInstance() {
        return DEFAULT_INSTANCE;
    }

    public static Builder newBuilder() {
        return (Builder)DEFAULT_INSTANCE.toBuilder();
    }

    public static Builder newBuilder(TimeOfDay timeOfDay) {
        return (Builder)((Builder)DEFAULT_INSTANCE.toBuilder()).mergeFrom((GeneratedMessageLite)timeOfDay);
    }

    public static TimeOfDay parseDelimitedFrom(InputStream inputStream) throws IOException {
        return (TimeOfDay)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static TimeOfDay parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (TimeOfDay)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static TimeOfDay parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
        return (TimeOfDay)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString);
    }

    public static TimeOfDay parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (TimeOfDay)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static TimeOfDay parseFrom(CodedInputStream codedInputStream) throws IOException {
        return (TimeOfDay)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream);
    }

    public static TimeOfDay parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (TimeOfDay)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static TimeOfDay parseFrom(InputStream inputStream) throws IOException {
        return (TimeOfDay)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static TimeOfDay parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (TimeOfDay)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static TimeOfDay parseFrom(byte[] arrby) throws InvalidProtocolBufferException {
        return (TimeOfDay)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby);
    }

    public static TimeOfDay parseFrom(byte[] arrby, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (TimeOfDay)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Parser<TimeOfDay> parser() {
        return DEFAULT_INSTANCE.getParserForType();
    }

    private void setHours(int n) {
        this.hours_ = n;
    }

    private void setMinutes(int n) {
        this.minutes_ = n;
    }

    private void setNanos(int n) {
        this.nanos_ = n;
    }

    private void setSeconds(int n) {
        this.seconds_ = n;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke var1_1, Object var2_2, Object var3_3) {
        var4_4 = var1_1.ordinal();
        var5_5 = false;
        switch (var4_4) {
            default: {
                throw new UnsupportedOperationException();
            }
            case 7: {
                if (TimeOfDay.PARSER != null) return TimeOfDay.PARSER;
                var32_6 = TimeOfDay.class;
                // MONITORENTER : com.google.type.TimeOfDay.class
                if (TimeOfDay.PARSER == null) {
                    TimeOfDay.PARSER = new GeneratedMessageLite.DefaultInstanceBasedParser((GeneratedMessageLite)TimeOfDay.DEFAULT_INSTANCE);
                }
                // MONITOREXIT : var32_6
                return TimeOfDay.PARSER;
            }
            case 2: {
                var25_7 = (CodedInputStream)var2_2;
                (ExtensionRegistryLite)var3_3;
                while (var5_5 == false) {
                    var30_8 = var25_7.readTag();
                    if (var30_8 == 0) ** GOTO lbl36
                    if (var30_8 == 8) ** GOTO lbl34
                    if (var30_8 == 16) ** GOTO lbl32
                    if (var30_8 == 24) ** GOTO lbl30
                    if (var30_8 != 32) {
                        if (var25_7.skipField(var30_8)) continue;
                    } else {
                        this.nanos_ = var25_7.readInt32();
                        continue;
lbl30: // 1 sources:
                        this.seconds_ = var25_7.readInt32();
                        continue;
lbl32: // 1 sources:
                        this.minutes_ = var25_7.readInt32();
                        continue;
lbl34: // 1 sources:
                        this.hours_ = var25_7.readInt32();
                        continue;
                    }
lbl36: // 2 sources:
                    var5_5 = true;
                    continue;
                    catch (IOException var29_10) {
                        throw new RuntimeException((Throwable)new InvalidProtocolBufferException(var29_10.getMessage()).setUnfinishedMessage((MessageLite)this));
                    }
                    catch (InvalidProtocolBufferException var27_11) {
                        throw new RuntimeException((Throwable)var27_11.setUnfinishedMessage((MessageLite)this));
                    }
                }
                return TimeOfDay.DEFAULT_INSTANCE;
            }
            case 6: {
                return TimeOfDay.DEFAULT_INSTANCE;
            }
            case 1: {
                var6_12 = (GeneratedMessageLite.Visitor)var2_2;
                var7_13 = (TimeOfDay)var3_3;
                var8_14 = this.hours_;
                var9_15 = var8_14 != 0;
                var10_16 = var7_13.hours_;
                var11_17 = var10_16 != 0;
                this.hours_ = var6_12.visitInt(var9_15, var8_14, var11_17, var10_16);
                var12_18 = this.minutes_;
                var13_19 = var12_18 != 0;
                var14_20 = var7_13.minutes_;
                var15_21 = var14_20 != 0;
                this.minutes_ = var6_12.visitInt(var13_19, var12_18, var15_21, var14_20);
                var16_22 = this.seconds_;
                var17_23 = var16_22 != 0;
                var18_24 = var7_13.seconds_;
                var19_25 = var18_24 != 0;
                this.seconds_ = var6_12.visitInt(var17_23, var16_22, var19_25, var18_24);
                var20_26 = this.nanos_;
                var21_27 = var20_26 != 0;
                var22_28 = var7_13.nanos_;
                var23_29 = false;
                if (var22_28 != 0) {
                    var23_29 = true;
                }
                this.nanos_ = var6_12.visitInt(var21_27, var20_26, var23_29, var22_28);
                return this;
            }
            case 5: {
                return new Builder(null);
            }
            case 3: {
                return null;
            }
            case 0: {
                return TimeOfDay.DEFAULT_INSTANCE;
            }
            case 4: 
        }
        return new TimeOfDay();
    }

    @Override
    public int getHours() {
        return this.hours_;
    }

    @Override
    public int getMinutes() {
        return this.minutes_;
    }

    @Override
    public int getNanos() {
        return this.nanos_;
    }

    @Override
    public int getSeconds() {
        return this.seconds_;
    }

    public int getSerializedSize() {
        int n;
        int n2;
        int n3;
        int n4 = this.memoizedSerializedSize;
        if (n4 != -1) {
            return n4;
        }
        int n5 = this.hours_;
        int n6 = 0;
        if (n5 != 0) {
            n6 = 0 + CodedOutputStream.computeInt32Size((int)1, (int)n5);
        }
        if ((n2 = this.minutes_) != 0) {
            n6 += CodedOutputStream.computeInt32Size((int)2, (int)n2);
        }
        if ((n = this.seconds_) != 0) {
            n6 += CodedOutputStream.computeInt32Size((int)3, (int)n);
        }
        if ((n3 = this.nanos_) != 0) {
            n6 += CodedOutputStream.computeInt32Size((int)4, (int)n3);
        }
        this.memoizedSerializedSize = n6;
        return n6;
    }

    public void writeTo(CodedOutputStream codedOutputStream) throws IOException {
        int n;
        int n2;
        int n3;
        int n4 = this.hours_;
        if (n4 != 0) {
            codedOutputStream.writeInt32(1, n4);
        }
        if ((n = this.minutes_) != 0) {
            codedOutputStream.writeInt32(2, n);
        }
        if ((n3 = this.seconds_) != 0) {
            codedOutputStream.writeInt32(3, n3);
        }
        if ((n2 = this.nanos_) != 0) {
            codedOutputStream.writeInt32(4, n2);
        }
    }

    public static final class Builder
    extends GeneratedMessageLite.Builder<TimeOfDay, Builder>
    implements TimeOfDayOrBuilder {
        private Builder() {
            super((GeneratedMessageLite)DEFAULT_INSTANCE);
        }

        public /* synthetic */ Builder(1 var1_1) {
            this();
        }

        public Builder clearHours() {
            this.copyOnWrite();
            ((TimeOfDay)this.instance).clearHours();
            return this;
        }

        public Builder clearMinutes() {
            this.copyOnWrite();
            ((TimeOfDay)this.instance).clearMinutes();
            return this;
        }

        public Builder clearNanos() {
            this.copyOnWrite();
            ((TimeOfDay)this.instance).clearNanos();
            return this;
        }

        public Builder clearSeconds() {
            this.copyOnWrite();
            ((TimeOfDay)this.instance).clearSeconds();
            return this;
        }

        @Override
        public int getHours() {
            return ((TimeOfDay)this.instance).getHours();
        }

        @Override
        public int getMinutes() {
            return ((TimeOfDay)this.instance).getMinutes();
        }

        @Override
        public int getNanos() {
            return ((TimeOfDay)this.instance).getNanos();
        }

        @Override
        public int getSeconds() {
            return ((TimeOfDay)this.instance).getSeconds();
        }

        public Builder setHours(int n) {
            this.copyOnWrite();
            ((TimeOfDay)this.instance).setHours(n);
            return this;
        }

        public Builder setMinutes(int n) {
            this.copyOnWrite();
            ((TimeOfDay)this.instance).setMinutes(n);
            return this;
        }

        public Builder setNanos(int n) {
            this.copyOnWrite();
            ((TimeOfDay)this.instance).setNanos(n);
            return this;
        }

        public Builder setSeconds(int n) {
            this.copyOnWrite();
            ((TimeOfDay)this.instance).setSeconds(n);
            return this;
        }
    }

}

