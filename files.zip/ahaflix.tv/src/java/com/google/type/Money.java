/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.protobuf.AbstractMessageLite
 *  com.google.protobuf.ByteString
 *  com.google.protobuf.CodedInputStream
 *  com.google.protobuf.CodedOutputStream
 *  com.google.protobuf.ExtensionRegistryLite
 *  com.google.protobuf.GeneratedMessageLite
 *  com.google.protobuf.GeneratedMessageLite$Builder
 *  com.google.protobuf.GeneratedMessageLite$DefaultInstanceBasedParser
 *  com.google.protobuf.GeneratedMessageLite$MethodToInvoke
 *  com.google.protobuf.GeneratedMessageLite$Visitor
 *  com.google.protobuf.InvalidProtocolBufferException
 *  com.google.protobuf.MessageLite
 *  com.google.protobuf.Parser
 *  com.google.type.Money$1
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 *  java.util.Objects
 */
package com.google.type;

import com.google.protobuf.AbstractMessageLite;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.CodedOutputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.MessageLite;
import com.google.protobuf.Parser;
import com.google.type.Money;
import com.google.type.MoneyOrBuilder;
import java.io.IOException;
import java.io.InputStream;
import java.util.Objects;

public final class Money
extends GeneratedMessageLite<Money, Builder>
implements MoneyOrBuilder {
    public static final int CURRENCY_CODE_FIELD_NUMBER = 1;
    private static final Money DEFAULT_INSTANCE;
    public static final int NANOS_FIELD_NUMBER = 3;
    private static volatile Parser<Money> PARSER;
    public static final int UNITS_FIELD_NUMBER = 2;
    private String currencyCode_ = "";
    private int nanos_;
    private long units_;

    public static {
        Money money;
        DEFAULT_INSTANCE = money = new Money();
        money.makeImmutable();
    }

    private Money() {
    }

    private void clearCurrencyCode() {
        this.currencyCode_ = Money.getDefaultInstance().getCurrencyCode();
    }

    private void clearNanos() {
        this.nanos_ = 0;
    }

    private void clearUnits() {
        this.units_ = 0L;
    }

    public static Money getDefaultInstance() {
        return DEFAULT_INSTANCE;
    }

    public static Builder newBuilder() {
        return (Builder)DEFAULT_INSTANCE.toBuilder();
    }

    public static Builder newBuilder(Money money) {
        return (Builder)((Builder)DEFAULT_INSTANCE.toBuilder()).mergeFrom((GeneratedMessageLite)money);
    }

    public static Money parseDelimitedFrom(InputStream inputStream) throws IOException {
        return (Money)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static Money parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (Money)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Money parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
        return (Money)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString);
    }

    public static Money parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (Money)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Money parseFrom(CodedInputStream codedInputStream) throws IOException {
        return (Money)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream);
    }

    public static Money parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (Money)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Money parseFrom(InputStream inputStream) throws IOException {
        return (Money)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static Money parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (Money)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Money parseFrom(byte[] arrby) throws InvalidProtocolBufferException {
        return (Money)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby);
    }

    public static Money parseFrom(byte[] arrby, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (Money)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Parser<Money> parser() {
        return DEFAULT_INSTANCE.getParserForType();
    }

    private void setCurrencyCode(String string) {
        Objects.requireNonNull((Object)string);
        this.currencyCode_ = string;
    }

    private void setCurrencyCodeBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.currencyCode_ = byteString.toStringUtf8();
    }

    private void setNanos(int n) {
        this.nanos_ = n;
    }

    private void setUnits(long l) {
        this.units_ = l;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke var1_1, Object var2_2, Object var3_3) {
        var4_4 = var1_1.ordinal();
        var5_5 = false;
        switch (var4_4) {
            default: {
                throw new UnsupportedOperationException();
            }
            case 7: {
                if (Money.PARSER != null) return Money.PARSER;
                var26_6 = Money.class;
                // MONITORENTER : com.google.type.Money.class
                if (Money.PARSER == null) {
                    Money.PARSER = new GeneratedMessageLite.DefaultInstanceBasedParser((GeneratedMessageLite)Money.DEFAULT_INSTANCE);
                }
                // MONITOREXIT : var26_6
                return Money.PARSER;
            }
            case 2: {
                var19_7 = (CodedInputStream)var2_2;
                (ExtensionRegistryLite)var3_3;
                while (var5_5 == false) {
                    var24_8 = var19_7.readTag();
                    if (var24_8 == 0) ** GOTO lbl33
                    if (var24_8 == 10) ** GOTO lbl31
                    if (var24_8 == 16) ** GOTO lbl29
                    if (var24_8 != 24) {
                        if (var19_7.skipField(var24_8)) continue;
                    } else {
                        this.nanos_ = var19_7.readInt32();
                        continue;
lbl29: // 1 sources:
                        this.units_ = var19_7.readInt64();
                        continue;
lbl31: // 1 sources:
                        this.currencyCode_ = var19_7.readStringRequireUtf8();
                        continue;
                    }
lbl33: // 2 sources:
                    var5_5 = true;
                    continue;
                    catch (IOException var23_10) {
                        throw new RuntimeException((Throwable)new InvalidProtocolBufferException(var23_10.getMessage()).setUnfinishedMessage((MessageLite)this));
                    }
                    catch (InvalidProtocolBufferException var21_11) {
                        throw new RuntimeException((Throwable)var21_11.setUnfinishedMessage((MessageLite)this));
                    }
                }
                return Money.DEFAULT_INSTANCE;
            }
            case 6: {
                return Money.DEFAULT_INSTANCE;
            }
            case 1: {
                var6_12 = (GeneratedMessageLite.Visitor)var2_2;
                var7_13 = (Money)var3_3;
                this.currencyCode_ = var6_12.visitString(true ^ this.currencyCode_.isEmpty(), this.currencyCode_, true ^ var7_13.currencyCode_.isEmpty(), var7_13.currencyCode_);
                var8_14 = this.units_;
                var10_15 = var8_14 != 0L;
                var11_16 = var7_13.units_;
                var13_17 = var11_16 != 0L;
                this.units_ = var6_12.visitLong(var10_15, var8_14, var13_17, var11_16);
                var14_18 = this.nanos_;
                var15_19 = var14_18 != 0;
                var16_20 = var7_13.nanos_;
                var17_21 = false;
                if (var16_20 != 0) {
                    var17_21 = true;
                }
                this.nanos_ = var6_12.visitInt(var15_19, var14_18, var17_21, var16_20);
                return this;
            }
            case 5: {
                return new Builder(null);
            }
            case 3: {
                return null;
            }
            case 0: {
                return Money.DEFAULT_INSTANCE;
            }
            case 4: 
        }
        return new Money();
    }

    @Override
    public String getCurrencyCode() {
        return this.currencyCode_;
    }

    @Override
    public ByteString getCurrencyCodeBytes() {
        return ByteString.copyFromUtf8((String)this.currencyCode_);
    }

    @Override
    public int getNanos() {
        return this.nanos_;
    }

    public int getSerializedSize() {
        int n;
        long l;
        int n2 = this.memoizedSerializedSize;
        if (n2 != -1) {
            return n2;
        }
        boolean bl = this.currencyCode_.isEmpty();
        int n3 = 0;
        if (!bl) {
            n3 = 0 + CodedOutputStream.computeStringSize((int)1, (String)this.getCurrencyCode());
        }
        if ((l = this.units_) != 0L) {
            n3 += CodedOutputStream.computeInt64Size((int)2, (long)l);
        }
        if ((n = this.nanos_) != 0) {
            n3 += CodedOutputStream.computeInt32Size((int)3, (int)n);
        }
        this.memoizedSerializedSize = n3;
        return n3;
    }

    @Override
    public long getUnits() {
        return this.units_;
    }

    public void writeTo(CodedOutputStream codedOutputStream) throws IOException {
        int n;
        long l;
        if (!this.currencyCode_.isEmpty()) {
            codedOutputStream.writeString(1, this.getCurrencyCode());
        }
        if ((l = this.units_) != 0L) {
            codedOutputStream.writeInt64(2, l);
        }
        if ((n = this.nanos_) != 0) {
            codedOutputStream.writeInt32(3, n);
        }
    }

    public static final class Builder
    extends GeneratedMessageLite.Builder<Money, Builder>
    implements MoneyOrBuilder {
        private Builder() {
            super((GeneratedMessageLite)DEFAULT_INSTANCE);
        }

        public /* synthetic */ Builder(1 var1_1) {
            this();
        }

        public Builder clearCurrencyCode() {
            this.copyOnWrite();
            ((Money)this.instance).clearCurrencyCode();
            return this;
        }

        public Builder clearNanos() {
            this.copyOnWrite();
            ((Money)this.instance).clearNanos();
            return this;
        }

        public Builder clearUnits() {
            this.copyOnWrite();
            ((Money)this.instance).clearUnits();
            return this;
        }

        @Override
        public String getCurrencyCode() {
            return ((Money)this.instance).getCurrencyCode();
        }

        @Override
        public ByteString getCurrencyCodeBytes() {
            return ((Money)this.instance).getCurrencyCodeBytes();
        }

        @Override
        public int getNanos() {
            return ((Money)this.instance).getNanos();
        }

        @Override
        public long getUnits() {
            return ((Money)this.instance).getUnits();
        }

        public Builder setCurrencyCode(String string) {
            this.copyOnWrite();
            ((Money)this.instance).setCurrencyCode(string);
            return this;
        }

        public Builder setCurrencyCodeBytes(ByteString byteString) {
            this.copyOnWrite();
            ((Money)this.instance).setCurrencyCodeBytes(byteString);
            return this;
        }

        public Builder setNanos(int n) {
            this.copyOnWrite();
            ((Money)this.instance).setNanos(n);
            return this;
        }

        public Builder setUnits(long l) {
            this.copyOnWrite();
            ((Money)this.instance).setUnits(l);
            return this;
        }
    }

}

