/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.protobuf.ByteString
 *  com.google.protobuf.CodedInputStream
 *  com.google.protobuf.CodedOutputStream
 *  com.google.protobuf.ExtensionRegistryLite
 *  com.google.protobuf.GeneratedMessageLite
 *  com.google.protobuf.GeneratedMessageLite$Builder
 *  com.google.protobuf.GeneratedMessageLite$DefaultInstanceBasedParser
 *  com.google.protobuf.GeneratedMessageLite$MethodToInvoke
 *  com.google.protobuf.GeneratedMessageLite$Visitor
 *  com.google.protobuf.InvalidProtocolBufferException
 *  com.google.protobuf.MessageLite
 *  com.google.protobuf.Parser
 *  com.google.type.LatLng$1
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 */
package com.google.type;

import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.CodedOutputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.MessageLite;
import com.google.protobuf.Parser;
import com.google.type.LatLng;
import com.google.type.LatLngOrBuilder;
import java.io.IOException;
import java.io.InputStream;

public final class LatLng
extends GeneratedMessageLite<LatLng, Builder>
implements LatLngOrBuilder {
    private static final LatLng DEFAULT_INSTANCE;
    public static final int LATITUDE_FIELD_NUMBER = 1;
    public static final int LONGITUDE_FIELD_NUMBER = 2;
    private static volatile Parser<LatLng> PARSER;
    private double latitude_;
    private double longitude_;

    public static {
        LatLng latLng;
        DEFAULT_INSTANCE = latLng = new LatLng();
        latLng.makeImmutable();
    }

    private LatLng() {
    }

    private void clearLatitude() {
        this.latitude_ = 0.0;
    }

    private void clearLongitude() {
        this.longitude_ = 0.0;
    }

    public static LatLng getDefaultInstance() {
        return DEFAULT_INSTANCE;
    }

    public static Builder newBuilder() {
        return (Builder)DEFAULT_INSTANCE.toBuilder();
    }

    public static Builder newBuilder(LatLng latLng) {
        return (Builder)((Builder)DEFAULT_INSTANCE.toBuilder()).mergeFrom((GeneratedMessageLite)latLng);
    }

    public static LatLng parseDelimitedFrom(InputStream inputStream) throws IOException {
        return (LatLng)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static LatLng parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (LatLng)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static LatLng parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
        return (LatLng)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString);
    }

    public static LatLng parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (LatLng)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static LatLng parseFrom(CodedInputStream codedInputStream) throws IOException {
        return (LatLng)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream);
    }

    public static LatLng parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (LatLng)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static LatLng parseFrom(InputStream inputStream) throws IOException {
        return (LatLng)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static LatLng parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (LatLng)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static LatLng parseFrom(byte[] arrby) throws InvalidProtocolBufferException {
        return (LatLng)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby);
    }

    public static LatLng parseFrom(byte[] arrby, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (LatLng)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Parser<LatLng> parser() {
        return DEFAULT_INSTANCE.getParserForType();
    }

    private void setLatitude(double d) {
        this.latitude_ = d;
    }

    private void setLongitude(double d) {
        this.longitude_ = d;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke var1_1, Object var2_2, Object var3_3) {
        var4_4 = var1_1.ordinal();
        var5_5 = false;
        switch (var4_4) {
            default: {
                throw new UnsupportedOperationException();
            }
            case 7: {
                if (LatLng.PARSER != null) return LatLng.PARSER;
                var28_6 = LatLng.class;
                // MONITORENTER : com.google.type.LatLng.class
                if (LatLng.PARSER == null) {
                    LatLng.PARSER = new GeneratedMessageLite.DefaultInstanceBasedParser((GeneratedMessageLite)LatLng.DEFAULT_INSTANCE);
                }
                // MONITOREXIT : var28_6
                return LatLng.PARSER;
            }
            case 2: {
                var21_7 = (CodedInputStream)var2_2;
                (ExtensionRegistryLite)var3_3;
                while (var5_5 == false) {
                    var26_8 = var21_7.readTag();
                    if (var26_8 == 0) ** GOTO lbl30
                    if (var26_8 == 9) ** GOTO lbl28
                    if (var26_8 != 17) {
                        if (var21_7.skipField(var26_8)) continue;
                    } else {
                        this.longitude_ = var21_7.readDouble();
                        continue;
lbl28: // 1 sources:
                        this.latitude_ = var21_7.readDouble();
                        continue;
                    }
lbl30: // 2 sources:
                    var5_5 = true;
                    continue;
                    catch (IOException var25_10) {
                        throw new RuntimeException((Throwable)new InvalidProtocolBufferException(var25_10.getMessage()).setUnfinishedMessage((MessageLite)this));
                    }
                    catch (InvalidProtocolBufferException var23_11) {
                        throw new RuntimeException((Throwable)var23_11.setUnfinishedMessage((MessageLite)this));
                    }
                }
                return LatLng.DEFAULT_INSTANCE;
            }
            case 6: {
                return LatLng.DEFAULT_INSTANCE;
            }
            case 1: {
                var6_12 = (GeneratedMessageLite.Visitor)var2_2;
                var7_13 = (LatLng)var3_3;
                var8_14 = this.latitude_;
                var10_15 = var8_14 != 0.0;
                var11_16 = var7_13.latitude_;
                var13_17 = var11_16 != 0.0;
                this.latitude_ = var6_12.visitDouble(var10_15, var8_14, var13_17, var11_16);
                var14_18 = this.longitude_;
                var16_19 = var14_18 != 0.0;
                var17_20 = var7_13.longitude_;
                var19_21 = var17_20 != 0.0;
                this.longitude_ = var6_12.visitDouble(var16_19, var14_18, var19_21, var17_20);
                return this;
            }
            case 5: {
                return new Builder(null);
            }
            case 3: {
                return null;
            }
            case 0: {
                return LatLng.DEFAULT_INSTANCE;
            }
            case 4: 
        }
        return new LatLng();
    }

    @Override
    public double getLatitude() {
        return this.latitude_;
    }

    @Override
    public double getLongitude() {
        return this.longitude_;
    }

    public int getSerializedSize() {
        double d;
        int n = this.memoizedSerializedSize;
        if (n != -1) {
            return n;
        }
        double d2 = this.latitude_;
        double d3 = d2 DCMPL 0.0;
        int n2 = 0;
        if (d3 != false) {
            n2 = 0 + CodedOutputStream.computeDoubleSize((int)1, (double)d2);
        }
        if ((d = this.longitude_) != 0.0) {
            n2 += CodedOutputStream.computeDoubleSize((int)2, (double)d);
        }
        this.memoizedSerializedSize = n2;
        return n2;
    }

    public void writeTo(CodedOutputStream codedOutputStream) throws IOException {
        double d;
        double d2 = this.latitude_;
        if (d2 != 0.0) {
            codedOutputStream.writeDouble(1, d2);
        }
        if ((d = this.longitude_) != 0.0) {
            codedOutputStream.writeDouble(2, d);
        }
    }

    public static final class Builder
    extends GeneratedMessageLite.Builder<LatLng, Builder>
    implements LatLngOrBuilder {
        private Builder() {
            super((GeneratedMessageLite)DEFAULT_INSTANCE);
        }

        public /* synthetic */ Builder(1 var1_1) {
            this();
        }

        public Builder clearLatitude() {
            this.copyOnWrite();
            ((LatLng)this.instance).clearLatitude();
            return this;
        }

        public Builder clearLongitude() {
            this.copyOnWrite();
            ((LatLng)this.instance).clearLongitude();
            return this;
        }

        @Override
        public double getLatitude() {
            return ((LatLng)this.instance).getLatitude();
        }

        @Override
        public double getLongitude() {
            return ((LatLng)this.instance).getLongitude();
        }

        public Builder setLatitude(double d) {
            this.copyOnWrite();
            ((LatLng)this.instance).setLatitude(d);
            return this;
        }

        public Builder setLongitude(double d) {
            this.copyOnWrite();
            ((LatLng)this.instance).setLongitude(d);
            return this;
        }
    }

}

