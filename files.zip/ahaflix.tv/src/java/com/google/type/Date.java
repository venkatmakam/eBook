/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.protobuf.ByteString
 *  com.google.protobuf.CodedInputStream
 *  com.google.protobuf.CodedOutputStream
 *  com.google.protobuf.ExtensionRegistryLite
 *  com.google.protobuf.GeneratedMessageLite
 *  com.google.protobuf.GeneratedMessageLite$Builder
 *  com.google.protobuf.GeneratedMessageLite$DefaultInstanceBasedParser
 *  com.google.protobuf.GeneratedMessageLite$MethodToInvoke
 *  com.google.protobuf.GeneratedMessageLite$Visitor
 *  com.google.protobuf.InvalidProtocolBufferException
 *  com.google.protobuf.MessageLite
 *  com.google.protobuf.Parser
 *  com.google.type.Date$1
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 */
package com.google.type;

import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.CodedOutputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.MessageLite;
import com.google.protobuf.Parser;
import com.google.type.Date;
import com.google.type.DateOrBuilder;
import java.io.IOException;
import java.io.InputStream;

public final class Date
extends GeneratedMessageLite<Date, Builder>
implements DateOrBuilder {
    public static final int DAY_FIELD_NUMBER = 3;
    private static final Date DEFAULT_INSTANCE;
    public static final int MONTH_FIELD_NUMBER = 2;
    private static volatile Parser<Date> PARSER;
    public static final int YEAR_FIELD_NUMBER = 1;
    private int day_;
    private int month_;
    private int year_;

    public static {
        Date date;
        DEFAULT_INSTANCE = date = new Date();
        date.makeImmutable();
    }

    private Date() {
    }

    private void clearDay() {
        this.day_ = 0;
    }

    private void clearMonth() {
        this.month_ = 0;
    }

    private void clearYear() {
        this.year_ = 0;
    }

    public static Date getDefaultInstance() {
        return DEFAULT_INSTANCE;
    }

    public static Builder newBuilder() {
        return (Builder)DEFAULT_INSTANCE.toBuilder();
    }

    public static Builder newBuilder(Date date) {
        return (Builder)((Builder)DEFAULT_INSTANCE.toBuilder()).mergeFrom((GeneratedMessageLite)date);
    }

    public static Date parseDelimitedFrom(InputStream inputStream) throws IOException {
        return (Date)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static Date parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (Date)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Date parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
        return (Date)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString);
    }

    public static Date parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (Date)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Date parseFrom(CodedInputStream codedInputStream) throws IOException {
        return (Date)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream);
    }

    public static Date parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (Date)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Date parseFrom(InputStream inputStream) throws IOException {
        return (Date)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static Date parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (Date)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Date parseFrom(byte[] arrby) throws InvalidProtocolBufferException {
        return (Date)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby);
    }

    public static Date parseFrom(byte[] arrby, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (Date)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Parser<Date> parser() {
        return DEFAULT_INSTANCE.getParserForType();
    }

    private void setDay(int n) {
        this.day_ = n;
    }

    private void setMonth(int n) {
        this.month_ = n;
    }

    private void setYear(int n) {
        this.year_ = n;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke var1_1, Object var2_2, Object var3_3) {
        var4_4 = var1_1.ordinal();
        var5_5 = false;
        switch (var4_4) {
            default: {
                throw new UnsupportedOperationException();
            }
            case 7: {
                if (Date.PARSER != null) return Date.PARSER;
                var28_6 = Date.class;
                // MONITORENTER : com.google.type.Date.class
                if (Date.PARSER == null) {
                    Date.PARSER = new GeneratedMessageLite.DefaultInstanceBasedParser((GeneratedMessageLite)Date.DEFAULT_INSTANCE);
                }
                // MONITOREXIT : var28_6
                return Date.PARSER;
            }
            case 2: {
                var21_7 = (CodedInputStream)var2_2;
                (ExtensionRegistryLite)var3_3;
                while (var5_5 == false) {
                    var26_8 = var21_7.readTag();
                    if (var26_8 == 0) ** GOTO lbl33
                    if (var26_8 == 8) ** GOTO lbl31
                    if (var26_8 == 16) ** GOTO lbl29
                    if (var26_8 != 24) {
                        if (var21_7.skipField(var26_8)) continue;
                    } else {
                        this.day_ = var21_7.readInt32();
                        continue;
lbl29: // 1 sources:
                        this.month_ = var21_7.readInt32();
                        continue;
lbl31: // 1 sources:
                        this.year_ = var21_7.readInt32();
                        continue;
                    }
lbl33: // 2 sources:
                    var5_5 = true;
                    continue;
                    catch (IOException var25_10) {
                        throw new RuntimeException((Throwable)new InvalidProtocolBufferException(var25_10.getMessage()).setUnfinishedMessage((MessageLite)this));
                    }
                    catch (InvalidProtocolBufferException var23_11) {
                        throw new RuntimeException((Throwable)var23_11.setUnfinishedMessage((MessageLite)this));
                    }
                }
                return Date.DEFAULT_INSTANCE;
            }
            case 6: {
                return Date.DEFAULT_INSTANCE;
            }
            case 1: {
                var6_12 = (GeneratedMessageLite.Visitor)var2_2;
                var7_13 = (Date)var3_3;
                var8_14 = this.year_;
                var9_15 = var8_14 != 0;
                var10_16 = var7_13.year_;
                var11_17 = var10_16 != 0;
                this.year_ = var6_12.visitInt(var9_15, var8_14, var11_17, var10_16);
                var12_18 = this.month_;
                var13_19 = var12_18 != 0;
                var14_20 = var7_13.month_;
                var15_21 = var14_20 != 0;
                this.month_ = var6_12.visitInt(var13_19, var12_18, var15_21, var14_20);
                var16_22 = this.day_;
                var17_23 = var16_22 != 0;
                var18_24 = var7_13.day_;
                var19_25 = false;
                if (var18_24 != 0) {
                    var19_25 = true;
                }
                this.day_ = var6_12.visitInt(var17_23, var16_22, var19_25, var18_24);
                return this;
            }
            case 5: {
                return new Builder(null);
            }
            case 3: {
                return null;
            }
            case 0: {
                return Date.DEFAULT_INSTANCE;
            }
            case 4: 
        }
        return new Date();
    }

    @Override
    public int getDay() {
        return this.day_;
    }

    @Override
    public int getMonth() {
        return this.month_;
    }

    public int getSerializedSize() {
        int n;
        int n2;
        int n3 = this.memoizedSerializedSize;
        if (n3 != -1) {
            return n3;
        }
        int n4 = this.year_;
        int n5 = 0;
        if (n4 != 0) {
            n5 = 0 + CodedOutputStream.computeInt32Size((int)1, (int)n4);
        }
        if ((n2 = this.month_) != 0) {
            n5 += CodedOutputStream.computeInt32Size((int)2, (int)n2);
        }
        if ((n = this.day_) != 0) {
            n5 += CodedOutputStream.computeInt32Size((int)3, (int)n);
        }
        this.memoizedSerializedSize = n5;
        return n5;
    }

    @Override
    public int getYear() {
        return this.year_;
    }

    public void writeTo(CodedOutputStream codedOutputStream) throws IOException {
        int n;
        int n2;
        int n3 = this.year_;
        if (n3 != 0) {
            codedOutputStream.writeInt32(1, n3);
        }
        if ((n = this.month_) != 0) {
            codedOutputStream.writeInt32(2, n);
        }
        if ((n2 = this.day_) != 0) {
            codedOutputStream.writeInt32(3, n2);
        }
    }

    public static final class Builder
    extends GeneratedMessageLite.Builder<Date, Builder>
    implements DateOrBuilder {
        private Builder() {
            super((GeneratedMessageLite)DEFAULT_INSTANCE);
        }

        public /* synthetic */ Builder(1 var1_1) {
            this();
        }

        public Builder clearDay() {
            this.copyOnWrite();
            ((Date)this.instance).clearDay();
            return this;
        }

        public Builder clearMonth() {
            this.copyOnWrite();
            ((Date)this.instance).clearMonth();
            return this;
        }

        public Builder clearYear() {
            this.copyOnWrite();
            ((Date)this.instance).clearYear();
            return this;
        }

        @Override
        public int getDay() {
            return ((Date)this.instance).getDay();
        }

        @Override
        public int getMonth() {
            return ((Date)this.instance).getMonth();
        }

        @Override
        public int getYear() {
            return ((Date)this.instance).getYear();
        }

        public Builder setDay(int n) {
            this.copyOnWrite();
            ((Date)this.instance).setDay(n);
            return this;
        }

        public Builder setMonth(int n) {
            this.copyOnWrite();
            ((Date)this.instance).setMonth(n);
            return this;
        }

        public Builder setYear(int n) {
            this.copyOnWrite();
            ((Date)this.instance).setYear(n);
            return this;
        }
    }

}

