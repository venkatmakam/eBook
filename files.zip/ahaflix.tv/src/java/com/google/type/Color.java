/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.protobuf.ByteString
 *  com.google.protobuf.CodedInputStream
 *  com.google.protobuf.CodedOutputStream
 *  com.google.protobuf.ExtensionRegistryLite
 *  com.google.protobuf.FloatValue
 *  com.google.protobuf.FloatValue$Builder
 *  com.google.protobuf.GeneratedMessageLite
 *  com.google.protobuf.GeneratedMessageLite$Builder
 *  com.google.protobuf.GeneratedMessageLite$DefaultInstanceBasedParser
 *  com.google.protobuf.GeneratedMessageLite$MethodToInvoke
 *  com.google.protobuf.GeneratedMessageLite$Visitor
 *  com.google.protobuf.InvalidProtocolBufferException
 *  com.google.protobuf.MessageLite
 *  com.google.protobuf.Parser
 *  com.google.type.Color$1
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 *  java.util.Objects
 */
package com.google.type;

import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.CodedOutputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.FloatValue;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.MessageLite;
import com.google.protobuf.Parser;
import com.google.type.Color;
import com.google.type.ColorOrBuilder;
import java.io.IOException;
import java.io.InputStream;
import java.util.Objects;

public final class Color
extends GeneratedMessageLite<Color, Builder>
implements ColorOrBuilder {
    public static final int ALPHA_FIELD_NUMBER = 4;
    public static final int BLUE_FIELD_NUMBER = 3;
    private static final Color DEFAULT_INSTANCE;
    public static final int GREEN_FIELD_NUMBER = 2;
    private static volatile Parser<Color> PARSER;
    public static final int RED_FIELD_NUMBER = 1;
    private FloatValue alpha_;
    private float blue_;
    private float green_;
    private float red_;

    public static {
        Color color;
        DEFAULT_INSTANCE = color = new Color();
        color.makeImmutable();
    }

    private Color() {
    }

    private void clearAlpha() {
        this.alpha_ = null;
    }

    private void clearBlue() {
        this.blue_ = 0.0f;
    }

    private void clearGreen() {
        this.green_ = 0.0f;
    }

    private void clearRed() {
        this.red_ = 0.0f;
    }

    public static Color getDefaultInstance() {
        return DEFAULT_INSTANCE;
    }

    private void mergeAlpha(FloatValue floatValue) {
        FloatValue floatValue2 = this.alpha_;
        if (floatValue2 != null && floatValue2 != FloatValue.getDefaultInstance()) {
            this.alpha_ = (FloatValue)((FloatValue.Builder)FloatValue.newBuilder((FloatValue)this.alpha_).mergeFrom((GeneratedMessageLite)floatValue)).buildPartial();
            return;
        }
        this.alpha_ = floatValue;
    }

    public static Builder newBuilder() {
        return (Builder)DEFAULT_INSTANCE.toBuilder();
    }

    public static Builder newBuilder(Color color) {
        return (Builder)((Builder)DEFAULT_INSTANCE.toBuilder()).mergeFrom((GeneratedMessageLite)color);
    }

    public static Color parseDelimitedFrom(InputStream inputStream) throws IOException {
        return (Color)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static Color parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (Color)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Color parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
        return (Color)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString);
    }

    public static Color parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (Color)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Color parseFrom(CodedInputStream codedInputStream) throws IOException {
        return (Color)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream);
    }

    public static Color parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (Color)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Color parseFrom(InputStream inputStream) throws IOException {
        return (Color)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static Color parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (Color)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Color parseFrom(byte[] arrby) throws InvalidProtocolBufferException {
        return (Color)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby);
    }

    public static Color parseFrom(byte[] arrby, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (Color)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Parser<Color> parser() {
        return DEFAULT_INSTANCE.getParserForType();
    }

    private void setAlpha(FloatValue.Builder builder) {
        this.alpha_ = (FloatValue)builder.build();
    }

    private void setAlpha(FloatValue floatValue) {
        Objects.requireNonNull((Object)floatValue);
        this.alpha_ = floatValue;
    }

    private void setBlue(float f) {
        this.blue_ = f;
    }

    private void setGreen(float f) {
        this.green_ = f;
    }

    private void setRed(float f) {
        this.red_ = f;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke var1_1, Object var2_2, Object var3_3) {
        var4_4 = var1_1.ordinal();
        var5_5 = false;
        switch (var4_4) {
            default: {
                throw new UnsupportedOperationException();
            }
            case 7: {
                if (Color.PARSER != null) return Color.PARSER;
                var33_6 = Color.class;
                // MONITORENTER : com.google.type.Color.class
                if (Color.PARSER == null) {
                    Color.PARSER = new GeneratedMessageLite.DefaultInstanceBasedParser((GeneratedMessageLite)Color.DEFAULT_INSTANCE);
                }
                // MONITOREXIT : var33_6
                return Color.PARSER;
            }
            case 2: {
                var22_7 = (CodedInputStream)var2_2;
                var23_8 = (ExtensionRegistryLite)var3_3;
lbl17: // 3 sources:
                do {
                    if (var5_5 != false) return Color.DEFAULT_INSTANCE;
                    var27_9 = var22_7.readTag();
                    if (var27_9 == 0) ** GOTO lbl37
                    if (var27_9 == 13) ** GOTO lbl35
                    if (var27_9 == 21) ** GOTO lbl33
                    if (var27_9 == 29) ** GOTO lbl31
                    if (var27_9 != 34) {
                        if (var22_7.skipField(var27_9)) continue;
                    } else {
                        var28_10 = this.alpha_;
                        var29_11 = var28_10 != null ? (FloatValue.Builder)var28_10.toBuilder() : null;
lbl31: // 1 sources:
                        this.blue_ = var22_7.readFloat();
                        continue;
lbl33: // 1 sources:
                        this.green_ = var22_7.readFloat();
                        continue;
lbl35: // 1 sources:
                        this.red_ = var22_7.readFloat();
                        continue;
                    }
lbl37: // 2 sources:
                    var5_5 = true;
                    continue;
                    catch (IOException var26_14) {
                        throw new RuntimeException((Throwable)new InvalidProtocolBufferException(var26_14.getMessage()).setUnfinishedMessage((MessageLite)this));
                    }
                    catch (InvalidProtocolBufferException var24_15) {
                        throw new RuntimeException((Throwable)var24_15.setUnfinishedMessage((MessageLite)this));
                    }
                    break;
                } while (true);
            }
            case 6: {
                return Color.DEFAULT_INSTANCE;
            }
            case 1: {
                var6_16 = (GeneratedMessageLite.Visitor)var2_2;
                var7_17 = (Color)var3_3;
                var8_18 = this.red_;
                var9_19 = var8_18 != 0.0f;
                var10_20 = var7_17.red_;
                var11_21 = var10_20 != 0.0f;
                this.red_ = var6_16.visitFloat(var9_19, var8_18, var11_21, var10_20);
                var12_22 = this.green_;
                var13_23 = var12_22 != 0.0f;
                var14_24 = var7_17.green_;
                var15_25 = var14_24 != 0.0f;
                this.green_ = var6_16.visitFloat(var13_23, var12_22, var15_25, var14_24);
                var16_26 = this.blue_;
                var17_27 = var16_26 != 0.0f;
                var18_28 = var7_17.blue_;
                var19_29 = var18_28 FCMPL 0.0f;
                var20_30 = false;
                if (var19_29 != false) {
                    var20_30 = true;
                }
                this.blue_ = var6_16.visitFloat(var17_27, var16_26, var20_30, var18_28);
                this.alpha_ = (FloatValue)var6_16.visitMessage((MessageLite)this.alpha_, (MessageLite)var7_17.alpha_);
                return this;
            }
            case 5: {
                return new Builder(null);
            }
            case 3: {
                return null;
            }
            case 0: {
                return Color.DEFAULT_INSTANCE;
            }
            case 4: {
                return new Color();
            }
        }
        this.alpha_ = var30_12 = (FloatValue)var22_7.readMessage(FloatValue.parser(), var23_8);
        if (var29_11 == null) ** GOTO lbl17
        var29_11.mergeFrom((GeneratedMessageLite)var30_12);
        this.alpha_ = (FloatValue)var29_11.buildPartial();
        ** while (true)
    }

    @Override
    public FloatValue getAlpha() {
        FloatValue floatValue = this.alpha_;
        if (floatValue == null) {
            floatValue = FloatValue.getDefaultInstance();
        }
        return floatValue;
    }

    @Override
    public float getBlue() {
        return this.blue_;
    }

    @Override
    public float getGreen() {
        return this.green_;
    }

    @Override
    public float getRed() {
        return this.red_;
    }

    public int getSerializedSize() {
        float f;
        float f2;
        int n = this.memoizedSerializedSize;
        if (n != -1) {
            return n;
        }
        float f3 = this.red_;
        float f4 = f3 FCMPL 0.0f;
        int n2 = 0;
        if (f4 != false) {
            n2 = 0 + CodedOutputStream.computeFloatSize((int)1, (float)f3);
        }
        if ((f2 = this.green_) != 0.0f) {
            n2 += CodedOutputStream.computeFloatSize((int)2, (float)f2);
        }
        if ((f = this.blue_) != 0.0f) {
            n2 += CodedOutputStream.computeFloatSize((int)3, (float)f);
        }
        if (this.alpha_ != null) {
            n2 += CodedOutputStream.computeMessageSize((int)4, (MessageLite)this.getAlpha());
        }
        this.memoizedSerializedSize = n2;
        return n2;
    }

    @Override
    public boolean hasAlpha() {
        return this.alpha_ != null;
    }

    public void writeTo(CodedOutputStream codedOutputStream) throws IOException {
        float f;
        float f2;
        float f3 = this.red_;
        if (f3 != 0.0f) {
            codedOutputStream.writeFloat(1, f3);
        }
        if ((f = this.green_) != 0.0f) {
            codedOutputStream.writeFloat(2, f);
        }
        if ((f2 = this.blue_) != 0.0f) {
            codedOutputStream.writeFloat(3, f2);
        }
        if (this.alpha_ != null) {
            codedOutputStream.writeMessage(4, (MessageLite)this.getAlpha());
        }
    }

    public static final class Builder
    extends GeneratedMessageLite.Builder<Color, Builder>
    implements ColorOrBuilder {
        private Builder() {
            super((GeneratedMessageLite)DEFAULT_INSTANCE);
        }

        public /* synthetic */ Builder(1 var1_1) {
            this();
        }

        public Builder clearAlpha() {
            this.copyOnWrite();
            ((Color)this.instance).clearAlpha();
            return this;
        }

        public Builder clearBlue() {
            this.copyOnWrite();
            ((Color)this.instance).clearBlue();
            return this;
        }

        public Builder clearGreen() {
            this.copyOnWrite();
            ((Color)this.instance).clearGreen();
            return this;
        }

        public Builder clearRed() {
            this.copyOnWrite();
            ((Color)this.instance).clearRed();
            return this;
        }

        @Override
        public FloatValue getAlpha() {
            return ((Color)this.instance).getAlpha();
        }

        @Override
        public float getBlue() {
            return ((Color)this.instance).getBlue();
        }

        @Override
        public float getGreen() {
            return ((Color)this.instance).getGreen();
        }

        @Override
        public float getRed() {
            return ((Color)this.instance).getRed();
        }

        @Override
        public boolean hasAlpha() {
            return ((Color)this.instance).hasAlpha();
        }

        public Builder mergeAlpha(FloatValue floatValue) {
            this.copyOnWrite();
            ((Color)this.instance).mergeAlpha(floatValue);
            return this;
        }

        public Builder setAlpha(FloatValue.Builder builder) {
            this.copyOnWrite();
            ((Color)this.instance).setAlpha(builder);
            return this;
        }

        public Builder setAlpha(FloatValue floatValue) {
            this.copyOnWrite();
            ((Color)this.instance).setAlpha(floatValue);
            return this;
        }

        public Builder setBlue(float f) {
            this.copyOnWrite();
            ((Color)this.instance).setBlue(f);
            return this;
        }

        public Builder setGreen(float f) {
            this.copyOnWrite();
            ((Color)this.instance).setGreen(f);
            return this;
        }

        public Builder setRed(float f) {
            this.copyOnWrite();
            ((Color)this.instance).setRed(f);
            return this;
        }
    }

}

