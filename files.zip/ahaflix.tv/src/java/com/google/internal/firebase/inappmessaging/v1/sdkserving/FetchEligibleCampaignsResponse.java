/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.internal.firebase.inappmessaging.v1.CampaignProto
 *  com.google.internal.firebase.inappmessaging.v1.CampaignProto$ThickContentOrBuilder
 *  com.google.internal.firebase.inappmessaging.v1.sdkserving.FetchEligibleCampaignsResponse$1
 *  com.google.internal.firebase.inappmessaging.v1.sdkserving.FetchEligibleCampaignsResponseOrBuilder
 *  com.google.protobuf.AbstractMessageLite
 *  com.google.protobuf.ByteString
 *  com.google.protobuf.CodedInputStream
 *  com.google.protobuf.CodedOutputStream
 *  com.google.protobuf.ExtensionRegistryLite
 *  com.google.protobuf.GeneratedMessageLite
 *  com.google.protobuf.GeneratedMessageLite$Builder
 *  com.google.protobuf.GeneratedMessageLite$DefaultInstanceBasedParser
 *  com.google.protobuf.GeneratedMessageLite$MergeFromVisitor
 *  com.google.protobuf.GeneratedMessageLite$MethodToInvoke
 *  com.google.protobuf.GeneratedMessageLite$Visitor
 *  com.google.protobuf.Internal
 *  com.google.protobuf.Internal$ProtobufList
 *  com.google.protobuf.InvalidProtocolBufferException
 *  com.google.protobuf.MessageLite
 *  com.google.protobuf.Parser
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Class
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 *  java.util.Collections
 *  java.util.List
 *  java.util.Objects
 */
package com.google.internal.firebase.inappmessaging.v1.sdkserving;

import com.google.internal.firebase.inappmessaging.v1.CampaignProto;
import com.google.internal.firebase.inappmessaging.v1.sdkserving.FetchEligibleCampaignsResponse;
import com.google.internal.firebase.inappmessaging.v1.sdkserving.FetchEligibleCampaignsResponseOrBuilder;
import com.google.protobuf.AbstractMessageLite;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.CodedOutputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.Internal;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.MessageLite;
import com.google.protobuf.Parser;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

public final class FetchEligibleCampaignsResponse
extends GeneratedMessageLite<FetchEligibleCampaignsResponse, Builder>
implements FetchEligibleCampaignsResponseOrBuilder {
    private static final FetchEligibleCampaignsResponse DEFAULT_INSTANCE;
    public static final int EXPIRATION_EPOCH_TIMESTAMP_MILLIS_FIELD_NUMBER = 2;
    public static final int MESSAGES_FIELD_NUMBER = 1;
    private static volatile Parser<FetchEligibleCampaignsResponse> PARSER;
    private int bitField0_;
    private long expirationEpochTimestampMillis_;
    private Internal.ProtobufList<CampaignProto.ThickContent> messages_ = GeneratedMessageLite.emptyProtobufList();

    public static {
        FetchEligibleCampaignsResponse fetchEligibleCampaignsResponse;
        DEFAULT_INSTANCE = fetchEligibleCampaignsResponse = new FetchEligibleCampaignsResponse();
        fetchEligibleCampaignsResponse.makeImmutable();
    }

    private FetchEligibleCampaignsResponse() {
    }

    private void addAllMessages(Iterable<? extends CampaignProto.ThickContent> iterable) {
        this.ensureMessagesIsMutable();
        AbstractMessageLite.addAll(iterable, this.messages_);
    }

    private void addMessages(int n, CampaignProto.ThickContent.Builder builder) {
        this.ensureMessagesIsMutable();
        this.messages_.add(n, (Object)((CampaignProto.ThickContent)builder.build()));
    }

    private void addMessages(int n, CampaignProto.ThickContent thickContent) {
        Objects.requireNonNull((Object)((Object)thickContent));
        this.ensureMessagesIsMutable();
        this.messages_.add(n, (Object)thickContent);
    }

    private void addMessages(CampaignProto.ThickContent.Builder builder) {
        this.ensureMessagesIsMutable();
        this.messages_.add((Object)((CampaignProto.ThickContent)builder.build()));
    }

    private void addMessages(CampaignProto.ThickContent thickContent) {
        Objects.requireNonNull((Object)((Object)thickContent));
        this.ensureMessagesIsMutable();
        this.messages_.add((Object)thickContent);
    }

    private void clearExpirationEpochTimestampMillis() {
        this.expirationEpochTimestampMillis_ = 0L;
    }

    private void clearMessages() {
        this.messages_ = GeneratedMessageLite.emptyProtobufList();
    }

    private void ensureMessagesIsMutable() {
        if (!this.messages_.isModifiable()) {
            this.messages_ = GeneratedMessageLite.mutableCopy(this.messages_);
        }
    }

    public static FetchEligibleCampaignsResponse getDefaultInstance() {
        return DEFAULT_INSTANCE;
    }

    public static Builder newBuilder() {
        return (Builder)DEFAULT_INSTANCE.toBuilder();
    }

    public static Builder newBuilder(FetchEligibleCampaignsResponse fetchEligibleCampaignsResponse) {
        return (Builder)((Builder)DEFAULT_INSTANCE.toBuilder()).mergeFrom((GeneratedMessageLite)fetchEligibleCampaignsResponse);
    }

    public static FetchEligibleCampaignsResponse parseDelimitedFrom(InputStream inputStream) throws IOException {
        return (FetchEligibleCampaignsResponse)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static FetchEligibleCampaignsResponse parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (FetchEligibleCampaignsResponse)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static FetchEligibleCampaignsResponse parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
        return (FetchEligibleCampaignsResponse)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString);
    }

    public static FetchEligibleCampaignsResponse parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (FetchEligibleCampaignsResponse)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static FetchEligibleCampaignsResponse parseFrom(CodedInputStream codedInputStream) throws IOException {
        return (FetchEligibleCampaignsResponse)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream);
    }

    public static FetchEligibleCampaignsResponse parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (FetchEligibleCampaignsResponse)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static FetchEligibleCampaignsResponse parseFrom(InputStream inputStream) throws IOException {
        return (FetchEligibleCampaignsResponse)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static FetchEligibleCampaignsResponse parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (FetchEligibleCampaignsResponse)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static FetchEligibleCampaignsResponse parseFrom(byte[] arrby) throws InvalidProtocolBufferException {
        return (FetchEligibleCampaignsResponse)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby);
    }

    public static FetchEligibleCampaignsResponse parseFrom(byte[] arrby, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (FetchEligibleCampaignsResponse)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Parser<FetchEligibleCampaignsResponse> parser() {
        return DEFAULT_INSTANCE.getParserForType();
    }

    private void removeMessages(int n) {
        this.ensureMessagesIsMutable();
        this.messages_.remove(n);
    }

    private void setExpirationEpochTimestampMillis(long l) {
        this.expirationEpochTimestampMillis_ = l;
    }

    private void setMessages(int n, CampaignProto.ThickContent.Builder builder) {
        this.ensureMessagesIsMutable();
        this.messages_.set(n, (Object)((CampaignProto.ThickContent)builder.build()));
    }

    private void setMessages(int n, CampaignProto.ThickContent thickContent) {
        Objects.requireNonNull((Object)((Object)thickContent));
        this.ensureMessagesIsMutable();
        this.messages_.set(n, (Object)thickContent);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke var1_1, Object var2_2, Object var3_3) {
        var4_4 = var1_1.ordinal();
        var5_5 = false;
        switch (var4_4) {
            default: {
                throw new UnsupportedOperationException();
            }
            case 7: {
                if (FetchEligibleCampaignsResponse.PARSER != null) return FetchEligibleCampaignsResponse.PARSER;
                var22_6 = FetchEligibleCampaignsResponse.class;
                // MONITORENTER : com.google.internal.firebase.inappmessaging.v1.sdkserving.FetchEligibleCampaignsResponse.class
                if (FetchEligibleCampaignsResponse.PARSER == null) {
                    FetchEligibleCampaignsResponse.PARSER = new GeneratedMessageLite.DefaultInstanceBasedParser((GeneratedMessageLite)FetchEligibleCampaignsResponse.DEFAULT_INSTANCE);
                }
                // MONITOREXIT : var22_6
                return FetchEligibleCampaignsResponse.PARSER;
            }
            case 2: {
                var14_7 = (CodedInputStream)var2_2;
                var15_8 = (ExtensionRegistryLite)var3_3;
                while (var5_5 == false) {
                    var19_9 = var14_7.readTag();
                    if (var19_9 == 0) ** GOTO lbl32
                    if (var19_9 == 10) ** GOTO lbl28
                    if (var19_9 != 16) {
                        if (var14_7.skipField(var19_9)) continue;
                    } else {
                        this.expirationEpochTimestampMillis_ = var14_7.readInt64();
                        continue;
lbl28: // 1 sources:
                        if (!this.messages_.isModifiable()) {
                            this.messages_ = GeneratedMessageLite.mutableCopy(this.messages_);
                        }
                        this.messages_.add((Object)((CampaignProto.ThickContent)var14_7.readMessage(CampaignProto.ThickContent.parser(), var15_8)));
                        continue;
                    }
lbl32: // 2 sources:
                    var5_5 = true;
                    continue;
                    catch (IOException var18_11) {
                        throw new RuntimeException((Throwable)new InvalidProtocolBufferException(var18_11.getMessage()).setUnfinishedMessage((MessageLite)this));
                    }
                    catch (InvalidProtocolBufferException var16_12) {
                        throw new RuntimeException((Throwable)var16_12.setUnfinishedMessage((MessageLite)this));
                    }
                }
                return FetchEligibleCampaignsResponse.DEFAULT_INSTANCE;
            }
            case 6: {
                return FetchEligibleCampaignsResponse.DEFAULT_INSTANCE;
            }
            case 1: {
                var6_13 = (GeneratedMessageLite.Visitor)var2_2;
                var7_14 = (FetchEligibleCampaignsResponse)var3_3;
                this.messages_ = var6_13.visitList(this.messages_, var7_14.messages_);
                var8_15 = this.expirationEpochTimestampMillis_;
                var10_16 = var8_15 != 0L;
                var11_17 = var7_14.expirationEpochTimestampMillis_;
                var13_18 = var11_17 != 0L;
                this.expirationEpochTimestampMillis_ = var6_13.visitLong(var10_16, var8_15, var13_18, var11_17);
                if (var6_13 != GeneratedMessageLite.MergeFromVisitor.INSTANCE) return this;
                this.bitField0_ |= var7_14.bitField0_;
                return this;
            }
            case 5: {
                return new Builder(null);
            }
            case 3: {
                this.messages_.makeImmutable();
                return null;
            }
            case 0: {
                return FetchEligibleCampaignsResponse.DEFAULT_INSTANCE;
            }
            case 4: 
        }
        return new FetchEligibleCampaignsResponse();
    }

    public long getExpirationEpochTimestampMillis() {
        return this.expirationEpochTimestampMillis_;
    }

    public CampaignProto.ThickContent getMessages(int n) {
        return (CampaignProto.ThickContent)((Object)this.messages_.get(n));
    }

    public int getMessagesCount() {
        return this.messages_.size();
    }

    public List<CampaignProto.ThickContent> getMessagesList() {
        return this.messages_;
    }

    public CampaignProto.ThickContentOrBuilder getMessagesOrBuilder(int n) {
        return (CampaignProto.ThickContentOrBuilder)this.messages_.get(n);
    }

    public List<? extends CampaignProto.ThickContentOrBuilder> getMessagesOrBuilderList() {
        return this.messages_;
    }

    public int getSerializedSize() {
        int n = this.memoizedSerializedSize;
        if (n != -1) {
            return n;
        }
        int n2 = 0;
        for (int i = 0; i < this.messages_.size(); ++i) {
            n2 += CodedOutputStream.computeMessageSize((int)1, (MessageLite)((MessageLite)this.messages_.get(i)));
        }
        long l = this.expirationEpochTimestampMillis_;
        if (l != 0L) {
            n2 += CodedOutputStream.computeInt64Size((int)2, (long)l);
        }
        this.memoizedSerializedSize = n2;
        return n2;
    }

    public void writeTo(CodedOutputStream codedOutputStream) throws IOException {
        for (int i = 0; i < this.messages_.size(); ++i) {
            codedOutputStream.writeMessage(1, (MessageLite)this.messages_.get(i));
        }
        long l = this.expirationEpochTimestampMillis_;
        if (l != 0L) {
            codedOutputStream.writeInt64(2, l);
        }
    }

    public static final class Builder
    extends GeneratedMessageLite.Builder<FetchEligibleCampaignsResponse, Builder>
    implements FetchEligibleCampaignsResponseOrBuilder {
        private Builder() {
            super((GeneratedMessageLite)DEFAULT_INSTANCE);
        }

        public /* synthetic */ Builder(1 var1_1) {
            this();
        }

        public Builder addAllMessages(Iterable<? extends CampaignProto.ThickContent> iterable) {
            this.copyOnWrite();
            ((FetchEligibleCampaignsResponse)this.instance).addAllMessages((Iterable<? extends CampaignProto.ThickContent>)iterable);
            return this;
        }

        public Builder addMessages(int n, CampaignProto.ThickContent.Builder builder) {
            this.copyOnWrite();
            ((FetchEligibleCampaignsResponse)this.instance).addMessages(n, builder);
            return this;
        }

        public Builder addMessages(int n, CampaignProto.ThickContent thickContent) {
            this.copyOnWrite();
            ((FetchEligibleCampaignsResponse)this.instance).addMessages(n, thickContent);
            return this;
        }

        public Builder addMessages(CampaignProto.ThickContent.Builder builder) {
            this.copyOnWrite();
            ((FetchEligibleCampaignsResponse)this.instance).addMessages(builder);
            return this;
        }

        public Builder addMessages(CampaignProto.ThickContent thickContent) {
            this.copyOnWrite();
            ((FetchEligibleCampaignsResponse)this.instance).addMessages(thickContent);
            return this;
        }

        public Builder clearExpirationEpochTimestampMillis() {
            this.copyOnWrite();
            ((FetchEligibleCampaignsResponse)this.instance).clearExpirationEpochTimestampMillis();
            return this;
        }

        public Builder clearMessages() {
            this.copyOnWrite();
            ((FetchEligibleCampaignsResponse)this.instance).clearMessages();
            return this;
        }

        public long getExpirationEpochTimestampMillis() {
            return ((FetchEligibleCampaignsResponse)this.instance).getExpirationEpochTimestampMillis();
        }

        public CampaignProto.ThickContent getMessages(int n) {
            return ((FetchEligibleCampaignsResponse)this.instance).getMessages(n);
        }

        public int getMessagesCount() {
            return ((FetchEligibleCampaignsResponse)this.instance).getMessagesCount();
        }

        public List<CampaignProto.ThickContent> getMessagesList() {
            return Collections.unmodifiableList(((FetchEligibleCampaignsResponse)this.instance).getMessagesList());
        }

        public Builder removeMessages(int n) {
            this.copyOnWrite();
            ((FetchEligibleCampaignsResponse)this.instance).removeMessages(n);
            return this;
        }

        public Builder setExpirationEpochTimestampMillis(long l) {
            this.copyOnWrite();
            ((FetchEligibleCampaignsResponse)this.instance).setExpirationEpochTimestampMillis(l);
            return this;
        }

        public Builder setMessages(int n, CampaignProto.ThickContent.Builder builder) {
            this.copyOnWrite();
            ((FetchEligibleCampaignsResponse)this.instance).setMessages(n, builder);
            return this;
        }

        public Builder setMessages(int n, CampaignProto.ThickContent thickContent) {
            this.copyOnWrite();
            ((FetchEligibleCampaignsResponse)this.instance).setMessages(n, thickContent);
            return this;
        }
    }

}

