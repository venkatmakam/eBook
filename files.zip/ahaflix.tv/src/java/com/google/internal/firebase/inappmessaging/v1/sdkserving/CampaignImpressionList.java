/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.internal.firebase.inappmessaging.v1.sdkserving.CampaignImpressionList$1
 *  com.google.internal.firebase.inappmessaging.v1.sdkserving.CampaignImpressionListOrBuilder
 *  com.google.internal.firebase.inappmessaging.v1.sdkserving.CampaignImpressionOrBuilder
 *  com.google.protobuf.AbstractMessageLite
 *  com.google.protobuf.ByteString
 *  com.google.protobuf.CodedInputStream
 *  com.google.protobuf.CodedOutputStream
 *  com.google.protobuf.ExtensionRegistryLite
 *  com.google.protobuf.GeneratedMessageLite
 *  com.google.protobuf.GeneratedMessageLite$Builder
 *  com.google.protobuf.GeneratedMessageLite$DefaultInstanceBasedParser
 *  com.google.protobuf.GeneratedMessageLite$MethodToInvoke
 *  com.google.protobuf.GeneratedMessageLite$Visitor
 *  com.google.protobuf.Internal
 *  com.google.protobuf.Internal$ProtobufList
 *  com.google.protobuf.InvalidProtocolBufferException
 *  com.google.protobuf.MessageLite
 *  com.google.protobuf.Parser
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Class
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 *  java.util.Collections
 *  java.util.List
 *  java.util.Objects
 */
package com.google.internal.firebase.inappmessaging.v1.sdkserving;

import com.google.internal.firebase.inappmessaging.v1.sdkserving.CampaignImpression;
import com.google.internal.firebase.inappmessaging.v1.sdkserving.CampaignImpressionList;
import com.google.internal.firebase.inappmessaging.v1.sdkserving.CampaignImpressionListOrBuilder;
import com.google.internal.firebase.inappmessaging.v1.sdkserving.CampaignImpressionOrBuilder;
import com.google.protobuf.AbstractMessageLite;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.CodedOutputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.Internal;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.MessageLite;
import com.google.protobuf.Parser;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

public final class CampaignImpressionList
extends GeneratedMessageLite<CampaignImpressionList, Builder>
implements CampaignImpressionListOrBuilder {
    public static final int ALREADY_SEEN_CAMPAIGNS_FIELD_NUMBER = 1;
    private static final CampaignImpressionList DEFAULT_INSTANCE;
    private static volatile Parser<CampaignImpressionList> PARSER;
    private Internal.ProtobufList<CampaignImpression> alreadySeenCampaigns_ = GeneratedMessageLite.emptyProtobufList();

    public static {
        CampaignImpressionList campaignImpressionList;
        DEFAULT_INSTANCE = campaignImpressionList = new CampaignImpressionList();
        campaignImpressionList.makeImmutable();
    }

    private CampaignImpressionList() {
    }

    private void addAllAlreadySeenCampaigns(Iterable<? extends CampaignImpression> iterable) {
        this.ensureAlreadySeenCampaignsIsMutable();
        AbstractMessageLite.addAll(iterable, this.alreadySeenCampaigns_);
    }

    private void addAlreadySeenCampaigns(int n, CampaignImpression.Builder builder) {
        this.ensureAlreadySeenCampaignsIsMutable();
        this.alreadySeenCampaigns_.add(n, (Object)((CampaignImpression)builder.build()));
    }

    private void addAlreadySeenCampaigns(int n, CampaignImpression campaignImpression) {
        Objects.requireNonNull((Object)((Object)campaignImpression));
        this.ensureAlreadySeenCampaignsIsMutable();
        this.alreadySeenCampaigns_.add(n, (Object)campaignImpression);
    }

    private void addAlreadySeenCampaigns(CampaignImpression.Builder builder) {
        this.ensureAlreadySeenCampaignsIsMutable();
        this.alreadySeenCampaigns_.add((Object)((CampaignImpression)builder.build()));
    }

    private void addAlreadySeenCampaigns(CampaignImpression campaignImpression) {
        Objects.requireNonNull((Object)((Object)campaignImpression));
        this.ensureAlreadySeenCampaignsIsMutable();
        this.alreadySeenCampaigns_.add((Object)campaignImpression);
    }

    private void clearAlreadySeenCampaigns() {
        this.alreadySeenCampaigns_ = GeneratedMessageLite.emptyProtobufList();
    }

    private void ensureAlreadySeenCampaignsIsMutable() {
        if (!this.alreadySeenCampaigns_.isModifiable()) {
            this.alreadySeenCampaigns_ = GeneratedMessageLite.mutableCopy(this.alreadySeenCampaigns_);
        }
    }

    public static CampaignImpressionList getDefaultInstance() {
        return DEFAULT_INSTANCE;
    }

    public static Builder newBuilder() {
        return (Builder)DEFAULT_INSTANCE.toBuilder();
    }

    public static Builder newBuilder(CampaignImpressionList campaignImpressionList) {
        return (Builder)((Builder)DEFAULT_INSTANCE.toBuilder()).mergeFrom((GeneratedMessageLite)campaignImpressionList);
    }

    public static CampaignImpressionList parseDelimitedFrom(InputStream inputStream) throws IOException {
        return (CampaignImpressionList)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static CampaignImpressionList parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (CampaignImpressionList)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static CampaignImpressionList parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
        return (CampaignImpressionList)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString);
    }

    public static CampaignImpressionList parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (CampaignImpressionList)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static CampaignImpressionList parseFrom(CodedInputStream codedInputStream) throws IOException {
        return (CampaignImpressionList)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream);
    }

    public static CampaignImpressionList parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (CampaignImpressionList)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static CampaignImpressionList parseFrom(InputStream inputStream) throws IOException {
        return (CampaignImpressionList)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static CampaignImpressionList parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (CampaignImpressionList)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static CampaignImpressionList parseFrom(byte[] arrby) throws InvalidProtocolBufferException {
        return (CampaignImpressionList)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby);
    }

    public static CampaignImpressionList parseFrom(byte[] arrby, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (CampaignImpressionList)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Parser<CampaignImpressionList> parser() {
        return DEFAULT_INSTANCE.getParserForType();
    }

    private void removeAlreadySeenCampaigns(int n) {
        this.ensureAlreadySeenCampaignsIsMutable();
        this.alreadySeenCampaigns_.remove(n);
    }

    private void setAlreadySeenCampaigns(int n, CampaignImpression.Builder builder) {
        this.ensureAlreadySeenCampaignsIsMutable();
        this.alreadySeenCampaigns_.set(n, (Object)((CampaignImpression)builder.build()));
    }

    private void setAlreadySeenCampaigns(int n, CampaignImpression campaignImpression) {
        Objects.requireNonNull((Object)((Object)campaignImpression));
        this.ensureAlreadySeenCampaignsIsMutable();
        this.alreadySeenCampaigns_.set(n, (Object)campaignImpression);
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object object, Object object2) {
        switch (methodToInvoke.ordinal()) {
            default: {
                throw new UnsupportedOperationException();
            }
            case 7: {
                if (PARSER != null) return PARSER;
                Class<CampaignImpressionList> class_ = CampaignImpressionList.class;
                // MONITORENTER : com.google.internal.firebase.inappmessaging.v1.sdkserving.CampaignImpressionList.class
                if (PARSER == null) {
                    PARSER = new GeneratedMessageLite.DefaultInstanceBasedParser((GeneratedMessageLite)DEFAULT_INSTANCE);
                }
                // MONITOREXIT : class_
                return PARSER;
            }
            case 2: {
                CodedInputStream codedInputStream = (CodedInputStream)object;
                ExtensionRegistryLite extensionRegistryLite = (ExtensionRegistryLite)object2;
                boolean bl = false;
                while (!bl) {
                    int n = codedInputStream.readTag();
                    if (n != 0) {
                        if (n != 10) {
                            if (codedInputStream.skipField(n)) continue;
                        } else {
                            if (!this.alreadySeenCampaigns_.isModifiable()) {
                                this.alreadySeenCampaigns_ = GeneratedMessageLite.mutableCopy(this.alreadySeenCampaigns_);
                            }
                            this.alreadySeenCampaigns_.add((Object)((CampaignImpression)codedInputStream.readMessage(CampaignImpression.parser(), extensionRegistryLite)));
                            continue;
                        }
                    }
                    bl = true;
                    continue;
                    catch (IOException iOException) {
                        throw new RuntimeException((Throwable)new InvalidProtocolBufferException(iOException.getMessage()).setUnfinishedMessage((MessageLite)this));
                    }
                    catch (InvalidProtocolBufferException invalidProtocolBufferException) {
                        throw new RuntimeException((Throwable)invalidProtocolBufferException.setUnfinishedMessage((MessageLite)this));
                    }
                }
                return DEFAULT_INSTANCE;
            }
            case 6: {
                return DEFAULT_INSTANCE;
            }
            case 1: {
                GeneratedMessageLite.Visitor visitor = (GeneratedMessageLite.Visitor)object;
                CampaignImpressionList campaignImpressionList = (CampaignImpressionList)((Object)object2);
                this.alreadySeenCampaigns_ = visitor.visitList(this.alreadySeenCampaigns_, campaignImpressionList.alreadySeenCampaigns_);
                return this;
            }
            case 5: {
                return new Builder(null);
            }
            case 3: {
                this.alreadySeenCampaigns_.makeImmutable();
                return null;
            }
            case 0: {
                return DEFAULT_INSTANCE;
            }
            case 4: 
        }
        return new CampaignImpressionList();
    }

    public CampaignImpression getAlreadySeenCampaigns(int n) {
        return (CampaignImpression)((Object)this.alreadySeenCampaigns_.get(n));
    }

    public int getAlreadySeenCampaignsCount() {
        return this.alreadySeenCampaigns_.size();
    }

    public List<CampaignImpression> getAlreadySeenCampaignsList() {
        return this.alreadySeenCampaigns_;
    }

    public CampaignImpressionOrBuilder getAlreadySeenCampaignsOrBuilder(int n) {
        return (CampaignImpressionOrBuilder)this.alreadySeenCampaigns_.get(n);
    }

    public List<? extends CampaignImpressionOrBuilder> getAlreadySeenCampaignsOrBuilderList() {
        return this.alreadySeenCampaigns_;
    }

    public int getSerializedSize() {
        int n = this.memoizedSerializedSize;
        if (n != -1) {
            return n;
        }
        int n2 = 0;
        for (int i = 0; i < this.alreadySeenCampaigns_.size(); ++i) {
            n2 += CodedOutputStream.computeMessageSize((int)1, (MessageLite)((MessageLite)this.alreadySeenCampaigns_.get(i)));
        }
        this.memoizedSerializedSize = n2;
        return n2;
    }

    public void writeTo(CodedOutputStream codedOutputStream) throws IOException {
        for (int i = 0; i < this.alreadySeenCampaigns_.size(); ++i) {
            codedOutputStream.writeMessage(1, (MessageLite)this.alreadySeenCampaigns_.get(i));
        }
    }

    public static final class Builder
    extends GeneratedMessageLite.Builder<CampaignImpressionList, Builder>
    implements CampaignImpressionListOrBuilder {
        private Builder() {
            super((GeneratedMessageLite)DEFAULT_INSTANCE);
        }

        public /* synthetic */ Builder(1 var1_1) {
            this();
        }

        public Builder addAllAlreadySeenCampaigns(Iterable<? extends CampaignImpression> iterable) {
            this.copyOnWrite();
            ((CampaignImpressionList)this.instance).addAllAlreadySeenCampaigns((Iterable<? extends CampaignImpression>)iterable);
            return this;
        }

        public Builder addAlreadySeenCampaigns(int n, CampaignImpression.Builder builder) {
            this.copyOnWrite();
            ((CampaignImpressionList)this.instance).addAlreadySeenCampaigns(n, builder);
            return this;
        }

        public Builder addAlreadySeenCampaigns(int n, CampaignImpression campaignImpression) {
            this.copyOnWrite();
            ((CampaignImpressionList)this.instance).addAlreadySeenCampaigns(n, campaignImpression);
            return this;
        }

        public Builder addAlreadySeenCampaigns(CampaignImpression.Builder builder) {
            this.copyOnWrite();
            ((CampaignImpressionList)this.instance).addAlreadySeenCampaigns(builder);
            return this;
        }

        public Builder addAlreadySeenCampaigns(CampaignImpression campaignImpression) {
            this.copyOnWrite();
            ((CampaignImpressionList)this.instance).addAlreadySeenCampaigns(campaignImpression);
            return this;
        }

        public Builder clearAlreadySeenCampaigns() {
            this.copyOnWrite();
            ((CampaignImpressionList)this.instance).clearAlreadySeenCampaigns();
            return this;
        }

        public CampaignImpression getAlreadySeenCampaigns(int n) {
            return ((CampaignImpressionList)this.instance).getAlreadySeenCampaigns(n);
        }

        public int getAlreadySeenCampaignsCount() {
            return ((CampaignImpressionList)this.instance).getAlreadySeenCampaignsCount();
        }

        public List<CampaignImpression> getAlreadySeenCampaignsList() {
            return Collections.unmodifiableList(((CampaignImpressionList)this.instance).getAlreadySeenCampaignsList());
        }

        public Builder removeAlreadySeenCampaigns(int n) {
            this.copyOnWrite();
            ((CampaignImpressionList)this.instance).removeAlreadySeenCampaigns(n);
            return this;
        }

        public Builder setAlreadySeenCampaigns(int n, CampaignImpression.Builder builder) {
            this.copyOnWrite();
            ((CampaignImpressionList)this.instance).setAlreadySeenCampaigns(n, builder);
            return this;
        }

        public Builder setAlreadySeenCampaigns(int n, CampaignImpression campaignImpression) {
            this.copyOnWrite();
            ((CampaignImpressionList)this.instance).setAlreadySeenCampaigns(n, campaignImpression);
            return this;
        }
    }

}

