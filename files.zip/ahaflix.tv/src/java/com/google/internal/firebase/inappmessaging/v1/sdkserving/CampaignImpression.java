/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.internal.firebase.inappmessaging.v1.sdkserving.CampaignImpression$1
 *  com.google.internal.firebase.inappmessaging.v1.sdkserving.CampaignImpressionOrBuilder
 *  com.google.protobuf.AbstractMessageLite
 *  com.google.protobuf.ByteString
 *  com.google.protobuf.CodedInputStream
 *  com.google.protobuf.CodedOutputStream
 *  com.google.protobuf.ExtensionRegistryLite
 *  com.google.protobuf.GeneratedMessageLite
 *  com.google.protobuf.GeneratedMessageLite$Builder
 *  com.google.protobuf.GeneratedMessageLite$DefaultInstanceBasedParser
 *  com.google.protobuf.GeneratedMessageLite$MethodToInvoke
 *  com.google.protobuf.GeneratedMessageLite$Visitor
 *  com.google.protobuf.InvalidProtocolBufferException
 *  com.google.protobuf.MessageLite
 *  com.google.protobuf.Parser
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 *  java.util.Objects
 */
package com.google.internal.firebase.inappmessaging.v1.sdkserving;

import com.google.internal.firebase.inappmessaging.v1.sdkserving.CampaignImpression;
import com.google.internal.firebase.inappmessaging.v1.sdkserving.CampaignImpressionOrBuilder;
import com.google.protobuf.AbstractMessageLite;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.CodedOutputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.MessageLite;
import com.google.protobuf.Parser;
import java.io.IOException;
import java.io.InputStream;
import java.util.Objects;

public final class CampaignImpression
extends GeneratedMessageLite<CampaignImpression, Builder>
implements CampaignImpressionOrBuilder {
    public static final int CAMPAIGN_ID_FIELD_NUMBER = 1;
    private static final CampaignImpression DEFAULT_INSTANCE;
    public static final int IMPRESSION_TIMESTAMP_MILLIS_FIELD_NUMBER = 2;
    private static volatile Parser<CampaignImpression> PARSER;
    private String campaignId_ = "";
    private long impressionTimestampMillis_;

    public static {
        CampaignImpression campaignImpression;
        DEFAULT_INSTANCE = campaignImpression = new CampaignImpression();
        campaignImpression.makeImmutable();
    }

    private CampaignImpression() {
    }

    private void clearCampaignId() {
        this.campaignId_ = CampaignImpression.getDefaultInstance().getCampaignId();
    }

    private void clearImpressionTimestampMillis() {
        this.impressionTimestampMillis_ = 0L;
    }

    public static CampaignImpression getDefaultInstance() {
        return DEFAULT_INSTANCE;
    }

    public static Builder newBuilder() {
        return (Builder)DEFAULT_INSTANCE.toBuilder();
    }

    public static Builder newBuilder(CampaignImpression campaignImpression) {
        return (Builder)((Builder)DEFAULT_INSTANCE.toBuilder()).mergeFrom((GeneratedMessageLite)campaignImpression);
    }

    public static CampaignImpression parseDelimitedFrom(InputStream inputStream) throws IOException {
        return (CampaignImpression)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static CampaignImpression parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (CampaignImpression)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static CampaignImpression parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
        return (CampaignImpression)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString);
    }

    public static CampaignImpression parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (CampaignImpression)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static CampaignImpression parseFrom(CodedInputStream codedInputStream) throws IOException {
        return (CampaignImpression)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream);
    }

    public static CampaignImpression parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (CampaignImpression)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static CampaignImpression parseFrom(InputStream inputStream) throws IOException {
        return (CampaignImpression)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static CampaignImpression parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (CampaignImpression)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static CampaignImpression parseFrom(byte[] arrby) throws InvalidProtocolBufferException {
        return (CampaignImpression)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby);
    }

    public static CampaignImpression parseFrom(byte[] arrby, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (CampaignImpression)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Parser<CampaignImpression> parser() {
        return DEFAULT_INSTANCE.getParserForType();
    }

    private void setCampaignId(String string2) {
        Objects.requireNonNull((Object)string2);
        this.campaignId_ = string2;
    }

    private void setCampaignIdBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.campaignId_ = byteString.toStringUtf8();
    }

    private void setImpressionTimestampMillis(long l) {
        this.impressionTimestampMillis_ = l;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke var1_1, Object var2_2, Object var3_3) {
        var4_4 = var1_1.ordinal();
        var5_5 = false;
        switch (var4_4) {
            default: {
                throw new UnsupportedOperationException();
            }
            case 7: {
                if (CampaignImpression.PARSER != null) return CampaignImpression.PARSER;
                var22_6 = CampaignImpression.class;
                // MONITORENTER : com.google.internal.firebase.inappmessaging.v1.sdkserving.CampaignImpression.class
                if (CampaignImpression.PARSER == null) {
                    CampaignImpression.PARSER = new GeneratedMessageLite.DefaultInstanceBasedParser((GeneratedMessageLite)CampaignImpression.DEFAULT_INSTANCE);
                }
                // MONITOREXIT : var22_6
                return CampaignImpression.PARSER;
            }
            case 2: {
                var15_7 = (CodedInputStream)var2_2;
                (ExtensionRegistryLite)var3_3;
                while (var5_5 == false) {
                    var20_8 = var15_7.readTag();
                    if (var20_8 == 0) ** GOTO lbl30
                    if (var20_8 == 10) ** GOTO lbl28
                    if (var20_8 != 16) {
                        if (var15_7.skipField(var20_8)) continue;
                    } else {
                        this.impressionTimestampMillis_ = var15_7.readInt64();
                        continue;
lbl28: // 1 sources:
                        this.campaignId_ = var15_7.readStringRequireUtf8();
                        continue;
                    }
lbl30: // 2 sources:
                    var5_5 = true;
                    continue;
                    catch (IOException var19_10) {
                        throw new RuntimeException((Throwable)new InvalidProtocolBufferException(var19_10.getMessage()).setUnfinishedMessage((MessageLite)this));
                    }
                    catch (InvalidProtocolBufferException var17_11) {
                        throw new RuntimeException((Throwable)var17_11.setUnfinishedMessage((MessageLite)this));
                    }
                }
                return CampaignImpression.DEFAULT_INSTANCE;
            }
            case 6: {
                return CampaignImpression.DEFAULT_INSTANCE;
            }
            case 1: {
                var6_12 = (GeneratedMessageLite.Visitor)var2_2;
                var7_13 = (CampaignImpression)var3_3;
                this.campaignId_ = var6_12.visitString(true ^ this.campaignId_.isEmpty(), this.campaignId_, true ^ var7_13.campaignId_.isEmpty(), var7_13.campaignId_);
                var8_14 = this.impressionTimestampMillis_;
                var10_15 = var8_14 != 0L;
                var11_16 = var7_13.impressionTimestampMillis_;
                var13_17 = var11_16 != 0L;
                this.impressionTimestampMillis_ = var6_12.visitLong(var10_15, var8_14, var13_17, var11_16);
                return this;
            }
            case 5: {
                return new Builder(null);
            }
            case 3: {
                return null;
            }
            case 0: {
                return CampaignImpression.DEFAULT_INSTANCE;
            }
            case 4: 
        }
        return new CampaignImpression();
    }

    public String getCampaignId() {
        return this.campaignId_;
    }

    public ByteString getCampaignIdBytes() {
        return ByteString.copyFromUtf8((String)this.campaignId_);
    }

    public long getImpressionTimestampMillis() {
        return this.impressionTimestampMillis_;
    }

    public int getSerializedSize() {
        long l;
        int n = this.memoizedSerializedSize;
        if (n != -1) {
            return n;
        }
        boolean bl = this.campaignId_.isEmpty();
        int n2 = 0;
        if (!bl) {
            n2 = 0 + CodedOutputStream.computeStringSize((int)1, (String)this.getCampaignId());
        }
        if ((l = this.impressionTimestampMillis_) != 0L) {
            n2 += CodedOutputStream.computeInt64Size((int)2, (long)l);
        }
        this.memoizedSerializedSize = n2;
        return n2;
    }

    public void writeTo(CodedOutputStream codedOutputStream) throws IOException {
        long l;
        if (!this.campaignId_.isEmpty()) {
            codedOutputStream.writeString(1, this.getCampaignId());
        }
        if ((l = this.impressionTimestampMillis_) != 0L) {
            codedOutputStream.writeInt64(2, l);
        }
    }

    public static final class Builder
    extends GeneratedMessageLite.Builder<CampaignImpression, Builder>
    implements CampaignImpressionOrBuilder {
        private Builder() {
            super((GeneratedMessageLite)DEFAULT_INSTANCE);
        }

        public /* synthetic */ Builder(1 var1_1) {
            this();
        }

        public Builder clearCampaignId() {
            this.copyOnWrite();
            ((CampaignImpression)this.instance).clearCampaignId();
            return this;
        }

        public Builder clearImpressionTimestampMillis() {
            this.copyOnWrite();
            ((CampaignImpression)this.instance).clearImpressionTimestampMillis();
            return this;
        }

        public String getCampaignId() {
            return ((CampaignImpression)this.instance).getCampaignId();
        }

        public ByteString getCampaignIdBytes() {
            return ((CampaignImpression)this.instance).getCampaignIdBytes();
        }

        public long getImpressionTimestampMillis() {
            return ((CampaignImpression)this.instance).getImpressionTimestampMillis();
        }

        public Builder setCampaignId(String string2) {
            this.copyOnWrite();
            ((CampaignImpression)this.instance).setCampaignId(string2);
            return this;
        }

        public Builder setCampaignIdBytes(ByteString byteString) {
            this.copyOnWrite();
            ((CampaignImpression)this.instance).setCampaignIdBytes(byteString);
            return this;
        }

        public Builder setImpressionTimestampMillis(long l) {
            this.copyOnWrite();
            ((CampaignImpression)this.instance).setImpressionTimestampMillis(l);
            return this;
        }
    }

}

