/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.developers.mobile.targeting.proto.ClientSignalsProto
 *  com.google.internal.firebase.inappmessaging.v1.sdkserving.CampaignImpressionOrBuilder
 *  com.google.internal.firebase.inappmessaging.v1.sdkserving.FetchEligibleCampaignsRequest$1
 *  com.google.internal.firebase.inappmessaging.v1.sdkserving.FetchEligibleCampaignsRequestOrBuilder
 *  com.google.protobuf.AbstractMessageLite
 *  com.google.protobuf.ByteString
 *  com.google.protobuf.CodedInputStream
 *  com.google.protobuf.CodedOutputStream
 *  com.google.protobuf.ExtensionRegistryLite
 *  com.google.protobuf.GeneratedMessageLite
 *  com.google.protobuf.GeneratedMessageLite$Builder
 *  com.google.protobuf.GeneratedMessageLite$DefaultInstanceBasedParser
 *  com.google.protobuf.GeneratedMessageLite$MergeFromVisitor
 *  com.google.protobuf.GeneratedMessageLite$MethodToInvoke
 *  com.google.protobuf.GeneratedMessageLite$Visitor
 *  com.google.protobuf.Internal
 *  com.google.protobuf.Internal$ProtobufList
 *  com.google.protobuf.InvalidProtocolBufferException
 *  com.google.protobuf.MessageLite
 *  com.google.protobuf.Parser
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Class
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 *  java.util.Collections
 *  java.util.List
 *  java.util.Objects
 */
package com.google.internal.firebase.inappmessaging.v1.sdkserving;

import com.google.developers.mobile.targeting.proto.ClientSignalsProto;
import com.google.internal.firebase.inappmessaging.v1.sdkserving.CampaignImpression;
import com.google.internal.firebase.inappmessaging.v1.sdkserving.CampaignImpressionOrBuilder;
import com.google.internal.firebase.inappmessaging.v1.sdkserving.ClientAppInfo;
import com.google.internal.firebase.inappmessaging.v1.sdkserving.FetchEligibleCampaignsRequest;
import com.google.internal.firebase.inappmessaging.v1.sdkserving.FetchEligibleCampaignsRequestOrBuilder;
import com.google.protobuf.AbstractMessageLite;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.CodedOutputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.Internal;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.MessageLite;
import com.google.protobuf.Parser;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

public final class FetchEligibleCampaignsRequest
extends GeneratedMessageLite<FetchEligibleCampaignsRequest, Builder>
implements FetchEligibleCampaignsRequestOrBuilder {
    public static final int ALREADY_SEEN_CAMPAIGNS_FIELD_NUMBER = 3;
    public static final int CLIENT_SIGNALS_FIELD_NUMBER = 4;
    private static final FetchEligibleCampaignsRequest DEFAULT_INSTANCE;
    private static volatile Parser<FetchEligibleCampaignsRequest> PARSER;
    public static final int PROJECT_NUMBER_FIELD_NUMBER = 1;
    public static final int REQUESTING_CLIENT_APP_FIELD_NUMBER = 2;
    private Internal.ProtobufList<CampaignImpression> alreadySeenCampaigns_ = GeneratedMessageLite.emptyProtobufList();
    private int bitField0_;
    private ClientSignalsProto.ClientSignals clientSignals_;
    private String projectNumber_ = "";
    private ClientAppInfo requestingClientApp_;

    public static {
        FetchEligibleCampaignsRequest fetchEligibleCampaignsRequest;
        DEFAULT_INSTANCE = fetchEligibleCampaignsRequest = new FetchEligibleCampaignsRequest();
        fetchEligibleCampaignsRequest.makeImmutable();
    }

    private FetchEligibleCampaignsRequest() {
    }

    private void addAllAlreadySeenCampaigns(Iterable<? extends CampaignImpression> iterable) {
        this.ensureAlreadySeenCampaignsIsMutable();
        AbstractMessageLite.addAll(iterable, this.alreadySeenCampaigns_);
    }

    private void addAlreadySeenCampaigns(int n, CampaignImpression.Builder builder) {
        this.ensureAlreadySeenCampaignsIsMutable();
        this.alreadySeenCampaigns_.add(n, (Object)((CampaignImpression)builder.build()));
    }

    private void addAlreadySeenCampaigns(int n, CampaignImpression campaignImpression) {
        Objects.requireNonNull((Object)((Object)campaignImpression));
        this.ensureAlreadySeenCampaignsIsMutable();
        this.alreadySeenCampaigns_.add(n, (Object)campaignImpression);
    }

    private void addAlreadySeenCampaigns(CampaignImpression.Builder builder) {
        this.ensureAlreadySeenCampaignsIsMutable();
        this.alreadySeenCampaigns_.add((Object)((CampaignImpression)builder.build()));
    }

    private void addAlreadySeenCampaigns(CampaignImpression campaignImpression) {
        Objects.requireNonNull((Object)((Object)campaignImpression));
        this.ensureAlreadySeenCampaignsIsMutable();
        this.alreadySeenCampaigns_.add((Object)campaignImpression);
    }

    private void clearAlreadySeenCampaigns() {
        this.alreadySeenCampaigns_ = GeneratedMessageLite.emptyProtobufList();
    }

    private void clearClientSignals() {
        this.clientSignals_ = null;
    }

    private void clearProjectNumber() {
        this.projectNumber_ = FetchEligibleCampaignsRequest.getDefaultInstance().getProjectNumber();
    }

    private void clearRequestingClientApp() {
        this.requestingClientApp_ = null;
    }

    private void ensureAlreadySeenCampaignsIsMutable() {
        if (!this.alreadySeenCampaigns_.isModifiable()) {
            this.alreadySeenCampaigns_ = GeneratedMessageLite.mutableCopy(this.alreadySeenCampaigns_);
        }
    }

    public static FetchEligibleCampaignsRequest getDefaultInstance() {
        return DEFAULT_INSTANCE;
    }

    private void mergeClientSignals(ClientSignalsProto.ClientSignals clientSignals) {
        ClientSignalsProto.ClientSignals clientSignals2 = this.clientSignals_;
        if (clientSignals2 != null && clientSignals2 != ClientSignalsProto.ClientSignals.getDefaultInstance()) {
            this.clientSignals_ = (ClientSignalsProto.ClientSignals)((ClientSignalsProto.ClientSignals.Builder)ClientSignalsProto.ClientSignals.newBuilder(this.clientSignals_).mergeFrom((GeneratedMessageLite)clientSignals)).buildPartial();
            return;
        }
        this.clientSignals_ = clientSignals;
    }

    private void mergeRequestingClientApp(ClientAppInfo clientAppInfo) {
        ClientAppInfo clientAppInfo2 = this.requestingClientApp_;
        if (clientAppInfo2 != null && clientAppInfo2 != ClientAppInfo.getDefaultInstance()) {
            this.requestingClientApp_ = (ClientAppInfo)((ClientAppInfo.Builder)ClientAppInfo.newBuilder(this.requestingClientApp_).mergeFrom((GeneratedMessageLite)clientAppInfo)).buildPartial();
            return;
        }
        this.requestingClientApp_ = clientAppInfo;
    }

    public static Builder newBuilder() {
        return (Builder)DEFAULT_INSTANCE.toBuilder();
    }

    public static Builder newBuilder(FetchEligibleCampaignsRequest fetchEligibleCampaignsRequest) {
        return (Builder)((Builder)DEFAULT_INSTANCE.toBuilder()).mergeFrom((GeneratedMessageLite)fetchEligibleCampaignsRequest);
    }

    public static FetchEligibleCampaignsRequest parseDelimitedFrom(InputStream inputStream) throws IOException {
        return (FetchEligibleCampaignsRequest)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static FetchEligibleCampaignsRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (FetchEligibleCampaignsRequest)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static FetchEligibleCampaignsRequest parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
        return (FetchEligibleCampaignsRequest)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString);
    }

    public static FetchEligibleCampaignsRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (FetchEligibleCampaignsRequest)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static FetchEligibleCampaignsRequest parseFrom(CodedInputStream codedInputStream) throws IOException {
        return (FetchEligibleCampaignsRequest)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream);
    }

    public static FetchEligibleCampaignsRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (FetchEligibleCampaignsRequest)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static FetchEligibleCampaignsRequest parseFrom(InputStream inputStream) throws IOException {
        return (FetchEligibleCampaignsRequest)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static FetchEligibleCampaignsRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (FetchEligibleCampaignsRequest)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static FetchEligibleCampaignsRequest parseFrom(byte[] arrby) throws InvalidProtocolBufferException {
        return (FetchEligibleCampaignsRequest)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby);
    }

    public static FetchEligibleCampaignsRequest parseFrom(byte[] arrby, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (FetchEligibleCampaignsRequest)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Parser<FetchEligibleCampaignsRequest> parser() {
        return DEFAULT_INSTANCE.getParserForType();
    }

    private void removeAlreadySeenCampaigns(int n) {
        this.ensureAlreadySeenCampaignsIsMutable();
        this.alreadySeenCampaigns_.remove(n);
    }

    private void setAlreadySeenCampaigns(int n, CampaignImpression.Builder builder) {
        this.ensureAlreadySeenCampaignsIsMutable();
        this.alreadySeenCampaigns_.set(n, (Object)((CampaignImpression)builder.build()));
    }

    private void setAlreadySeenCampaigns(int n, CampaignImpression campaignImpression) {
        Objects.requireNonNull((Object)((Object)campaignImpression));
        this.ensureAlreadySeenCampaignsIsMutable();
        this.alreadySeenCampaigns_.set(n, (Object)campaignImpression);
    }

    private void setClientSignals(ClientSignalsProto.ClientSignals.Builder builder) {
        this.clientSignals_ = (ClientSignalsProto.ClientSignals)builder.build();
    }

    private void setClientSignals(ClientSignalsProto.ClientSignals clientSignals) {
        Objects.requireNonNull((Object)((Object)clientSignals));
        this.clientSignals_ = clientSignals;
    }

    private void setProjectNumber(String string2) {
        Objects.requireNonNull((Object)string2);
        this.projectNumber_ = string2;
    }

    private void setProjectNumberBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.projectNumber_ = byteString.toStringUtf8();
    }

    private void setRequestingClientApp(ClientAppInfo.Builder builder) {
        this.requestingClientApp_ = (ClientAppInfo)builder.build();
    }

    private void setRequestingClientApp(ClientAppInfo clientAppInfo) {
        Objects.requireNonNull((Object)((Object)clientAppInfo));
        this.requestingClientApp_ = clientAppInfo;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke var1_1, Object var2_2, Object var3_3) {
        switch (var1_1.ordinal()) {
            default: {
                throw new UnsupportedOperationException();
            }
            case 7: {
                if (FetchEligibleCampaignsRequest.PARSER != null) return FetchEligibleCampaignsRequest.PARSER;
                var23_4 = FetchEligibleCampaignsRequest.class;
                // MONITORENTER : com.google.internal.firebase.inappmessaging.v1.sdkserving.FetchEligibleCampaignsRequest.class
                if (FetchEligibleCampaignsRequest.PARSER == null) {
                    FetchEligibleCampaignsRequest.PARSER = new GeneratedMessageLite.DefaultInstanceBasedParser((GeneratedMessageLite)FetchEligibleCampaignsRequest.DEFAULT_INSTANCE);
                }
                // MONITOREXIT : var23_4
                return FetchEligibleCampaignsRequest.PARSER;
            }
            case 2: {
                var6_5 = (CodedInputStream)var2_2;
                var7_6 = (ExtensionRegistryLite)var3_3;
                var8_7 = false;
lbl16: // 5 sources:
                do {
                    if (var8_7 != false) return FetchEligibleCampaignsRequest.DEFAULT_INSTANCE;
                    var12_8 = var6_5.readTag();
                    if (var12_8 == 0) ** GOTO lbl38
                    if (var12_8 == 10) ** GOTO lbl36
                    if (var12_8 == 18) ** GOTO lbl34
                    if (var12_8 == 26) ** GOTO lbl30
                    if (var12_8 != 34) {
                        if (var6_5.skipField(var12_8)) continue;
                    } else {
                        var18_12 = this.clientSignals_;
                        var19_13 = var18_12 != null ? (ClientSignalsProto.ClientSignals.Builder)var18_12.toBuilder() : null;
lbl30: // 1 sources:
                        if (!this.alreadySeenCampaigns_.isModifiable()) {
                            this.alreadySeenCampaigns_ = GeneratedMessageLite.mutableCopy(this.alreadySeenCampaigns_);
                        }
                        this.alreadySeenCampaigns_.add((Object)((CampaignImpression)var6_5.readMessage(CampaignImpression.parser(), var7_6)));
                        continue;
lbl34: // 1 sources:
                        var13_9 = this.requestingClientApp_;
                        var14_10 = var13_9 != null ? (ClientAppInfo.Builder)var13_9.toBuilder() : null;
lbl36: // 1 sources:
                        this.projectNumber_ = var6_5.readStringRequireUtf8();
                        continue;
                    }
lbl38: // 2 sources:
                    var8_7 = true;
                    continue;
                    catch (IOException var11_16) {
                        throw new RuntimeException((Throwable)new InvalidProtocolBufferException(var11_16.getMessage()).setUnfinishedMessage((MessageLite)this));
                    }
                    catch (InvalidProtocolBufferException var9_17) {
                        throw new RuntimeException((Throwable)var9_17.setUnfinishedMessage((MessageLite)this));
                    }
                    break;
                } while (true);
            }
            case 6: {
                return FetchEligibleCampaignsRequest.DEFAULT_INSTANCE;
            }
            case 1: {
                var4_18 = (GeneratedMessageLite.Visitor)var2_2;
                var5_19 = (FetchEligibleCampaignsRequest)var3_3;
                this.projectNumber_ = var4_18.visitString(true ^ this.projectNumber_.isEmpty(), this.projectNumber_, true ^ var5_19.projectNumber_.isEmpty(), var5_19.projectNumber_);
                this.requestingClientApp_ = (ClientAppInfo)var4_18.visitMessage((MessageLite)this.requestingClientApp_, (MessageLite)var5_19.requestingClientApp_);
                this.alreadySeenCampaigns_ = var4_18.visitList(this.alreadySeenCampaigns_, var5_19.alreadySeenCampaigns_);
                this.clientSignals_ = (ClientSignalsProto.ClientSignals)var4_18.visitMessage((MessageLite)this.clientSignals_, (MessageLite)var5_19.clientSignals_);
                if (var4_18 != GeneratedMessageLite.MergeFromVisitor.INSTANCE) return this;
                this.bitField0_ |= var5_19.bitField0_;
                return this;
            }
            case 5: {
                return new Builder(null);
            }
            case 3: {
                this.alreadySeenCampaigns_.makeImmutable();
                return null;
            }
            case 0: {
                return FetchEligibleCampaignsRequest.DEFAULT_INSTANCE;
            }
            case 4: {
                return new FetchEligibleCampaignsRequest();
            }
        }
        this.clientSignals_ = var20_14 = (ClientSignalsProto.ClientSignals)var6_5.readMessage(ClientSignalsProto.ClientSignals.parser(), var7_6);
        if (var19_13 == null) ** GOTO lbl16
        var19_13.mergeFrom((GeneratedMessageLite)var20_14);
        this.clientSignals_ = (ClientSignalsProto.ClientSignals)var19_13.buildPartial();
        ** GOTO lbl16
        this.requestingClientApp_ = var15_11 = (ClientAppInfo)var6_5.readMessage(ClientAppInfo.parser(), var7_6);
        if (var14_10 == null) ** GOTO lbl16
        var14_10.mergeFrom((GeneratedMessageLite)var15_11);
        this.requestingClientApp_ = (ClientAppInfo)var14_10.buildPartial();
        ** while (true)
    }

    public CampaignImpression getAlreadySeenCampaigns(int n) {
        return (CampaignImpression)((Object)this.alreadySeenCampaigns_.get(n));
    }

    public int getAlreadySeenCampaignsCount() {
        return this.alreadySeenCampaigns_.size();
    }

    public List<CampaignImpression> getAlreadySeenCampaignsList() {
        return this.alreadySeenCampaigns_;
    }

    public CampaignImpressionOrBuilder getAlreadySeenCampaignsOrBuilder(int n) {
        return (CampaignImpressionOrBuilder)this.alreadySeenCampaigns_.get(n);
    }

    public List<? extends CampaignImpressionOrBuilder> getAlreadySeenCampaignsOrBuilderList() {
        return this.alreadySeenCampaigns_;
    }

    public ClientSignalsProto.ClientSignals getClientSignals() {
        ClientSignalsProto.ClientSignals clientSignals = this.clientSignals_;
        if (clientSignals == null) {
            clientSignals = ClientSignalsProto.ClientSignals.getDefaultInstance();
        }
        return clientSignals;
    }

    public String getProjectNumber() {
        return this.projectNumber_;
    }

    public ByteString getProjectNumberBytes() {
        return ByteString.copyFromUtf8((String)this.projectNumber_);
    }

    public ClientAppInfo getRequestingClientApp() {
        ClientAppInfo clientAppInfo = this.requestingClientApp_;
        if (clientAppInfo == null) {
            clientAppInfo = ClientAppInfo.getDefaultInstance();
        }
        return clientAppInfo;
    }

    public int getSerializedSize() {
        int n = this.memoizedSerializedSize;
        if (n != -1) {
            return n;
        }
        int n2 = !this.projectNumber_.isEmpty() ? 0 + CodedOutputStream.computeStringSize((int)1, (String)this.getProjectNumber()) : 0;
        ClientAppInfo clientAppInfo = this.requestingClientApp_;
        int n3 = 0;
        if (clientAppInfo != null) {
            n2 += CodedOutputStream.computeMessageSize((int)2, (MessageLite)this.getRequestingClientApp());
        }
        while (n3 < this.alreadySeenCampaigns_.size()) {
            n2 += CodedOutputStream.computeMessageSize((int)3, (MessageLite)((MessageLite)this.alreadySeenCampaigns_.get(n3)));
            ++n3;
        }
        if (this.clientSignals_ != null) {
            n2 += CodedOutputStream.computeMessageSize((int)4, (MessageLite)this.getClientSignals());
        }
        this.memoizedSerializedSize = n2;
        return n2;
    }

    public boolean hasClientSignals() {
        return this.clientSignals_ != null;
    }

    public boolean hasRequestingClientApp() {
        return this.requestingClientApp_ != null;
    }

    public void writeTo(CodedOutputStream codedOutputStream) throws IOException {
        if (!this.projectNumber_.isEmpty()) {
            codedOutputStream.writeString(1, this.getProjectNumber());
        }
        if (this.requestingClientApp_ != null) {
            codedOutputStream.writeMessage(2, (MessageLite)this.getRequestingClientApp());
        }
        for (int i = 0; i < this.alreadySeenCampaigns_.size(); ++i) {
            codedOutputStream.writeMessage(3, (MessageLite)this.alreadySeenCampaigns_.get(i));
        }
        if (this.clientSignals_ != null) {
            codedOutputStream.writeMessage(4, (MessageLite)this.getClientSignals());
        }
    }

    public static final class Builder
    extends GeneratedMessageLite.Builder<FetchEligibleCampaignsRequest, Builder>
    implements FetchEligibleCampaignsRequestOrBuilder {
        private Builder() {
            super((GeneratedMessageLite)DEFAULT_INSTANCE);
        }

        public /* synthetic */ Builder(1 var1_1) {
            this();
        }

        public Builder addAllAlreadySeenCampaigns(Iterable<? extends CampaignImpression> iterable) {
            this.copyOnWrite();
            ((FetchEligibleCampaignsRequest)this.instance).addAllAlreadySeenCampaigns((Iterable<? extends CampaignImpression>)iterable);
            return this;
        }

        public Builder addAlreadySeenCampaigns(int n, CampaignImpression.Builder builder) {
            this.copyOnWrite();
            ((FetchEligibleCampaignsRequest)this.instance).addAlreadySeenCampaigns(n, builder);
            return this;
        }

        public Builder addAlreadySeenCampaigns(int n, CampaignImpression campaignImpression) {
            this.copyOnWrite();
            ((FetchEligibleCampaignsRequest)this.instance).addAlreadySeenCampaigns(n, campaignImpression);
            return this;
        }

        public Builder addAlreadySeenCampaigns(CampaignImpression.Builder builder) {
            this.copyOnWrite();
            ((FetchEligibleCampaignsRequest)this.instance).addAlreadySeenCampaigns(builder);
            return this;
        }

        public Builder addAlreadySeenCampaigns(CampaignImpression campaignImpression) {
            this.copyOnWrite();
            ((FetchEligibleCampaignsRequest)this.instance).addAlreadySeenCampaigns(campaignImpression);
            return this;
        }

        public Builder clearAlreadySeenCampaigns() {
            this.copyOnWrite();
            ((FetchEligibleCampaignsRequest)this.instance).clearAlreadySeenCampaigns();
            return this;
        }

        public Builder clearClientSignals() {
            this.copyOnWrite();
            ((FetchEligibleCampaignsRequest)this.instance).clearClientSignals();
            return this;
        }

        public Builder clearProjectNumber() {
            this.copyOnWrite();
            ((FetchEligibleCampaignsRequest)this.instance).clearProjectNumber();
            return this;
        }

        public Builder clearRequestingClientApp() {
            this.copyOnWrite();
            ((FetchEligibleCampaignsRequest)this.instance).clearRequestingClientApp();
            return this;
        }

        public CampaignImpression getAlreadySeenCampaigns(int n) {
            return ((FetchEligibleCampaignsRequest)this.instance).getAlreadySeenCampaigns(n);
        }

        public int getAlreadySeenCampaignsCount() {
            return ((FetchEligibleCampaignsRequest)this.instance).getAlreadySeenCampaignsCount();
        }

        public List<CampaignImpression> getAlreadySeenCampaignsList() {
            return Collections.unmodifiableList(((FetchEligibleCampaignsRequest)this.instance).getAlreadySeenCampaignsList());
        }

        public ClientSignalsProto.ClientSignals getClientSignals() {
            return ((FetchEligibleCampaignsRequest)this.instance).getClientSignals();
        }

        public String getProjectNumber() {
            return ((FetchEligibleCampaignsRequest)this.instance).getProjectNumber();
        }

        public ByteString getProjectNumberBytes() {
            return ((FetchEligibleCampaignsRequest)this.instance).getProjectNumberBytes();
        }

        public ClientAppInfo getRequestingClientApp() {
            return ((FetchEligibleCampaignsRequest)this.instance).getRequestingClientApp();
        }

        public boolean hasClientSignals() {
            return ((FetchEligibleCampaignsRequest)this.instance).hasClientSignals();
        }

        public boolean hasRequestingClientApp() {
            return ((FetchEligibleCampaignsRequest)this.instance).hasRequestingClientApp();
        }

        public Builder mergeClientSignals(ClientSignalsProto.ClientSignals clientSignals) {
            this.copyOnWrite();
            ((FetchEligibleCampaignsRequest)this.instance).mergeClientSignals(clientSignals);
            return this;
        }

        public Builder mergeRequestingClientApp(ClientAppInfo clientAppInfo) {
            this.copyOnWrite();
            ((FetchEligibleCampaignsRequest)this.instance).mergeRequestingClientApp(clientAppInfo);
            return this;
        }

        public Builder removeAlreadySeenCampaigns(int n) {
            this.copyOnWrite();
            ((FetchEligibleCampaignsRequest)this.instance).removeAlreadySeenCampaigns(n);
            return this;
        }

        public Builder setAlreadySeenCampaigns(int n, CampaignImpression.Builder builder) {
            this.copyOnWrite();
            ((FetchEligibleCampaignsRequest)this.instance).setAlreadySeenCampaigns(n, builder);
            return this;
        }

        public Builder setAlreadySeenCampaigns(int n, CampaignImpression campaignImpression) {
            this.copyOnWrite();
            ((FetchEligibleCampaignsRequest)this.instance).setAlreadySeenCampaigns(n, campaignImpression);
            return this;
        }

        public Builder setClientSignals(ClientSignalsProto.ClientSignals.Builder builder) {
            this.copyOnWrite();
            ((FetchEligibleCampaignsRequest)this.instance).setClientSignals(builder);
            return this;
        }

        public Builder setClientSignals(ClientSignalsProto.ClientSignals clientSignals) {
            this.copyOnWrite();
            ((FetchEligibleCampaignsRequest)this.instance).setClientSignals(clientSignals);
            return this;
        }

        public Builder setProjectNumber(String string2) {
            this.copyOnWrite();
            ((FetchEligibleCampaignsRequest)this.instance).setProjectNumber(string2);
            return this;
        }

        public Builder setProjectNumberBytes(ByteString byteString) {
            this.copyOnWrite();
            ((FetchEligibleCampaignsRequest)this.instance).setProjectNumberBytes(byteString);
            return this;
        }

        public Builder setRequestingClientApp(ClientAppInfo.Builder builder) {
            this.copyOnWrite();
            ((FetchEligibleCampaignsRequest)this.instance).setRequestingClientApp(builder);
            return this;
        }

        public Builder setRequestingClientApp(ClientAppInfo clientAppInfo) {
            this.copyOnWrite();
            ((FetchEligibleCampaignsRequest)this.instance).setRequestingClientApp(clientAppInfo);
            return this;
        }
    }

}

