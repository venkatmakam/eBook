/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.cloud.audit.RequestMetadata$1
 *  com.google.cloud.audit.RequestMetadataOrBuilder
 *  com.google.protobuf.AbstractMessageLite
 *  com.google.protobuf.ByteString
 *  com.google.protobuf.CodedInputStream
 *  com.google.protobuf.CodedOutputStream
 *  com.google.protobuf.ExtensionRegistryLite
 *  com.google.protobuf.GeneratedMessageLite
 *  com.google.protobuf.GeneratedMessageLite$Builder
 *  com.google.protobuf.GeneratedMessageLite$DefaultInstanceBasedParser
 *  com.google.protobuf.GeneratedMessageLite$MethodToInvoke
 *  com.google.protobuf.GeneratedMessageLite$Visitor
 *  com.google.protobuf.InvalidProtocolBufferException
 *  com.google.protobuf.MessageLite
 *  com.google.protobuf.Parser
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 *  java.util.Objects
 */
package com.google.cloud.audit;

import com.google.cloud.audit.RequestMetadata;
import com.google.cloud.audit.RequestMetadataOrBuilder;
import com.google.protobuf.AbstractMessageLite;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.CodedOutputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.MessageLite;
import com.google.protobuf.Parser;
import java.io.IOException;
import java.io.InputStream;
import java.util.Objects;

public final class RequestMetadata
extends GeneratedMessageLite<RequestMetadata, Builder>
implements RequestMetadataOrBuilder {
    public static final int CALLER_IP_FIELD_NUMBER = 1;
    public static final int CALLER_SUPPLIED_USER_AGENT_FIELD_NUMBER = 2;
    private static final RequestMetadata DEFAULT_INSTANCE;
    private static volatile Parser<RequestMetadata> PARSER;
    private String callerIp_ = "";
    private String callerSuppliedUserAgent_ = "";

    public static {
        RequestMetadata requestMetadata;
        DEFAULT_INSTANCE = requestMetadata = new RequestMetadata();
        requestMetadata.makeImmutable();
    }

    private RequestMetadata() {
    }

    private void clearCallerIp() {
        this.callerIp_ = RequestMetadata.getDefaultInstance().getCallerIp();
    }

    private void clearCallerSuppliedUserAgent() {
        this.callerSuppliedUserAgent_ = RequestMetadata.getDefaultInstance().getCallerSuppliedUserAgent();
    }

    public static RequestMetadata getDefaultInstance() {
        return DEFAULT_INSTANCE;
    }

    public static Builder newBuilder() {
        return (Builder)DEFAULT_INSTANCE.toBuilder();
    }

    public static Builder newBuilder(RequestMetadata requestMetadata) {
        return (Builder)((Builder)DEFAULT_INSTANCE.toBuilder()).mergeFrom((GeneratedMessageLite)requestMetadata);
    }

    public static RequestMetadata parseDelimitedFrom(InputStream inputStream) throws IOException {
        return (RequestMetadata)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static RequestMetadata parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (RequestMetadata)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static RequestMetadata parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
        return (RequestMetadata)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString);
    }

    public static RequestMetadata parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (RequestMetadata)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static RequestMetadata parseFrom(CodedInputStream codedInputStream) throws IOException {
        return (RequestMetadata)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream);
    }

    public static RequestMetadata parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (RequestMetadata)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static RequestMetadata parseFrom(InputStream inputStream) throws IOException {
        return (RequestMetadata)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static RequestMetadata parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (RequestMetadata)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static RequestMetadata parseFrom(byte[] arrby) throws InvalidProtocolBufferException {
        return (RequestMetadata)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby);
    }

    public static RequestMetadata parseFrom(byte[] arrby, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (RequestMetadata)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Parser<RequestMetadata> parser() {
        return DEFAULT_INSTANCE.getParserForType();
    }

    private void setCallerIp(String string2) {
        Objects.requireNonNull((Object)string2);
        this.callerIp_ = string2;
    }

    private void setCallerIpBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.callerIp_ = byteString.toStringUtf8();
    }

    private void setCallerSuppliedUserAgent(String string2) {
        Objects.requireNonNull((Object)string2);
        this.callerSuppliedUserAgent_ = string2;
    }

    private void setCallerSuppliedUserAgentBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.callerSuppliedUserAgent_ = byteString.toStringUtf8();
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke var1_1, Object var2_2, Object var3_3) {
        switch (var1_1.ordinal()) {
            default: {
                throw new UnsupportedOperationException();
            }
            case 7: {
                if (RequestMetadata.PARSER != null) return RequestMetadata.PARSER;
                var15_4 = RequestMetadata.class;
                // MONITORENTER : com.google.cloud.audit.RequestMetadata.class
                if (RequestMetadata.PARSER == null) {
                    RequestMetadata.PARSER = new GeneratedMessageLite.DefaultInstanceBasedParser((GeneratedMessageLite)RequestMetadata.DEFAULT_INSTANCE);
                }
                // MONITOREXIT : var15_4
                return RequestMetadata.PARSER;
            }
            case 2: {
                var7_5 = (CodedInputStream)var2_2;
                (ExtensionRegistryLite)var3_3;
                var9_6 = false;
                while (var9_6 == false) {
                    var13_7 = var7_5.readTag();
                    if (var13_7 == 0) ** GOTO lbl29
                    if (var13_7 == 10) ** GOTO lbl27
                    if (var13_7 != 18) {
                        if (var7_5.skipField(var13_7)) continue;
                    } else {
                        this.callerSuppliedUserAgent_ = var7_5.readStringRequireUtf8();
                        continue;
lbl27: // 1 sources:
                        this.callerIp_ = var7_5.readStringRequireUtf8();
                        continue;
                    }
lbl29: // 2 sources:
                    var9_6 = true;
                    continue;
                    catch (IOException var12_9) {
                        throw new RuntimeException((Throwable)new InvalidProtocolBufferException(var12_9.getMessage()).setUnfinishedMessage((MessageLite)this));
                    }
                    catch (InvalidProtocolBufferException var10_10) {
                        throw new RuntimeException((Throwable)var10_10.setUnfinishedMessage((MessageLite)this));
                    }
                }
                return RequestMetadata.DEFAULT_INSTANCE;
            }
            case 6: {
                return RequestMetadata.DEFAULT_INSTANCE;
            }
            case 1: {
                var4_11 = (GeneratedMessageLite.Visitor)var2_2;
                var5_12 = (RequestMetadata)var3_3;
                this.callerIp_ = var4_11.visitString(true ^ this.callerIp_.isEmpty(), this.callerIp_, true ^ var5_12.callerIp_.isEmpty(), var5_12.callerIp_);
                this.callerSuppliedUserAgent_ = var4_11.visitString(true ^ this.callerSuppliedUserAgent_.isEmpty(), this.callerSuppliedUserAgent_, true ^ var5_12.callerSuppliedUserAgent_.isEmpty(), var5_12.callerSuppliedUserAgent_);
                return this;
            }
            case 5: {
                return new Builder(null);
            }
            case 3: {
                return null;
            }
            case 0: {
                return RequestMetadata.DEFAULT_INSTANCE;
            }
            case 4: 
        }
        return new RequestMetadata();
    }

    public String getCallerIp() {
        return this.callerIp_;
    }

    public ByteString getCallerIpBytes() {
        return ByteString.copyFromUtf8((String)this.callerIp_);
    }

    public String getCallerSuppliedUserAgent() {
        return this.callerSuppliedUserAgent_;
    }

    public ByteString getCallerSuppliedUserAgentBytes() {
        return ByteString.copyFromUtf8((String)this.callerSuppliedUserAgent_);
    }

    public int getSerializedSize() {
        int n = this.memoizedSerializedSize;
        if (n != -1) {
            return n;
        }
        boolean bl = this.callerIp_.isEmpty();
        int n2 = 0;
        if (!bl) {
            n2 = 0 + CodedOutputStream.computeStringSize((int)1, (String)this.getCallerIp());
        }
        if (!this.callerSuppliedUserAgent_.isEmpty()) {
            n2 += CodedOutputStream.computeStringSize((int)2, (String)this.getCallerSuppliedUserAgent());
        }
        this.memoizedSerializedSize = n2;
        return n2;
    }

    public void writeTo(CodedOutputStream codedOutputStream) throws IOException {
        if (!this.callerIp_.isEmpty()) {
            codedOutputStream.writeString(1, this.getCallerIp());
        }
        if (!this.callerSuppliedUserAgent_.isEmpty()) {
            codedOutputStream.writeString(2, this.getCallerSuppliedUserAgent());
        }
    }

    public static final class Builder
    extends GeneratedMessageLite.Builder<RequestMetadata, Builder>
    implements RequestMetadataOrBuilder {
        private Builder() {
            super((GeneratedMessageLite)DEFAULT_INSTANCE);
        }

        public /* synthetic */ Builder(1 var1_1) {
            this();
        }

        public Builder clearCallerIp() {
            this.copyOnWrite();
            ((RequestMetadata)this.instance).clearCallerIp();
            return this;
        }

        public Builder clearCallerSuppliedUserAgent() {
            this.copyOnWrite();
            ((RequestMetadata)this.instance).clearCallerSuppliedUserAgent();
            return this;
        }

        public String getCallerIp() {
            return ((RequestMetadata)this.instance).getCallerIp();
        }

        public ByteString getCallerIpBytes() {
            return ((RequestMetadata)this.instance).getCallerIpBytes();
        }

        public String getCallerSuppliedUserAgent() {
            return ((RequestMetadata)this.instance).getCallerSuppliedUserAgent();
        }

        public ByteString getCallerSuppliedUserAgentBytes() {
            return ((RequestMetadata)this.instance).getCallerSuppliedUserAgentBytes();
        }

        public Builder setCallerIp(String string2) {
            this.copyOnWrite();
            ((RequestMetadata)this.instance).setCallerIp(string2);
            return this;
        }

        public Builder setCallerIpBytes(ByteString byteString) {
            this.copyOnWrite();
            ((RequestMetadata)this.instance).setCallerIpBytes(byteString);
            return this;
        }

        public Builder setCallerSuppliedUserAgent(String string2) {
            this.copyOnWrite();
            ((RequestMetadata)this.instance).setCallerSuppliedUserAgent(string2);
            return this;
        }

        public Builder setCallerSuppliedUserAgentBytes(ByteString byteString) {
            this.copyOnWrite();
            ((RequestMetadata)this.instance).setCallerSuppliedUserAgentBytes(byteString);
            return this;
        }
    }

}

