/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.cloud.audit.AuthorizationInfo$1
 *  com.google.cloud.audit.AuthorizationInfoOrBuilder
 *  com.google.protobuf.AbstractMessageLite
 *  com.google.protobuf.ByteString
 *  com.google.protobuf.CodedInputStream
 *  com.google.protobuf.CodedOutputStream
 *  com.google.protobuf.ExtensionRegistryLite
 *  com.google.protobuf.GeneratedMessageLite
 *  com.google.protobuf.GeneratedMessageLite$Builder
 *  com.google.protobuf.GeneratedMessageLite$DefaultInstanceBasedParser
 *  com.google.protobuf.GeneratedMessageLite$MethodToInvoke
 *  com.google.protobuf.GeneratedMessageLite$Visitor
 *  com.google.protobuf.InvalidProtocolBufferException
 *  com.google.protobuf.MessageLite
 *  com.google.protobuf.Parser
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 *  java.util.Objects
 */
package com.google.cloud.audit;

import com.google.cloud.audit.AuthorizationInfo;
import com.google.cloud.audit.AuthorizationInfoOrBuilder;
import com.google.protobuf.AbstractMessageLite;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.CodedOutputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.MessageLite;
import com.google.protobuf.Parser;
import java.io.IOException;
import java.io.InputStream;
import java.util.Objects;

public final class AuthorizationInfo
extends GeneratedMessageLite<AuthorizationInfo, Builder>
implements AuthorizationInfoOrBuilder {
    private static final AuthorizationInfo DEFAULT_INSTANCE;
    public static final int GRANTED_FIELD_NUMBER = 3;
    private static volatile Parser<AuthorizationInfo> PARSER;
    public static final int PERMISSION_FIELD_NUMBER = 2;
    public static final int RESOURCE_FIELD_NUMBER = 1;
    private boolean granted_;
    private String permission_ = "";
    private String resource_ = "";

    public static {
        AuthorizationInfo authorizationInfo;
        DEFAULT_INSTANCE = authorizationInfo = new AuthorizationInfo();
        authorizationInfo.makeImmutable();
    }

    private AuthorizationInfo() {
    }

    private void clearGranted() {
        this.granted_ = false;
    }

    private void clearPermission() {
        this.permission_ = AuthorizationInfo.getDefaultInstance().getPermission();
    }

    private void clearResource() {
        this.resource_ = AuthorizationInfo.getDefaultInstance().getResource();
    }

    public static AuthorizationInfo getDefaultInstance() {
        return DEFAULT_INSTANCE;
    }

    public static Builder newBuilder() {
        return (Builder)DEFAULT_INSTANCE.toBuilder();
    }

    public static Builder newBuilder(AuthorizationInfo authorizationInfo) {
        return (Builder)((Builder)DEFAULT_INSTANCE.toBuilder()).mergeFrom((GeneratedMessageLite)authorizationInfo);
    }

    public static AuthorizationInfo parseDelimitedFrom(InputStream inputStream) throws IOException {
        return (AuthorizationInfo)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static AuthorizationInfo parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (AuthorizationInfo)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static AuthorizationInfo parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
        return (AuthorizationInfo)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString);
    }

    public static AuthorizationInfo parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (AuthorizationInfo)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static AuthorizationInfo parseFrom(CodedInputStream codedInputStream) throws IOException {
        return (AuthorizationInfo)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream);
    }

    public static AuthorizationInfo parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (AuthorizationInfo)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static AuthorizationInfo parseFrom(InputStream inputStream) throws IOException {
        return (AuthorizationInfo)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static AuthorizationInfo parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (AuthorizationInfo)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static AuthorizationInfo parseFrom(byte[] arrby) throws InvalidProtocolBufferException {
        return (AuthorizationInfo)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby);
    }

    public static AuthorizationInfo parseFrom(byte[] arrby, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (AuthorizationInfo)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Parser<AuthorizationInfo> parser() {
        return DEFAULT_INSTANCE.getParserForType();
    }

    private void setGranted(boolean bl) {
        this.granted_ = bl;
    }

    private void setPermission(String string2) {
        Objects.requireNonNull((Object)string2);
        this.permission_ = string2;
    }

    private void setPermissionBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.permission_ = byteString.toStringUtf8();
    }

    private void setResource(String string2) {
        Objects.requireNonNull((Object)string2);
        this.resource_ = string2;
    }

    private void setResourceBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.resource_ = byteString.toStringUtf8();
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke var1_1, Object var2_2, Object var3_3) {
        switch (var1_1.ordinal()) {
            default: {
                throw new UnsupportedOperationException();
            }
            case 7: {
                if (AuthorizationInfo.PARSER != null) return AuthorizationInfo.PARSER;
                var17_4 = AuthorizationInfo.class;
                // MONITORENTER : com.google.cloud.audit.AuthorizationInfo.class
                if (AuthorizationInfo.PARSER == null) {
                    AuthorizationInfo.PARSER = new GeneratedMessageLite.DefaultInstanceBasedParser((GeneratedMessageLite)AuthorizationInfo.DEFAULT_INSTANCE);
                }
                // MONITOREXIT : var17_4
                return AuthorizationInfo.PARSER;
            }
            case 2: {
                var9_5 = (CodedInputStream)var2_2;
                (ExtensionRegistryLite)var3_3;
                var11_6 = false;
                while (var11_6 == false) {
                    var15_7 = var9_5.readTag();
                    if (var15_7 == 0) ** GOTO lbl32
                    if (var15_7 == 10) ** GOTO lbl30
                    if (var15_7 == 18) ** GOTO lbl28
                    if (var15_7 != 24) {
                        if (var9_5.skipField(var15_7)) continue;
                    } else {
                        this.granted_ = var9_5.readBool();
                        continue;
lbl28: // 1 sources:
                        this.permission_ = var9_5.readStringRequireUtf8();
                        continue;
lbl30: // 1 sources:
                        this.resource_ = var9_5.readStringRequireUtf8();
                        continue;
                    }
lbl32: // 2 sources:
                    var11_6 = true;
                    continue;
                    catch (IOException var14_9) {
                        throw new RuntimeException((Throwable)new InvalidProtocolBufferException(var14_9.getMessage()).setUnfinishedMessage((MessageLite)this));
                    }
                    catch (InvalidProtocolBufferException var12_10) {
                        throw new RuntimeException((Throwable)var12_10.setUnfinishedMessage((MessageLite)this));
                    }
                }
                return AuthorizationInfo.DEFAULT_INSTANCE;
            }
            case 6: {
                return AuthorizationInfo.DEFAULT_INSTANCE;
            }
            case 1: {
                var4_11 = (GeneratedMessageLite.Visitor)var2_2;
                var5_12 = (AuthorizationInfo)var3_3;
                this.resource_ = var4_11.visitString(true ^ this.resource_.isEmpty(), this.resource_, true ^ var5_12.resource_.isEmpty(), var5_12.resource_);
                this.permission_ = var4_11.visitString(true ^ this.permission_.isEmpty(), this.permission_, true ^ var5_12.permission_.isEmpty(), var5_12.permission_);
                var6_13 = this.granted_;
                var7_14 = var5_12.granted_;
                this.granted_ = var4_11.visitBoolean(var6_13, var6_13, var7_14, var7_14);
                return this;
            }
            case 5: {
                return new Builder(null);
            }
            case 3: {
                return null;
            }
            case 0: {
                return AuthorizationInfo.DEFAULT_INSTANCE;
            }
            case 4: 
        }
        return new AuthorizationInfo();
    }

    public boolean getGranted() {
        return this.granted_;
    }

    public String getPermission() {
        return this.permission_;
    }

    public ByteString getPermissionBytes() {
        return ByteString.copyFromUtf8((String)this.permission_);
    }

    public String getResource() {
        return this.resource_;
    }

    public ByteString getResourceBytes() {
        return ByteString.copyFromUtf8((String)this.resource_);
    }

    public int getSerializedSize() {
        boolean bl;
        int n = this.memoizedSerializedSize;
        if (n != -1) {
            return n;
        }
        boolean bl2 = this.resource_.isEmpty();
        int n2 = 0;
        if (!bl2) {
            n2 = 0 + CodedOutputStream.computeStringSize((int)1, (String)this.getResource());
        }
        if (!this.permission_.isEmpty()) {
            n2 += CodedOutputStream.computeStringSize((int)2, (String)this.getPermission());
        }
        if (bl = this.granted_) {
            n2 += CodedOutputStream.computeBoolSize((int)3, (boolean)bl);
        }
        this.memoizedSerializedSize = n2;
        return n2;
    }

    public void writeTo(CodedOutputStream codedOutputStream) throws IOException {
        boolean bl;
        if (!this.resource_.isEmpty()) {
            codedOutputStream.writeString(1, this.getResource());
        }
        if (!this.permission_.isEmpty()) {
            codedOutputStream.writeString(2, this.getPermission());
        }
        if (bl = this.granted_) {
            codedOutputStream.writeBool(3, bl);
        }
    }

    public static final class Builder
    extends GeneratedMessageLite.Builder<AuthorizationInfo, Builder>
    implements AuthorizationInfoOrBuilder {
        private Builder() {
            super((GeneratedMessageLite)DEFAULT_INSTANCE);
        }

        public /* synthetic */ Builder(1 var1_1) {
            this();
        }

        public Builder clearGranted() {
            this.copyOnWrite();
            ((AuthorizationInfo)this.instance).clearGranted();
            return this;
        }

        public Builder clearPermission() {
            this.copyOnWrite();
            ((AuthorizationInfo)this.instance).clearPermission();
            return this;
        }

        public Builder clearResource() {
            this.copyOnWrite();
            ((AuthorizationInfo)this.instance).clearResource();
            return this;
        }

        public boolean getGranted() {
            return ((AuthorizationInfo)this.instance).getGranted();
        }

        public String getPermission() {
            return ((AuthorizationInfo)this.instance).getPermission();
        }

        public ByteString getPermissionBytes() {
            return ((AuthorizationInfo)this.instance).getPermissionBytes();
        }

        public String getResource() {
            return ((AuthorizationInfo)this.instance).getResource();
        }

        public ByteString getResourceBytes() {
            return ((AuthorizationInfo)this.instance).getResourceBytes();
        }

        public Builder setGranted(boolean bl) {
            this.copyOnWrite();
            ((AuthorizationInfo)this.instance).setGranted(bl);
            return this;
        }

        public Builder setPermission(String string2) {
            this.copyOnWrite();
            ((AuthorizationInfo)this.instance).setPermission(string2);
            return this;
        }

        public Builder setPermissionBytes(ByteString byteString) {
            this.copyOnWrite();
            ((AuthorizationInfo)this.instance).setPermissionBytes(byteString);
            return this;
        }

        public Builder setResource(String string2) {
            this.copyOnWrite();
            ((AuthorizationInfo)this.instance).setResource(string2);
            return this;
        }

        public Builder setResourceBytes(ByteString byteString) {
            this.copyOnWrite();
            ((AuthorizationInfo)this.instance).setResourceBytes(byteString);
            return this;
        }
    }

}

