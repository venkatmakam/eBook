/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.api.SystemParameterOrBuilder
 *  com.google.api.SystemParameterRule$1
 *  com.google.api.SystemParameterRuleOrBuilder
 *  com.google.protobuf.AbstractMessageLite
 *  com.google.protobuf.ByteString
 *  com.google.protobuf.CodedInputStream
 *  com.google.protobuf.CodedOutputStream
 *  com.google.protobuf.ExtensionRegistryLite
 *  com.google.protobuf.GeneratedMessageLite
 *  com.google.protobuf.GeneratedMessageLite$Builder
 *  com.google.protobuf.GeneratedMessageLite$DefaultInstanceBasedParser
 *  com.google.protobuf.GeneratedMessageLite$MergeFromVisitor
 *  com.google.protobuf.GeneratedMessageLite$MethodToInvoke
 *  com.google.protobuf.GeneratedMessageLite$Visitor
 *  com.google.protobuf.Internal
 *  com.google.protobuf.Internal$ProtobufList
 *  com.google.protobuf.InvalidProtocolBufferException
 *  com.google.protobuf.MessageLite
 *  com.google.protobuf.Parser
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Class
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 *  java.util.Collections
 *  java.util.List
 *  java.util.Objects
 */
package com.google.api;

import com.google.api.SystemParameter;
import com.google.api.SystemParameterOrBuilder;
import com.google.api.SystemParameterRule;
import com.google.api.SystemParameterRuleOrBuilder;
import com.google.protobuf.AbstractMessageLite;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.CodedOutputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.Internal;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.MessageLite;
import com.google.protobuf.Parser;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

public final class SystemParameterRule
extends GeneratedMessageLite<SystemParameterRule, Builder>
implements SystemParameterRuleOrBuilder {
    private static final SystemParameterRule DEFAULT_INSTANCE;
    public static final int PARAMETERS_FIELD_NUMBER = 2;
    private static volatile Parser<SystemParameterRule> PARSER;
    public static final int SELECTOR_FIELD_NUMBER = 1;
    private int bitField0_;
    private Internal.ProtobufList<SystemParameter> parameters_ = GeneratedMessageLite.emptyProtobufList();
    private String selector_ = "";

    public static {
        SystemParameterRule systemParameterRule;
        DEFAULT_INSTANCE = systemParameterRule = new SystemParameterRule();
        systemParameterRule.makeImmutable();
    }

    private SystemParameterRule() {
    }

    private void addAllParameters(Iterable<? extends SystemParameter> iterable) {
        this.ensureParametersIsMutable();
        AbstractMessageLite.addAll(iterable, this.parameters_);
    }

    private void addParameters(int n, SystemParameter.Builder builder) {
        this.ensureParametersIsMutable();
        this.parameters_.add(n, (Object)((SystemParameter)builder.build()));
    }

    private void addParameters(int n, SystemParameter systemParameter) {
        Objects.requireNonNull((Object)((Object)systemParameter));
        this.ensureParametersIsMutable();
        this.parameters_.add(n, (Object)systemParameter);
    }

    private void addParameters(SystemParameter.Builder builder) {
        this.ensureParametersIsMutable();
        this.parameters_.add((Object)((SystemParameter)builder.build()));
    }

    private void addParameters(SystemParameter systemParameter) {
        Objects.requireNonNull((Object)((Object)systemParameter));
        this.ensureParametersIsMutable();
        this.parameters_.add((Object)systemParameter);
    }

    private void clearParameters() {
        this.parameters_ = GeneratedMessageLite.emptyProtobufList();
    }

    private void clearSelector() {
        this.selector_ = SystemParameterRule.getDefaultInstance().getSelector();
    }

    private void ensureParametersIsMutable() {
        if (!this.parameters_.isModifiable()) {
            this.parameters_ = GeneratedMessageLite.mutableCopy(this.parameters_);
        }
    }

    public static SystemParameterRule getDefaultInstance() {
        return DEFAULT_INSTANCE;
    }

    public static Builder newBuilder() {
        return (Builder)DEFAULT_INSTANCE.toBuilder();
    }

    public static Builder newBuilder(SystemParameterRule systemParameterRule) {
        return (Builder)((Builder)DEFAULT_INSTANCE.toBuilder()).mergeFrom((GeneratedMessageLite)systemParameterRule);
    }

    public static SystemParameterRule parseDelimitedFrom(InputStream inputStream) throws IOException {
        return (SystemParameterRule)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static SystemParameterRule parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (SystemParameterRule)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static SystemParameterRule parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
        return (SystemParameterRule)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString);
    }

    public static SystemParameterRule parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (SystemParameterRule)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static SystemParameterRule parseFrom(CodedInputStream codedInputStream) throws IOException {
        return (SystemParameterRule)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream);
    }

    public static SystemParameterRule parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (SystemParameterRule)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static SystemParameterRule parseFrom(InputStream inputStream) throws IOException {
        return (SystemParameterRule)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static SystemParameterRule parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (SystemParameterRule)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static SystemParameterRule parseFrom(byte[] arrby) throws InvalidProtocolBufferException {
        return (SystemParameterRule)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby);
    }

    public static SystemParameterRule parseFrom(byte[] arrby, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (SystemParameterRule)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Parser<SystemParameterRule> parser() {
        return DEFAULT_INSTANCE.getParserForType();
    }

    private void removeParameters(int n) {
        this.ensureParametersIsMutable();
        this.parameters_.remove(n);
    }

    private void setParameters(int n, SystemParameter.Builder builder) {
        this.ensureParametersIsMutable();
        this.parameters_.set(n, (Object)((SystemParameter)builder.build()));
    }

    private void setParameters(int n, SystemParameter systemParameter) {
        Objects.requireNonNull((Object)((Object)systemParameter));
        this.ensureParametersIsMutable();
        this.parameters_.set(n, (Object)systemParameter);
    }

    private void setSelector(String string2) {
        Objects.requireNonNull((Object)string2);
        this.selector_ = string2;
    }

    private void setSelectorBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.selector_ = byteString.toStringUtf8();
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke var1_1, Object var2_2, Object var3_3) {
        switch (var1_1.ordinal()) {
            default: {
                throw new UnsupportedOperationException();
            }
            case 7: {
                if (SystemParameterRule.PARSER != null) return SystemParameterRule.PARSER;
                var15_4 = SystemParameterRule.class;
                // MONITORENTER : com.google.api.SystemParameterRule.class
                if (SystemParameterRule.PARSER == null) {
                    SystemParameterRule.PARSER = new GeneratedMessageLite.DefaultInstanceBasedParser((GeneratedMessageLite)SystemParameterRule.DEFAULT_INSTANCE);
                }
                // MONITOREXIT : var15_4
                return SystemParameterRule.PARSER;
            }
            case 2: {
                var6_5 = (CodedInputStream)var2_2;
                var7_6 = (ExtensionRegistryLite)var3_3;
                var8_7 = false;
                while (var8_7 == false) {
                    var12_8 = var6_5.readTag();
                    if (var12_8 == 0) ** GOTO lbl31
                    if (var12_8 == 10) ** GOTO lbl29
                    if (var12_8 != 18) {
                        if (var6_5.skipField(var12_8)) continue;
                    } else {
                        if (!this.parameters_.isModifiable()) {
                            this.parameters_ = GeneratedMessageLite.mutableCopy(this.parameters_);
                        }
                        this.parameters_.add((Object)((SystemParameter)var6_5.readMessage(SystemParameter.parser(), var7_6)));
                        continue;
lbl29: // 1 sources:
                        this.selector_ = var6_5.readStringRequireUtf8();
                        continue;
                    }
lbl31: // 2 sources:
                    var8_7 = true;
                    continue;
                    catch (IOException var11_10) {
                        throw new RuntimeException((Throwable)new InvalidProtocolBufferException(var11_10.getMessage()).setUnfinishedMessage((MessageLite)this));
                    }
                    catch (InvalidProtocolBufferException var9_11) {
                        throw new RuntimeException((Throwable)var9_11.setUnfinishedMessage((MessageLite)this));
                    }
                }
                return SystemParameterRule.DEFAULT_INSTANCE;
            }
            case 6: {
                return SystemParameterRule.DEFAULT_INSTANCE;
            }
            case 1: {
                var4_12 = (GeneratedMessageLite.Visitor)var2_2;
                var5_13 = (SystemParameterRule)var3_3;
                this.selector_ = var4_12.visitString(true ^ this.selector_.isEmpty(), this.selector_, true ^ var5_13.selector_.isEmpty(), var5_13.selector_);
                this.parameters_ = var4_12.visitList(this.parameters_, var5_13.parameters_);
                if (var4_12 != GeneratedMessageLite.MergeFromVisitor.INSTANCE) return this;
                this.bitField0_ |= var5_13.bitField0_;
                return this;
            }
            case 5: {
                return new Builder(null);
            }
            case 3: {
                this.parameters_.makeImmutable();
                return null;
            }
            case 0: {
                return SystemParameterRule.DEFAULT_INSTANCE;
            }
            case 4: 
        }
        return new SystemParameterRule();
    }

    public SystemParameter getParameters(int n) {
        return (SystemParameter)((Object)this.parameters_.get(n));
    }

    public int getParametersCount() {
        return this.parameters_.size();
    }

    public List<SystemParameter> getParametersList() {
        return this.parameters_;
    }

    public SystemParameterOrBuilder getParametersOrBuilder(int n) {
        return (SystemParameterOrBuilder)this.parameters_.get(n);
    }

    public List<? extends SystemParameterOrBuilder> getParametersOrBuilderList() {
        return this.parameters_;
    }

    public String getSelector() {
        return this.selector_;
    }

    public ByteString getSelectorBytes() {
        return ByteString.copyFromUtf8((String)this.selector_);
    }

    public int getSerializedSize() {
        int n;
        int n2 = this.memoizedSerializedSize;
        if (n2 != -1) {
            return n2;
        }
        boolean bl = this.selector_.isEmpty();
        int n3 = 0;
        if (!bl) {
            n = 0 + CodedOutputStream.computeStringSize((int)1, (String)this.getSelector());
            n3 = 0;
        } else {
            n = 0;
        }
        while (n3 < this.parameters_.size()) {
            n += CodedOutputStream.computeMessageSize((int)2, (MessageLite)((MessageLite)this.parameters_.get(n3)));
            ++n3;
        }
        this.memoizedSerializedSize = n;
        return n;
    }

    public void writeTo(CodedOutputStream codedOutputStream) throws IOException {
        if (!this.selector_.isEmpty()) {
            codedOutputStream.writeString(1, this.getSelector());
        }
        for (int i = 0; i < this.parameters_.size(); ++i) {
            codedOutputStream.writeMessage(2, (MessageLite)this.parameters_.get(i));
        }
    }

    public static final class Builder
    extends GeneratedMessageLite.Builder<SystemParameterRule, Builder>
    implements SystemParameterRuleOrBuilder {
        private Builder() {
            super((GeneratedMessageLite)DEFAULT_INSTANCE);
        }

        public /* synthetic */ Builder(1 var1_1) {
            this();
        }

        public Builder addAllParameters(Iterable<? extends SystemParameter> iterable) {
            this.copyOnWrite();
            ((SystemParameterRule)this.instance).addAllParameters((Iterable<? extends SystemParameter>)iterable);
            return this;
        }

        public Builder addParameters(int n, SystemParameter.Builder builder) {
            this.copyOnWrite();
            ((SystemParameterRule)this.instance).addParameters(n, builder);
            return this;
        }

        public Builder addParameters(int n, SystemParameter systemParameter) {
            this.copyOnWrite();
            ((SystemParameterRule)this.instance).addParameters(n, systemParameter);
            return this;
        }

        public Builder addParameters(SystemParameter.Builder builder) {
            this.copyOnWrite();
            ((SystemParameterRule)this.instance).addParameters(builder);
            return this;
        }

        public Builder addParameters(SystemParameter systemParameter) {
            this.copyOnWrite();
            ((SystemParameterRule)this.instance).addParameters(systemParameter);
            return this;
        }

        public Builder clearParameters() {
            this.copyOnWrite();
            ((SystemParameterRule)this.instance).clearParameters();
            return this;
        }

        public Builder clearSelector() {
            this.copyOnWrite();
            ((SystemParameterRule)this.instance).clearSelector();
            return this;
        }

        public SystemParameter getParameters(int n) {
            return ((SystemParameterRule)this.instance).getParameters(n);
        }

        public int getParametersCount() {
            return ((SystemParameterRule)this.instance).getParametersCount();
        }

        public List<SystemParameter> getParametersList() {
            return Collections.unmodifiableList(((SystemParameterRule)this.instance).getParametersList());
        }

        public String getSelector() {
            return ((SystemParameterRule)this.instance).getSelector();
        }

        public ByteString getSelectorBytes() {
            return ((SystemParameterRule)this.instance).getSelectorBytes();
        }

        public Builder removeParameters(int n) {
            this.copyOnWrite();
            ((SystemParameterRule)this.instance).removeParameters(n);
            return this;
        }

        public Builder setParameters(int n, SystemParameter.Builder builder) {
            this.copyOnWrite();
            ((SystemParameterRule)this.instance).setParameters(n, builder);
            return this;
        }

        public Builder setParameters(int n, SystemParameter systemParameter) {
            this.copyOnWrite();
            ((SystemParameterRule)this.instance).setParameters(n, systemParameter);
            return this;
        }

        public Builder setSelector(String string2) {
            this.copyOnWrite();
            ((SystemParameterRule)this.instance).setSelector(string2);
            return this;
        }

        public Builder setSelectorBytes(ByteString byteString) {
            this.copyOnWrite();
            ((SystemParameterRule)this.instance).setSelectorBytes(byteString);
            return this;
        }
    }

}

