/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.api.AdviceOrBuilder
 *  com.google.api.ChangeType
 *  com.google.api.ConfigChange$1
 *  com.google.api.ConfigChangeOrBuilder
 *  com.google.protobuf.AbstractMessageLite
 *  com.google.protobuf.ByteString
 *  com.google.protobuf.CodedInputStream
 *  com.google.protobuf.CodedOutputStream
 *  com.google.protobuf.ExtensionRegistryLite
 *  com.google.protobuf.GeneratedMessageLite
 *  com.google.protobuf.GeneratedMessageLite$Builder
 *  com.google.protobuf.GeneratedMessageLite$DefaultInstanceBasedParser
 *  com.google.protobuf.GeneratedMessageLite$MergeFromVisitor
 *  com.google.protobuf.GeneratedMessageLite$MethodToInvoke
 *  com.google.protobuf.GeneratedMessageLite$Visitor
 *  com.google.protobuf.Internal
 *  com.google.protobuf.Internal$ProtobufList
 *  com.google.protobuf.InvalidProtocolBufferException
 *  com.google.protobuf.MessageLite
 *  com.google.protobuf.Parser
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Class
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 *  java.util.Collections
 *  java.util.List
 *  java.util.Objects
 */
package com.google.api;

import com.google.api.Advice;
import com.google.api.AdviceOrBuilder;
import com.google.api.ChangeType;
import com.google.api.ConfigChange;
import com.google.api.ConfigChangeOrBuilder;
import com.google.protobuf.AbstractMessageLite;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.CodedOutputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.Internal;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.MessageLite;
import com.google.protobuf.Parser;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

public final class ConfigChange
extends GeneratedMessageLite<ConfigChange, Builder>
implements ConfigChangeOrBuilder {
    public static final int ADVICES_FIELD_NUMBER = 5;
    public static final int CHANGE_TYPE_FIELD_NUMBER = 4;
    private static final ConfigChange DEFAULT_INSTANCE;
    public static final int ELEMENT_FIELD_NUMBER = 1;
    public static final int NEW_VALUE_FIELD_NUMBER = 3;
    public static final int OLD_VALUE_FIELD_NUMBER = 2;
    private static volatile Parser<ConfigChange> PARSER;
    private Internal.ProtobufList<Advice> advices_ = GeneratedMessageLite.emptyProtobufList();
    private int bitField0_;
    private int changeType_;
    private String element_ = "";
    private String newValue_ = "";
    private String oldValue_ = "";

    public static {
        ConfigChange configChange;
        DEFAULT_INSTANCE = configChange = new ConfigChange();
        configChange.makeImmutable();
    }

    private ConfigChange() {
    }

    private void addAdvices(int n, Advice.Builder builder) {
        this.ensureAdvicesIsMutable();
        this.advices_.add(n, (Object)((Advice)builder.build()));
    }

    private void addAdvices(int n, Advice advice) {
        Objects.requireNonNull((Object)((Object)advice));
        this.ensureAdvicesIsMutable();
        this.advices_.add(n, (Object)advice);
    }

    private void addAdvices(Advice.Builder builder) {
        this.ensureAdvicesIsMutable();
        this.advices_.add((Object)((Advice)builder.build()));
    }

    private void addAdvices(Advice advice) {
        Objects.requireNonNull((Object)((Object)advice));
        this.ensureAdvicesIsMutable();
        this.advices_.add((Object)advice);
    }

    private void addAllAdvices(Iterable<? extends Advice> iterable) {
        this.ensureAdvicesIsMutable();
        AbstractMessageLite.addAll(iterable, this.advices_);
    }

    private void clearAdvices() {
        this.advices_ = GeneratedMessageLite.emptyProtobufList();
    }

    private void clearChangeType() {
        this.changeType_ = 0;
    }

    private void clearElement() {
        this.element_ = ConfigChange.getDefaultInstance().getElement();
    }

    private void clearNewValue() {
        this.newValue_ = ConfigChange.getDefaultInstance().getNewValue();
    }

    private void clearOldValue() {
        this.oldValue_ = ConfigChange.getDefaultInstance().getOldValue();
    }

    private void ensureAdvicesIsMutable() {
        if (!this.advices_.isModifiable()) {
            this.advices_ = GeneratedMessageLite.mutableCopy(this.advices_);
        }
    }

    public static ConfigChange getDefaultInstance() {
        return DEFAULT_INSTANCE;
    }

    public static Builder newBuilder() {
        return (Builder)DEFAULT_INSTANCE.toBuilder();
    }

    public static Builder newBuilder(ConfigChange configChange) {
        return (Builder)((Builder)DEFAULT_INSTANCE.toBuilder()).mergeFrom((GeneratedMessageLite)configChange);
    }

    public static ConfigChange parseDelimitedFrom(InputStream inputStream) throws IOException {
        return (ConfigChange)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static ConfigChange parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (ConfigChange)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static ConfigChange parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
        return (ConfigChange)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString);
    }

    public static ConfigChange parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (ConfigChange)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static ConfigChange parseFrom(CodedInputStream codedInputStream) throws IOException {
        return (ConfigChange)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream);
    }

    public static ConfigChange parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (ConfigChange)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static ConfigChange parseFrom(InputStream inputStream) throws IOException {
        return (ConfigChange)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static ConfigChange parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (ConfigChange)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static ConfigChange parseFrom(byte[] arrby) throws InvalidProtocolBufferException {
        return (ConfigChange)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby);
    }

    public static ConfigChange parseFrom(byte[] arrby, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (ConfigChange)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Parser<ConfigChange> parser() {
        return DEFAULT_INSTANCE.getParserForType();
    }

    private void removeAdvices(int n) {
        this.ensureAdvicesIsMutable();
        this.advices_.remove(n);
    }

    private void setAdvices(int n, Advice.Builder builder) {
        this.ensureAdvicesIsMutable();
        this.advices_.set(n, (Object)((Advice)builder.build()));
    }

    private void setAdvices(int n, Advice advice) {
        Objects.requireNonNull((Object)((Object)advice));
        this.ensureAdvicesIsMutable();
        this.advices_.set(n, (Object)advice);
    }

    private void setChangeType(ChangeType changeType) {
        Objects.requireNonNull((Object)changeType);
        this.changeType_ = changeType.getNumber();
    }

    private void setChangeTypeValue(int n) {
        this.changeType_ = n;
    }

    private void setElement(String string2) {
        Objects.requireNonNull((Object)string2);
        this.element_ = string2;
    }

    private void setElementBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.element_ = byteString.toStringUtf8();
    }

    private void setNewValue(String string2) {
        Objects.requireNonNull((Object)string2);
        this.newValue_ = string2;
    }

    private void setNewValueBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.newValue_ = byteString.toStringUtf8();
    }

    private void setOldValue(String string2) {
        Objects.requireNonNull((Object)string2);
        this.oldValue_ = string2;
    }

    private void setOldValueBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.oldValue_ = byteString.toStringUtf8();
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke var1_1, Object var2_2, Object var3_3) {
        var4_4 = var1_1.ordinal();
        var5_5 = false;
        switch (var4_4) {
            default: {
                throw new UnsupportedOperationException();
            }
            case 7: {
                if (ConfigChange.PARSER != null) return ConfigChange.PARSER;
                var20_6 = ConfigChange.class;
                // MONITORENTER : com.google.api.ConfigChange.class
                if (ConfigChange.PARSER == null) {
                    ConfigChange.PARSER = new GeneratedMessageLite.DefaultInstanceBasedParser((GeneratedMessageLite)ConfigChange.DEFAULT_INSTANCE);
                }
                // MONITOREXIT : var20_6
                return ConfigChange.PARSER;
            }
            case 2: {
                var12_7 = (CodedInputStream)var2_2;
                var13_8 = (ExtensionRegistryLite)var3_3;
                while (var5_5 == false) {
                    var17_9 = var12_7.readTag();
                    if (var17_9 == 0) ** GOTO lbl41
                    if (var17_9 == 10) ** GOTO lbl39
                    if (var17_9 == 18) ** GOTO lbl37
                    if (var17_9 == 26) ** GOTO lbl35
                    if (var17_9 == 32) ** GOTO lbl33
                    if (var17_9 != 42) {
                        if (var12_7.skipField(var17_9)) continue;
                    } else {
                        if (!this.advices_.isModifiable()) {
                            this.advices_ = GeneratedMessageLite.mutableCopy(this.advices_);
                        }
                        this.advices_.add((Object)((Advice)var12_7.readMessage(Advice.parser(), var13_8)));
                        continue;
lbl33: // 1 sources:
                        this.changeType_ = var12_7.readEnum();
                        continue;
lbl35: // 1 sources:
                        this.newValue_ = var12_7.readStringRequireUtf8();
                        continue;
lbl37: // 1 sources:
                        this.oldValue_ = var12_7.readStringRequireUtf8();
                        continue;
lbl39: // 1 sources:
                        this.element_ = var12_7.readStringRequireUtf8();
                        continue;
                    }
lbl41: // 2 sources:
                    var5_5 = true;
                    continue;
                    catch (IOException var16_11) {
                        throw new RuntimeException((Throwable)new InvalidProtocolBufferException(var16_11.getMessage()).setUnfinishedMessage((MessageLite)this));
                    }
                    catch (InvalidProtocolBufferException var14_12) {
                        throw new RuntimeException((Throwable)var14_12.setUnfinishedMessage((MessageLite)this));
                    }
                }
                return ConfigChange.DEFAULT_INSTANCE;
            }
            case 6: {
                return ConfigChange.DEFAULT_INSTANCE;
            }
            case 1: {
                var6_13 = (GeneratedMessageLite.Visitor)var2_2;
                var7_14 = (ConfigChange)var3_3;
                this.element_ = var6_13.visitString(true ^ this.element_.isEmpty(), this.element_, true ^ var7_14.element_.isEmpty(), var7_14.element_);
                this.oldValue_ = var6_13.visitString(true ^ this.oldValue_.isEmpty(), this.oldValue_, true ^ var7_14.oldValue_.isEmpty(), var7_14.oldValue_);
                this.newValue_ = var6_13.visitString(true ^ this.newValue_.isEmpty(), this.newValue_, true ^ var7_14.newValue_.isEmpty(), var7_14.newValue_);
                var8_15 = this.changeType_;
                var9_16 = var8_15 != 0;
                var10_17 = var7_14.changeType_;
                var11_18 = false;
                if (var10_17 != 0) {
                    var11_18 = true;
                }
                this.changeType_ = var6_13.visitInt(var9_16, var8_15, var11_18, var10_17);
                this.advices_ = var6_13.visitList(this.advices_, var7_14.advices_);
                if (var6_13 != GeneratedMessageLite.MergeFromVisitor.INSTANCE) return this;
                this.bitField0_ |= var7_14.bitField0_;
                return this;
            }
            case 5: {
                return new Builder(null);
            }
            case 3: {
                this.advices_.makeImmutable();
                return null;
            }
            case 0: {
                return ConfigChange.DEFAULT_INSTANCE;
            }
            case 4: 
        }
        return new ConfigChange();
    }

    public Advice getAdvices(int n) {
        return (Advice)((Object)this.advices_.get(n));
    }

    public int getAdvicesCount() {
        return this.advices_.size();
    }

    public List<Advice> getAdvicesList() {
        return this.advices_;
    }

    public AdviceOrBuilder getAdvicesOrBuilder(int n) {
        return (AdviceOrBuilder)this.advices_.get(n);
    }

    public List<? extends AdviceOrBuilder> getAdvicesOrBuilderList() {
        return this.advices_;
    }

    public ChangeType getChangeType() {
        ChangeType changeType = ChangeType.forNumber((int)this.changeType_);
        if (changeType == null) {
            changeType = ChangeType.UNRECOGNIZED;
        }
        return changeType;
    }

    public int getChangeTypeValue() {
        return this.changeType_;
    }

    public String getElement() {
        return this.element_;
    }

    public ByteString getElementBytes() {
        return ByteString.copyFromUtf8((String)this.element_);
    }

    public String getNewValue() {
        return this.newValue_;
    }

    public ByteString getNewValueBytes() {
        return ByteString.copyFromUtf8((String)this.newValue_);
    }

    public String getOldValue() {
        return this.oldValue_;
    }

    public ByteString getOldValueBytes() {
        return ByteString.copyFromUtf8((String)this.oldValue_);
    }

    public int getSerializedSize() {
        int n = this.memoizedSerializedSize;
        if (n != -1) {
            return n;
        }
        int n2 = !this.element_.isEmpty() ? 0 + CodedOutputStream.computeStringSize((int)1, (String)this.getElement()) : 0;
        if (!this.oldValue_.isEmpty()) {
            n2 += CodedOutputStream.computeStringSize((int)2, (String)this.getOldValue());
        }
        if (!this.newValue_.isEmpty()) {
            n2 += CodedOutputStream.computeStringSize((int)3, (String)this.getNewValue());
        }
        int n3 = this.changeType_;
        int n4 = ChangeType.CHANGE_TYPE_UNSPECIFIED.getNumber();
        int n5 = 0;
        if (n3 != n4) {
            n2 += CodedOutputStream.computeEnumSize((int)4, (int)this.changeType_);
        }
        while (n5 < this.advices_.size()) {
            n2 += CodedOutputStream.computeMessageSize((int)5, (MessageLite)((MessageLite)this.advices_.get(n5)));
            ++n5;
        }
        this.memoizedSerializedSize = n2;
        return n2;
    }

    public void writeTo(CodedOutputStream codedOutputStream) throws IOException {
        if (!this.element_.isEmpty()) {
            codedOutputStream.writeString(1, this.getElement());
        }
        if (!this.oldValue_.isEmpty()) {
            codedOutputStream.writeString(2, this.getOldValue());
        }
        if (!this.newValue_.isEmpty()) {
            codedOutputStream.writeString(3, this.getNewValue());
        }
        if (this.changeType_ != ChangeType.CHANGE_TYPE_UNSPECIFIED.getNumber()) {
            codedOutputStream.writeEnum(4, this.changeType_);
        }
        for (int i = 0; i < this.advices_.size(); ++i) {
            codedOutputStream.writeMessage(5, (MessageLite)this.advices_.get(i));
        }
    }

    public static final class Builder
    extends GeneratedMessageLite.Builder<ConfigChange, Builder>
    implements ConfigChangeOrBuilder {
        private Builder() {
            super((GeneratedMessageLite)DEFAULT_INSTANCE);
        }

        public /* synthetic */ Builder(1 var1_1) {
            this();
        }

        public Builder addAdvices(int n, Advice.Builder builder) {
            this.copyOnWrite();
            ((ConfigChange)this.instance).addAdvices(n, builder);
            return this;
        }

        public Builder addAdvices(int n, Advice advice) {
            this.copyOnWrite();
            ((ConfigChange)this.instance).addAdvices(n, advice);
            return this;
        }

        public Builder addAdvices(Advice.Builder builder) {
            this.copyOnWrite();
            ((ConfigChange)this.instance).addAdvices(builder);
            return this;
        }

        public Builder addAdvices(Advice advice) {
            this.copyOnWrite();
            ((ConfigChange)this.instance).addAdvices(advice);
            return this;
        }

        public Builder addAllAdvices(Iterable<? extends Advice> iterable) {
            this.copyOnWrite();
            ((ConfigChange)this.instance).addAllAdvices((Iterable<? extends Advice>)iterable);
            return this;
        }

        public Builder clearAdvices() {
            this.copyOnWrite();
            ((ConfigChange)this.instance).clearAdvices();
            return this;
        }

        public Builder clearChangeType() {
            this.copyOnWrite();
            ((ConfigChange)this.instance).clearChangeType();
            return this;
        }

        public Builder clearElement() {
            this.copyOnWrite();
            ((ConfigChange)this.instance).clearElement();
            return this;
        }

        public Builder clearNewValue() {
            this.copyOnWrite();
            ((ConfigChange)this.instance).clearNewValue();
            return this;
        }

        public Builder clearOldValue() {
            this.copyOnWrite();
            ((ConfigChange)this.instance).clearOldValue();
            return this;
        }

        public Advice getAdvices(int n) {
            return ((ConfigChange)this.instance).getAdvices(n);
        }

        public int getAdvicesCount() {
            return ((ConfigChange)this.instance).getAdvicesCount();
        }

        public List<Advice> getAdvicesList() {
            return Collections.unmodifiableList(((ConfigChange)this.instance).getAdvicesList());
        }

        public ChangeType getChangeType() {
            return ((ConfigChange)this.instance).getChangeType();
        }

        public int getChangeTypeValue() {
            return ((ConfigChange)this.instance).getChangeTypeValue();
        }

        public String getElement() {
            return ((ConfigChange)this.instance).getElement();
        }

        public ByteString getElementBytes() {
            return ((ConfigChange)this.instance).getElementBytes();
        }

        public String getNewValue() {
            return ((ConfigChange)this.instance).getNewValue();
        }

        public ByteString getNewValueBytes() {
            return ((ConfigChange)this.instance).getNewValueBytes();
        }

        public String getOldValue() {
            return ((ConfigChange)this.instance).getOldValue();
        }

        public ByteString getOldValueBytes() {
            return ((ConfigChange)this.instance).getOldValueBytes();
        }

        public Builder removeAdvices(int n) {
            this.copyOnWrite();
            ((ConfigChange)this.instance).removeAdvices(n);
            return this;
        }

        public Builder setAdvices(int n, Advice.Builder builder) {
            this.copyOnWrite();
            ((ConfigChange)this.instance).setAdvices(n, builder);
            return this;
        }

        public Builder setAdvices(int n, Advice advice) {
            this.copyOnWrite();
            ((ConfigChange)this.instance).setAdvices(n, advice);
            return this;
        }

        public Builder setChangeType(ChangeType changeType) {
            this.copyOnWrite();
            ((ConfigChange)this.instance).setChangeType(changeType);
            return this;
        }

        public Builder setChangeTypeValue(int n) {
            this.copyOnWrite();
            ((ConfigChange)this.instance).setChangeTypeValue(n);
            return this;
        }

        public Builder setElement(String string2) {
            this.copyOnWrite();
            ((ConfigChange)this.instance).setElement(string2);
            return this;
        }

        public Builder setElementBytes(ByteString byteString) {
            this.copyOnWrite();
            ((ConfigChange)this.instance).setElementBytes(byteString);
            return this;
        }

        public Builder setNewValue(String string2) {
            this.copyOnWrite();
            ((ConfigChange)this.instance).setNewValue(string2);
            return this;
        }

        public Builder setNewValueBytes(ByteString byteString) {
            this.copyOnWrite();
            ((ConfigChange)this.instance).setNewValueBytes(byteString);
            return this;
        }

        public Builder setOldValue(String string2) {
            this.copyOnWrite();
            ((ConfigChange)this.instance).setOldValue(string2);
            return this;
        }

        public Builder setOldValueBytes(ByteString byteString) {
            this.copyOnWrite();
            ((ConfigChange)this.instance).setOldValueBytes(byteString);
            return this;
        }
    }

}

