/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.api.AuthRequirementOrBuilder
 *  com.google.api.AuthenticationRule$1
 *  com.google.api.AuthenticationRuleOrBuilder
 *  com.google.protobuf.AbstractMessageLite
 *  com.google.protobuf.ByteString
 *  com.google.protobuf.CodedInputStream
 *  com.google.protobuf.CodedOutputStream
 *  com.google.protobuf.ExtensionRegistryLite
 *  com.google.protobuf.GeneratedMessageLite
 *  com.google.protobuf.GeneratedMessageLite$Builder
 *  com.google.protobuf.GeneratedMessageLite$DefaultInstanceBasedParser
 *  com.google.protobuf.GeneratedMessageLite$MergeFromVisitor
 *  com.google.protobuf.GeneratedMessageLite$MethodToInvoke
 *  com.google.protobuf.GeneratedMessageLite$Visitor
 *  com.google.protobuf.Internal
 *  com.google.protobuf.Internal$ProtobufList
 *  com.google.protobuf.InvalidProtocolBufferException
 *  com.google.protobuf.MessageLite
 *  com.google.protobuf.Parser
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Class
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 *  java.util.Collections
 *  java.util.List
 *  java.util.Objects
 */
package com.google.api;

import com.google.api.AuthRequirement;
import com.google.api.AuthRequirementOrBuilder;
import com.google.api.AuthenticationRule;
import com.google.api.AuthenticationRuleOrBuilder;
import com.google.api.OAuthRequirements;
import com.google.protobuf.AbstractMessageLite;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.CodedOutputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.Internal;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.MessageLite;
import com.google.protobuf.Parser;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

public final class AuthenticationRule
extends GeneratedMessageLite<AuthenticationRule, Builder>
implements AuthenticationRuleOrBuilder {
    public static final int ALLOW_WITHOUT_CREDENTIAL_FIELD_NUMBER = 5;
    private static final AuthenticationRule DEFAULT_INSTANCE;
    public static final int OAUTH_FIELD_NUMBER = 2;
    private static volatile Parser<AuthenticationRule> PARSER;
    public static final int REQUIREMENTS_FIELD_NUMBER = 7;
    public static final int SELECTOR_FIELD_NUMBER = 1;
    private boolean allowWithoutCredential_;
    private int bitField0_;
    private OAuthRequirements oauth_;
    private Internal.ProtobufList<AuthRequirement> requirements_ = GeneratedMessageLite.emptyProtobufList();
    private String selector_ = "";

    public static {
        AuthenticationRule authenticationRule;
        DEFAULT_INSTANCE = authenticationRule = new AuthenticationRule();
        authenticationRule.makeImmutable();
    }

    private AuthenticationRule() {
    }

    private void addAllRequirements(Iterable<? extends AuthRequirement> iterable) {
        this.ensureRequirementsIsMutable();
        AbstractMessageLite.addAll(iterable, this.requirements_);
    }

    private void addRequirements(int n, AuthRequirement.Builder builder) {
        this.ensureRequirementsIsMutable();
        this.requirements_.add(n, (Object)((AuthRequirement)builder.build()));
    }

    private void addRequirements(int n, AuthRequirement authRequirement) {
        Objects.requireNonNull((Object)((Object)authRequirement));
        this.ensureRequirementsIsMutable();
        this.requirements_.add(n, (Object)authRequirement);
    }

    private void addRequirements(AuthRequirement.Builder builder) {
        this.ensureRequirementsIsMutable();
        this.requirements_.add((Object)((AuthRequirement)builder.build()));
    }

    private void addRequirements(AuthRequirement authRequirement) {
        Objects.requireNonNull((Object)((Object)authRequirement));
        this.ensureRequirementsIsMutable();
        this.requirements_.add((Object)authRequirement);
    }

    private void clearAllowWithoutCredential() {
        this.allowWithoutCredential_ = false;
    }

    private void clearOauth() {
        this.oauth_ = null;
    }

    private void clearRequirements() {
        this.requirements_ = GeneratedMessageLite.emptyProtobufList();
    }

    private void clearSelector() {
        this.selector_ = AuthenticationRule.getDefaultInstance().getSelector();
    }

    private void ensureRequirementsIsMutable() {
        if (!this.requirements_.isModifiable()) {
            this.requirements_ = GeneratedMessageLite.mutableCopy(this.requirements_);
        }
    }

    public static AuthenticationRule getDefaultInstance() {
        return DEFAULT_INSTANCE;
    }

    private void mergeOauth(OAuthRequirements oAuthRequirements) {
        OAuthRequirements oAuthRequirements2 = this.oauth_;
        if (oAuthRequirements2 != null && oAuthRequirements2 != OAuthRequirements.getDefaultInstance()) {
            this.oauth_ = (OAuthRequirements)((OAuthRequirements.Builder)OAuthRequirements.newBuilder(this.oauth_).mergeFrom((GeneratedMessageLite)oAuthRequirements)).buildPartial();
            return;
        }
        this.oauth_ = oAuthRequirements;
    }

    public static Builder newBuilder() {
        return (Builder)DEFAULT_INSTANCE.toBuilder();
    }

    public static Builder newBuilder(AuthenticationRule authenticationRule) {
        return (Builder)((Builder)DEFAULT_INSTANCE.toBuilder()).mergeFrom((GeneratedMessageLite)authenticationRule);
    }

    public static AuthenticationRule parseDelimitedFrom(InputStream inputStream) throws IOException {
        return (AuthenticationRule)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static AuthenticationRule parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (AuthenticationRule)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static AuthenticationRule parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
        return (AuthenticationRule)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString);
    }

    public static AuthenticationRule parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (AuthenticationRule)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static AuthenticationRule parseFrom(CodedInputStream codedInputStream) throws IOException {
        return (AuthenticationRule)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream);
    }

    public static AuthenticationRule parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (AuthenticationRule)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static AuthenticationRule parseFrom(InputStream inputStream) throws IOException {
        return (AuthenticationRule)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static AuthenticationRule parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (AuthenticationRule)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static AuthenticationRule parseFrom(byte[] arrby) throws InvalidProtocolBufferException {
        return (AuthenticationRule)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby);
    }

    public static AuthenticationRule parseFrom(byte[] arrby, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (AuthenticationRule)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Parser<AuthenticationRule> parser() {
        return DEFAULT_INSTANCE.getParserForType();
    }

    private void removeRequirements(int n) {
        this.ensureRequirementsIsMutable();
        this.requirements_.remove(n);
    }

    private void setAllowWithoutCredential(boolean bl) {
        this.allowWithoutCredential_ = bl;
    }

    private void setOauth(OAuthRequirements.Builder builder) {
        this.oauth_ = (OAuthRequirements)builder.build();
    }

    private void setOauth(OAuthRequirements oAuthRequirements) {
        Objects.requireNonNull((Object)((Object)oAuthRequirements));
        this.oauth_ = oAuthRequirements;
    }

    private void setRequirements(int n, AuthRequirement.Builder builder) {
        this.ensureRequirementsIsMutable();
        this.requirements_.set(n, (Object)((AuthRequirement)builder.build()));
    }

    private void setRequirements(int n, AuthRequirement authRequirement) {
        Objects.requireNonNull((Object)((Object)authRequirement));
        this.ensureRequirementsIsMutable();
        this.requirements_.set(n, (Object)authRequirement);
    }

    private void setSelector(String string2) {
        Objects.requireNonNull((Object)string2);
        this.selector_ = string2;
    }

    private void setSelectorBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.selector_ = byteString.toStringUtf8();
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke var1_1, Object var2_2, Object var3_3) {
        switch (var1_1.ordinal()) {
            default: {
                throw new UnsupportedOperationException();
            }
            case 7: {
                if (AuthenticationRule.PARSER != null) return AuthenticationRule.PARSER;
                var21_4 = AuthenticationRule.class;
                // MONITORENTER : com.google.api.AuthenticationRule.class
                if (AuthenticationRule.PARSER == null) {
                    AuthenticationRule.PARSER = new GeneratedMessageLite.DefaultInstanceBasedParser((GeneratedMessageLite)AuthenticationRule.DEFAULT_INSTANCE);
                }
                // MONITOREXIT : var21_4
                return AuthenticationRule.PARSER;
            }
            case 2: {
                var8_5 = (CodedInputStream)var2_2;
                var9_6 = (ExtensionRegistryLite)var3_3;
                var10_7 = false;
lbl16: // 3 sources:
                do {
                    if (var10_7 != false) return AuthenticationRule.DEFAULT_INSTANCE;
                    var14_10 = var8_5.readTag();
                    if (var14_10 == 0) ** GOTO lbl38
                    if (var14_10 == 10) ** GOTO lbl36
                    if (var14_10 == 18) ** GOTO lbl34
                    if (var14_10 == 40) ** GOTO lbl32
                    if (var14_10 != 58) {
                        if (var8_5.skipField(var14_10)) continue;
                    } else {
                        if (!this.requirements_.isModifiable()) {
                            this.requirements_ = GeneratedMessageLite.mutableCopy(this.requirements_);
                        }
                        this.requirements_.add((Object)((AuthRequirement)var8_5.readMessage(AuthRequirement.parser(), var9_6)));
                        continue;
lbl32: // 1 sources:
                        this.allowWithoutCredential_ = var8_5.readBool();
                        continue;
lbl34: // 1 sources:
                        var15_11 = this.oauth_;
                        var16_8 = var15_11 != null ? (OAuthRequirements.Builder)var15_11.toBuilder() : null;
lbl36: // 1 sources:
                        this.selector_ = var8_5.readStringRequireUtf8();
                        continue;
                    }
lbl38: // 2 sources:
                    var10_7 = true;
                    continue;
                    catch (IOException var13_13) {
                        throw new RuntimeException((Throwable)new InvalidProtocolBufferException(var13_13.getMessage()).setUnfinishedMessage((MessageLite)this));
                    }
                    catch (InvalidProtocolBufferException var11_14) {
                        throw new RuntimeException((Throwable)var11_14.setUnfinishedMessage((MessageLite)this));
                    }
                    break;
                } while (true);
            }
            case 6: {
                return AuthenticationRule.DEFAULT_INSTANCE;
            }
            case 1: {
                var4_15 = (GeneratedMessageLite.Visitor)var2_2;
                var5_16 = (AuthenticationRule)var3_3;
                this.selector_ = var4_15.visitString(true ^ this.selector_.isEmpty(), this.selector_, true ^ var5_16.selector_.isEmpty(), var5_16.selector_);
                this.oauth_ = (OAuthRequirements)var4_15.visitMessage((MessageLite)this.oauth_, (MessageLite)var5_16.oauth_);
                var6_17 = this.allowWithoutCredential_;
                var7_18 = var5_16.allowWithoutCredential_;
                this.allowWithoutCredential_ = var4_15.visitBoolean(var6_17, var6_17, var7_18, var7_18);
                this.requirements_ = var4_15.visitList(this.requirements_, var5_16.requirements_);
                if (var4_15 != GeneratedMessageLite.MergeFromVisitor.INSTANCE) return this;
                this.bitField0_ |= var5_16.bitField0_;
                return this;
            }
            case 5: {
                return new Builder(null);
            }
            case 3: {
                this.requirements_.makeImmutable();
                return null;
            }
            case 0: {
                return AuthenticationRule.DEFAULT_INSTANCE;
            }
            case 4: {
                return new AuthenticationRule();
            }
        }
        this.oauth_ = var17_9 = (OAuthRequirements)var8_5.readMessage(OAuthRequirements.parser(), var9_6);
        if (var16_8 == null) ** GOTO lbl16
        var16_8.mergeFrom((GeneratedMessageLite)var17_9);
        this.oauth_ = (OAuthRequirements)var16_8.buildPartial();
        ** while (true)
    }

    public boolean getAllowWithoutCredential() {
        return this.allowWithoutCredential_;
    }

    public OAuthRequirements getOauth() {
        OAuthRequirements oAuthRequirements = this.oauth_;
        if (oAuthRequirements == null) {
            oAuthRequirements = OAuthRequirements.getDefaultInstance();
        }
        return oAuthRequirements;
    }

    public AuthRequirement getRequirements(int n) {
        return (AuthRequirement)((Object)this.requirements_.get(n));
    }

    public int getRequirementsCount() {
        return this.requirements_.size();
    }

    public List<AuthRequirement> getRequirementsList() {
        return this.requirements_;
    }

    public AuthRequirementOrBuilder getRequirementsOrBuilder(int n) {
        return (AuthRequirementOrBuilder)this.requirements_.get(n);
    }

    public List<? extends AuthRequirementOrBuilder> getRequirementsOrBuilderList() {
        return this.requirements_;
    }

    public String getSelector() {
        return this.selector_;
    }

    public ByteString getSelectorBytes() {
        return ByteString.copyFromUtf8((String)this.selector_);
    }

    public int getSerializedSize() {
        int n = this.memoizedSerializedSize;
        if (n != -1) {
            return n;
        }
        int n2 = !this.selector_.isEmpty() ? 0 + CodedOutputStream.computeStringSize((int)1, (String)this.getSelector()) : 0;
        if (this.oauth_ != null) {
            n2 += CodedOutputStream.computeMessageSize((int)2, (MessageLite)this.getOauth());
        }
        boolean bl = this.allowWithoutCredential_;
        int n3 = 0;
        if (bl) {
            n2 += CodedOutputStream.computeBoolSize((int)5, (boolean)bl);
        }
        while (n3 < this.requirements_.size()) {
            n2 += CodedOutputStream.computeMessageSize((int)7, (MessageLite)((MessageLite)this.requirements_.get(n3)));
            ++n3;
        }
        this.memoizedSerializedSize = n2;
        return n2;
    }

    public boolean hasOauth() {
        return this.oauth_ != null;
    }

    public void writeTo(CodedOutputStream codedOutputStream) throws IOException {
        boolean bl;
        if (!this.selector_.isEmpty()) {
            codedOutputStream.writeString(1, this.getSelector());
        }
        if (this.oauth_ != null) {
            codedOutputStream.writeMessage(2, (MessageLite)this.getOauth());
        }
        if (bl = this.allowWithoutCredential_) {
            codedOutputStream.writeBool(5, bl);
        }
        for (int i = 0; i < this.requirements_.size(); ++i) {
            codedOutputStream.writeMessage(7, (MessageLite)this.requirements_.get(i));
        }
    }

    public static final class Builder
    extends GeneratedMessageLite.Builder<AuthenticationRule, Builder>
    implements AuthenticationRuleOrBuilder {
        private Builder() {
            super((GeneratedMessageLite)DEFAULT_INSTANCE);
        }

        public /* synthetic */ Builder(1 var1_1) {
            this();
        }

        public Builder addAllRequirements(Iterable<? extends AuthRequirement> iterable) {
            this.copyOnWrite();
            ((AuthenticationRule)this.instance).addAllRequirements((Iterable<? extends AuthRequirement>)iterable);
            return this;
        }

        public Builder addRequirements(int n, AuthRequirement.Builder builder) {
            this.copyOnWrite();
            ((AuthenticationRule)this.instance).addRequirements(n, builder);
            return this;
        }

        public Builder addRequirements(int n, AuthRequirement authRequirement) {
            this.copyOnWrite();
            ((AuthenticationRule)this.instance).addRequirements(n, authRequirement);
            return this;
        }

        public Builder addRequirements(AuthRequirement.Builder builder) {
            this.copyOnWrite();
            ((AuthenticationRule)this.instance).addRequirements(builder);
            return this;
        }

        public Builder addRequirements(AuthRequirement authRequirement) {
            this.copyOnWrite();
            ((AuthenticationRule)this.instance).addRequirements(authRequirement);
            return this;
        }

        public Builder clearAllowWithoutCredential() {
            this.copyOnWrite();
            ((AuthenticationRule)this.instance).clearAllowWithoutCredential();
            return this;
        }

        public Builder clearOauth() {
            this.copyOnWrite();
            ((AuthenticationRule)this.instance).clearOauth();
            return this;
        }

        public Builder clearRequirements() {
            this.copyOnWrite();
            ((AuthenticationRule)this.instance).clearRequirements();
            return this;
        }

        public Builder clearSelector() {
            this.copyOnWrite();
            ((AuthenticationRule)this.instance).clearSelector();
            return this;
        }

        public boolean getAllowWithoutCredential() {
            return ((AuthenticationRule)this.instance).getAllowWithoutCredential();
        }

        public OAuthRequirements getOauth() {
            return ((AuthenticationRule)this.instance).getOauth();
        }

        public AuthRequirement getRequirements(int n) {
            return ((AuthenticationRule)this.instance).getRequirements(n);
        }

        public int getRequirementsCount() {
            return ((AuthenticationRule)this.instance).getRequirementsCount();
        }

        public List<AuthRequirement> getRequirementsList() {
            return Collections.unmodifiableList(((AuthenticationRule)this.instance).getRequirementsList());
        }

        public String getSelector() {
            return ((AuthenticationRule)this.instance).getSelector();
        }

        public ByteString getSelectorBytes() {
            return ((AuthenticationRule)this.instance).getSelectorBytes();
        }

        public boolean hasOauth() {
            return ((AuthenticationRule)this.instance).hasOauth();
        }

        public Builder mergeOauth(OAuthRequirements oAuthRequirements) {
            this.copyOnWrite();
            ((AuthenticationRule)this.instance).mergeOauth(oAuthRequirements);
            return this;
        }

        public Builder removeRequirements(int n) {
            this.copyOnWrite();
            ((AuthenticationRule)this.instance).removeRequirements(n);
            return this;
        }

        public Builder setAllowWithoutCredential(boolean bl) {
            this.copyOnWrite();
            ((AuthenticationRule)this.instance).setAllowWithoutCredential(bl);
            return this;
        }

        public Builder setOauth(OAuthRequirements.Builder builder) {
            this.copyOnWrite();
            ((AuthenticationRule)this.instance).setOauth(builder);
            return this;
        }

        public Builder setOauth(OAuthRequirements oAuthRequirements) {
            this.copyOnWrite();
            ((AuthenticationRule)this.instance).setOauth(oAuthRequirements);
            return this;
        }

        public Builder setRequirements(int n, AuthRequirement.Builder builder) {
            this.copyOnWrite();
            ((AuthenticationRule)this.instance).setRequirements(n, builder);
            return this;
        }

        public Builder setRequirements(int n, AuthRequirement authRequirement) {
            this.copyOnWrite();
            ((AuthenticationRule)this.instance).setRequirements(n, authRequirement);
            return this;
        }

        public Builder setSelector(String string2) {
            this.copyOnWrite();
            ((AuthenticationRule)this.instance).setSelector(string2);
            return this;
        }

        public Builder setSelectorBytes(ByteString byteString) {
            this.copyOnWrite();
            ((AuthenticationRule)this.instance).setSelectorBytes(byteString);
            return this;
        }
    }

}

