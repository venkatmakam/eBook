/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.api.DocumentationRule$1
 *  com.google.api.DocumentationRuleOrBuilder
 *  com.google.protobuf.AbstractMessageLite
 *  com.google.protobuf.ByteString
 *  com.google.protobuf.CodedInputStream
 *  com.google.protobuf.CodedOutputStream
 *  com.google.protobuf.ExtensionRegistryLite
 *  com.google.protobuf.GeneratedMessageLite
 *  com.google.protobuf.GeneratedMessageLite$Builder
 *  com.google.protobuf.GeneratedMessageLite$DefaultInstanceBasedParser
 *  com.google.protobuf.GeneratedMessageLite$MethodToInvoke
 *  com.google.protobuf.GeneratedMessageLite$Visitor
 *  com.google.protobuf.InvalidProtocolBufferException
 *  com.google.protobuf.MessageLite
 *  com.google.protobuf.Parser
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 *  java.util.Objects
 */
package com.google.api;

import com.google.api.DocumentationRule;
import com.google.api.DocumentationRuleOrBuilder;
import com.google.protobuf.AbstractMessageLite;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.CodedOutputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.MessageLite;
import com.google.protobuf.Parser;
import java.io.IOException;
import java.io.InputStream;
import java.util.Objects;

public final class DocumentationRule
extends GeneratedMessageLite<DocumentationRule, Builder>
implements DocumentationRuleOrBuilder {
    private static final DocumentationRule DEFAULT_INSTANCE;
    public static final int DEPRECATION_DESCRIPTION_FIELD_NUMBER = 3;
    public static final int DESCRIPTION_FIELD_NUMBER = 2;
    private static volatile Parser<DocumentationRule> PARSER;
    public static final int SELECTOR_FIELD_NUMBER = 1;
    private String deprecationDescription_ = "";
    private String description_ = "";
    private String selector_ = "";

    public static {
        DocumentationRule documentationRule;
        DEFAULT_INSTANCE = documentationRule = new DocumentationRule();
        documentationRule.makeImmutable();
    }

    private DocumentationRule() {
    }

    private void clearDeprecationDescription() {
        this.deprecationDescription_ = DocumentationRule.getDefaultInstance().getDeprecationDescription();
    }

    private void clearDescription() {
        this.description_ = DocumentationRule.getDefaultInstance().getDescription();
    }

    private void clearSelector() {
        this.selector_ = DocumentationRule.getDefaultInstance().getSelector();
    }

    public static DocumentationRule getDefaultInstance() {
        return DEFAULT_INSTANCE;
    }

    public static Builder newBuilder() {
        return (Builder)DEFAULT_INSTANCE.toBuilder();
    }

    public static Builder newBuilder(DocumentationRule documentationRule) {
        return (Builder)((Builder)DEFAULT_INSTANCE.toBuilder()).mergeFrom((GeneratedMessageLite)documentationRule);
    }

    public static DocumentationRule parseDelimitedFrom(InputStream inputStream) throws IOException {
        return (DocumentationRule)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static DocumentationRule parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (DocumentationRule)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static DocumentationRule parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
        return (DocumentationRule)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString);
    }

    public static DocumentationRule parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (DocumentationRule)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static DocumentationRule parseFrom(CodedInputStream codedInputStream) throws IOException {
        return (DocumentationRule)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream);
    }

    public static DocumentationRule parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (DocumentationRule)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static DocumentationRule parseFrom(InputStream inputStream) throws IOException {
        return (DocumentationRule)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static DocumentationRule parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (DocumentationRule)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static DocumentationRule parseFrom(byte[] arrby) throws InvalidProtocolBufferException {
        return (DocumentationRule)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby);
    }

    public static DocumentationRule parseFrom(byte[] arrby, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (DocumentationRule)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Parser<DocumentationRule> parser() {
        return DEFAULT_INSTANCE.getParserForType();
    }

    private void setDeprecationDescription(String string2) {
        Objects.requireNonNull((Object)string2);
        this.deprecationDescription_ = string2;
    }

    private void setDeprecationDescriptionBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.deprecationDescription_ = byteString.toStringUtf8();
    }

    private void setDescription(String string2) {
        Objects.requireNonNull((Object)string2);
        this.description_ = string2;
    }

    private void setDescriptionBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.description_ = byteString.toStringUtf8();
    }

    private void setSelector(String string2) {
        Objects.requireNonNull((Object)string2);
        this.selector_ = string2;
    }

    private void setSelectorBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.selector_ = byteString.toStringUtf8();
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke var1_1, Object var2_2, Object var3_3) {
        switch (var1_1.ordinal()) {
            default: {
                throw new UnsupportedOperationException();
            }
            case 7: {
                if (DocumentationRule.PARSER != null) return DocumentationRule.PARSER;
                var15_4 = DocumentationRule.class;
                // MONITORENTER : com.google.api.DocumentationRule.class
                if (DocumentationRule.PARSER == null) {
                    DocumentationRule.PARSER = new GeneratedMessageLite.DefaultInstanceBasedParser((GeneratedMessageLite)DocumentationRule.DEFAULT_INSTANCE);
                }
                // MONITOREXIT : var15_4
                return DocumentationRule.PARSER;
            }
            case 2: {
                var7_5 = (CodedInputStream)var2_2;
                (ExtensionRegistryLite)var3_3;
                var9_6 = false;
                while (var9_6 == false) {
                    var13_7 = var7_5.readTag();
                    if (var13_7 == 0) ** GOTO lbl32
                    if (var13_7 == 10) ** GOTO lbl30
                    if (var13_7 == 18) ** GOTO lbl28
                    if (var13_7 != 26) {
                        if (var7_5.skipField(var13_7)) continue;
                    } else {
                        this.deprecationDescription_ = var7_5.readStringRequireUtf8();
                        continue;
lbl28: // 1 sources:
                        this.description_ = var7_5.readStringRequireUtf8();
                        continue;
lbl30: // 1 sources:
                        this.selector_ = var7_5.readStringRequireUtf8();
                        continue;
                    }
lbl32: // 2 sources:
                    var9_6 = true;
                    continue;
                    catch (IOException var12_9) {
                        throw new RuntimeException((Throwable)new InvalidProtocolBufferException(var12_9.getMessage()).setUnfinishedMessage((MessageLite)this));
                    }
                    catch (InvalidProtocolBufferException var10_10) {
                        throw new RuntimeException((Throwable)var10_10.setUnfinishedMessage((MessageLite)this));
                    }
                }
                return DocumentationRule.DEFAULT_INSTANCE;
            }
            case 6: {
                return DocumentationRule.DEFAULT_INSTANCE;
            }
            case 1: {
                var4_11 = (GeneratedMessageLite.Visitor)var2_2;
                var5_12 = (DocumentationRule)var3_3;
                this.selector_ = var4_11.visitString(true ^ this.selector_.isEmpty(), this.selector_, true ^ var5_12.selector_.isEmpty(), var5_12.selector_);
                this.description_ = var4_11.visitString(true ^ this.description_.isEmpty(), this.description_, true ^ var5_12.description_.isEmpty(), var5_12.description_);
                this.deprecationDescription_ = var4_11.visitString(true ^ this.deprecationDescription_.isEmpty(), this.deprecationDescription_, true ^ var5_12.deprecationDescription_.isEmpty(), var5_12.deprecationDescription_);
                return this;
            }
            case 5: {
                return new Builder(null);
            }
            case 3: {
                return null;
            }
            case 0: {
                return DocumentationRule.DEFAULT_INSTANCE;
            }
            case 4: 
        }
        return new DocumentationRule();
    }

    public String getDeprecationDescription() {
        return this.deprecationDescription_;
    }

    public ByteString getDeprecationDescriptionBytes() {
        return ByteString.copyFromUtf8((String)this.deprecationDescription_);
    }

    public String getDescription() {
        return this.description_;
    }

    public ByteString getDescriptionBytes() {
        return ByteString.copyFromUtf8((String)this.description_);
    }

    public String getSelector() {
        return this.selector_;
    }

    public ByteString getSelectorBytes() {
        return ByteString.copyFromUtf8((String)this.selector_);
    }

    public int getSerializedSize() {
        int n = this.memoizedSerializedSize;
        if (n != -1) {
            return n;
        }
        boolean bl = this.selector_.isEmpty();
        int n2 = 0;
        if (!bl) {
            n2 = 0 + CodedOutputStream.computeStringSize((int)1, (String)this.getSelector());
        }
        if (!this.description_.isEmpty()) {
            n2 += CodedOutputStream.computeStringSize((int)2, (String)this.getDescription());
        }
        if (!this.deprecationDescription_.isEmpty()) {
            n2 += CodedOutputStream.computeStringSize((int)3, (String)this.getDeprecationDescription());
        }
        this.memoizedSerializedSize = n2;
        return n2;
    }

    public void writeTo(CodedOutputStream codedOutputStream) throws IOException {
        if (!this.selector_.isEmpty()) {
            codedOutputStream.writeString(1, this.getSelector());
        }
        if (!this.description_.isEmpty()) {
            codedOutputStream.writeString(2, this.getDescription());
        }
        if (!this.deprecationDescription_.isEmpty()) {
            codedOutputStream.writeString(3, this.getDeprecationDescription());
        }
    }

    public static final class Builder
    extends GeneratedMessageLite.Builder<DocumentationRule, Builder>
    implements DocumentationRuleOrBuilder {
        private Builder() {
            super((GeneratedMessageLite)DEFAULT_INSTANCE);
        }

        public /* synthetic */ Builder(1 var1_1) {
            this();
        }

        public Builder clearDeprecationDescription() {
            this.copyOnWrite();
            ((DocumentationRule)this.instance).clearDeprecationDescription();
            return this;
        }

        public Builder clearDescription() {
            this.copyOnWrite();
            ((DocumentationRule)this.instance).clearDescription();
            return this;
        }

        public Builder clearSelector() {
            this.copyOnWrite();
            ((DocumentationRule)this.instance).clearSelector();
            return this;
        }

        public String getDeprecationDescription() {
            return ((DocumentationRule)this.instance).getDeprecationDescription();
        }

        public ByteString getDeprecationDescriptionBytes() {
            return ((DocumentationRule)this.instance).getDeprecationDescriptionBytes();
        }

        public String getDescription() {
            return ((DocumentationRule)this.instance).getDescription();
        }

        public ByteString getDescriptionBytes() {
            return ((DocumentationRule)this.instance).getDescriptionBytes();
        }

        public String getSelector() {
            return ((DocumentationRule)this.instance).getSelector();
        }

        public ByteString getSelectorBytes() {
            return ((DocumentationRule)this.instance).getSelectorBytes();
        }

        public Builder setDeprecationDescription(String string2) {
            this.copyOnWrite();
            ((DocumentationRule)this.instance).setDeprecationDescription(string2);
            return this;
        }

        public Builder setDeprecationDescriptionBytes(ByteString byteString) {
            this.copyOnWrite();
            ((DocumentationRule)this.instance).setDeprecationDescriptionBytes(byteString);
            return this;
        }

        public Builder setDescription(String string2) {
            this.copyOnWrite();
            ((DocumentationRule)this.instance).setDescription(string2);
            return this;
        }

        public Builder setDescriptionBytes(ByteString byteString) {
            this.copyOnWrite();
            ((DocumentationRule)this.instance).setDescriptionBytes(byteString);
            return this;
        }

        public Builder setSelector(String string2) {
            this.copyOnWrite();
            ((DocumentationRule)this.instance).setSelector(string2);
            return this;
        }

        public Builder setSelectorBytes(ByteString byteString) {
            this.copyOnWrite();
            ((DocumentationRule)this.instance).setSelectorBytes(byteString);
            return this;
        }
    }

}

