/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.api.Experimental$1
 *  com.google.api.ExperimentalOrBuilder
 *  com.google.protobuf.ByteString
 *  com.google.protobuf.CodedInputStream
 *  com.google.protobuf.CodedOutputStream
 *  com.google.protobuf.ExtensionRegistryLite
 *  com.google.protobuf.GeneratedMessageLite
 *  com.google.protobuf.GeneratedMessageLite$Builder
 *  com.google.protobuf.GeneratedMessageLite$DefaultInstanceBasedParser
 *  com.google.protobuf.GeneratedMessageLite$MethodToInvoke
 *  com.google.protobuf.GeneratedMessageLite$Visitor
 *  com.google.protobuf.InvalidProtocolBufferException
 *  com.google.protobuf.MessageLite
 *  com.google.protobuf.Parser
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 *  java.util.Objects
 */
package com.google.api;

import com.google.api.AuthorizationConfig;
import com.google.api.Experimental;
import com.google.api.ExperimentalOrBuilder;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.CodedOutputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.MessageLite;
import com.google.protobuf.Parser;
import java.io.IOException;
import java.io.InputStream;
import java.util.Objects;

public final class Experimental
extends GeneratedMessageLite<Experimental, Builder>
implements ExperimentalOrBuilder {
    public static final int AUTHORIZATION_FIELD_NUMBER = 8;
    private static final Experimental DEFAULT_INSTANCE;
    private static volatile Parser<Experimental> PARSER;
    private AuthorizationConfig authorization_;

    public static {
        Experimental experimental;
        DEFAULT_INSTANCE = experimental = new Experimental();
        experimental.makeImmutable();
    }

    private Experimental() {
    }

    private void clearAuthorization() {
        this.authorization_ = null;
    }

    public static Experimental getDefaultInstance() {
        return DEFAULT_INSTANCE;
    }

    private void mergeAuthorization(AuthorizationConfig authorizationConfig) {
        AuthorizationConfig authorizationConfig2 = this.authorization_;
        if (authorizationConfig2 != null && authorizationConfig2 != AuthorizationConfig.getDefaultInstance()) {
            this.authorization_ = (AuthorizationConfig)((AuthorizationConfig.Builder)AuthorizationConfig.newBuilder(this.authorization_).mergeFrom((GeneratedMessageLite)authorizationConfig)).buildPartial();
            return;
        }
        this.authorization_ = authorizationConfig;
    }

    public static Builder newBuilder() {
        return (Builder)DEFAULT_INSTANCE.toBuilder();
    }

    public static Builder newBuilder(Experimental experimental) {
        return (Builder)((Builder)DEFAULT_INSTANCE.toBuilder()).mergeFrom((GeneratedMessageLite)experimental);
    }

    public static Experimental parseDelimitedFrom(InputStream inputStream) throws IOException {
        return (Experimental)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static Experimental parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (Experimental)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Experimental parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
        return (Experimental)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString);
    }

    public static Experimental parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (Experimental)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Experimental parseFrom(CodedInputStream codedInputStream) throws IOException {
        return (Experimental)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream);
    }

    public static Experimental parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (Experimental)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Experimental parseFrom(InputStream inputStream) throws IOException {
        return (Experimental)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static Experimental parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (Experimental)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Experimental parseFrom(byte[] arrby) throws InvalidProtocolBufferException {
        return (Experimental)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby);
    }

    public static Experimental parseFrom(byte[] arrby, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (Experimental)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Parser<Experimental> parser() {
        return DEFAULT_INSTANCE.getParserForType();
    }

    private void setAuthorization(AuthorizationConfig.Builder builder) {
        this.authorization_ = (AuthorizationConfig)builder.build();
    }

    private void setAuthorization(AuthorizationConfig authorizationConfig) {
        Objects.requireNonNull((Object)((Object)authorizationConfig));
        this.authorization_ = authorizationConfig;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object object, Object object2) {
        switch (methodToInvoke.ordinal()) {
            default: {
                throw new UnsupportedOperationException();
            }
            case 7: {
                if (PARSER != null) return PARSER;
                Class<Experimental> class_ = Experimental.class;
                synchronized (Experimental.class) {
                    if (PARSER != null) return PARSER;
                    PARSER = new GeneratedMessageLite.DefaultInstanceBasedParser((GeneratedMessageLite)DEFAULT_INSTANCE);
                    // ** MonitorExit[var19_4] (shouldn't be in output)
                    return PARSER;
                }
            }
            case 2: {
                CodedInputStream codedInputStream = (CodedInputStream)object;
                ExtensionRegistryLite extensionRegistryLite = (ExtensionRegistryLite)object2;
                boolean bl = false;
                while (!bl) {
                    try {
                        AuthorizationConfig.Builder builder;
                        AuthorizationConfig authorizationConfig;
                        int n = codedInputStream.readTag();
                        if (n != 0) {
                            if (n != 66) {
                                if (codedInputStream.skipField(n)) continue;
                            } else {
                                AuthorizationConfig authorizationConfig2 = this.authorization_;
                                builder = authorizationConfig2 != null ? (AuthorizationConfig.Builder)authorizationConfig2.toBuilder() : null;
                            }
                        }
                        bl = true;
                        continue;
                        this.authorization_ = authorizationConfig = (AuthorizationConfig)codedInputStream.readMessage(AuthorizationConfig.parser(), extensionRegistryLite);
                        if (builder == null) continue;
                        builder.mergeFrom((GeneratedMessageLite)authorizationConfig);
                        this.authorization_ = (AuthorizationConfig)builder.buildPartial();
                    }
                    catch (IOException iOException) {
                        throw new RuntimeException((Throwable)new InvalidProtocolBufferException(iOException.getMessage()).setUnfinishedMessage((MessageLite)this));
                    }
                    catch (InvalidProtocolBufferException invalidProtocolBufferException) {
                        throw new RuntimeException((Throwable)invalidProtocolBufferException.setUnfinishedMessage((MessageLite)this));
                    }
                }
                return DEFAULT_INSTANCE;
            }
            case 6: {
                return DEFAULT_INSTANCE;
            }
            case 1: {
                GeneratedMessageLite.Visitor visitor = (GeneratedMessageLite.Visitor)object;
                Experimental experimental = (Experimental)((Object)object2);
                this.authorization_ = (AuthorizationConfig)visitor.visitMessage((MessageLite)this.authorization_, (MessageLite)experimental.authorization_);
                return this;
            }
            case 5: {
                return new Builder(null);
            }
            case 3: {
                return null;
            }
            case 0: {
                return DEFAULT_INSTANCE;
            }
            case 4: 
        }
        return new Experimental();
    }

    public AuthorizationConfig getAuthorization() {
        AuthorizationConfig authorizationConfig = this.authorization_;
        if (authorizationConfig == null) {
            authorizationConfig = AuthorizationConfig.getDefaultInstance();
        }
        return authorizationConfig;
    }

    public int getSerializedSize() {
        int n = this.memoizedSerializedSize;
        if (n != -1) {
            return n;
        }
        AuthorizationConfig authorizationConfig = this.authorization_;
        int n2 = 0;
        if (authorizationConfig != null) {
            n2 = 0 + CodedOutputStream.computeMessageSize((int)8, (MessageLite)this.getAuthorization());
        }
        this.memoizedSerializedSize = n2;
        return n2;
    }

    public boolean hasAuthorization() {
        return this.authorization_ != null;
    }

    public void writeTo(CodedOutputStream codedOutputStream) throws IOException {
        if (this.authorization_ != null) {
            codedOutputStream.writeMessage(8, (MessageLite)this.getAuthorization());
        }
    }

    public static final class Builder
    extends GeneratedMessageLite.Builder<Experimental, Builder>
    implements ExperimentalOrBuilder {
        private Builder() {
            super((GeneratedMessageLite)DEFAULT_INSTANCE);
        }

        public /* synthetic */ Builder(1 var1_1) {
            this();
        }

        public Builder clearAuthorization() {
            this.copyOnWrite();
            ((Experimental)this.instance).clearAuthorization();
            return this;
        }

        public AuthorizationConfig getAuthorization() {
            return ((Experimental)this.instance).getAuthorization();
        }

        public boolean hasAuthorization() {
            return ((Experimental)this.instance).hasAuthorization();
        }

        public Builder mergeAuthorization(AuthorizationConfig authorizationConfig) {
            this.copyOnWrite();
            ((Experimental)this.instance).mergeAuthorization(authorizationConfig);
            return this;
        }

        public Builder setAuthorization(AuthorizationConfig.Builder builder) {
            this.copyOnWrite();
            ((Experimental)this.instance).setAuthorization(builder);
            return this;
        }

        public Builder setAuthorization(AuthorizationConfig authorizationConfig) {
            this.copyOnWrite();
            ((Experimental)this.instance).setAuthorization(authorizationConfig);
            return this;
        }
    }

}

