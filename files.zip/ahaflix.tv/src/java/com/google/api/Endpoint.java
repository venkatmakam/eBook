/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.api.Endpoint$1
 *  com.google.api.EndpointOrBuilder
 *  com.google.protobuf.AbstractMessageLite
 *  com.google.protobuf.ByteString
 *  com.google.protobuf.CodedInputStream
 *  com.google.protobuf.CodedOutputStream
 *  com.google.protobuf.ExtensionRegistryLite
 *  com.google.protobuf.GeneratedMessageLite
 *  com.google.protobuf.GeneratedMessageLite$Builder
 *  com.google.protobuf.GeneratedMessageLite$DefaultInstanceBasedParser
 *  com.google.protobuf.GeneratedMessageLite$MergeFromVisitor
 *  com.google.protobuf.GeneratedMessageLite$MethodToInvoke
 *  com.google.protobuf.GeneratedMessageLite$Visitor
 *  com.google.protobuf.Internal
 *  com.google.protobuf.Internal$ProtobufList
 *  com.google.protobuf.InvalidProtocolBufferException
 *  com.google.protobuf.MessageLite
 *  com.google.protobuf.Parser
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Class
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 *  java.util.Collections
 *  java.util.List
 *  java.util.Objects
 */
package com.google.api;

import com.google.api.Endpoint;
import com.google.api.EndpointOrBuilder;
import com.google.protobuf.AbstractMessageLite;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.CodedOutputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.Internal;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.MessageLite;
import com.google.protobuf.Parser;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

public final class Endpoint
extends GeneratedMessageLite<Endpoint, Builder>
implements EndpointOrBuilder {
    public static final int ALIASES_FIELD_NUMBER = 2;
    public static final int ALLOW_CORS_FIELD_NUMBER = 5;
    public static final int APIS_FIELD_NUMBER = 3;
    private static final Endpoint DEFAULT_INSTANCE;
    public static final int FEATURES_FIELD_NUMBER = 4;
    public static final int NAME_FIELD_NUMBER = 1;
    private static volatile Parser<Endpoint> PARSER;
    public static final int TARGET_FIELD_NUMBER = 101;
    private Internal.ProtobufList<String> aliases_ = GeneratedMessageLite.emptyProtobufList();
    private boolean allowCors_;
    private Internal.ProtobufList<String> apis_ = GeneratedMessageLite.emptyProtobufList();
    private int bitField0_;
    private Internal.ProtobufList<String> features_ = GeneratedMessageLite.emptyProtobufList();
    private String name_ = "";
    private String target_ = "";

    public static {
        Endpoint endpoint;
        DEFAULT_INSTANCE = endpoint = new Endpoint();
        endpoint.makeImmutable();
    }

    private Endpoint() {
    }

    private void addAliases(String string2) {
        Objects.requireNonNull((Object)string2);
        this.ensureAliasesIsMutable();
        this.aliases_.add((Object)string2);
    }

    private void addAliasesBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.ensureAliasesIsMutable();
        this.aliases_.add((Object)byteString.toStringUtf8());
    }

    private void addAllAliases(Iterable<String> iterable) {
        this.ensureAliasesIsMutable();
        AbstractMessageLite.addAll(iterable, this.aliases_);
    }

    private void addAllApis(Iterable<String> iterable) {
        this.ensureApisIsMutable();
        AbstractMessageLite.addAll(iterable, this.apis_);
    }

    private void addAllFeatures(Iterable<String> iterable) {
        this.ensureFeaturesIsMutable();
        AbstractMessageLite.addAll(iterable, this.features_);
    }

    private void addApis(String string2) {
        Objects.requireNonNull((Object)string2);
        this.ensureApisIsMutable();
        this.apis_.add((Object)string2);
    }

    private void addApisBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.ensureApisIsMutable();
        this.apis_.add((Object)byteString.toStringUtf8());
    }

    private void addFeatures(String string2) {
        Objects.requireNonNull((Object)string2);
        this.ensureFeaturesIsMutable();
        this.features_.add((Object)string2);
    }

    private void addFeaturesBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.ensureFeaturesIsMutable();
        this.features_.add((Object)byteString.toStringUtf8());
    }

    private void clearAliases() {
        this.aliases_ = GeneratedMessageLite.emptyProtobufList();
    }

    private void clearAllowCors() {
        this.allowCors_ = false;
    }

    private void clearApis() {
        this.apis_ = GeneratedMessageLite.emptyProtobufList();
    }

    private void clearFeatures() {
        this.features_ = GeneratedMessageLite.emptyProtobufList();
    }

    private void clearName() {
        this.name_ = Endpoint.getDefaultInstance().getName();
    }

    private void clearTarget() {
        this.target_ = Endpoint.getDefaultInstance().getTarget();
    }

    private void ensureAliasesIsMutable() {
        if (!this.aliases_.isModifiable()) {
            this.aliases_ = GeneratedMessageLite.mutableCopy(this.aliases_);
        }
    }

    private void ensureApisIsMutable() {
        if (!this.apis_.isModifiable()) {
            this.apis_ = GeneratedMessageLite.mutableCopy(this.apis_);
        }
    }

    private void ensureFeaturesIsMutable() {
        if (!this.features_.isModifiable()) {
            this.features_ = GeneratedMessageLite.mutableCopy(this.features_);
        }
    }

    public static Endpoint getDefaultInstance() {
        return DEFAULT_INSTANCE;
    }

    public static Builder newBuilder() {
        return (Builder)DEFAULT_INSTANCE.toBuilder();
    }

    public static Builder newBuilder(Endpoint endpoint) {
        return (Builder)((Builder)DEFAULT_INSTANCE.toBuilder()).mergeFrom((GeneratedMessageLite)endpoint);
    }

    public static Endpoint parseDelimitedFrom(InputStream inputStream) throws IOException {
        return (Endpoint)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static Endpoint parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (Endpoint)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Endpoint parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
        return (Endpoint)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString);
    }

    public static Endpoint parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (Endpoint)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Endpoint parseFrom(CodedInputStream codedInputStream) throws IOException {
        return (Endpoint)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream);
    }

    public static Endpoint parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (Endpoint)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Endpoint parseFrom(InputStream inputStream) throws IOException {
        return (Endpoint)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static Endpoint parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (Endpoint)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Endpoint parseFrom(byte[] arrby) throws InvalidProtocolBufferException {
        return (Endpoint)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby);
    }

    public static Endpoint parseFrom(byte[] arrby, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (Endpoint)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Parser<Endpoint> parser() {
        return DEFAULT_INSTANCE.getParserForType();
    }

    private void setAliases(int n, String string2) {
        Objects.requireNonNull((Object)string2);
        this.ensureAliasesIsMutable();
        this.aliases_.set(n, (Object)string2);
    }

    private void setAllowCors(boolean bl) {
        this.allowCors_ = bl;
    }

    private void setApis(int n, String string2) {
        Objects.requireNonNull((Object)string2);
        this.ensureApisIsMutable();
        this.apis_.set(n, (Object)string2);
    }

    private void setFeatures(int n, String string2) {
        Objects.requireNonNull((Object)string2);
        this.ensureFeaturesIsMutable();
        this.features_.set(n, (Object)string2);
    }

    private void setName(String string2) {
        Objects.requireNonNull((Object)string2);
        this.name_ = string2;
    }

    private void setNameBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.name_ = byteString.toStringUtf8();
    }

    private void setTarget(String string2) {
        Objects.requireNonNull((Object)string2);
        this.target_ = string2;
    }

    private void setTargetBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.target_ = byteString.toStringUtf8();
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke var1_1, Object var2_2, Object var3_3) {
        switch (var1_1.ordinal()) {
            default: {
                throw new UnsupportedOperationException();
            }
            case 7: {
                if (Endpoint.PARSER != null) return Endpoint.PARSER;
                var22_4 = Endpoint.class;
                // MONITORENTER : com.google.api.Endpoint.class
                if (Endpoint.PARSER == null) {
                    Endpoint.PARSER = new GeneratedMessageLite.DefaultInstanceBasedParser((GeneratedMessageLite)Endpoint.DEFAULT_INSTANCE);
                }
                // MONITOREXIT : var22_4
                return Endpoint.PARSER;
            }
            case 2: {
                var8_5 = (CodedInputStream)var2_2;
                (ExtensionRegistryLite)var3_3;
                var10_6 = false;
                while (var10_6 == false) {
                    var14_9 = var8_5.readTag();
                    if (var14_9 == 0) ** GOTO lbl50
                    if (var14_9 == 10) ** GOTO lbl48
                    if (var14_9 == 18) ** GOTO lbl43
                    if (var14_9 == 26) ** GOTO lbl38
                    if (var14_9 == 34) ** GOTO lbl33
                    if (var14_9 == 40) ** GOTO lbl31
                    if (var14_9 != 810) {
                        if (var8_5.skipField(var14_9)) continue;
                    } else {
                        this.target_ = var8_5.readStringRequireUtf8();
                        continue;
lbl31: // 1 sources:
                        this.allowCors_ = var8_5.readBool();
                        continue;
lbl33: // 1 sources:
                        var19_8 = var8_5.readStringRequireUtf8();
                        if (!this.features_.isModifiable()) {
                            this.features_ = GeneratedMessageLite.mutableCopy(this.features_);
                        }
                        this.features_.add((Object)var19_8);
                        continue;
lbl38: // 1 sources:
                        var17_7 = var8_5.readStringRequireUtf8();
                        if (!this.apis_.isModifiable()) {
                            this.apis_ = GeneratedMessageLite.mutableCopy(this.apis_);
                        }
                        this.apis_.add((Object)var17_7);
                        continue;
lbl43: // 1 sources:
                        var15_10 = var8_5.readStringRequireUtf8();
                        if (!this.aliases_.isModifiable()) {
                            this.aliases_ = GeneratedMessageLite.mutableCopy(this.aliases_);
                        }
                        this.aliases_.add((Object)var15_10);
                        continue;
lbl48: // 1 sources:
                        this.name_ = var8_5.readStringRequireUtf8();
                        continue;
                    }
lbl50: // 2 sources:
                    var10_6 = true;
                    continue;
                    catch (IOException var13_12) {
                        throw new RuntimeException((Throwable)new InvalidProtocolBufferException(var13_12.getMessage()).setUnfinishedMessage((MessageLite)this));
                    }
                    catch (InvalidProtocolBufferException var11_13) {
                        throw new RuntimeException((Throwable)var11_13.setUnfinishedMessage((MessageLite)this));
                    }
                }
                return Endpoint.DEFAULT_INSTANCE;
            }
            case 6: {
                return Endpoint.DEFAULT_INSTANCE;
            }
            case 1: {
                var4_14 = (GeneratedMessageLite.Visitor)var2_2;
                var5_15 = (Endpoint)var3_3;
                this.name_ = var4_14.visitString(true ^ this.name_.isEmpty(), this.name_, true ^ var5_15.name_.isEmpty(), var5_15.name_);
                this.aliases_ = var4_14.visitList(this.aliases_, var5_15.aliases_);
                this.apis_ = var4_14.visitList(this.apis_, var5_15.apis_);
                this.features_ = var4_14.visitList(this.features_, var5_15.features_);
                this.target_ = var4_14.visitString(true ^ this.target_.isEmpty(), this.target_, true ^ var5_15.target_.isEmpty(), var5_15.target_);
                var6_16 = this.allowCors_;
                var7_17 = var5_15.allowCors_;
                this.allowCors_ = var4_14.visitBoolean(var6_16, var6_16, var7_17, var7_17);
                if (var4_14 != GeneratedMessageLite.MergeFromVisitor.INSTANCE) return this;
                this.bitField0_ |= var5_15.bitField0_;
                return this;
            }
            case 5: {
                return new Builder(null);
            }
            case 3: {
                this.aliases_.makeImmutable();
                this.apis_.makeImmutable();
                this.features_.makeImmutable();
                return null;
            }
            case 0: {
                return Endpoint.DEFAULT_INSTANCE;
            }
            case 4: 
        }
        return new Endpoint();
    }

    public String getAliases(int n) {
        return (String)this.aliases_.get(n);
    }

    public ByteString getAliasesBytes(int n) {
        return ByteString.copyFromUtf8((String)((String)this.aliases_.get(n)));
    }

    public int getAliasesCount() {
        return this.aliases_.size();
    }

    public List<String> getAliasesList() {
        return this.aliases_;
    }

    public boolean getAllowCors() {
        return this.allowCors_;
    }

    public String getApis(int n) {
        return (String)this.apis_.get(n);
    }

    public ByteString getApisBytes(int n) {
        return ByteString.copyFromUtf8((String)((String)this.apis_.get(n)));
    }

    public int getApisCount() {
        return this.apis_.size();
    }

    public List<String> getApisList() {
        return this.apis_;
    }

    public String getFeatures(int n) {
        return (String)this.features_.get(n);
    }

    public ByteString getFeaturesBytes(int n) {
        return ByteString.copyFromUtf8((String)((String)this.features_.get(n)));
    }

    public int getFeaturesCount() {
        return this.features_.size();
    }

    public List<String> getFeaturesList() {
        return this.features_;
    }

    public String getName() {
        return this.name_;
    }

    public ByteString getNameBytes() {
        return ByteString.copyFromUtf8((String)this.name_);
    }

    public int getSerializedSize() {
        int n = this.memoizedSerializedSize;
        if (n != -1) {
            return n;
        }
        boolean bl = this.name_.isEmpty();
        int n2 = 0;
        int n3 = !bl ? 0 + CodedOutputStream.computeStringSize((int)1, (String)this.getName()) : 0;
        int n4 = 0;
        for (int i = 0; i < this.aliases_.size(); ++i) {
            n4 += CodedOutputStream.computeStringSizeNoTag((String)((String)this.aliases_.get(i)));
        }
        int n5 = n3 + n4 + 1 * this.getAliasesList().size();
        int n6 = 0;
        for (int i = 0; i < this.apis_.size(); ++i) {
            n6 += CodedOutputStream.computeStringSizeNoTag((String)((String)this.apis_.get(i)));
        }
        int n7 = n5 + n6 + 1 * this.getApisList().size();
        int n8 = 0;
        while (n2 < this.features_.size()) {
            n8 += CodedOutputStream.computeStringSizeNoTag((String)((String)this.features_.get(n2)));
            ++n2;
        }
        int n9 = n7 + n8 + 1 * this.getFeaturesList().size();
        boolean bl2 = this.allowCors_;
        if (bl2) {
            n9 += CodedOutputStream.computeBoolSize((int)5, (boolean)bl2);
        }
        if (!this.target_.isEmpty()) {
            n9 += CodedOutputStream.computeStringSize((int)101, (String)this.getTarget());
        }
        this.memoizedSerializedSize = n9;
        return n9;
    }

    public String getTarget() {
        return this.target_;
    }

    public ByteString getTargetBytes() {
        return ByteString.copyFromUtf8((String)this.target_);
    }

    public void writeTo(CodedOutputStream codedOutputStream) throws IOException {
        if (!this.name_.isEmpty()) {
            codedOutputStream.writeString(1, this.getName());
        }
        for (int i = 0; i < this.aliases_.size(); ++i) {
            codedOutputStream.writeString(2, (String)this.aliases_.get(i));
        }
        int n = 0;
        do {
            int n2 = this.apis_.size();
            if (n >= n2) break;
            codedOutputStream.writeString(3, (String)this.apis_.get(n));
            ++n;
        } while (true);
        for (int i = 0; i < this.features_.size(); ++i) {
            codedOutputStream.writeString(4, (String)this.features_.get(i));
        }
        boolean bl = this.allowCors_;
        if (bl) {
            codedOutputStream.writeBool(5, bl);
        }
        if (!this.target_.isEmpty()) {
            codedOutputStream.writeString(101, this.getTarget());
        }
    }

    public static final class Builder
    extends GeneratedMessageLite.Builder<Endpoint, Builder>
    implements EndpointOrBuilder {
        private Builder() {
            super((GeneratedMessageLite)DEFAULT_INSTANCE);
        }

        public /* synthetic */ Builder(1 var1_1) {
            this();
        }

        public Builder addAliases(String string2) {
            this.copyOnWrite();
            ((Endpoint)this.instance).addAliases(string2);
            return this;
        }

        public Builder addAliasesBytes(ByteString byteString) {
            this.copyOnWrite();
            ((Endpoint)this.instance).addAliasesBytes(byteString);
            return this;
        }

        public Builder addAllAliases(Iterable<String> iterable) {
            this.copyOnWrite();
            ((Endpoint)this.instance).addAllAliases((Iterable<String>)iterable);
            return this;
        }

        public Builder addAllApis(Iterable<String> iterable) {
            this.copyOnWrite();
            ((Endpoint)this.instance).addAllApis((Iterable<String>)iterable);
            return this;
        }

        public Builder addAllFeatures(Iterable<String> iterable) {
            this.copyOnWrite();
            ((Endpoint)this.instance).addAllFeatures((Iterable<String>)iterable);
            return this;
        }

        public Builder addApis(String string2) {
            this.copyOnWrite();
            ((Endpoint)this.instance).addApis(string2);
            return this;
        }

        public Builder addApisBytes(ByteString byteString) {
            this.copyOnWrite();
            ((Endpoint)this.instance).addApisBytes(byteString);
            return this;
        }

        public Builder addFeatures(String string2) {
            this.copyOnWrite();
            ((Endpoint)this.instance).addFeatures(string2);
            return this;
        }

        public Builder addFeaturesBytes(ByteString byteString) {
            this.copyOnWrite();
            ((Endpoint)this.instance).addFeaturesBytes(byteString);
            return this;
        }

        public Builder clearAliases() {
            this.copyOnWrite();
            ((Endpoint)this.instance).clearAliases();
            return this;
        }

        public Builder clearAllowCors() {
            this.copyOnWrite();
            ((Endpoint)this.instance).clearAllowCors();
            return this;
        }

        public Builder clearApis() {
            this.copyOnWrite();
            ((Endpoint)this.instance).clearApis();
            return this;
        }

        public Builder clearFeatures() {
            this.copyOnWrite();
            ((Endpoint)this.instance).clearFeatures();
            return this;
        }

        public Builder clearName() {
            this.copyOnWrite();
            ((Endpoint)this.instance).clearName();
            return this;
        }

        public Builder clearTarget() {
            this.copyOnWrite();
            ((Endpoint)this.instance).clearTarget();
            return this;
        }

        public String getAliases(int n) {
            return ((Endpoint)this.instance).getAliases(n);
        }

        public ByteString getAliasesBytes(int n) {
            return ((Endpoint)this.instance).getAliasesBytes(n);
        }

        public int getAliasesCount() {
            return ((Endpoint)this.instance).getAliasesCount();
        }

        public List<String> getAliasesList() {
            return Collections.unmodifiableList(((Endpoint)this.instance).getAliasesList());
        }

        public boolean getAllowCors() {
            return ((Endpoint)this.instance).getAllowCors();
        }

        public String getApis(int n) {
            return ((Endpoint)this.instance).getApis(n);
        }

        public ByteString getApisBytes(int n) {
            return ((Endpoint)this.instance).getApisBytes(n);
        }

        public int getApisCount() {
            return ((Endpoint)this.instance).getApisCount();
        }

        public List<String> getApisList() {
            return Collections.unmodifiableList(((Endpoint)this.instance).getApisList());
        }

        public String getFeatures(int n) {
            return ((Endpoint)this.instance).getFeatures(n);
        }

        public ByteString getFeaturesBytes(int n) {
            return ((Endpoint)this.instance).getFeaturesBytes(n);
        }

        public int getFeaturesCount() {
            return ((Endpoint)this.instance).getFeaturesCount();
        }

        public List<String> getFeaturesList() {
            return Collections.unmodifiableList(((Endpoint)this.instance).getFeaturesList());
        }

        public String getName() {
            return ((Endpoint)this.instance).getName();
        }

        public ByteString getNameBytes() {
            return ((Endpoint)this.instance).getNameBytes();
        }

        public String getTarget() {
            return ((Endpoint)this.instance).getTarget();
        }

        public ByteString getTargetBytes() {
            return ((Endpoint)this.instance).getTargetBytes();
        }

        public Builder setAliases(int n, String string2) {
            this.copyOnWrite();
            ((Endpoint)this.instance).setAliases(n, string2);
            return this;
        }

        public Builder setAllowCors(boolean bl) {
            this.copyOnWrite();
            ((Endpoint)this.instance).setAllowCors(bl);
            return this;
        }

        public Builder setApis(int n, String string2) {
            this.copyOnWrite();
            ((Endpoint)this.instance).setApis(n, string2);
            return this;
        }

        public Builder setFeatures(int n, String string2) {
            this.copyOnWrite();
            ((Endpoint)this.instance).setFeatures(n, string2);
            return this;
        }

        public Builder setName(String string2) {
            this.copyOnWrite();
            ((Endpoint)this.instance).setName(string2);
            return this;
        }

        public Builder setNameBytes(ByteString byteString) {
            this.copyOnWrite();
            ((Endpoint)this.instance).setNameBytes(byteString);
            return this;
        }

        public Builder setTarget(String string2) {
            this.copyOnWrite();
            ((Endpoint)this.instance).setTarget(string2);
            return this;
        }

        public Builder setTargetBytes(ByteString byteString) {
            this.copyOnWrite();
            ((Endpoint)this.instance).setTargetBytes(byteString);
            return this;
        }
    }

}

