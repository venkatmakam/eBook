/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.api.MonitoredResource$1
 *  com.google.api.MonitoredResource$LabelsDefaultEntryHolder
 *  com.google.api.MonitoredResourceOrBuilder
 *  com.google.protobuf.AbstractMessageLite
 *  com.google.protobuf.ByteString
 *  com.google.protobuf.CodedInputStream
 *  com.google.protobuf.CodedOutputStream
 *  com.google.protobuf.ExtensionRegistryLite
 *  com.google.protobuf.GeneratedMessageLite
 *  com.google.protobuf.GeneratedMessageLite$Builder
 *  com.google.protobuf.GeneratedMessageLite$DefaultInstanceBasedParser
 *  com.google.protobuf.GeneratedMessageLite$MergeFromVisitor
 *  com.google.protobuf.GeneratedMessageLite$MethodToInvoke
 *  com.google.protobuf.GeneratedMessageLite$Visitor
 *  com.google.protobuf.InvalidProtocolBufferException
 *  com.google.protobuf.MapEntryLite
 *  com.google.protobuf.MapFieldLite
 *  com.google.protobuf.MessageLite
 *  com.google.protobuf.Parser
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Class
 *  java.lang.Deprecated
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 *  java.util.Collections
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Objects
 *  java.util.Set
 */
package com.google.api;

import com.google.api.MonitoredResource;
import com.google.api.MonitoredResourceOrBuilder;
import com.google.protobuf.AbstractMessageLite;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.CodedOutputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.MapEntryLite;
import com.google.protobuf.MapFieldLite;
import com.google.protobuf.MessageLite;
import com.google.protobuf.Parser;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

public final class MonitoredResource
extends GeneratedMessageLite<MonitoredResource, Builder>
implements MonitoredResourceOrBuilder {
    private static final MonitoredResource DEFAULT_INSTANCE;
    public static final int LABELS_FIELD_NUMBER = 2;
    private static volatile Parser<MonitoredResource> PARSER;
    public static final int TYPE_FIELD_NUMBER = 1;
    private int bitField0_;
    private MapFieldLite<String, String> labels_ = MapFieldLite.emptyMapField();
    private String type_ = "";

    public static {
        MonitoredResource monitoredResource;
        DEFAULT_INSTANCE = monitoredResource = new MonitoredResource();
        monitoredResource.makeImmutable();
    }

    private MonitoredResource() {
    }

    private void clearType() {
        this.type_ = MonitoredResource.getDefaultInstance().getType();
    }

    public static MonitoredResource getDefaultInstance() {
        return DEFAULT_INSTANCE;
    }

    private Map<String, String> getMutableLabelsMap() {
        return this.internalGetMutableLabels();
    }

    private MapFieldLite<String, String> internalGetLabels() {
        return this.labels_;
    }

    private MapFieldLite<String, String> internalGetMutableLabels() {
        if (!this.labels_.isMutable()) {
            this.labels_ = this.labels_.mutableCopy();
        }
        return this.labels_;
    }

    public static Builder newBuilder() {
        return (Builder)DEFAULT_INSTANCE.toBuilder();
    }

    public static Builder newBuilder(MonitoredResource monitoredResource) {
        return (Builder)((Builder)DEFAULT_INSTANCE.toBuilder()).mergeFrom((GeneratedMessageLite)monitoredResource);
    }

    public static MonitoredResource parseDelimitedFrom(InputStream inputStream) throws IOException {
        return (MonitoredResource)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static MonitoredResource parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (MonitoredResource)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static MonitoredResource parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
        return (MonitoredResource)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString);
    }

    public static MonitoredResource parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (MonitoredResource)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static MonitoredResource parseFrom(CodedInputStream codedInputStream) throws IOException {
        return (MonitoredResource)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream);
    }

    public static MonitoredResource parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (MonitoredResource)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static MonitoredResource parseFrom(InputStream inputStream) throws IOException {
        return (MonitoredResource)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static MonitoredResource parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (MonitoredResource)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static MonitoredResource parseFrom(byte[] arrby) throws InvalidProtocolBufferException {
        return (MonitoredResource)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby);
    }

    public static MonitoredResource parseFrom(byte[] arrby, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (MonitoredResource)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Parser<MonitoredResource> parser() {
        return DEFAULT_INSTANCE.getParserForType();
    }

    private void setType(String string2) {
        Objects.requireNonNull((Object)string2);
        this.type_ = string2;
    }

    private void setTypeBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.type_ = byteString.toStringUtf8();
    }

    public boolean containsLabels(String string2) {
        Objects.requireNonNull((Object)string2);
        return this.internalGetLabels().containsKey((Object)string2);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke var1_1, Object var2_2, Object var3_3) {
        switch (var1_1.ordinal()) {
            default: {
                throw new UnsupportedOperationException();
            }
            case 7: {
                if (MonitoredResource.PARSER != null) return MonitoredResource.PARSER;
                var14_4 = MonitoredResource.class;
                // MONITORENTER : com.google.api.MonitoredResource.class
                if (MonitoredResource.PARSER == null) {
                    MonitoredResource.PARSER = new GeneratedMessageLite.DefaultInstanceBasedParser((GeneratedMessageLite)MonitoredResource.DEFAULT_INSTANCE);
                }
                // MONITOREXIT : var14_4
                return MonitoredResource.PARSER;
            }
            case 2: {
                var6_5 = (CodedInputStream)var2_2;
                var7_6 = (ExtensionRegistryLite)var3_3;
                var8_7 = false;
                while (var8_7 == false) {
                    var12_8 = var6_5.readTag();
                    if (var12_8 == 0) ** GOTO lbl31
                    if (var12_8 == 10) ** GOTO lbl29
                    if (var12_8 != 18) {
                        if (var6_5.skipField(var12_8)) continue;
                    } else {
                        if (!this.labels_.isMutable()) {
                            this.labels_ = this.labels_.mutableCopy();
                        }
                        LabelsDefaultEntryHolder.defaultEntry.parseInto(this.labels_, var6_5, var7_6);
                        continue;
lbl29: // 1 sources:
                        this.type_ = var6_5.readStringRequireUtf8();
                        continue;
                    }
lbl31: // 2 sources:
                    var8_7 = true;
                    continue;
                    catch (IOException var11_10) {
                        throw new RuntimeException((Throwable)new InvalidProtocolBufferException(var11_10.getMessage()).setUnfinishedMessage((MessageLite)this));
                    }
                    catch (InvalidProtocolBufferException var9_11) {
                        throw new RuntimeException((Throwable)var9_11.setUnfinishedMessage((MessageLite)this));
                    }
                }
                return MonitoredResource.DEFAULT_INSTANCE;
            }
            case 6: {
                return MonitoredResource.DEFAULT_INSTANCE;
            }
            case 1: {
                var4_12 = (GeneratedMessageLite.Visitor)var2_2;
                var5_13 = (MonitoredResource)var3_3;
                this.type_ = var4_12.visitString(true ^ this.type_.isEmpty(), this.type_, true ^ var5_13.type_.isEmpty(), var5_13.type_);
                this.labels_ = var4_12.visitMap(this.labels_, var5_13.internalGetLabels());
                if (var4_12 != GeneratedMessageLite.MergeFromVisitor.INSTANCE) return this;
                this.bitField0_ |= var5_13.bitField0_;
                return this;
            }
            case 5: {
                return new Builder(null);
            }
            case 3: {
                this.labels_.makeImmutable();
                return null;
            }
            case 0: {
                return MonitoredResource.DEFAULT_INSTANCE;
            }
            case 4: 
        }
        return new MonitoredResource();
    }

    @Deprecated
    public Map<String, String> getLabels() {
        return this.getLabelsMap();
    }

    public int getLabelsCount() {
        return this.internalGetLabels().size();
    }

    public Map<String, String> getLabelsMap() {
        return Collections.unmodifiableMap(this.internalGetLabels());
    }

    public String getLabelsOrDefault(String string2, String string3) {
        Objects.requireNonNull((Object)string2);
        MapFieldLite<String, String> mapFieldLite = this.internalGetLabels();
        if (mapFieldLite.containsKey((Object)string2)) {
            string3 = (String)mapFieldLite.get((Object)string2);
        }
        return string3;
    }

    public String getLabelsOrThrow(String string2) {
        Objects.requireNonNull((Object)string2);
        MapFieldLite<String, String> mapFieldLite = this.internalGetLabels();
        if (mapFieldLite.containsKey((Object)string2)) {
            return (String)mapFieldLite.get((Object)string2);
        }
        throw new IllegalArgumentException();
    }

    public int getSerializedSize() {
        int n = this.memoizedSerializedSize;
        if (n != -1) {
            return n;
        }
        boolean bl = this.type_.isEmpty();
        int n2 = 0;
        if (!bl) {
            n2 = 0 + CodedOutputStream.computeStringSize((int)1, (String)this.getType());
        }
        for (Map.Entry entry : this.internalGetLabels().entrySet()) {
            n2 += LabelsDefaultEntryHolder.defaultEntry.computeMessageSize(2, (Object)((String)entry.getKey()), (Object)((String)entry.getValue()));
        }
        this.memoizedSerializedSize = n2;
        return n2;
    }

    public String getType() {
        return this.type_;
    }

    public ByteString getTypeBytes() {
        return ByteString.copyFromUtf8((String)this.type_);
    }

    public void writeTo(CodedOutputStream codedOutputStream) throws IOException {
        if (!this.type_.isEmpty()) {
            codedOutputStream.writeString(1, this.getType());
        }
        for (Map.Entry entry : this.internalGetLabels().entrySet()) {
            LabelsDefaultEntryHolder.defaultEntry.serializeTo(codedOutputStream, 2, (Object)((String)entry.getKey()), (Object)((String)entry.getValue()));
        }
    }

    public static final class Builder
    extends GeneratedMessageLite.Builder<MonitoredResource, Builder>
    implements MonitoredResourceOrBuilder {
        private Builder() {
            super((GeneratedMessageLite)DEFAULT_INSTANCE);
        }

        public /* synthetic */ Builder(1 var1_1) {
            this();
        }

        public Builder clearLabels() {
            this.copyOnWrite();
            ((MonitoredResource)this.instance).getMutableLabelsMap().clear();
            return this;
        }

        public Builder clearType() {
            this.copyOnWrite();
            ((MonitoredResource)this.instance).clearType();
            return this;
        }

        public boolean containsLabels(String string2) {
            Objects.requireNonNull((Object)string2);
            return ((MonitoredResource)this.instance).getLabelsMap().containsKey((Object)string2);
        }

        @Deprecated
        public Map<String, String> getLabels() {
            return this.getLabelsMap();
        }

        public int getLabelsCount() {
            return ((MonitoredResource)this.instance).getLabelsMap().size();
        }

        public Map<String, String> getLabelsMap() {
            return Collections.unmodifiableMap(((MonitoredResource)this.instance).getLabelsMap());
        }

        public String getLabelsOrDefault(String string2, String string3) {
            Objects.requireNonNull((Object)string2);
            Map<String, String> map = ((MonitoredResource)this.instance).getLabelsMap();
            if (map.containsKey((Object)string2)) {
                string3 = (String)map.get((Object)string2);
            }
            return string3;
        }

        public String getLabelsOrThrow(String string2) {
            Objects.requireNonNull((Object)string2);
            Map<String, String> map = ((MonitoredResource)this.instance).getLabelsMap();
            if (map.containsKey((Object)string2)) {
                return (String)map.get((Object)string2);
            }
            throw new IllegalArgumentException();
        }

        public String getType() {
            return ((MonitoredResource)this.instance).getType();
        }

        public ByteString getTypeBytes() {
            return ((MonitoredResource)this.instance).getTypeBytes();
        }

        public Builder putAllLabels(Map<String, String> map) {
            this.copyOnWrite();
            ((MonitoredResource)this.instance).getMutableLabelsMap().putAll(map);
            return this;
        }

        public Builder putLabels(String string2, String string3) {
            Objects.requireNonNull((Object)string2);
            Objects.requireNonNull((Object)string3);
            this.copyOnWrite();
            ((MonitoredResource)this.instance).getMutableLabelsMap().put((Object)string2, (Object)string3);
            return this;
        }

        public Builder removeLabels(String string2) {
            Objects.requireNonNull((Object)string2);
            this.copyOnWrite();
            ((MonitoredResource)this.instance).getMutableLabelsMap().remove((Object)string2);
            return this;
        }

        public Builder setType(String string2) {
            this.copyOnWrite();
            ((MonitoredResource)this.instance).setType(string2);
            return this;
        }

        public Builder setTypeBytes(ByteString byteString) {
            this.copyOnWrite();
            ((MonitoredResource)this.instance).setTypeBytes(byteString);
            return this;
        }
    }

}

