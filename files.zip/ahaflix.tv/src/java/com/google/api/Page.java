/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.api.Page$1
 *  com.google.api.PageOrBuilder
 *  com.google.protobuf.AbstractMessageLite
 *  com.google.protobuf.ByteString
 *  com.google.protobuf.CodedInputStream
 *  com.google.protobuf.CodedOutputStream
 *  com.google.protobuf.ExtensionRegistryLite
 *  com.google.protobuf.GeneratedMessageLite
 *  com.google.protobuf.GeneratedMessageLite$Builder
 *  com.google.protobuf.GeneratedMessageLite$DefaultInstanceBasedParser
 *  com.google.protobuf.GeneratedMessageLite$MergeFromVisitor
 *  com.google.protobuf.GeneratedMessageLite$MethodToInvoke
 *  com.google.protobuf.GeneratedMessageLite$Visitor
 *  com.google.protobuf.Internal
 *  com.google.protobuf.Internal$ProtobufList
 *  com.google.protobuf.InvalidProtocolBufferException
 *  com.google.protobuf.MessageLite
 *  com.google.protobuf.Parser
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Class
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 *  java.util.Collections
 *  java.util.List
 *  java.util.Objects
 */
package com.google.api;

import com.google.api.Page;
import com.google.api.PageOrBuilder;
import com.google.protobuf.AbstractMessageLite;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.CodedOutputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.Internal;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.MessageLite;
import com.google.protobuf.Parser;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

public final class Page
extends GeneratedMessageLite<Page, Builder>
implements PageOrBuilder {
    public static final int CONTENT_FIELD_NUMBER = 2;
    private static final Page DEFAULT_INSTANCE;
    public static final int NAME_FIELD_NUMBER = 1;
    private static volatile Parser<Page> PARSER;
    public static final int SUBPAGES_FIELD_NUMBER = 3;
    private int bitField0_;
    private String content_ = "";
    private String name_ = "";
    private Internal.ProtobufList<Page> subpages_ = GeneratedMessageLite.emptyProtobufList();

    public static {
        Page page;
        DEFAULT_INSTANCE = page = new Page();
        page.makeImmutable();
    }

    private Page() {
    }

    private void addAllSubpages(Iterable<? extends Page> iterable) {
        this.ensureSubpagesIsMutable();
        AbstractMessageLite.addAll(iterable, this.subpages_);
    }

    private void addSubpages(int n, Builder builder) {
        this.ensureSubpagesIsMutable();
        this.subpages_.add(n, (Object)((Page)builder.build()));
    }

    private void addSubpages(int n, Page page) {
        Objects.requireNonNull((Object)((Object)page));
        this.ensureSubpagesIsMutable();
        this.subpages_.add(n, (Object)page);
    }

    private void addSubpages(Builder builder) {
        this.ensureSubpagesIsMutable();
        this.subpages_.add((Object)((Page)builder.build()));
    }

    private void addSubpages(Page page) {
        Objects.requireNonNull((Object)((Object)page));
        this.ensureSubpagesIsMutable();
        this.subpages_.add((Object)page);
    }

    private void clearContent() {
        this.content_ = Page.getDefaultInstance().getContent();
    }

    private void clearName() {
        this.name_ = Page.getDefaultInstance().getName();
    }

    private void clearSubpages() {
        this.subpages_ = GeneratedMessageLite.emptyProtobufList();
    }

    private void ensureSubpagesIsMutable() {
        if (!this.subpages_.isModifiable()) {
            this.subpages_ = GeneratedMessageLite.mutableCopy(this.subpages_);
        }
    }

    public static Page getDefaultInstance() {
        return DEFAULT_INSTANCE;
    }

    public static Builder newBuilder() {
        return (Builder)DEFAULT_INSTANCE.toBuilder();
    }

    public static Builder newBuilder(Page page) {
        return (Builder)((Builder)DEFAULT_INSTANCE.toBuilder()).mergeFrom((GeneratedMessageLite)page);
    }

    public static Page parseDelimitedFrom(InputStream inputStream) throws IOException {
        return (Page)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static Page parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (Page)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Page parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
        return (Page)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString);
    }

    public static Page parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (Page)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Page parseFrom(CodedInputStream codedInputStream) throws IOException {
        return (Page)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream);
    }

    public static Page parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (Page)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Page parseFrom(InputStream inputStream) throws IOException {
        return (Page)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static Page parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (Page)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Page parseFrom(byte[] arrby) throws InvalidProtocolBufferException {
        return (Page)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby);
    }

    public static Page parseFrom(byte[] arrby, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (Page)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Parser<Page> parser() {
        return DEFAULT_INSTANCE.getParserForType();
    }

    private void removeSubpages(int n) {
        this.ensureSubpagesIsMutable();
        this.subpages_.remove(n);
    }

    private void setContent(String string2) {
        Objects.requireNonNull((Object)string2);
        this.content_ = string2;
    }

    private void setContentBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.content_ = byteString.toStringUtf8();
    }

    private void setName(String string2) {
        Objects.requireNonNull((Object)string2);
        this.name_ = string2;
    }

    private void setNameBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.name_ = byteString.toStringUtf8();
    }

    private void setSubpages(int n, Builder builder) {
        this.ensureSubpagesIsMutable();
        this.subpages_.set(n, (Object)((Page)builder.build()));
    }

    private void setSubpages(int n, Page page) {
        Objects.requireNonNull((Object)((Object)page));
        this.ensureSubpagesIsMutable();
        this.subpages_.set(n, (Object)page);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke var1_1, Object var2_2, Object var3_3) {
        switch (var1_1.ordinal()) {
            default: {
                throw new UnsupportedOperationException();
            }
            case 7: {
                if (Page.PARSER != null) return Page.PARSER;
                var15_4 = Page.class;
                // MONITORENTER : com.google.api.Page.class
                if (Page.PARSER == null) {
                    Page.PARSER = new GeneratedMessageLite.DefaultInstanceBasedParser((GeneratedMessageLite)Page.DEFAULT_INSTANCE);
                }
                // MONITOREXIT : var15_4
                return Page.PARSER;
            }
            case 2: {
                var6_5 = (CodedInputStream)var2_2;
                var7_6 = (ExtensionRegistryLite)var3_3;
                var8_7 = false;
                while (var8_7 == false) {
                    var12_8 = var6_5.readTag();
                    if (var12_8 == 0) ** GOTO lbl34
                    if (var12_8 == 10) ** GOTO lbl32
                    if (var12_8 == 18) ** GOTO lbl30
                    if (var12_8 != 26) {
                        if (var6_5.skipField(var12_8)) continue;
                    } else {
                        if (!this.subpages_.isModifiable()) {
                            this.subpages_ = GeneratedMessageLite.mutableCopy(this.subpages_);
                        }
                        this.subpages_.add((Object)((Page)var6_5.readMessage(Page.parser(), var7_6)));
                        continue;
lbl30: // 1 sources:
                        this.content_ = var6_5.readStringRequireUtf8();
                        continue;
lbl32: // 1 sources:
                        this.name_ = var6_5.readStringRequireUtf8();
                        continue;
                    }
lbl34: // 2 sources:
                    var8_7 = true;
                    continue;
                    catch (IOException var11_10) {
                        throw new RuntimeException((Throwable)new InvalidProtocolBufferException(var11_10.getMessage()).setUnfinishedMessage((MessageLite)this));
                    }
                    catch (InvalidProtocolBufferException var9_11) {
                        throw new RuntimeException((Throwable)var9_11.setUnfinishedMessage((MessageLite)this));
                    }
                }
                return Page.DEFAULT_INSTANCE;
            }
            case 6: {
                return Page.DEFAULT_INSTANCE;
            }
            case 1: {
                var4_12 = (GeneratedMessageLite.Visitor)var2_2;
                var5_13 = (Page)var3_3;
                this.name_ = var4_12.visitString(true ^ this.name_.isEmpty(), this.name_, true ^ var5_13.name_.isEmpty(), var5_13.name_);
                this.content_ = var4_12.visitString(true ^ this.content_.isEmpty(), this.content_, true ^ var5_13.content_.isEmpty(), var5_13.content_);
                this.subpages_ = var4_12.visitList(this.subpages_, var5_13.subpages_);
                if (var4_12 != GeneratedMessageLite.MergeFromVisitor.INSTANCE) return this;
                this.bitField0_ |= var5_13.bitField0_;
                return this;
            }
            case 5: {
                return new Builder(null);
            }
            case 3: {
                this.subpages_.makeImmutable();
                return null;
            }
            case 0: {
                return Page.DEFAULT_INSTANCE;
            }
            case 4: 
        }
        return new Page();
    }

    public String getContent() {
        return this.content_;
    }

    public ByteString getContentBytes() {
        return ByteString.copyFromUtf8((String)this.content_);
    }

    public String getName() {
        return this.name_;
    }

    public ByteString getNameBytes() {
        return ByteString.copyFromUtf8((String)this.name_);
    }

    public int getSerializedSize() {
        int n = this.memoizedSerializedSize;
        if (n != -1) {
            return n;
        }
        int n2 = !this.name_.isEmpty() ? 0 + CodedOutputStream.computeStringSize((int)1, (String)this.getName()) : 0;
        boolean bl = this.content_.isEmpty();
        int n3 = 0;
        if (!bl) {
            n2 += CodedOutputStream.computeStringSize((int)2, (String)this.getContent());
        }
        while (n3 < this.subpages_.size()) {
            n2 += CodedOutputStream.computeMessageSize((int)3, (MessageLite)((MessageLite)this.subpages_.get(n3)));
            ++n3;
        }
        this.memoizedSerializedSize = n2;
        return n2;
    }

    public Page getSubpages(int n) {
        return (Page)((Object)this.subpages_.get(n));
    }

    public int getSubpagesCount() {
        return this.subpages_.size();
    }

    public List<Page> getSubpagesList() {
        return this.subpages_;
    }

    public PageOrBuilder getSubpagesOrBuilder(int n) {
        return (PageOrBuilder)this.subpages_.get(n);
    }

    public List<? extends PageOrBuilder> getSubpagesOrBuilderList() {
        return this.subpages_;
    }

    public void writeTo(CodedOutputStream codedOutputStream) throws IOException {
        if (!this.name_.isEmpty()) {
            codedOutputStream.writeString(1, this.getName());
        }
        if (!this.content_.isEmpty()) {
            codedOutputStream.writeString(2, this.getContent());
        }
        for (int i = 0; i < this.subpages_.size(); ++i) {
            codedOutputStream.writeMessage(3, (MessageLite)this.subpages_.get(i));
        }
    }

    public static final class Builder
    extends GeneratedMessageLite.Builder<Page, Builder>
    implements PageOrBuilder {
        private Builder() {
            super((GeneratedMessageLite)DEFAULT_INSTANCE);
        }

        public /* synthetic */ Builder(1 var1_1) {
            this();
        }

        public Builder addAllSubpages(Iterable<? extends Page> iterable) {
            this.copyOnWrite();
            ((Page)this.instance).addAllSubpages((Iterable<? extends Page>)iterable);
            return this;
        }

        public Builder addSubpages(int n, Builder builder) {
            this.copyOnWrite();
            ((Page)this.instance).addSubpages(n, builder);
            return this;
        }

        public Builder addSubpages(int n, Page page) {
            this.copyOnWrite();
            ((Page)this.instance).addSubpages(n, page);
            return this;
        }

        public Builder addSubpages(Builder builder) {
            this.copyOnWrite();
            ((Page)this.instance).addSubpages(builder);
            return this;
        }

        public Builder addSubpages(Page page) {
            this.copyOnWrite();
            ((Page)this.instance).addSubpages(page);
            return this;
        }

        public Builder clearContent() {
            this.copyOnWrite();
            ((Page)this.instance).clearContent();
            return this;
        }

        public Builder clearName() {
            this.copyOnWrite();
            ((Page)this.instance).clearName();
            return this;
        }

        public Builder clearSubpages() {
            this.copyOnWrite();
            ((Page)this.instance).clearSubpages();
            return this;
        }

        public String getContent() {
            return ((Page)this.instance).getContent();
        }

        public ByteString getContentBytes() {
            return ((Page)this.instance).getContentBytes();
        }

        public String getName() {
            return ((Page)this.instance).getName();
        }

        public ByteString getNameBytes() {
            return ((Page)this.instance).getNameBytes();
        }

        public Page getSubpages(int n) {
            return ((Page)this.instance).getSubpages(n);
        }

        public int getSubpagesCount() {
            return ((Page)this.instance).getSubpagesCount();
        }

        public List<Page> getSubpagesList() {
            return Collections.unmodifiableList(((Page)this.instance).getSubpagesList());
        }

        public Builder removeSubpages(int n) {
            this.copyOnWrite();
            ((Page)this.instance).removeSubpages(n);
            return this;
        }

        public Builder setContent(String string2) {
            this.copyOnWrite();
            ((Page)this.instance).setContent(string2);
            return this;
        }

        public Builder setContentBytes(ByteString byteString) {
            this.copyOnWrite();
            ((Page)this.instance).setContentBytes(byteString);
            return this;
        }

        public Builder setName(String string2) {
            this.copyOnWrite();
            ((Page)this.instance).setName(string2);
            return this;
        }

        public Builder setNameBytes(ByteString byteString) {
            this.copyOnWrite();
            ((Page)this.instance).setNameBytes(byteString);
            return this;
        }

        public Builder setSubpages(int n, Builder builder) {
            this.copyOnWrite();
            ((Page)this.instance).setSubpages(n, builder);
            return this;
        }

        public Builder setSubpages(int n, Page page) {
            this.copyOnWrite();
            ((Page)this.instance).setSubpages(n, page);
            return this;
        }
    }

}

