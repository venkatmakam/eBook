/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.api.BackendRule$1
 *  com.google.api.BackendRuleOrBuilder
 *  com.google.protobuf.AbstractMessageLite
 *  com.google.protobuf.ByteString
 *  com.google.protobuf.CodedInputStream
 *  com.google.protobuf.CodedOutputStream
 *  com.google.protobuf.ExtensionRegistryLite
 *  com.google.protobuf.GeneratedMessageLite
 *  com.google.protobuf.GeneratedMessageLite$Builder
 *  com.google.protobuf.GeneratedMessageLite$DefaultInstanceBasedParser
 *  com.google.protobuf.GeneratedMessageLite$MethodToInvoke
 *  com.google.protobuf.GeneratedMessageLite$Visitor
 *  com.google.protobuf.InvalidProtocolBufferException
 *  com.google.protobuf.MessageLite
 *  com.google.protobuf.Parser
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 *  java.util.Objects
 */
package com.google.api;

import com.google.api.BackendRule;
import com.google.api.BackendRuleOrBuilder;
import com.google.protobuf.AbstractMessageLite;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.CodedOutputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.MessageLite;
import com.google.protobuf.Parser;
import java.io.IOException;
import java.io.InputStream;
import java.util.Objects;

public final class BackendRule
extends GeneratedMessageLite<BackendRule, Builder>
implements BackendRuleOrBuilder {
    public static final int ADDRESS_FIELD_NUMBER = 2;
    public static final int DEADLINE_FIELD_NUMBER = 3;
    private static final BackendRule DEFAULT_INSTANCE;
    private static volatile Parser<BackendRule> PARSER;
    public static final int SELECTOR_FIELD_NUMBER = 1;
    private String address_ = "";
    private double deadline_;
    private String selector_ = "";

    public static {
        BackendRule backendRule;
        DEFAULT_INSTANCE = backendRule = new BackendRule();
        backendRule.makeImmutable();
    }

    private BackendRule() {
    }

    private void clearAddress() {
        this.address_ = BackendRule.getDefaultInstance().getAddress();
    }

    private void clearDeadline() {
        this.deadline_ = 0.0;
    }

    private void clearSelector() {
        this.selector_ = BackendRule.getDefaultInstance().getSelector();
    }

    public static BackendRule getDefaultInstance() {
        return DEFAULT_INSTANCE;
    }

    public static Builder newBuilder() {
        return (Builder)DEFAULT_INSTANCE.toBuilder();
    }

    public static Builder newBuilder(BackendRule backendRule) {
        return (Builder)((Builder)DEFAULT_INSTANCE.toBuilder()).mergeFrom((GeneratedMessageLite)backendRule);
    }

    public static BackendRule parseDelimitedFrom(InputStream inputStream) throws IOException {
        return (BackendRule)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static BackendRule parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (BackendRule)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static BackendRule parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
        return (BackendRule)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString);
    }

    public static BackendRule parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (BackendRule)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static BackendRule parseFrom(CodedInputStream codedInputStream) throws IOException {
        return (BackendRule)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream);
    }

    public static BackendRule parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (BackendRule)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static BackendRule parseFrom(InputStream inputStream) throws IOException {
        return (BackendRule)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static BackendRule parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (BackendRule)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static BackendRule parseFrom(byte[] arrby) throws InvalidProtocolBufferException {
        return (BackendRule)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby);
    }

    public static BackendRule parseFrom(byte[] arrby, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (BackendRule)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Parser<BackendRule> parser() {
        return DEFAULT_INSTANCE.getParserForType();
    }

    private void setAddress(String string2) {
        Objects.requireNonNull((Object)string2);
        this.address_ = string2;
    }

    private void setAddressBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.address_ = byteString.toStringUtf8();
    }

    private void setDeadline(double d) {
        this.deadline_ = d;
    }

    private void setSelector(String string2) {
        Objects.requireNonNull((Object)string2);
        this.selector_ = string2;
    }

    private void setSelectorBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.selector_ = byteString.toStringUtf8();
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke var1_1, Object var2_2, Object var3_3) {
        var4_4 = var1_1.ordinal();
        var5_5 = false;
        switch (var4_4) {
            default: {
                throw new UnsupportedOperationException();
            }
            case 7: {
                if (BackendRule.PARSER != null) return BackendRule.PARSER;
                var22_6 = BackendRule.class;
                // MONITORENTER : com.google.api.BackendRule.class
                if (BackendRule.PARSER == null) {
                    BackendRule.PARSER = new GeneratedMessageLite.DefaultInstanceBasedParser((GeneratedMessageLite)BackendRule.DEFAULT_INSTANCE);
                }
                // MONITOREXIT : var22_6
                return BackendRule.PARSER;
            }
            case 2: {
                var15_7 = (CodedInputStream)var2_2;
                (ExtensionRegistryLite)var3_3;
                while (var5_5 == false) {
                    var20_8 = var15_7.readTag();
                    if (var20_8 == 0) ** GOTO lbl33
                    if (var20_8 == 10) ** GOTO lbl31
                    if (var20_8 == 18) ** GOTO lbl29
                    if (var20_8 != 25) {
                        if (var15_7.skipField(var20_8)) continue;
                    } else {
                        this.deadline_ = var15_7.readDouble();
                        continue;
lbl29: // 1 sources:
                        this.address_ = var15_7.readStringRequireUtf8();
                        continue;
lbl31: // 1 sources:
                        this.selector_ = var15_7.readStringRequireUtf8();
                        continue;
                    }
lbl33: // 2 sources:
                    var5_5 = true;
                    continue;
                    catch (IOException var19_10) {
                        throw new RuntimeException((Throwable)new InvalidProtocolBufferException(var19_10.getMessage()).setUnfinishedMessage((MessageLite)this));
                    }
                    catch (InvalidProtocolBufferException var17_11) {
                        throw new RuntimeException((Throwable)var17_11.setUnfinishedMessage((MessageLite)this));
                    }
                }
                return BackendRule.DEFAULT_INSTANCE;
            }
            case 6: {
                return BackendRule.DEFAULT_INSTANCE;
            }
            case 1: {
                var6_12 = (GeneratedMessageLite.Visitor)var2_2;
                var7_13 = (BackendRule)var3_3;
                this.selector_ = var6_12.visitString(true ^ this.selector_.isEmpty(), this.selector_, true ^ var7_13.selector_.isEmpty(), var7_13.selector_);
                this.address_ = var6_12.visitString(true ^ this.address_.isEmpty(), this.address_, true ^ var7_13.address_.isEmpty(), var7_13.address_);
                var8_14 = this.deadline_;
                var10_15 = var8_14 != 0.0;
                var11_16 = var7_13.deadline_;
                var13_17 = var11_16 != 0.0;
                this.deadline_ = var6_12.visitDouble(var10_15, var8_14, var13_17, var11_16);
                return this;
            }
            case 5: {
                return new Builder(null);
            }
            case 3: {
                return null;
            }
            case 0: {
                return BackendRule.DEFAULT_INSTANCE;
            }
            case 4: 
        }
        return new BackendRule();
    }

    public String getAddress() {
        return this.address_;
    }

    public ByteString getAddressBytes() {
        return ByteString.copyFromUtf8((String)this.address_);
    }

    public double getDeadline() {
        return this.deadline_;
    }

    public String getSelector() {
        return this.selector_;
    }

    public ByteString getSelectorBytes() {
        return ByteString.copyFromUtf8((String)this.selector_);
    }

    public int getSerializedSize() {
        double d;
        int n = this.memoizedSerializedSize;
        if (n != -1) {
            return n;
        }
        boolean bl = this.selector_.isEmpty();
        int n2 = 0;
        if (!bl) {
            n2 = 0 + CodedOutputStream.computeStringSize((int)1, (String)this.getSelector());
        }
        if (!this.address_.isEmpty()) {
            n2 += CodedOutputStream.computeStringSize((int)2, (String)this.getAddress());
        }
        if ((d = this.deadline_) != 0.0) {
            n2 += CodedOutputStream.computeDoubleSize((int)3, (double)d);
        }
        this.memoizedSerializedSize = n2;
        return n2;
    }

    public void writeTo(CodedOutputStream codedOutputStream) throws IOException {
        double d;
        if (!this.selector_.isEmpty()) {
            codedOutputStream.writeString(1, this.getSelector());
        }
        if (!this.address_.isEmpty()) {
            codedOutputStream.writeString(2, this.getAddress());
        }
        if ((d = this.deadline_) != 0.0) {
            codedOutputStream.writeDouble(3, d);
        }
    }

    public static final class Builder
    extends GeneratedMessageLite.Builder<BackendRule, Builder>
    implements BackendRuleOrBuilder {
        private Builder() {
            super((GeneratedMessageLite)DEFAULT_INSTANCE);
        }

        public /* synthetic */ Builder(1 var1_1) {
            this();
        }

        public Builder clearAddress() {
            this.copyOnWrite();
            ((BackendRule)this.instance).clearAddress();
            return this;
        }

        public Builder clearDeadline() {
            this.copyOnWrite();
            ((BackendRule)this.instance).clearDeadline();
            return this;
        }

        public Builder clearSelector() {
            this.copyOnWrite();
            ((BackendRule)this.instance).clearSelector();
            return this;
        }

        public String getAddress() {
            return ((BackendRule)this.instance).getAddress();
        }

        public ByteString getAddressBytes() {
            return ((BackendRule)this.instance).getAddressBytes();
        }

        public double getDeadline() {
            return ((BackendRule)this.instance).getDeadline();
        }

        public String getSelector() {
            return ((BackendRule)this.instance).getSelector();
        }

        public ByteString getSelectorBytes() {
            return ((BackendRule)this.instance).getSelectorBytes();
        }

        public Builder setAddress(String string2) {
            this.copyOnWrite();
            ((BackendRule)this.instance).setAddress(string2);
            return this;
        }

        public Builder setAddressBytes(ByteString byteString) {
            this.copyOnWrite();
            ((BackendRule)this.instance).setAddressBytes(byteString);
            return this;
        }

        public Builder setDeadline(double d) {
            this.copyOnWrite();
            ((BackendRule)this.instance).setDeadline(d);
            return this;
        }

        public Builder setSelector(String string2) {
            this.copyOnWrite();
            ((BackendRule)this.instance).setSelector(string2);
            return this;
        }

        public Builder setSelectorBytes(ByteString byteString) {
            this.copyOnWrite();
            ((BackendRule)this.instance).setSelectorBytes(byteString);
            return this;
        }
    }

}

