/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.api.Documentation$1
 *  com.google.api.DocumentationOrBuilder
 *  com.google.api.DocumentationRuleOrBuilder
 *  com.google.api.PageOrBuilder
 *  com.google.protobuf.AbstractMessageLite
 *  com.google.protobuf.ByteString
 *  com.google.protobuf.CodedInputStream
 *  com.google.protobuf.CodedOutputStream
 *  com.google.protobuf.ExtensionRegistryLite
 *  com.google.protobuf.GeneratedMessageLite
 *  com.google.protobuf.GeneratedMessageLite$Builder
 *  com.google.protobuf.GeneratedMessageLite$DefaultInstanceBasedParser
 *  com.google.protobuf.GeneratedMessageLite$MergeFromVisitor
 *  com.google.protobuf.GeneratedMessageLite$MethodToInvoke
 *  com.google.protobuf.GeneratedMessageLite$Visitor
 *  com.google.protobuf.Internal
 *  com.google.protobuf.Internal$ProtobufList
 *  com.google.protobuf.InvalidProtocolBufferException
 *  com.google.protobuf.MessageLite
 *  com.google.protobuf.Parser
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Class
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 *  java.util.Collections
 *  java.util.List
 *  java.util.Objects
 */
package com.google.api;

import com.google.api.Documentation;
import com.google.api.DocumentationOrBuilder;
import com.google.api.DocumentationRule;
import com.google.api.DocumentationRuleOrBuilder;
import com.google.api.Page;
import com.google.api.PageOrBuilder;
import com.google.protobuf.AbstractMessageLite;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.CodedOutputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.Internal;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.MessageLite;
import com.google.protobuf.Parser;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

public final class Documentation
extends GeneratedMessageLite<Documentation, Builder>
implements DocumentationOrBuilder {
    private static final Documentation DEFAULT_INSTANCE;
    public static final int DOCUMENTATION_ROOT_URL_FIELD_NUMBER = 4;
    public static final int OVERVIEW_FIELD_NUMBER = 2;
    public static final int PAGES_FIELD_NUMBER = 5;
    private static volatile Parser<Documentation> PARSER;
    public static final int RULES_FIELD_NUMBER = 3;
    public static final int SUMMARY_FIELD_NUMBER = 1;
    private int bitField0_;
    private String documentationRootUrl_ = "";
    private String overview_ = "";
    private Internal.ProtobufList<Page> pages_ = GeneratedMessageLite.emptyProtobufList();
    private Internal.ProtobufList<DocumentationRule> rules_ = GeneratedMessageLite.emptyProtobufList();
    private String summary_ = "";

    public static {
        Documentation documentation;
        DEFAULT_INSTANCE = documentation = new Documentation();
        documentation.makeImmutable();
    }

    private Documentation() {
    }

    private void addAllPages(Iterable<? extends Page> iterable) {
        this.ensurePagesIsMutable();
        AbstractMessageLite.addAll(iterable, this.pages_);
    }

    private void addAllRules(Iterable<? extends DocumentationRule> iterable) {
        this.ensureRulesIsMutable();
        AbstractMessageLite.addAll(iterable, this.rules_);
    }

    private void addPages(int n, Page.Builder builder) {
        this.ensurePagesIsMutable();
        this.pages_.add(n, (Object)((Page)builder.build()));
    }

    private void addPages(int n, Page page) {
        Objects.requireNonNull((Object)((Object)page));
        this.ensurePagesIsMutable();
        this.pages_.add(n, (Object)page);
    }

    private void addPages(Page.Builder builder) {
        this.ensurePagesIsMutable();
        this.pages_.add((Object)((Page)builder.build()));
    }

    private void addPages(Page page) {
        Objects.requireNonNull((Object)((Object)page));
        this.ensurePagesIsMutable();
        this.pages_.add((Object)page);
    }

    private void addRules(int n, DocumentationRule.Builder builder) {
        this.ensureRulesIsMutable();
        this.rules_.add(n, (Object)((DocumentationRule)builder.build()));
    }

    private void addRules(int n, DocumentationRule documentationRule) {
        Objects.requireNonNull((Object)((Object)documentationRule));
        this.ensureRulesIsMutable();
        this.rules_.add(n, (Object)documentationRule);
    }

    private void addRules(DocumentationRule.Builder builder) {
        this.ensureRulesIsMutable();
        this.rules_.add((Object)((DocumentationRule)builder.build()));
    }

    private void addRules(DocumentationRule documentationRule) {
        Objects.requireNonNull((Object)((Object)documentationRule));
        this.ensureRulesIsMutable();
        this.rules_.add((Object)documentationRule);
    }

    private void clearDocumentationRootUrl() {
        this.documentationRootUrl_ = Documentation.getDefaultInstance().getDocumentationRootUrl();
    }

    private void clearOverview() {
        this.overview_ = Documentation.getDefaultInstance().getOverview();
    }

    private void clearPages() {
        this.pages_ = GeneratedMessageLite.emptyProtobufList();
    }

    private void clearRules() {
        this.rules_ = GeneratedMessageLite.emptyProtobufList();
    }

    private void clearSummary() {
        this.summary_ = Documentation.getDefaultInstance().getSummary();
    }

    private void ensurePagesIsMutable() {
        if (!this.pages_.isModifiable()) {
            this.pages_ = GeneratedMessageLite.mutableCopy(this.pages_);
        }
    }

    private void ensureRulesIsMutable() {
        if (!this.rules_.isModifiable()) {
            this.rules_ = GeneratedMessageLite.mutableCopy(this.rules_);
        }
    }

    public static Documentation getDefaultInstance() {
        return DEFAULT_INSTANCE;
    }

    public static Builder newBuilder() {
        return (Builder)DEFAULT_INSTANCE.toBuilder();
    }

    public static Builder newBuilder(Documentation documentation) {
        return (Builder)((Builder)DEFAULT_INSTANCE.toBuilder()).mergeFrom((GeneratedMessageLite)documentation);
    }

    public static Documentation parseDelimitedFrom(InputStream inputStream) throws IOException {
        return (Documentation)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static Documentation parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (Documentation)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Documentation parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
        return (Documentation)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString);
    }

    public static Documentation parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (Documentation)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Documentation parseFrom(CodedInputStream codedInputStream) throws IOException {
        return (Documentation)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream);
    }

    public static Documentation parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (Documentation)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Documentation parseFrom(InputStream inputStream) throws IOException {
        return (Documentation)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static Documentation parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (Documentation)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Documentation parseFrom(byte[] arrby) throws InvalidProtocolBufferException {
        return (Documentation)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby);
    }

    public static Documentation parseFrom(byte[] arrby, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (Documentation)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Parser<Documentation> parser() {
        return DEFAULT_INSTANCE.getParserForType();
    }

    private void removePages(int n) {
        this.ensurePagesIsMutable();
        this.pages_.remove(n);
    }

    private void removeRules(int n) {
        this.ensureRulesIsMutable();
        this.rules_.remove(n);
    }

    private void setDocumentationRootUrl(String string2) {
        Objects.requireNonNull((Object)string2);
        this.documentationRootUrl_ = string2;
    }

    private void setDocumentationRootUrlBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.documentationRootUrl_ = byteString.toStringUtf8();
    }

    private void setOverview(String string2) {
        Objects.requireNonNull((Object)string2);
        this.overview_ = string2;
    }

    private void setOverviewBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.overview_ = byteString.toStringUtf8();
    }

    private void setPages(int n, Page.Builder builder) {
        this.ensurePagesIsMutable();
        this.pages_.set(n, (Object)((Page)builder.build()));
    }

    private void setPages(int n, Page page) {
        Objects.requireNonNull((Object)((Object)page));
        this.ensurePagesIsMutable();
        this.pages_.set(n, (Object)page);
    }

    private void setRules(int n, DocumentationRule.Builder builder) {
        this.ensureRulesIsMutable();
        this.rules_.set(n, (Object)((DocumentationRule)builder.build()));
    }

    private void setRules(int n, DocumentationRule documentationRule) {
        Objects.requireNonNull((Object)((Object)documentationRule));
        this.ensureRulesIsMutable();
        this.rules_.set(n, (Object)documentationRule);
    }

    private void setSummary(String string2) {
        Objects.requireNonNull((Object)string2);
        this.summary_ = string2;
    }

    private void setSummaryBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.summary_ = byteString.toStringUtf8();
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke var1_1, Object var2_2, Object var3_3) {
        switch (var1_1.ordinal()) {
            default: {
                throw new UnsupportedOperationException();
            }
            case 7: {
                if (Documentation.PARSER != null) return Documentation.PARSER;
                var16_4 = Documentation.class;
                // MONITORENTER : com.google.api.Documentation.class
                if (Documentation.PARSER == null) {
                    Documentation.PARSER = new GeneratedMessageLite.DefaultInstanceBasedParser((GeneratedMessageLite)Documentation.DEFAULT_INSTANCE);
                }
                // MONITOREXIT : var16_4
                return Documentation.PARSER;
            }
            case 2: {
                var6_5 = (CodedInputStream)var2_2;
                var7_6 = (ExtensionRegistryLite)var3_3;
                var8_7 = false;
                while (var8_7 == false) {
                    var12_8 = var6_5.readTag();
                    if (var12_8 == 0) ** GOTO lbl42
                    if (var12_8 == 10) ** GOTO lbl40
                    if (var12_8 == 18) ** GOTO lbl38
                    if (var12_8 == 26) ** GOTO lbl34
                    if (var12_8 == 34) ** GOTO lbl32
                    if (var12_8 != 42) {
                        if (var6_5.skipField(var12_8)) continue;
                    } else {
                        if (!this.pages_.isModifiable()) {
                            this.pages_ = GeneratedMessageLite.mutableCopy(this.pages_);
                        }
                        this.pages_.add((Object)((Page)var6_5.readMessage(Page.parser(), var7_6)));
                        continue;
lbl32: // 1 sources:
                        this.documentationRootUrl_ = var6_5.readStringRequireUtf8();
                        continue;
lbl34: // 1 sources:
                        if (!this.rules_.isModifiable()) {
                            this.rules_ = GeneratedMessageLite.mutableCopy(this.rules_);
                        }
                        this.rules_.add((Object)((DocumentationRule)var6_5.readMessage(DocumentationRule.parser(), var7_6)));
                        continue;
lbl38: // 1 sources:
                        this.overview_ = var6_5.readStringRequireUtf8();
                        continue;
lbl40: // 1 sources:
                        this.summary_ = var6_5.readStringRequireUtf8();
                        continue;
                    }
lbl42: // 2 sources:
                    var8_7 = true;
                    continue;
                    catch (IOException var11_10) {
                        throw new RuntimeException((Throwable)new InvalidProtocolBufferException(var11_10.getMessage()).setUnfinishedMessage((MessageLite)this));
                    }
                    catch (InvalidProtocolBufferException var9_11) {
                        throw new RuntimeException((Throwable)var9_11.setUnfinishedMessage((MessageLite)this));
                    }
                }
                return Documentation.DEFAULT_INSTANCE;
            }
            case 6: {
                return Documentation.DEFAULT_INSTANCE;
            }
            case 1: {
                var4_12 = (GeneratedMessageLite.Visitor)var2_2;
                var5_13 = (Documentation)var3_3;
                this.summary_ = var4_12.visitString(true ^ this.summary_.isEmpty(), this.summary_, true ^ var5_13.summary_.isEmpty(), var5_13.summary_);
                this.pages_ = var4_12.visitList(this.pages_, var5_13.pages_);
                this.rules_ = var4_12.visitList(this.rules_, var5_13.rules_);
                this.documentationRootUrl_ = var4_12.visitString(true ^ this.documentationRootUrl_.isEmpty(), this.documentationRootUrl_, true ^ var5_13.documentationRootUrl_.isEmpty(), var5_13.documentationRootUrl_);
                this.overview_ = var4_12.visitString(true ^ this.overview_.isEmpty(), this.overview_, true ^ var5_13.overview_.isEmpty(), var5_13.overview_);
                if (var4_12 != GeneratedMessageLite.MergeFromVisitor.INSTANCE) return this;
                this.bitField0_ |= var5_13.bitField0_;
                return this;
            }
            case 5: {
                return new Builder(null);
            }
            case 3: {
                this.pages_.makeImmutable();
                this.rules_.makeImmutable();
                return null;
            }
            case 0: {
                return Documentation.DEFAULT_INSTANCE;
            }
            case 4: 
        }
        return new Documentation();
    }

    public String getDocumentationRootUrl() {
        return this.documentationRootUrl_;
    }

    public ByteString getDocumentationRootUrlBytes() {
        return ByteString.copyFromUtf8((String)this.documentationRootUrl_);
    }

    public String getOverview() {
        return this.overview_;
    }

    public ByteString getOverviewBytes() {
        return ByteString.copyFromUtf8((String)this.overview_);
    }

    public Page getPages(int n) {
        return (Page)((Object)this.pages_.get(n));
    }

    public int getPagesCount() {
        return this.pages_.size();
    }

    public List<Page> getPagesList() {
        return this.pages_;
    }

    public PageOrBuilder getPagesOrBuilder(int n) {
        return (PageOrBuilder)this.pages_.get(n);
    }

    public List<? extends PageOrBuilder> getPagesOrBuilderList() {
        return this.pages_;
    }

    public DocumentationRule getRules(int n) {
        return (DocumentationRule)((Object)this.rules_.get(n));
    }

    public int getRulesCount() {
        return this.rules_.size();
    }

    public List<DocumentationRule> getRulesList() {
        return this.rules_;
    }

    public DocumentationRuleOrBuilder getRulesOrBuilder(int n) {
        return (DocumentationRuleOrBuilder)this.rules_.get(n);
    }

    public List<? extends DocumentationRuleOrBuilder> getRulesOrBuilderList() {
        return this.rules_;
    }

    public int getSerializedSize() {
        int n = this.memoizedSerializedSize;
        if (n != -1) {
            return n;
        }
        int n2 = !this.summary_.isEmpty() ? 0 + CodedOutputStream.computeStringSize((int)1, (String)this.getSummary()) : 0;
        if (!this.overview_.isEmpty()) {
            n2 += CodedOutputStream.computeStringSize((int)2, (String)this.getOverview());
        }
        for (int i = 0; i < this.rules_.size(); ++i) {
            n2 += CodedOutputStream.computeMessageSize((int)3, (MessageLite)((MessageLite)this.rules_.get(i)));
        }
        boolean bl = this.documentationRootUrl_.isEmpty();
        int n3 = 0;
        if (!bl) {
            n2 += CodedOutputStream.computeStringSize((int)4, (String)this.getDocumentationRootUrl());
        }
        while (n3 < this.pages_.size()) {
            n2 += CodedOutputStream.computeMessageSize((int)5, (MessageLite)((MessageLite)this.pages_.get(n3)));
            ++n3;
        }
        this.memoizedSerializedSize = n2;
        return n2;
    }

    public String getSummary() {
        return this.summary_;
    }

    public ByteString getSummaryBytes() {
        return ByteString.copyFromUtf8((String)this.summary_);
    }

    public void writeTo(CodedOutputStream codedOutputStream) throws IOException {
        if (!this.summary_.isEmpty()) {
            codedOutputStream.writeString(1, this.getSummary());
        }
        if (!this.overview_.isEmpty()) {
            codedOutputStream.writeString(2, this.getOverview());
        }
        for (int i = 0; i < this.rules_.size(); ++i) {
            codedOutputStream.writeMessage(3, (MessageLite)this.rules_.get(i));
        }
        boolean bl = this.documentationRootUrl_.isEmpty();
        int n = 0;
        if (!bl) {
            codedOutputStream.writeString(4, this.getDocumentationRootUrl());
        }
        while (n < this.pages_.size()) {
            codedOutputStream.writeMessage(5, (MessageLite)this.pages_.get(n));
            ++n;
        }
    }

    public static final class Builder
    extends GeneratedMessageLite.Builder<Documentation, Builder>
    implements DocumentationOrBuilder {
        private Builder() {
            super((GeneratedMessageLite)DEFAULT_INSTANCE);
        }

        public /* synthetic */ Builder(1 var1_1) {
            this();
        }

        public Builder addAllPages(Iterable<? extends Page> iterable) {
            this.copyOnWrite();
            ((Documentation)this.instance).addAllPages((Iterable<? extends Page>)iterable);
            return this;
        }

        public Builder addAllRules(Iterable<? extends DocumentationRule> iterable) {
            this.copyOnWrite();
            ((Documentation)this.instance).addAllRules((Iterable<? extends DocumentationRule>)iterable);
            return this;
        }

        public Builder addPages(int n, Page.Builder builder) {
            this.copyOnWrite();
            ((Documentation)this.instance).addPages(n, builder);
            return this;
        }

        public Builder addPages(int n, Page page) {
            this.copyOnWrite();
            ((Documentation)this.instance).addPages(n, page);
            return this;
        }

        public Builder addPages(Page.Builder builder) {
            this.copyOnWrite();
            ((Documentation)this.instance).addPages(builder);
            return this;
        }

        public Builder addPages(Page page) {
            this.copyOnWrite();
            ((Documentation)this.instance).addPages(page);
            return this;
        }

        public Builder addRules(int n, DocumentationRule.Builder builder) {
            this.copyOnWrite();
            ((Documentation)this.instance).addRules(n, builder);
            return this;
        }

        public Builder addRules(int n, DocumentationRule documentationRule) {
            this.copyOnWrite();
            ((Documentation)this.instance).addRules(n, documentationRule);
            return this;
        }

        public Builder addRules(DocumentationRule.Builder builder) {
            this.copyOnWrite();
            ((Documentation)this.instance).addRules(builder);
            return this;
        }

        public Builder addRules(DocumentationRule documentationRule) {
            this.copyOnWrite();
            ((Documentation)this.instance).addRules(documentationRule);
            return this;
        }

        public Builder clearDocumentationRootUrl() {
            this.copyOnWrite();
            ((Documentation)this.instance).clearDocumentationRootUrl();
            return this;
        }

        public Builder clearOverview() {
            this.copyOnWrite();
            ((Documentation)this.instance).clearOverview();
            return this;
        }

        public Builder clearPages() {
            this.copyOnWrite();
            ((Documentation)this.instance).clearPages();
            return this;
        }

        public Builder clearRules() {
            this.copyOnWrite();
            ((Documentation)this.instance).clearRules();
            return this;
        }

        public Builder clearSummary() {
            this.copyOnWrite();
            ((Documentation)this.instance).clearSummary();
            return this;
        }

        public String getDocumentationRootUrl() {
            return ((Documentation)this.instance).getDocumentationRootUrl();
        }

        public ByteString getDocumentationRootUrlBytes() {
            return ((Documentation)this.instance).getDocumentationRootUrlBytes();
        }

        public String getOverview() {
            return ((Documentation)this.instance).getOverview();
        }

        public ByteString getOverviewBytes() {
            return ((Documentation)this.instance).getOverviewBytes();
        }

        public Page getPages(int n) {
            return ((Documentation)this.instance).getPages(n);
        }

        public int getPagesCount() {
            return ((Documentation)this.instance).getPagesCount();
        }

        public List<Page> getPagesList() {
            return Collections.unmodifiableList(((Documentation)this.instance).getPagesList());
        }

        public DocumentationRule getRules(int n) {
            return ((Documentation)this.instance).getRules(n);
        }

        public int getRulesCount() {
            return ((Documentation)this.instance).getRulesCount();
        }

        public List<DocumentationRule> getRulesList() {
            return Collections.unmodifiableList(((Documentation)this.instance).getRulesList());
        }

        public String getSummary() {
            return ((Documentation)this.instance).getSummary();
        }

        public ByteString getSummaryBytes() {
            return ((Documentation)this.instance).getSummaryBytes();
        }

        public Builder removePages(int n) {
            this.copyOnWrite();
            ((Documentation)this.instance).removePages(n);
            return this;
        }

        public Builder removeRules(int n) {
            this.copyOnWrite();
            ((Documentation)this.instance).removeRules(n);
            return this;
        }

        public Builder setDocumentationRootUrl(String string2) {
            this.copyOnWrite();
            ((Documentation)this.instance).setDocumentationRootUrl(string2);
            return this;
        }

        public Builder setDocumentationRootUrlBytes(ByteString byteString) {
            this.copyOnWrite();
            ((Documentation)this.instance).setDocumentationRootUrlBytes(byteString);
            return this;
        }

        public Builder setOverview(String string2) {
            this.copyOnWrite();
            ((Documentation)this.instance).setOverview(string2);
            return this;
        }

        public Builder setOverviewBytes(ByteString byteString) {
            this.copyOnWrite();
            ((Documentation)this.instance).setOverviewBytes(byteString);
            return this;
        }

        public Builder setPages(int n, Page.Builder builder) {
            this.copyOnWrite();
            ((Documentation)this.instance).setPages(n, builder);
            return this;
        }

        public Builder setPages(int n, Page page) {
            this.copyOnWrite();
            ((Documentation)this.instance).setPages(n, page);
            return this;
        }

        public Builder setRules(int n, DocumentationRule.Builder builder) {
            this.copyOnWrite();
            ((Documentation)this.instance).setRules(n, builder);
            return this;
        }

        public Builder setRules(int n, DocumentationRule documentationRule) {
            this.copyOnWrite();
            ((Documentation)this.instance).setRules(n, documentationRule);
            return this;
        }

        public Builder setSummary(String string2) {
            this.copyOnWrite();
            ((Documentation)this.instance).setSummary(string2);
            return this;
        }

        public Builder setSummaryBytes(ByteString byteString) {
            this.copyOnWrite();
            ((Documentation)this.instance).setSummaryBytes(byteString);
            return this;
        }
    }

}

