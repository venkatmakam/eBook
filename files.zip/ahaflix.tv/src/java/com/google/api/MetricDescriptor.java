/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.api.LabelDescriptorOrBuilder
 *  com.google.api.MetricDescriptor$1
 *  com.google.api.MetricDescriptor$MetricKind
 *  com.google.api.MetricDescriptor$ValueType
 *  com.google.api.MetricDescriptorOrBuilder
 *  com.google.protobuf.AbstractMessageLite
 *  com.google.protobuf.ByteString
 *  com.google.protobuf.CodedInputStream
 *  com.google.protobuf.CodedOutputStream
 *  com.google.protobuf.ExtensionRegistryLite
 *  com.google.protobuf.GeneratedMessageLite
 *  com.google.protobuf.GeneratedMessageLite$Builder
 *  com.google.protobuf.GeneratedMessageLite$DefaultInstanceBasedParser
 *  com.google.protobuf.GeneratedMessageLite$MergeFromVisitor
 *  com.google.protobuf.GeneratedMessageLite$MethodToInvoke
 *  com.google.protobuf.GeneratedMessageLite$Visitor
 *  com.google.protobuf.Internal
 *  com.google.protobuf.Internal$ProtobufList
 *  com.google.protobuf.InvalidProtocolBufferException
 *  com.google.protobuf.MessageLite
 *  com.google.protobuf.Parser
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Class
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 *  java.util.Collections
 *  java.util.List
 *  java.util.Objects
 */
package com.google.api;

import com.google.api.LabelDescriptor;
import com.google.api.LabelDescriptorOrBuilder;
import com.google.api.MetricDescriptor;
import com.google.api.MetricDescriptorOrBuilder;
import com.google.protobuf.AbstractMessageLite;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.CodedOutputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.Internal;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.MessageLite;
import com.google.protobuf.Parser;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

/*
 * Exception performing whole class analysis ignored.
 */
public final class MetricDescriptor
extends GeneratedMessageLite<MetricDescriptor, Builder>
implements MetricDescriptorOrBuilder {
    private static final MetricDescriptor DEFAULT_INSTANCE;
    public static final int DESCRIPTION_FIELD_NUMBER = 6;
    public static final int DISPLAY_NAME_FIELD_NUMBER = 7;
    public static final int LABELS_FIELD_NUMBER = 2;
    public static final int METRIC_KIND_FIELD_NUMBER = 3;
    public static final int NAME_FIELD_NUMBER = 1;
    private static volatile Parser<MetricDescriptor> PARSER;
    public static final int TYPE_FIELD_NUMBER = 8;
    public static final int UNIT_FIELD_NUMBER = 5;
    public static final int VALUE_TYPE_FIELD_NUMBER = 4;
    private int bitField0_;
    private String description_ = "";
    private String displayName_ = "";
    private Internal.ProtobufList<LabelDescriptor> labels_ = GeneratedMessageLite.emptyProtobufList();
    private int metricKind_;
    private String name_ = "";
    private String type_ = "";
    private String unit_ = "";
    private int valueType_;

    public static {
        MetricDescriptor metricDescriptor;
        DEFAULT_INSTANCE = metricDescriptor = new MetricDescriptor();
        metricDescriptor.makeImmutable();
    }

    private MetricDescriptor() {
    }

    private void addAllLabels(Iterable<? extends LabelDescriptor> iterable) {
        this.ensureLabelsIsMutable();
        AbstractMessageLite.addAll(iterable, this.labels_);
    }

    private void addLabels(int n, LabelDescriptor.Builder builder) {
        this.ensureLabelsIsMutable();
        this.labels_.add(n, (Object)((LabelDescriptor)builder.build()));
    }

    private void addLabels(int n, LabelDescriptor labelDescriptor) {
        Objects.requireNonNull((Object)((Object)labelDescriptor));
        this.ensureLabelsIsMutable();
        this.labels_.add(n, (Object)labelDescriptor);
    }

    private void addLabels(LabelDescriptor.Builder builder) {
        this.ensureLabelsIsMutable();
        this.labels_.add((Object)((LabelDescriptor)builder.build()));
    }

    private void addLabels(LabelDescriptor labelDescriptor) {
        Objects.requireNonNull((Object)((Object)labelDescriptor));
        this.ensureLabelsIsMutable();
        this.labels_.add((Object)labelDescriptor);
    }

    private void clearDescription() {
        this.description_ = MetricDescriptor.getDefaultInstance().getDescription();
    }

    private void clearDisplayName() {
        this.displayName_ = MetricDescriptor.getDefaultInstance().getDisplayName();
    }

    private void clearLabels() {
        this.labels_ = GeneratedMessageLite.emptyProtobufList();
    }

    private void clearMetricKind() {
        this.metricKind_ = 0;
    }

    private void clearName() {
        this.name_ = MetricDescriptor.getDefaultInstance().getName();
    }

    private void clearType() {
        this.type_ = MetricDescriptor.getDefaultInstance().getType();
    }

    private void clearUnit() {
        this.unit_ = MetricDescriptor.getDefaultInstance().getUnit();
    }

    private void clearValueType() {
        this.valueType_ = 0;
    }

    private void ensureLabelsIsMutable() {
        if (!this.labels_.isModifiable()) {
            this.labels_ = GeneratedMessageLite.mutableCopy(this.labels_);
        }
    }

    public static MetricDescriptor getDefaultInstance() {
        return DEFAULT_INSTANCE;
    }

    public static Builder newBuilder() {
        return (Builder)DEFAULT_INSTANCE.toBuilder();
    }

    public static Builder newBuilder(MetricDescriptor metricDescriptor) {
        return (Builder)((Builder)DEFAULT_INSTANCE.toBuilder()).mergeFrom((GeneratedMessageLite)metricDescriptor);
    }

    public static MetricDescriptor parseDelimitedFrom(InputStream inputStream) throws IOException {
        return (MetricDescriptor)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static MetricDescriptor parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (MetricDescriptor)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static MetricDescriptor parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
        return (MetricDescriptor)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString);
    }

    public static MetricDescriptor parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (MetricDescriptor)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static MetricDescriptor parseFrom(CodedInputStream codedInputStream) throws IOException {
        return (MetricDescriptor)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream);
    }

    public static MetricDescriptor parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (MetricDescriptor)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static MetricDescriptor parseFrom(InputStream inputStream) throws IOException {
        return (MetricDescriptor)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static MetricDescriptor parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (MetricDescriptor)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static MetricDescriptor parseFrom(byte[] arrby) throws InvalidProtocolBufferException {
        return (MetricDescriptor)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby);
    }

    public static MetricDescriptor parseFrom(byte[] arrby, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (MetricDescriptor)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Parser<MetricDescriptor> parser() {
        return DEFAULT_INSTANCE.getParserForType();
    }

    private void removeLabels(int n) {
        this.ensureLabelsIsMutable();
        this.labels_.remove(n);
    }

    private void setDescription(String string2) {
        Objects.requireNonNull((Object)string2);
        this.description_ = string2;
    }

    private void setDescriptionBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.description_ = byteString.toStringUtf8();
    }

    private void setDisplayName(String string2) {
        Objects.requireNonNull((Object)string2);
        this.displayName_ = string2;
    }

    private void setDisplayNameBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.displayName_ = byteString.toStringUtf8();
    }

    private void setLabels(int n, LabelDescriptor.Builder builder) {
        this.ensureLabelsIsMutable();
        this.labels_.set(n, (Object)((LabelDescriptor)builder.build()));
    }

    private void setLabels(int n, LabelDescriptor labelDescriptor) {
        Objects.requireNonNull((Object)((Object)labelDescriptor));
        this.ensureLabelsIsMutable();
        this.labels_.set(n, (Object)labelDescriptor);
    }

    private void setMetricKind(MetricKind metricKind) {
        Objects.requireNonNull((Object)metricKind);
        this.metricKind_ = metricKind.getNumber();
    }

    private void setMetricKindValue(int n) {
        this.metricKind_ = n;
    }

    private void setName(String string2) {
        Objects.requireNonNull((Object)string2);
        this.name_ = string2;
    }

    private void setNameBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.name_ = byteString.toStringUtf8();
    }

    private void setType(String string2) {
        Objects.requireNonNull((Object)string2);
        this.type_ = string2;
    }

    private void setTypeBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.type_ = byteString.toStringUtf8();
    }

    private void setUnit(String string2) {
        Objects.requireNonNull((Object)string2);
        this.unit_ = string2;
    }

    private void setUnitBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.unit_ = byteString.toStringUtf8();
    }

    private void setValueType(ValueType valueType) {
        Objects.requireNonNull((Object)valueType);
        this.valueType_ = valueType.getNumber();
    }

    private void setValueTypeValue(int n) {
        this.valueType_ = n;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke var1_1, Object var2_2, Object var3_3) {
        var4_4 = var1_1.ordinal();
        var5_5 = false;
        switch (var4_4) {
            default: {
                throw new UnsupportedOperationException();
            }
            case 7: {
                if (MetricDescriptor.PARSER != null) return MetricDescriptor.PARSER;
                var24_6 = MetricDescriptor.class;
                // MONITORENTER : com.google.api.MetricDescriptor.class
                if (MetricDescriptor.PARSER == null) {
                    MetricDescriptor.PARSER = new GeneratedMessageLite.DefaultInstanceBasedParser((GeneratedMessageLite)MetricDescriptor.DEFAULT_INSTANCE);
                }
                // MONITOREXIT : var24_6
                return MetricDescriptor.PARSER;
            }
            case 2: {
                var16_7 = (CodedInputStream)var2_2;
                var17_8 = (ExtensionRegistryLite)var3_3;
                while (var5_5 == false) {
                    var21_9 = var16_7.readTag();
                    if (var21_9 == 0) ** GOTO lbl50
                    if (var21_9 == 10) ** GOTO lbl48
                    if (var21_9 == 18) ** GOTO lbl44
                    if (var21_9 == 24) ** GOTO lbl42
                    if (var21_9 == 32) ** GOTO lbl40
                    if (var21_9 == 42) ** GOTO lbl38
                    if (var21_9 == 50) ** GOTO lbl36
                    if (var21_9 == 58) ** GOTO lbl34
                    if (var21_9 != 66) {
                        if (var16_7.skipField(var21_9)) continue;
                    } else {
                        this.type_ = var16_7.readStringRequireUtf8();
                        continue;
lbl34: // 1 sources:
                        this.displayName_ = var16_7.readStringRequireUtf8();
                        continue;
lbl36: // 1 sources:
                        this.description_ = var16_7.readStringRequireUtf8();
                        continue;
lbl38: // 1 sources:
                        this.unit_ = var16_7.readStringRequireUtf8();
                        continue;
lbl40: // 1 sources:
                        this.valueType_ = var16_7.readEnum();
                        continue;
lbl42: // 1 sources:
                        this.metricKind_ = var16_7.readEnum();
                        continue;
lbl44: // 1 sources:
                        if (!this.labels_.isModifiable()) {
                            this.labels_ = GeneratedMessageLite.mutableCopy(this.labels_);
                        }
                        this.labels_.add((Object)((LabelDescriptor)var16_7.readMessage(LabelDescriptor.parser(), var17_8)));
                        continue;
lbl48: // 1 sources:
                        this.name_ = var16_7.readStringRequireUtf8();
                        continue;
                    }
lbl50: // 2 sources:
                    var5_5 = true;
                    continue;
                    catch (IOException var20_11) {
                        throw new RuntimeException((Throwable)new InvalidProtocolBufferException(var20_11.getMessage()).setUnfinishedMessage((MessageLite)this));
                    }
                    catch (InvalidProtocolBufferException var18_12) {
                        throw new RuntimeException((Throwable)var18_12.setUnfinishedMessage((MessageLite)this));
                    }
                }
                return MetricDescriptor.DEFAULT_INSTANCE;
            }
            case 6: {
                return MetricDescriptor.DEFAULT_INSTANCE;
            }
            case 1: {
                var6_13 = (GeneratedMessageLite.Visitor)var2_2;
                var7_14 = (MetricDescriptor)var3_3;
                this.name_ = var6_13.visitString(true ^ this.name_.isEmpty(), this.name_, true ^ var7_14.name_.isEmpty(), var7_14.name_);
                this.type_ = var6_13.visitString(true ^ this.type_.isEmpty(), this.type_, true ^ var7_14.type_.isEmpty(), var7_14.type_);
                this.labels_ = var6_13.visitList(this.labels_, var7_14.labels_);
                var8_15 = this.metricKind_;
                var9_16 = var8_15 != 0;
                var10_17 = var7_14.metricKind_;
                var11_18 = var10_17 != 0;
                this.metricKind_ = var6_13.visitInt(var9_16, var8_15, var11_18, var10_17);
                var12_19 = this.valueType_;
                var13_20 = var12_19 != 0;
                var14_21 = var7_14.valueType_;
                var15_22 = false;
                if (var14_21 != 0) {
                    var15_22 = true;
                }
                this.valueType_ = var6_13.visitInt(var13_20, var12_19, var15_22, var14_21);
                this.unit_ = var6_13.visitString(true ^ this.unit_.isEmpty(), this.unit_, true ^ var7_14.unit_.isEmpty(), var7_14.unit_);
                this.description_ = var6_13.visitString(true ^ this.description_.isEmpty(), this.description_, true ^ var7_14.description_.isEmpty(), var7_14.description_);
                this.displayName_ = var6_13.visitString(true ^ this.displayName_.isEmpty(), this.displayName_, true ^ var7_14.displayName_.isEmpty(), var7_14.displayName_);
                if (var6_13 != GeneratedMessageLite.MergeFromVisitor.INSTANCE) return this;
                this.bitField0_ |= var7_14.bitField0_;
                return this;
            }
            case 5: {
                return new Builder(null);
            }
            case 3: {
                this.labels_.makeImmutable();
                return null;
            }
            case 0: {
                return MetricDescriptor.DEFAULT_INSTANCE;
            }
            case 4: 
        }
        return new MetricDescriptor();
    }

    public String getDescription() {
        return this.description_;
    }

    public ByteString getDescriptionBytes() {
        return ByteString.copyFromUtf8((String)this.description_);
    }

    public String getDisplayName() {
        return this.displayName_;
    }

    public ByteString getDisplayNameBytes() {
        return ByteString.copyFromUtf8((String)this.displayName_);
    }

    public LabelDescriptor getLabels(int n) {
        return (LabelDescriptor)((Object)this.labels_.get(n));
    }

    public int getLabelsCount() {
        return this.labels_.size();
    }

    public List<LabelDescriptor> getLabelsList() {
        return this.labels_;
    }

    public LabelDescriptorOrBuilder getLabelsOrBuilder(int n) {
        return (LabelDescriptorOrBuilder)this.labels_.get(n);
    }

    public List<? extends LabelDescriptorOrBuilder> getLabelsOrBuilderList() {
        return this.labels_;
    }

    public MetricKind getMetricKind() {
        MetricKind metricKind = MetricKind.forNumber((int)this.metricKind_);
        if (metricKind == null) {
            metricKind = MetricKind.UNRECOGNIZED;
        }
        return metricKind;
    }

    public int getMetricKindValue() {
        return this.metricKind_;
    }

    public String getName() {
        return this.name_;
    }

    public ByteString getNameBytes() {
        return ByteString.copyFromUtf8((String)this.name_);
    }

    public int getSerializedSize() {
        int n;
        int n2 = this.memoizedSerializedSize;
        if (n2 != -1) {
            return n2;
        }
        boolean bl = this.name_.isEmpty();
        int n3 = 0;
        if (!bl) {
            n = 0 + CodedOutputStream.computeStringSize((int)1, (String)this.getName());
            n3 = 0;
        } else {
            n = 0;
        }
        while (n3 < this.labels_.size()) {
            n += CodedOutputStream.computeMessageSize((int)2, (MessageLite)((MessageLite)this.labels_.get(n3)));
            ++n3;
        }
        if (this.metricKind_ != MetricKind.METRIC_KIND_UNSPECIFIED.getNumber()) {
            n += CodedOutputStream.computeEnumSize((int)3, (int)this.metricKind_);
        }
        if (this.valueType_ != ValueType.VALUE_TYPE_UNSPECIFIED.getNumber()) {
            n += CodedOutputStream.computeEnumSize((int)4, (int)this.valueType_);
        }
        if (!this.unit_.isEmpty()) {
            n += CodedOutputStream.computeStringSize((int)5, (String)this.getUnit());
        }
        if (!this.description_.isEmpty()) {
            n += CodedOutputStream.computeStringSize((int)6, (String)this.getDescription());
        }
        if (!this.displayName_.isEmpty()) {
            n += CodedOutputStream.computeStringSize((int)7, (String)this.getDisplayName());
        }
        if (!this.type_.isEmpty()) {
            n += CodedOutputStream.computeStringSize((int)8, (String)this.getType());
        }
        this.memoizedSerializedSize = n;
        return n;
    }

    public String getType() {
        return this.type_;
    }

    public ByteString getTypeBytes() {
        return ByteString.copyFromUtf8((String)this.type_);
    }

    public String getUnit() {
        return this.unit_;
    }

    public ByteString getUnitBytes() {
        return ByteString.copyFromUtf8((String)this.unit_);
    }

    public ValueType getValueType() {
        ValueType valueType = ValueType.forNumber((int)this.valueType_);
        if (valueType == null) {
            valueType = ValueType.UNRECOGNIZED;
        }
        return valueType;
    }

    public int getValueTypeValue() {
        return this.valueType_;
    }

    public void writeTo(CodedOutputStream codedOutputStream) throws IOException {
        if (!this.name_.isEmpty()) {
            codedOutputStream.writeString(1, this.getName());
        }
        for (int i = 0; i < this.labels_.size(); ++i) {
            codedOutputStream.writeMessage(2, (MessageLite)this.labels_.get(i));
        }
        if (this.metricKind_ != MetricKind.METRIC_KIND_UNSPECIFIED.getNumber()) {
            codedOutputStream.writeEnum(3, this.metricKind_);
        }
        if (this.valueType_ != ValueType.VALUE_TYPE_UNSPECIFIED.getNumber()) {
            codedOutputStream.writeEnum(4, this.valueType_);
        }
        if (!this.unit_.isEmpty()) {
            codedOutputStream.writeString(5, this.getUnit());
        }
        if (!this.description_.isEmpty()) {
            codedOutputStream.writeString(6, this.getDescription());
        }
        if (!this.displayName_.isEmpty()) {
            codedOutputStream.writeString(7, this.getDisplayName());
        }
        if (!this.type_.isEmpty()) {
            codedOutputStream.writeString(8, this.getType());
        }
    }

    public static final class Builder
    extends GeneratedMessageLite.Builder<MetricDescriptor, Builder>
    implements MetricDescriptorOrBuilder {
        private Builder() {
            super((GeneratedMessageLite)DEFAULT_INSTANCE);
        }

        public /* synthetic */ Builder(1 var1_1) {
            this();
        }

        public Builder addAllLabels(Iterable<? extends LabelDescriptor> iterable) {
            this.copyOnWrite();
            ((MetricDescriptor)this.instance).addAllLabels((Iterable<? extends LabelDescriptor>)iterable);
            return this;
        }

        public Builder addLabels(int n, LabelDescriptor.Builder builder) {
            this.copyOnWrite();
            ((MetricDescriptor)this.instance).addLabels(n, builder);
            return this;
        }

        public Builder addLabels(int n, LabelDescriptor labelDescriptor) {
            this.copyOnWrite();
            ((MetricDescriptor)this.instance).addLabels(n, labelDescriptor);
            return this;
        }

        public Builder addLabels(LabelDescriptor.Builder builder) {
            this.copyOnWrite();
            ((MetricDescriptor)this.instance).addLabels(builder);
            return this;
        }

        public Builder addLabels(LabelDescriptor labelDescriptor) {
            this.copyOnWrite();
            ((MetricDescriptor)this.instance).addLabels(labelDescriptor);
            return this;
        }

        public Builder clearDescription() {
            this.copyOnWrite();
            ((MetricDescriptor)this.instance).clearDescription();
            return this;
        }

        public Builder clearDisplayName() {
            this.copyOnWrite();
            ((MetricDescriptor)this.instance).clearDisplayName();
            return this;
        }

        public Builder clearLabels() {
            this.copyOnWrite();
            ((MetricDescriptor)this.instance).clearLabels();
            return this;
        }

        public Builder clearMetricKind() {
            this.copyOnWrite();
            ((MetricDescriptor)this.instance).clearMetricKind();
            return this;
        }

        public Builder clearName() {
            this.copyOnWrite();
            ((MetricDescriptor)this.instance).clearName();
            return this;
        }

        public Builder clearType() {
            this.copyOnWrite();
            ((MetricDescriptor)this.instance).clearType();
            return this;
        }

        public Builder clearUnit() {
            this.copyOnWrite();
            ((MetricDescriptor)this.instance).clearUnit();
            return this;
        }

        public Builder clearValueType() {
            this.copyOnWrite();
            ((MetricDescriptor)this.instance).clearValueType();
            return this;
        }

        public String getDescription() {
            return ((MetricDescriptor)this.instance).getDescription();
        }

        public ByteString getDescriptionBytes() {
            return ((MetricDescriptor)this.instance).getDescriptionBytes();
        }

        public String getDisplayName() {
            return ((MetricDescriptor)this.instance).getDisplayName();
        }

        public ByteString getDisplayNameBytes() {
            return ((MetricDescriptor)this.instance).getDisplayNameBytes();
        }

        public LabelDescriptor getLabels(int n) {
            return ((MetricDescriptor)this.instance).getLabels(n);
        }

        public int getLabelsCount() {
            return ((MetricDescriptor)this.instance).getLabelsCount();
        }

        public List<LabelDescriptor> getLabelsList() {
            return Collections.unmodifiableList(((MetricDescriptor)this.instance).getLabelsList());
        }

        public MetricKind getMetricKind() {
            return ((MetricDescriptor)this.instance).getMetricKind();
        }

        public int getMetricKindValue() {
            return ((MetricDescriptor)this.instance).getMetricKindValue();
        }

        public String getName() {
            return ((MetricDescriptor)this.instance).getName();
        }

        public ByteString getNameBytes() {
            return ((MetricDescriptor)this.instance).getNameBytes();
        }

        public String getType() {
            return ((MetricDescriptor)this.instance).getType();
        }

        public ByteString getTypeBytes() {
            return ((MetricDescriptor)this.instance).getTypeBytes();
        }

        public String getUnit() {
            return ((MetricDescriptor)this.instance).getUnit();
        }

        public ByteString getUnitBytes() {
            return ((MetricDescriptor)this.instance).getUnitBytes();
        }

        public ValueType getValueType() {
            return ((MetricDescriptor)this.instance).getValueType();
        }

        public int getValueTypeValue() {
            return ((MetricDescriptor)this.instance).getValueTypeValue();
        }

        public Builder removeLabels(int n) {
            this.copyOnWrite();
            ((MetricDescriptor)this.instance).removeLabels(n);
            return this;
        }

        public Builder setDescription(String string2) {
            this.copyOnWrite();
            ((MetricDescriptor)this.instance).setDescription(string2);
            return this;
        }

        public Builder setDescriptionBytes(ByteString byteString) {
            this.copyOnWrite();
            ((MetricDescriptor)this.instance).setDescriptionBytes(byteString);
            return this;
        }

        public Builder setDisplayName(String string2) {
            this.copyOnWrite();
            ((MetricDescriptor)this.instance).setDisplayName(string2);
            return this;
        }

        public Builder setDisplayNameBytes(ByteString byteString) {
            this.copyOnWrite();
            ((MetricDescriptor)this.instance).setDisplayNameBytes(byteString);
            return this;
        }

        public Builder setLabels(int n, LabelDescriptor.Builder builder) {
            this.copyOnWrite();
            ((MetricDescriptor)this.instance).setLabels(n, builder);
            return this;
        }

        public Builder setLabels(int n, LabelDescriptor labelDescriptor) {
            this.copyOnWrite();
            ((MetricDescriptor)this.instance).setLabels(n, labelDescriptor);
            return this;
        }

        public Builder setMetricKind(MetricKind metricKind) {
            this.copyOnWrite();
            ((MetricDescriptor)this.instance).setMetricKind(metricKind);
            return this;
        }

        public Builder setMetricKindValue(int n) {
            this.copyOnWrite();
            ((MetricDescriptor)this.instance).setMetricKindValue(n);
            return this;
        }

        public Builder setName(String string2) {
            this.copyOnWrite();
            ((MetricDescriptor)this.instance).setName(string2);
            return this;
        }

        public Builder setNameBytes(ByteString byteString) {
            this.copyOnWrite();
            ((MetricDescriptor)this.instance).setNameBytes(byteString);
            return this;
        }

        public Builder setType(String string2) {
            this.copyOnWrite();
            ((MetricDescriptor)this.instance).setType(string2);
            return this;
        }

        public Builder setTypeBytes(ByteString byteString) {
            this.copyOnWrite();
            ((MetricDescriptor)this.instance).setTypeBytes(byteString);
            return this;
        }

        public Builder setUnit(String string2) {
            this.copyOnWrite();
            ((MetricDescriptor)this.instance).setUnit(string2);
            return this;
        }

        public Builder setUnitBytes(ByteString byteString) {
            this.copyOnWrite();
            ((MetricDescriptor)this.instance).setUnitBytes(byteString);
            return this;
        }

        public Builder setValueType(ValueType valueType) {
            this.copyOnWrite();
            ((MetricDescriptor)this.instance).setValueType(valueType);
            return this;
        }

        public Builder setValueTypeValue(int n) {
            this.copyOnWrite();
            ((MetricDescriptor)this.instance).setValueTypeValue(n);
            return this;
        }
    }

}

