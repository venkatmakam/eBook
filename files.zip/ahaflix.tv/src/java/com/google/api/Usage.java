/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.api.Usage$1
 *  com.google.api.UsageOrBuilder
 *  com.google.api.UsageRuleOrBuilder
 *  com.google.protobuf.AbstractMessageLite
 *  com.google.protobuf.ByteString
 *  com.google.protobuf.CodedInputStream
 *  com.google.protobuf.CodedOutputStream
 *  com.google.protobuf.ExtensionRegistryLite
 *  com.google.protobuf.GeneratedMessageLite
 *  com.google.protobuf.GeneratedMessageLite$Builder
 *  com.google.protobuf.GeneratedMessageLite$DefaultInstanceBasedParser
 *  com.google.protobuf.GeneratedMessageLite$MergeFromVisitor
 *  com.google.protobuf.GeneratedMessageLite$MethodToInvoke
 *  com.google.protobuf.GeneratedMessageLite$Visitor
 *  com.google.protobuf.Internal
 *  com.google.protobuf.Internal$ProtobufList
 *  com.google.protobuf.InvalidProtocolBufferException
 *  com.google.protobuf.MessageLite
 *  com.google.protobuf.Parser
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Class
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 *  java.util.Collections
 *  java.util.List
 *  java.util.Objects
 */
package com.google.api;

import com.google.api.Usage;
import com.google.api.UsageOrBuilder;
import com.google.api.UsageRule;
import com.google.api.UsageRuleOrBuilder;
import com.google.protobuf.AbstractMessageLite;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.CodedOutputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.Internal;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.MessageLite;
import com.google.protobuf.Parser;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

public final class Usage
extends GeneratedMessageLite<Usage, Builder>
implements UsageOrBuilder {
    private static final Usage DEFAULT_INSTANCE;
    private static volatile Parser<Usage> PARSER;
    public static final int PRODUCER_NOTIFICATION_CHANNEL_FIELD_NUMBER = 7;
    public static final int REQUIREMENTS_FIELD_NUMBER = 1;
    public static final int RULES_FIELD_NUMBER = 6;
    private int bitField0_;
    private String producerNotificationChannel_ = "";
    private Internal.ProtobufList<String> requirements_ = GeneratedMessageLite.emptyProtobufList();
    private Internal.ProtobufList<UsageRule> rules_ = GeneratedMessageLite.emptyProtobufList();

    public static {
        Usage usage;
        DEFAULT_INSTANCE = usage = new Usage();
        usage.makeImmutable();
    }

    private Usage() {
    }

    private void addAllRequirements(Iterable<String> iterable) {
        this.ensureRequirementsIsMutable();
        AbstractMessageLite.addAll(iterable, this.requirements_);
    }

    private void addAllRules(Iterable<? extends UsageRule> iterable) {
        this.ensureRulesIsMutable();
        AbstractMessageLite.addAll(iterable, this.rules_);
    }

    private void addRequirements(String string2) {
        Objects.requireNonNull((Object)string2);
        this.ensureRequirementsIsMutable();
        this.requirements_.add((Object)string2);
    }

    private void addRequirementsBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.ensureRequirementsIsMutable();
        this.requirements_.add((Object)byteString.toStringUtf8());
    }

    private void addRules(int n, UsageRule.Builder builder) {
        this.ensureRulesIsMutable();
        this.rules_.add(n, (Object)((UsageRule)builder.build()));
    }

    private void addRules(int n, UsageRule usageRule) {
        Objects.requireNonNull((Object)((Object)usageRule));
        this.ensureRulesIsMutable();
        this.rules_.add(n, (Object)usageRule);
    }

    private void addRules(UsageRule.Builder builder) {
        this.ensureRulesIsMutable();
        this.rules_.add((Object)((UsageRule)builder.build()));
    }

    private void addRules(UsageRule usageRule) {
        Objects.requireNonNull((Object)((Object)usageRule));
        this.ensureRulesIsMutable();
        this.rules_.add((Object)usageRule);
    }

    private void clearProducerNotificationChannel() {
        this.producerNotificationChannel_ = Usage.getDefaultInstance().getProducerNotificationChannel();
    }

    private void clearRequirements() {
        this.requirements_ = GeneratedMessageLite.emptyProtobufList();
    }

    private void clearRules() {
        this.rules_ = GeneratedMessageLite.emptyProtobufList();
    }

    private void ensureRequirementsIsMutable() {
        if (!this.requirements_.isModifiable()) {
            this.requirements_ = GeneratedMessageLite.mutableCopy(this.requirements_);
        }
    }

    private void ensureRulesIsMutable() {
        if (!this.rules_.isModifiable()) {
            this.rules_ = GeneratedMessageLite.mutableCopy(this.rules_);
        }
    }

    public static Usage getDefaultInstance() {
        return DEFAULT_INSTANCE;
    }

    public static Builder newBuilder() {
        return (Builder)DEFAULT_INSTANCE.toBuilder();
    }

    public static Builder newBuilder(Usage usage) {
        return (Builder)((Builder)DEFAULT_INSTANCE.toBuilder()).mergeFrom((GeneratedMessageLite)usage);
    }

    public static Usage parseDelimitedFrom(InputStream inputStream) throws IOException {
        return (Usage)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static Usage parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (Usage)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Usage parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
        return (Usage)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString);
    }

    public static Usage parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (Usage)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Usage parseFrom(CodedInputStream codedInputStream) throws IOException {
        return (Usage)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream);
    }

    public static Usage parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (Usage)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Usage parseFrom(InputStream inputStream) throws IOException {
        return (Usage)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static Usage parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (Usage)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Usage parseFrom(byte[] arrby) throws InvalidProtocolBufferException {
        return (Usage)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby);
    }

    public static Usage parseFrom(byte[] arrby, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (Usage)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Parser<Usage> parser() {
        return DEFAULT_INSTANCE.getParserForType();
    }

    private void removeRules(int n) {
        this.ensureRulesIsMutable();
        this.rules_.remove(n);
    }

    private void setProducerNotificationChannel(String string2) {
        Objects.requireNonNull((Object)string2);
        this.producerNotificationChannel_ = string2;
    }

    private void setProducerNotificationChannelBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.producerNotificationChannel_ = byteString.toStringUtf8();
    }

    private void setRequirements(int n, String string2) {
        Objects.requireNonNull((Object)string2);
        this.ensureRequirementsIsMutable();
        this.requirements_.set(n, (Object)string2);
    }

    private void setRules(int n, UsageRule.Builder builder) {
        this.ensureRulesIsMutable();
        this.rules_.set(n, (Object)((UsageRule)builder.build()));
    }

    private void setRules(int n, UsageRule usageRule) {
        Objects.requireNonNull((Object)((Object)usageRule));
        this.ensureRulesIsMutable();
        this.rules_.set(n, (Object)usageRule);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke var1_1, Object var2_2, Object var3_3) {
        switch (var1_1.ordinal()) {
            default: {
                throw new UnsupportedOperationException();
            }
            case 7: {
                if (Usage.PARSER != null) return Usage.PARSER;
                var17_4 = Usage.class;
                // MONITORENTER : com.google.api.Usage.class
                if (Usage.PARSER == null) {
                    Usage.PARSER = new GeneratedMessageLite.DefaultInstanceBasedParser((GeneratedMessageLite)Usage.DEFAULT_INSTANCE);
                }
                // MONITOREXIT : var17_4
                return Usage.PARSER;
            }
            case 2: {
                var6_5 = (CodedInputStream)var2_2;
                var7_6 = (ExtensionRegistryLite)var3_3;
                var8_7 = false;
                while (var8_7 == false) {
                    var12_8 = var6_5.readTag();
                    if (var12_8 == 0) ** GOTO lbl37
                    if (var12_8 == 10) ** GOTO lbl32
                    if (var12_8 == 50) ** GOTO lbl28
                    if (var12_8 != 58) {
                        if (var6_5.skipField(var12_8)) continue;
                    } else {
                        this.producerNotificationChannel_ = var6_5.readStringRequireUtf8();
                        continue;
lbl28: // 1 sources:
                        if (!this.rules_.isModifiable()) {
                            this.rules_ = GeneratedMessageLite.mutableCopy(this.rules_);
                        }
                        this.rules_.add((Object)((UsageRule)var6_5.readMessage(UsageRule.parser(), var7_6)));
                        continue;
lbl32: // 1 sources:
                        var13_9 = var6_5.readStringRequireUtf8();
                        if (!this.requirements_.isModifiable()) {
                            this.requirements_ = GeneratedMessageLite.mutableCopy(this.requirements_);
                        }
                        this.requirements_.add((Object)var13_9);
                        continue;
                    }
lbl37: // 2 sources:
                    var8_7 = true;
                    continue;
                    catch (IOException var11_11) {
                        throw new RuntimeException((Throwable)new InvalidProtocolBufferException(var11_11.getMessage()).setUnfinishedMessage((MessageLite)this));
                    }
                    catch (InvalidProtocolBufferException var9_12) {
                        throw new RuntimeException((Throwable)var9_12.setUnfinishedMessage((MessageLite)this));
                    }
                }
                return Usage.DEFAULT_INSTANCE;
            }
            case 6: {
                return Usage.DEFAULT_INSTANCE;
            }
            case 1: {
                var4_13 = (GeneratedMessageLite.Visitor)var2_2;
                var5_14 = (Usage)var3_3;
                this.requirements_ = var4_13.visitList(this.requirements_, var5_14.requirements_);
                this.rules_ = var4_13.visitList(this.rules_, var5_14.rules_);
                this.producerNotificationChannel_ = var4_13.visitString(true ^ this.producerNotificationChannel_.isEmpty(), this.producerNotificationChannel_, true ^ var5_14.producerNotificationChannel_.isEmpty(), var5_14.producerNotificationChannel_);
                if (var4_13 != GeneratedMessageLite.MergeFromVisitor.INSTANCE) return this;
                this.bitField0_ |= var5_14.bitField0_;
                return this;
            }
            case 5: {
                return new Builder(null);
            }
            case 3: {
                this.requirements_.makeImmutable();
                this.rules_.makeImmutable();
                return null;
            }
            case 0: {
                return Usage.DEFAULT_INSTANCE;
            }
            case 4: 
        }
        return new Usage();
    }

    public String getProducerNotificationChannel() {
        return this.producerNotificationChannel_;
    }

    public ByteString getProducerNotificationChannelBytes() {
        return ByteString.copyFromUtf8((String)this.producerNotificationChannel_);
    }

    public String getRequirements(int n) {
        return (String)this.requirements_.get(n);
    }

    public ByteString getRequirementsBytes(int n) {
        return ByteString.copyFromUtf8((String)((String)this.requirements_.get(n)));
    }

    public int getRequirementsCount() {
        return this.requirements_.size();
    }

    public List<String> getRequirementsList() {
        return this.requirements_;
    }

    public UsageRule getRules(int n) {
        return (UsageRule)((Object)this.rules_.get(n));
    }

    public int getRulesCount() {
        return this.rules_.size();
    }

    public List<UsageRule> getRulesList() {
        return this.rules_;
    }

    public UsageRuleOrBuilder getRulesOrBuilder(int n) {
        return (UsageRuleOrBuilder)this.rules_.get(n);
    }

    public List<? extends UsageRuleOrBuilder> getRulesOrBuilderList() {
        return this.rules_;
    }

    public int getSerializedSize() {
        int n = this.memoizedSerializedSize;
        if (n != -1) {
            return n;
        }
        int n2 = 0;
        int n3 = 0;
        for (int i = 0; i < this.requirements_.size(); ++i) {
            n3 += CodedOutputStream.computeStringSizeNoTag((String)((String)this.requirements_.get(i)));
        }
        int n4 = n3 + 0 + 1 * this.getRequirementsList().size();
        while (n2 < this.rules_.size()) {
            n4 += CodedOutputStream.computeMessageSize((int)6, (MessageLite)((MessageLite)this.rules_.get(n2)));
            ++n2;
        }
        if (!this.producerNotificationChannel_.isEmpty()) {
            n4 += CodedOutputStream.computeStringSize((int)7, (String)this.getProducerNotificationChannel());
        }
        this.memoizedSerializedSize = n4;
        return n4;
    }

    public void writeTo(CodedOutputStream codedOutputStream) throws IOException {
        int n = 0;
        do {
            int n2 = this.requirements_.size();
            if (n >= n2) break;
            codedOutputStream.writeString(1, (String)this.requirements_.get(n));
            ++n;
        } while (true);
        for (int i = 0; i < this.rules_.size(); ++i) {
            codedOutputStream.writeMessage(6, (MessageLite)this.rules_.get(i));
        }
        if (!this.producerNotificationChannel_.isEmpty()) {
            codedOutputStream.writeString(7, this.getProducerNotificationChannel());
        }
    }

    public static final class Builder
    extends GeneratedMessageLite.Builder<Usage, Builder>
    implements UsageOrBuilder {
        private Builder() {
            super((GeneratedMessageLite)DEFAULT_INSTANCE);
        }

        public /* synthetic */ Builder(1 var1_1) {
            this();
        }

        public Builder addAllRequirements(Iterable<String> iterable) {
            this.copyOnWrite();
            ((Usage)this.instance).addAllRequirements((Iterable<String>)iterable);
            return this;
        }

        public Builder addAllRules(Iterable<? extends UsageRule> iterable) {
            this.copyOnWrite();
            ((Usage)this.instance).addAllRules((Iterable<? extends UsageRule>)iterable);
            return this;
        }

        public Builder addRequirements(String string2) {
            this.copyOnWrite();
            ((Usage)this.instance).addRequirements(string2);
            return this;
        }

        public Builder addRequirementsBytes(ByteString byteString) {
            this.copyOnWrite();
            ((Usage)this.instance).addRequirementsBytes(byteString);
            return this;
        }

        public Builder addRules(int n, UsageRule.Builder builder) {
            this.copyOnWrite();
            ((Usage)this.instance).addRules(n, builder);
            return this;
        }

        public Builder addRules(int n, UsageRule usageRule) {
            this.copyOnWrite();
            ((Usage)this.instance).addRules(n, usageRule);
            return this;
        }

        public Builder addRules(UsageRule.Builder builder) {
            this.copyOnWrite();
            ((Usage)this.instance).addRules(builder);
            return this;
        }

        public Builder addRules(UsageRule usageRule) {
            this.copyOnWrite();
            ((Usage)this.instance).addRules(usageRule);
            return this;
        }

        public Builder clearProducerNotificationChannel() {
            this.copyOnWrite();
            ((Usage)this.instance).clearProducerNotificationChannel();
            return this;
        }

        public Builder clearRequirements() {
            this.copyOnWrite();
            ((Usage)this.instance).clearRequirements();
            return this;
        }

        public Builder clearRules() {
            this.copyOnWrite();
            ((Usage)this.instance).clearRules();
            return this;
        }

        public String getProducerNotificationChannel() {
            return ((Usage)this.instance).getProducerNotificationChannel();
        }

        public ByteString getProducerNotificationChannelBytes() {
            return ((Usage)this.instance).getProducerNotificationChannelBytes();
        }

        public String getRequirements(int n) {
            return ((Usage)this.instance).getRequirements(n);
        }

        public ByteString getRequirementsBytes(int n) {
            return ((Usage)this.instance).getRequirementsBytes(n);
        }

        public int getRequirementsCount() {
            return ((Usage)this.instance).getRequirementsCount();
        }

        public List<String> getRequirementsList() {
            return Collections.unmodifiableList(((Usage)this.instance).getRequirementsList());
        }

        public UsageRule getRules(int n) {
            return ((Usage)this.instance).getRules(n);
        }

        public int getRulesCount() {
            return ((Usage)this.instance).getRulesCount();
        }

        public List<UsageRule> getRulesList() {
            return Collections.unmodifiableList(((Usage)this.instance).getRulesList());
        }

        public Builder removeRules(int n) {
            this.copyOnWrite();
            ((Usage)this.instance).removeRules(n);
            return this;
        }

        public Builder setProducerNotificationChannel(String string2) {
            this.copyOnWrite();
            ((Usage)this.instance).setProducerNotificationChannel(string2);
            return this;
        }

        public Builder setProducerNotificationChannelBytes(ByteString byteString) {
            this.copyOnWrite();
            ((Usage)this.instance).setProducerNotificationChannelBytes(byteString);
            return this;
        }

        public Builder setRequirements(int n, String string2) {
            this.copyOnWrite();
            ((Usage)this.instance).setRequirements(n, string2);
            return this;
        }

        public Builder setRules(int n, UsageRule.Builder builder) {
            this.copyOnWrite();
            ((Usage)this.instance).setRules(n, builder);
            return this;
        }

        public Builder setRules(int n, UsageRule usageRule) {
            this.copyOnWrite();
            ((Usage)this.instance).setRules(n, usageRule);
            return this;
        }
    }

}

