/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.api.LabelDescriptor$1
 *  com.google.api.LabelDescriptor$ValueType
 *  com.google.api.LabelDescriptorOrBuilder
 *  com.google.protobuf.AbstractMessageLite
 *  com.google.protobuf.ByteString
 *  com.google.protobuf.CodedInputStream
 *  com.google.protobuf.CodedOutputStream
 *  com.google.protobuf.ExtensionRegistryLite
 *  com.google.protobuf.GeneratedMessageLite
 *  com.google.protobuf.GeneratedMessageLite$Builder
 *  com.google.protobuf.GeneratedMessageLite$DefaultInstanceBasedParser
 *  com.google.protobuf.GeneratedMessageLite$MethodToInvoke
 *  com.google.protobuf.GeneratedMessageLite$Visitor
 *  com.google.protobuf.InvalidProtocolBufferException
 *  com.google.protobuf.MessageLite
 *  com.google.protobuf.Parser
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 *  java.util.Objects
 */
package com.google.api;

import com.google.api.LabelDescriptor;
import com.google.api.LabelDescriptorOrBuilder;
import com.google.protobuf.AbstractMessageLite;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.CodedOutputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.MessageLite;
import com.google.protobuf.Parser;
import java.io.IOException;
import java.io.InputStream;
import java.util.Objects;

/*
 * Exception performing whole class analysis ignored.
 */
public final class LabelDescriptor
extends GeneratedMessageLite<LabelDescriptor, Builder>
implements LabelDescriptorOrBuilder {
    private static final LabelDescriptor DEFAULT_INSTANCE;
    public static final int DESCRIPTION_FIELD_NUMBER = 3;
    public static final int KEY_FIELD_NUMBER = 1;
    private static volatile Parser<LabelDescriptor> PARSER;
    public static final int VALUE_TYPE_FIELD_NUMBER = 2;
    private String description_ = "";
    private String key_ = "";
    private int valueType_;

    public static {
        LabelDescriptor labelDescriptor;
        DEFAULT_INSTANCE = labelDescriptor = new LabelDescriptor();
        labelDescriptor.makeImmutable();
    }

    private LabelDescriptor() {
    }

    private void clearDescription() {
        this.description_ = LabelDescriptor.getDefaultInstance().getDescription();
    }

    private void clearKey() {
        this.key_ = LabelDescriptor.getDefaultInstance().getKey();
    }

    private void clearValueType() {
        this.valueType_ = 0;
    }

    public static LabelDescriptor getDefaultInstance() {
        return DEFAULT_INSTANCE;
    }

    public static Builder newBuilder() {
        return (Builder)DEFAULT_INSTANCE.toBuilder();
    }

    public static Builder newBuilder(LabelDescriptor labelDescriptor) {
        return (Builder)((Builder)DEFAULT_INSTANCE.toBuilder()).mergeFrom((GeneratedMessageLite)labelDescriptor);
    }

    public static LabelDescriptor parseDelimitedFrom(InputStream inputStream) throws IOException {
        return (LabelDescriptor)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static LabelDescriptor parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (LabelDescriptor)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static LabelDescriptor parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
        return (LabelDescriptor)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString);
    }

    public static LabelDescriptor parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (LabelDescriptor)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static LabelDescriptor parseFrom(CodedInputStream codedInputStream) throws IOException {
        return (LabelDescriptor)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream);
    }

    public static LabelDescriptor parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (LabelDescriptor)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static LabelDescriptor parseFrom(InputStream inputStream) throws IOException {
        return (LabelDescriptor)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static LabelDescriptor parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (LabelDescriptor)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static LabelDescriptor parseFrom(byte[] arrby) throws InvalidProtocolBufferException {
        return (LabelDescriptor)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby);
    }

    public static LabelDescriptor parseFrom(byte[] arrby, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (LabelDescriptor)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Parser<LabelDescriptor> parser() {
        return DEFAULT_INSTANCE.getParserForType();
    }

    private void setDescription(String string2) {
        Objects.requireNonNull((Object)string2);
        this.description_ = string2;
    }

    private void setDescriptionBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.description_ = byteString.toStringUtf8();
    }

    private void setKey(String string2) {
        Objects.requireNonNull((Object)string2);
        this.key_ = string2;
    }

    private void setKeyBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.key_ = byteString.toStringUtf8();
    }

    private void setValueType(ValueType valueType) {
        Objects.requireNonNull((Object)valueType);
        this.valueType_ = valueType.getNumber();
    }

    private void setValueTypeValue(int n) {
        this.valueType_ = n;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke var1_1, Object var2_2, Object var3_3) {
        var4_4 = var1_1.ordinal();
        var5_5 = false;
        switch (var4_4) {
            default: {
                throw new UnsupportedOperationException();
            }
            case 7: {
                if (LabelDescriptor.PARSER != null) return LabelDescriptor.PARSER;
                var20_6 = LabelDescriptor.class;
                // MONITORENTER : com.google.api.LabelDescriptor.class
                if (LabelDescriptor.PARSER == null) {
                    LabelDescriptor.PARSER = new GeneratedMessageLite.DefaultInstanceBasedParser((GeneratedMessageLite)LabelDescriptor.DEFAULT_INSTANCE);
                }
                // MONITOREXIT : var20_6
                return LabelDescriptor.PARSER;
            }
            case 2: {
                var13_7 = (CodedInputStream)var2_2;
                (ExtensionRegistryLite)var3_3;
                while (var5_5 == false) {
                    var18_8 = var13_7.readTag();
                    if (var18_8 == 0) ** GOTO lbl33
                    if (var18_8 == 10) ** GOTO lbl31
                    if (var18_8 == 16) ** GOTO lbl29
                    if (var18_8 != 26) {
                        if (var13_7.skipField(var18_8)) continue;
                    } else {
                        this.description_ = var13_7.readStringRequireUtf8();
                        continue;
lbl29: // 1 sources:
                        this.valueType_ = var13_7.readEnum();
                        continue;
lbl31: // 1 sources:
                        this.key_ = var13_7.readStringRequireUtf8();
                        continue;
                    }
lbl33: // 2 sources:
                    var5_5 = true;
                    continue;
                    catch (IOException var17_10) {
                        throw new RuntimeException((Throwable)new InvalidProtocolBufferException(var17_10.getMessage()).setUnfinishedMessage((MessageLite)this));
                    }
                    catch (InvalidProtocolBufferException var15_11) {
                        throw new RuntimeException((Throwable)var15_11.setUnfinishedMessage((MessageLite)this));
                    }
                }
                return LabelDescriptor.DEFAULT_INSTANCE;
            }
            case 6: {
                return LabelDescriptor.DEFAULT_INSTANCE;
            }
            case 1: {
                var6_12 = (GeneratedMessageLite.Visitor)var2_2;
                var7_13 = (LabelDescriptor)var3_3;
                this.key_ = var6_12.visitString(true ^ this.key_.isEmpty(), this.key_, true ^ var7_13.key_.isEmpty(), var7_13.key_);
                var8_14 = this.valueType_;
                var9_15 = var8_14 != 0;
                var10_16 = var7_13.valueType_;
                var11_17 = false;
                if (var10_16 != 0) {
                    var11_17 = true;
                }
                this.valueType_ = var6_12.visitInt(var9_15, var8_14, var11_17, var10_16);
                this.description_ = var6_12.visitString(true ^ this.description_.isEmpty(), this.description_, true ^ var7_13.description_.isEmpty(), var7_13.description_);
                return this;
            }
            case 5: {
                return new Builder(null);
            }
            case 3: {
                return null;
            }
            case 0: {
                return LabelDescriptor.DEFAULT_INSTANCE;
            }
            case 4: 
        }
        return new LabelDescriptor();
    }

    public String getDescription() {
        return this.description_;
    }

    public ByteString getDescriptionBytes() {
        return ByteString.copyFromUtf8((String)this.description_);
    }

    public String getKey() {
        return this.key_;
    }

    public ByteString getKeyBytes() {
        return ByteString.copyFromUtf8((String)this.key_);
    }

    public int getSerializedSize() {
        int n = this.memoizedSerializedSize;
        if (n != -1) {
            return n;
        }
        boolean bl = this.key_.isEmpty();
        int n2 = 0;
        if (!bl) {
            n2 = 0 + CodedOutputStream.computeStringSize((int)1, (String)this.getKey());
        }
        if (this.valueType_ != ValueType.STRING.getNumber()) {
            n2 += CodedOutputStream.computeEnumSize((int)2, (int)this.valueType_);
        }
        if (!this.description_.isEmpty()) {
            n2 += CodedOutputStream.computeStringSize((int)3, (String)this.getDescription());
        }
        this.memoizedSerializedSize = n2;
        return n2;
    }

    public ValueType getValueType() {
        ValueType valueType = ValueType.forNumber((int)this.valueType_);
        if (valueType == null) {
            valueType = ValueType.UNRECOGNIZED;
        }
        return valueType;
    }

    public int getValueTypeValue() {
        return this.valueType_;
    }

    public void writeTo(CodedOutputStream codedOutputStream) throws IOException {
        if (!this.key_.isEmpty()) {
            codedOutputStream.writeString(1, this.getKey());
        }
        if (this.valueType_ != ValueType.STRING.getNumber()) {
            codedOutputStream.writeEnum(2, this.valueType_);
        }
        if (!this.description_.isEmpty()) {
            codedOutputStream.writeString(3, this.getDescription());
        }
    }

    public static final class Builder
    extends GeneratedMessageLite.Builder<LabelDescriptor, Builder>
    implements LabelDescriptorOrBuilder {
        private Builder() {
            super((GeneratedMessageLite)DEFAULT_INSTANCE);
        }

        public /* synthetic */ Builder(1 var1_1) {
            this();
        }

        public Builder clearDescription() {
            this.copyOnWrite();
            ((LabelDescriptor)this.instance).clearDescription();
            return this;
        }

        public Builder clearKey() {
            this.copyOnWrite();
            ((LabelDescriptor)this.instance).clearKey();
            return this;
        }

        public Builder clearValueType() {
            this.copyOnWrite();
            ((LabelDescriptor)this.instance).clearValueType();
            return this;
        }

        public String getDescription() {
            return ((LabelDescriptor)this.instance).getDescription();
        }

        public ByteString getDescriptionBytes() {
            return ((LabelDescriptor)this.instance).getDescriptionBytes();
        }

        public String getKey() {
            return ((LabelDescriptor)this.instance).getKey();
        }

        public ByteString getKeyBytes() {
            return ((LabelDescriptor)this.instance).getKeyBytes();
        }

        public ValueType getValueType() {
            return ((LabelDescriptor)this.instance).getValueType();
        }

        public int getValueTypeValue() {
            return ((LabelDescriptor)this.instance).getValueTypeValue();
        }

        public Builder setDescription(String string2) {
            this.copyOnWrite();
            ((LabelDescriptor)this.instance).setDescription(string2);
            return this;
        }

        public Builder setDescriptionBytes(ByteString byteString) {
            this.copyOnWrite();
            ((LabelDescriptor)this.instance).setDescriptionBytes(byteString);
            return this;
        }

        public Builder setKey(String string2) {
            this.copyOnWrite();
            ((LabelDescriptor)this.instance).setKey(string2);
            return this;
        }

        public Builder setKeyBytes(ByteString byteString) {
            this.copyOnWrite();
            ((LabelDescriptor)this.instance).setKeyBytes(byteString);
            return this;
        }

        public Builder setValueType(ValueType valueType) {
            this.copyOnWrite();
            ((LabelDescriptor)this.instance).setValueType(valueType);
            return this;
        }

        public Builder setValueTypeValue(int n) {
            this.copyOnWrite();
            ((LabelDescriptor)this.instance).setValueTypeValue(n);
            return this;
        }
    }

}

