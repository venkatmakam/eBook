/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.api.AuthProviderOrBuilder
 *  com.google.api.Authentication$1
 *  com.google.api.AuthenticationOrBuilder
 *  com.google.api.AuthenticationRuleOrBuilder
 *  com.google.protobuf.AbstractMessageLite
 *  com.google.protobuf.ByteString
 *  com.google.protobuf.CodedInputStream
 *  com.google.protobuf.CodedOutputStream
 *  com.google.protobuf.ExtensionRegistryLite
 *  com.google.protobuf.GeneratedMessageLite
 *  com.google.protobuf.GeneratedMessageLite$Builder
 *  com.google.protobuf.GeneratedMessageLite$DefaultInstanceBasedParser
 *  com.google.protobuf.GeneratedMessageLite$MethodToInvoke
 *  com.google.protobuf.GeneratedMessageLite$Visitor
 *  com.google.protobuf.Internal
 *  com.google.protobuf.Internal$ProtobufList
 *  com.google.protobuf.InvalidProtocolBufferException
 *  com.google.protobuf.MessageLite
 *  com.google.protobuf.Parser
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Class
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 *  java.util.Collections
 *  java.util.List
 *  java.util.Objects
 */
package com.google.api;

import com.google.api.AuthProvider;
import com.google.api.AuthProviderOrBuilder;
import com.google.api.Authentication;
import com.google.api.AuthenticationOrBuilder;
import com.google.api.AuthenticationRule;
import com.google.api.AuthenticationRuleOrBuilder;
import com.google.protobuf.AbstractMessageLite;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.CodedOutputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.Internal;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.MessageLite;
import com.google.protobuf.Parser;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

public final class Authentication
extends GeneratedMessageLite<Authentication, Builder>
implements AuthenticationOrBuilder {
    private static final Authentication DEFAULT_INSTANCE;
    private static volatile Parser<Authentication> PARSER;
    public static final int PROVIDERS_FIELD_NUMBER = 4;
    public static final int RULES_FIELD_NUMBER = 3;
    private Internal.ProtobufList<AuthProvider> providers_ = GeneratedMessageLite.emptyProtobufList();
    private Internal.ProtobufList<AuthenticationRule> rules_ = GeneratedMessageLite.emptyProtobufList();

    public static {
        Authentication authentication;
        DEFAULT_INSTANCE = authentication = new Authentication();
        authentication.makeImmutable();
    }

    private Authentication() {
    }

    private void addAllProviders(Iterable<? extends AuthProvider> iterable) {
        this.ensureProvidersIsMutable();
        AbstractMessageLite.addAll(iterable, this.providers_);
    }

    private void addAllRules(Iterable<? extends AuthenticationRule> iterable) {
        this.ensureRulesIsMutable();
        AbstractMessageLite.addAll(iterable, this.rules_);
    }

    private void addProviders(int n, AuthProvider.Builder builder) {
        this.ensureProvidersIsMutable();
        this.providers_.add(n, (Object)((AuthProvider)builder.build()));
    }

    private void addProviders(int n, AuthProvider authProvider) {
        Objects.requireNonNull((Object)((Object)authProvider));
        this.ensureProvidersIsMutable();
        this.providers_.add(n, (Object)authProvider);
    }

    private void addProviders(AuthProvider.Builder builder) {
        this.ensureProvidersIsMutable();
        this.providers_.add((Object)((AuthProvider)builder.build()));
    }

    private void addProviders(AuthProvider authProvider) {
        Objects.requireNonNull((Object)((Object)authProvider));
        this.ensureProvidersIsMutable();
        this.providers_.add((Object)authProvider);
    }

    private void addRules(int n, AuthenticationRule.Builder builder) {
        this.ensureRulesIsMutable();
        this.rules_.add(n, (Object)((AuthenticationRule)builder.build()));
    }

    private void addRules(int n, AuthenticationRule authenticationRule) {
        Objects.requireNonNull((Object)((Object)authenticationRule));
        this.ensureRulesIsMutable();
        this.rules_.add(n, (Object)authenticationRule);
    }

    private void addRules(AuthenticationRule.Builder builder) {
        this.ensureRulesIsMutable();
        this.rules_.add((Object)((AuthenticationRule)builder.build()));
    }

    private void addRules(AuthenticationRule authenticationRule) {
        Objects.requireNonNull((Object)((Object)authenticationRule));
        this.ensureRulesIsMutable();
        this.rules_.add((Object)authenticationRule);
    }

    private void clearProviders() {
        this.providers_ = GeneratedMessageLite.emptyProtobufList();
    }

    private void clearRules() {
        this.rules_ = GeneratedMessageLite.emptyProtobufList();
    }

    private void ensureProvidersIsMutable() {
        if (!this.providers_.isModifiable()) {
            this.providers_ = GeneratedMessageLite.mutableCopy(this.providers_);
        }
    }

    private void ensureRulesIsMutable() {
        if (!this.rules_.isModifiable()) {
            this.rules_ = GeneratedMessageLite.mutableCopy(this.rules_);
        }
    }

    public static Authentication getDefaultInstance() {
        return DEFAULT_INSTANCE;
    }

    public static Builder newBuilder() {
        return (Builder)DEFAULT_INSTANCE.toBuilder();
    }

    public static Builder newBuilder(Authentication authentication) {
        return (Builder)((Builder)DEFAULT_INSTANCE.toBuilder()).mergeFrom((GeneratedMessageLite)authentication);
    }

    public static Authentication parseDelimitedFrom(InputStream inputStream) throws IOException {
        return (Authentication)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static Authentication parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (Authentication)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Authentication parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
        return (Authentication)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString);
    }

    public static Authentication parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (Authentication)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Authentication parseFrom(CodedInputStream codedInputStream) throws IOException {
        return (Authentication)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream);
    }

    public static Authentication parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (Authentication)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Authentication parseFrom(InputStream inputStream) throws IOException {
        return (Authentication)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static Authentication parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (Authentication)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Authentication parseFrom(byte[] arrby) throws InvalidProtocolBufferException {
        return (Authentication)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby);
    }

    public static Authentication parseFrom(byte[] arrby, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (Authentication)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Parser<Authentication> parser() {
        return DEFAULT_INSTANCE.getParserForType();
    }

    private void removeProviders(int n) {
        this.ensureProvidersIsMutable();
        this.providers_.remove(n);
    }

    private void removeRules(int n) {
        this.ensureRulesIsMutable();
        this.rules_.remove(n);
    }

    private void setProviders(int n, AuthProvider.Builder builder) {
        this.ensureProvidersIsMutable();
        this.providers_.set(n, (Object)((AuthProvider)builder.build()));
    }

    private void setProviders(int n, AuthProvider authProvider) {
        Objects.requireNonNull((Object)((Object)authProvider));
        this.ensureProvidersIsMutable();
        this.providers_.set(n, (Object)authProvider);
    }

    private void setRules(int n, AuthenticationRule.Builder builder) {
        this.ensureRulesIsMutable();
        this.rules_.set(n, (Object)((AuthenticationRule)builder.build()));
    }

    private void setRules(int n, AuthenticationRule authenticationRule) {
        Objects.requireNonNull((Object)((Object)authenticationRule));
        this.ensureRulesIsMutable();
        this.rules_.set(n, (Object)authenticationRule);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke var1_1, Object var2_2, Object var3_3) {
        switch (var1_1.ordinal()) {
            default: {
                throw new UnsupportedOperationException();
            }
            case 7: {
                if (Authentication.PARSER != null) return Authentication.PARSER;
                var17_4 = Authentication.class;
                // MONITORENTER : com.google.api.Authentication.class
                if (Authentication.PARSER == null) {
                    Authentication.PARSER = new GeneratedMessageLite.DefaultInstanceBasedParser((GeneratedMessageLite)Authentication.DEFAULT_INSTANCE);
                }
                // MONITOREXIT : var17_4
                return Authentication.PARSER;
            }
            case 2: {
                var7_5 = (CodedInputStream)var2_2;
                var8_6 = (ExtensionRegistryLite)var3_3;
                var9_7 = false;
                while (var9_7 == false) {
                    var13_8 = var7_5.readTag();
                    if (var13_8 == 0) ** GOTO lbl33
                    if (var13_8 == 26) ** GOTO lbl29
                    if (var13_8 != 34) {
                        if (var7_5.skipField(var13_8)) continue;
                    } else {
                        if (!this.providers_.isModifiable()) {
                            this.providers_ = GeneratedMessageLite.mutableCopy(this.providers_);
                        }
                        this.providers_.add((Object)((AuthProvider)var7_5.readMessage(AuthProvider.parser(), var8_6)));
                        continue;
lbl29: // 1 sources:
                        if (!this.rules_.isModifiable()) {
                            this.rules_ = GeneratedMessageLite.mutableCopy(this.rules_);
                        }
                        this.rules_.add((Object)((AuthenticationRule)var7_5.readMessage(AuthenticationRule.parser(), var8_6)));
                        continue;
                    }
lbl33: // 2 sources:
                    var9_7 = true;
                    continue;
                    catch (IOException var12_10) {
                        throw new RuntimeException((Throwable)new InvalidProtocolBufferException(var12_10.getMessage()).setUnfinishedMessage((MessageLite)this));
                    }
                    catch (InvalidProtocolBufferException var10_11) {
                        throw new RuntimeException((Throwable)var10_11.setUnfinishedMessage((MessageLite)this));
                    }
                }
                return Authentication.DEFAULT_INSTANCE;
            }
            case 6: {
                return Authentication.DEFAULT_INSTANCE;
            }
            case 1: {
                var4_12 = (GeneratedMessageLite.Visitor)var2_2;
                var5_13 = (Authentication)var3_3;
                this.rules_ = var4_12.visitList(this.rules_, var5_13.rules_);
                this.providers_ = var4_12.visitList(this.providers_, var5_13.providers_);
                return this;
            }
            case 5: {
                return new Builder(null);
            }
            case 3: {
                this.rules_.makeImmutable();
                this.providers_.makeImmutable();
                return null;
            }
            case 0: {
                return Authentication.DEFAULT_INSTANCE;
            }
            case 4: 
        }
        return new Authentication();
    }

    public AuthProvider getProviders(int n) {
        return (AuthProvider)((Object)this.providers_.get(n));
    }

    public int getProvidersCount() {
        return this.providers_.size();
    }

    public List<AuthProvider> getProvidersList() {
        return this.providers_;
    }

    public AuthProviderOrBuilder getProvidersOrBuilder(int n) {
        return (AuthProviderOrBuilder)this.providers_.get(n);
    }

    public List<? extends AuthProviderOrBuilder> getProvidersOrBuilderList() {
        return this.providers_;
    }

    public AuthenticationRule getRules(int n) {
        return (AuthenticationRule)((Object)this.rules_.get(n));
    }

    public int getRulesCount() {
        return this.rules_.size();
    }

    public List<AuthenticationRule> getRulesList() {
        return this.rules_;
    }

    public AuthenticationRuleOrBuilder getRulesOrBuilder(int n) {
        return (AuthenticationRuleOrBuilder)this.rules_.get(n);
    }

    public List<? extends AuthenticationRuleOrBuilder> getRulesOrBuilderList() {
        return this.rules_;
    }

    public int getSerializedSize() {
        int n = this.memoizedSerializedSize;
        if (n != -1) {
            return n;
        }
        int n2 = 0;
        int n3 = 0;
        do {
            int n4 = this.rules_.size();
            if (n2 >= n4) break;
            n3 += CodedOutputStream.computeMessageSize((int)3, (MessageLite)((MessageLite)this.rules_.get(n2)));
            ++n2;
        } while (true);
        for (int i = 0; i < this.providers_.size(); ++i) {
            n3 += CodedOutputStream.computeMessageSize((int)4, (MessageLite)((MessageLite)this.providers_.get(i)));
        }
        this.memoizedSerializedSize = n3;
        return n3;
    }

    public void writeTo(CodedOutputStream codedOutputStream) throws IOException {
        int n = 0;
        do {
            int n2 = this.rules_.size();
            if (n >= n2) break;
            codedOutputStream.writeMessage(3, (MessageLite)this.rules_.get(n));
            ++n;
        } while (true);
        for (int i = 0; i < this.providers_.size(); ++i) {
            codedOutputStream.writeMessage(4, (MessageLite)this.providers_.get(i));
        }
    }

    public static final class Builder
    extends GeneratedMessageLite.Builder<Authentication, Builder>
    implements AuthenticationOrBuilder {
        private Builder() {
            super((GeneratedMessageLite)DEFAULT_INSTANCE);
        }

        public /* synthetic */ Builder(1 var1_1) {
            this();
        }

        public Builder addAllProviders(Iterable<? extends AuthProvider> iterable) {
            this.copyOnWrite();
            ((Authentication)this.instance).addAllProviders((Iterable<? extends AuthProvider>)iterable);
            return this;
        }

        public Builder addAllRules(Iterable<? extends AuthenticationRule> iterable) {
            this.copyOnWrite();
            ((Authentication)this.instance).addAllRules((Iterable<? extends AuthenticationRule>)iterable);
            return this;
        }

        public Builder addProviders(int n, AuthProvider.Builder builder) {
            this.copyOnWrite();
            ((Authentication)this.instance).addProviders(n, builder);
            return this;
        }

        public Builder addProviders(int n, AuthProvider authProvider) {
            this.copyOnWrite();
            ((Authentication)this.instance).addProviders(n, authProvider);
            return this;
        }

        public Builder addProviders(AuthProvider.Builder builder) {
            this.copyOnWrite();
            ((Authentication)this.instance).addProviders(builder);
            return this;
        }

        public Builder addProviders(AuthProvider authProvider) {
            this.copyOnWrite();
            ((Authentication)this.instance).addProviders(authProvider);
            return this;
        }

        public Builder addRules(int n, AuthenticationRule.Builder builder) {
            this.copyOnWrite();
            ((Authentication)this.instance).addRules(n, builder);
            return this;
        }

        public Builder addRules(int n, AuthenticationRule authenticationRule) {
            this.copyOnWrite();
            ((Authentication)this.instance).addRules(n, authenticationRule);
            return this;
        }

        public Builder addRules(AuthenticationRule.Builder builder) {
            this.copyOnWrite();
            ((Authentication)this.instance).addRules(builder);
            return this;
        }

        public Builder addRules(AuthenticationRule authenticationRule) {
            this.copyOnWrite();
            ((Authentication)this.instance).addRules(authenticationRule);
            return this;
        }

        public Builder clearProviders() {
            this.copyOnWrite();
            ((Authentication)this.instance).clearProviders();
            return this;
        }

        public Builder clearRules() {
            this.copyOnWrite();
            ((Authentication)this.instance).clearRules();
            return this;
        }

        public AuthProvider getProviders(int n) {
            return ((Authentication)this.instance).getProviders(n);
        }

        public int getProvidersCount() {
            return ((Authentication)this.instance).getProvidersCount();
        }

        public List<AuthProvider> getProvidersList() {
            return Collections.unmodifiableList(((Authentication)this.instance).getProvidersList());
        }

        public AuthenticationRule getRules(int n) {
            return ((Authentication)this.instance).getRules(n);
        }

        public int getRulesCount() {
            return ((Authentication)this.instance).getRulesCount();
        }

        public List<AuthenticationRule> getRulesList() {
            return Collections.unmodifiableList(((Authentication)this.instance).getRulesList());
        }

        public Builder removeProviders(int n) {
            this.copyOnWrite();
            ((Authentication)this.instance).removeProviders(n);
            return this;
        }

        public Builder removeRules(int n) {
            this.copyOnWrite();
            ((Authentication)this.instance).removeRules(n);
            return this;
        }

        public Builder setProviders(int n, AuthProvider.Builder builder) {
            this.copyOnWrite();
            ((Authentication)this.instance).setProviders(n, builder);
            return this;
        }

        public Builder setProviders(int n, AuthProvider authProvider) {
            this.copyOnWrite();
            ((Authentication)this.instance).setProviders(n, authProvider);
            return this;
        }

        public Builder setRules(int n, AuthenticationRule.Builder builder) {
            this.copyOnWrite();
            ((Authentication)this.instance).setRules(n, builder);
            return this;
        }

        public Builder setRules(int n, AuthenticationRule authenticationRule) {
            this.copyOnWrite();
            ((Authentication)this.instance).setRules(n, authenticationRule);
            return this;
        }
    }

}

