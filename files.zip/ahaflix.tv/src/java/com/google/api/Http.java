/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.api.Http$1
 *  com.google.api.HttpOrBuilder
 *  com.google.api.HttpRuleOrBuilder
 *  com.google.protobuf.AbstractMessageLite
 *  com.google.protobuf.ByteString
 *  com.google.protobuf.CodedInputStream
 *  com.google.protobuf.CodedOutputStream
 *  com.google.protobuf.ExtensionRegistryLite
 *  com.google.protobuf.GeneratedMessageLite
 *  com.google.protobuf.GeneratedMessageLite$Builder
 *  com.google.protobuf.GeneratedMessageLite$DefaultInstanceBasedParser
 *  com.google.protobuf.GeneratedMessageLite$MergeFromVisitor
 *  com.google.protobuf.GeneratedMessageLite$MethodToInvoke
 *  com.google.protobuf.GeneratedMessageLite$Visitor
 *  com.google.protobuf.Internal
 *  com.google.protobuf.Internal$ProtobufList
 *  com.google.protobuf.InvalidProtocolBufferException
 *  com.google.protobuf.MessageLite
 *  com.google.protobuf.Parser
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Class
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 *  java.util.Collections
 *  java.util.List
 *  java.util.Objects
 */
package com.google.api;

import com.google.api.Http;
import com.google.api.HttpOrBuilder;
import com.google.api.HttpRule;
import com.google.api.HttpRuleOrBuilder;
import com.google.protobuf.AbstractMessageLite;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.CodedOutputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.Internal;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.MessageLite;
import com.google.protobuf.Parser;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

public final class Http
extends GeneratedMessageLite<Http, Builder>
implements HttpOrBuilder {
    private static final Http DEFAULT_INSTANCE;
    public static final int FULLY_DECODE_RESERVED_EXPANSION_FIELD_NUMBER = 2;
    private static volatile Parser<Http> PARSER;
    public static final int RULES_FIELD_NUMBER = 1;
    private int bitField0_;
    private boolean fullyDecodeReservedExpansion_;
    private Internal.ProtobufList<HttpRule> rules_ = GeneratedMessageLite.emptyProtobufList();

    public static {
        Http http;
        DEFAULT_INSTANCE = http = new Http();
        http.makeImmutable();
    }

    private Http() {
    }

    private void addAllRules(Iterable<? extends HttpRule> iterable) {
        this.ensureRulesIsMutable();
        AbstractMessageLite.addAll(iterable, this.rules_);
    }

    private void addRules(int n, HttpRule.Builder builder) {
        this.ensureRulesIsMutable();
        this.rules_.add(n, (Object)((HttpRule)builder.build()));
    }

    private void addRules(int n, HttpRule httpRule) {
        Objects.requireNonNull((Object)((Object)httpRule));
        this.ensureRulesIsMutable();
        this.rules_.add(n, (Object)httpRule);
    }

    private void addRules(HttpRule.Builder builder) {
        this.ensureRulesIsMutable();
        this.rules_.add((Object)((HttpRule)builder.build()));
    }

    private void addRules(HttpRule httpRule) {
        Objects.requireNonNull((Object)((Object)httpRule));
        this.ensureRulesIsMutable();
        this.rules_.add((Object)httpRule);
    }

    private void clearFullyDecodeReservedExpansion() {
        this.fullyDecodeReservedExpansion_ = false;
    }

    private void clearRules() {
        this.rules_ = GeneratedMessageLite.emptyProtobufList();
    }

    private void ensureRulesIsMutable() {
        if (!this.rules_.isModifiable()) {
            this.rules_ = GeneratedMessageLite.mutableCopy(this.rules_);
        }
    }

    public static Http getDefaultInstance() {
        return DEFAULT_INSTANCE;
    }

    public static Builder newBuilder() {
        return (Builder)DEFAULT_INSTANCE.toBuilder();
    }

    public static Builder newBuilder(Http http) {
        return (Builder)((Builder)DEFAULT_INSTANCE.toBuilder()).mergeFrom((GeneratedMessageLite)http);
    }

    public static Http parseDelimitedFrom(InputStream inputStream) throws IOException {
        return (Http)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static Http parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (Http)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Http parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
        return (Http)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString);
    }

    public static Http parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (Http)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Http parseFrom(CodedInputStream codedInputStream) throws IOException {
        return (Http)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream);
    }

    public static Http parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (Http)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Http parseFrom(InputStream inputStream) throws IOException {
        return (Http)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static Http parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (Http)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Http parseFrom(byte[] arrby) throws InvalidProtocolBufferException {
        return (Http)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby);
    }

    public static Http parseFrom(byte[] arrby, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (Http)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Parser<Http> parser() {
        return DEFAULT_INSTANCE.getParserForType();
    }

    private void removeRules(int n) {
        this.ensureRulesIsMutable();
        this.rules_.remove(n);
    }

    private void setFullyDecodeReservedExpansion(boolean bl) {
        this.fullyDecodeReservedExpansion_ = bl;
    }

    private void setRules(int n, HttpRule.Builder builder) {
        this.ensureRulesIsMutable();
        this.rules_.set(n, (Object)((HttpRule)builder.build()));
    }

    private void setRules(int n, HttpRule httpRule) {
        Objects.requireNonNull((Object)((Object)httpRule));
        this.ensureRulesIsMutable();
        this.rules_.set(n, (Object)httpRule);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke var1_1, Object var2_2, Object var3_3) {
        switch (var1_1.ordinal()) {
            default: {
                throw new UnsupportedOperationException();
            }
            case 7: {
                if (Http.PARSER != null) return Http.PARSER;
                var17_4 = Http.class;
                // MONITORENTER : com.google.api.Http.class
                if (Http.PARSER == null) {
                    Http.PARSER = new GeneratedMessageLite.DefaultInstanceBasedParser((GeneratedMessageLite)Http.DEFAULT_INSTANCE);
                }
                // MONITOREXIT : var17_4
                return Http.PARSER;
            }
            case 2: {
                var8_5 = (CodedInputStream)var2_2;
                var9_6 = (ExtensionRegistryLite)var3_3;
                var10_7 = false;
                while (var10_7 == false) {
                    var14_8 = var8_5.readTag();
                    if (var14_8 == 0) ** GOTO lbl31
                    if (var14_8 == 10) ** GOTO lbl27
                    if (var14_8 != 16) {
                        if (var8_5.skipField(var14_8)) continue;
                    } else {
                        this.fullyDecodeReservedExpansion_ = var8_5.readBool();
                        continue;
lbl27: // 1 sources:
                        if (!this.rules_.isModifiable()) {
                            this.rules_ = GeneratedMessageLite.mutableCopy(this.rules_);
                        }
                        this.rules_.add((Object)((HttpRule)var8_5.readMessage(HttpRule.parser(), var9_6)));
                        continue;
                    }
lbl31: // 2 sources:
                    var10_7 = true;
                    continue;
                    catch (IOException var13_10) {
                        throw new RuntimeException((Throwable)new InvalidProtocolBufferException(var13_10.getMessage()).setUnfinishedMessage((MessageLite)this));
                    }
                    catch (InvalidProtocolBufferException var11_11) {
                        throw new RuntimeException((Throwable)var11_11.setUnfinishedMessage((MessageLite)this));
                    }
                }
                return Http.DEFAULT_INSTANCE;
            }
            case 6: {
                return Http.DEFAULT_INSTANCE;
            }
            case 1: {
                var4_12 = (GeneratedMessageLite.Visitor)var2_2;
                var5_13 = (Http)var3_3;
                this.rules_ = var4_12.visitList(this.rules_, var5_13.rules_);
                var6_14 = this.fullyDecodeReservedExpansion_;
                var7_15 = var5_13.fullyDecodeReservedExpansion_;
                this.fullyDecodeReservedExpansion_ = var4_12.visitBoolean(var6_14, var6_14, var7_15, var7_15);
                if (var4_12 != GeneratedMessageLite.MergeFromVisitor.INSTANCE) return this;
                this.bitField0_ |= var5_13.bitField0_;
                return this;
            }
            case 5: {
                return new Builder(null);
            }
            case 3: {
                this.rules_.makeImmutable();
                return null;
            }
            case 0: {
                return Http.DEFAULT_INSTANCE;
            }
            case 4: 
        }
        return new Http();
    }

    public boolean getFullyDecodeReservedExpansion() {
        return this.fullyDecodeReservedExpansion_;
    }

    public HttpRule getRules(int n) {
        return (HttpRule)((Object)this.rules_.get(n));
    }

    public int getRulesCount() {
        return this.rules_.size();
    }

    public List<HttpRule> getRulesList() {
        return this.rules_;
    }

    public HttpRuleOrBuilder getRulesOrBuilder(int n) {
        return (HttpRuleOrBuilder)this.rules_.get(n);
    }

    public List<? extends HttpRuleOrBuilder> getRulesOrBuilderList() {
        return this.rules_;
    }

    public int getSerializedSize() {
        int n = this.memoizedSerializedSize;
        if (n != -1) {
            return n;
        }
        int n2 = 0;
        for (int i = 0; i < this.rules_.size(); ++i) {
            n2 += CodedOutputStream.computeMessageSize((int)1, (MessageLite)((MessageLite)this.rules_.get(i)));
        }
        boolean bl = this.fullyDecodeReservedExpansion_;
        if (bl) {
            n2 += CodedOutputStream.computeBoolSize((int)2, (boolean)bl);
        }
        this.memoizedSerializedSize = n2;
        return n2;
    }

    public void writeTo(CodedOutputStream codedOutputStream) throws IOException {
        for (int i = 0; i < this.rules_.size(); ++i) {
            codedOutputStream.writeMessage(1, (MessageLite)this.rules_.get(i));
        }
        boolean bl = this.fullyDecodeReservedExpansion_;
        if (bl) {
            codedOutputStream.writeBool(2, bl);
        }
    }

    public static final class Builder
    extends GeneratedMessageLite.Builder<Http, Builder>
    implements HttpOrBuilder {
        private Builder() {
            super((GeneratedMessageLite)DEFAULT_INSTANCE);
        }

        public /* synthetic */ Builder(1 var1_1) {
            this();
        }

        public Builder addAllRules(Iterable<? extends HttpRule> iterable) {
            this.copyOnWrite();
            ((Http)this.instance).addAllRules((Iterable<? extends HttpRule>)iterable);
            return this;
        }

        public Builder addRules(int n, HttpRule.Builder builder) {
            this.copyOnWrite();
            ((Http)this.instance).addRules(n, builder);
            return this;
        }

        public Builder addRules(int n, HttpRule httpRule) {
            this.copyOnWrite();
            ((Http)this.instance).addRules(n, httpRule);
            return this;
        }

        public Builder addRules(HttpRule.Builder builder) {
            this.copyOnWrite();
            ((Http)this.instance).addRules(builder);
            return this;
        }

        public Builder addRules(HttpRule httpRule) {
            this.copyOnWrite();
            ((Http)this.instance).addRules(httpRule);
            return this;
        }

        public Builder clearFullyDecodeReservedExpansion() {
            this.copyOnWrite();
            ((Http)this.instance).clearFullyDecodeReservedExpansion();
            return this;
        }

        public Builder clearRules() {
            this.copyOnWrite();
            ((Http)this.instance).clearRules();
            return this;
        }

        public boolean getFullyDecodeReservedExpansion() {
            return ((Http)this.instance).getFullyDecodeReservedExpansion();
        }

        public HttpRule getRules(int n) {
            return ((Http)this.instance).getRules(n);
        }

        public int getRulesCount() {
            return ((Http)this.instance).getRulesCount();
        }

        public List<HttpRule> getRulesList() {
            return Collections.unmodifiableList(((Http)this.instance).getRulesList());
        }

        public Builder removeRules(int n) {
            this.copyOnWrite();
            ((Http)this.instance).removeRules(n);
            return this;
        }

        public Builder setFullyDecodeReservedExpansion(boolean bl) {
            this.copyOnWrite();
            ((Http)this.instance).setFullyDecodeReservedExpansion(bl);
            return this;
        }

        public Builder setRules(int n, HttpRule.Builder builder) {
            this.copyOnWrite();
            ((Http)this.instance).setRules(n, builder);
            return this;
        }

        public Builder setRules(int n, HttpRule httpRule) {
            this.copyOnWrite();
            ((Http)this.instance).setRules(n, httpRule);
            return this;
        }
    }

}

