/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.api.LabelDescriptorOrBuilder
 *  com.google.api.LogDescriptor$1
 *  com.google.api.LogDescriptorOrBuilder
 *  com.google.protobuf.AbstractMessageLite
 *  com.google.protobuf.ByteString
 *  com.google.protobuf.CodedInputStream
 *  com.google.protobuf.CodedOutputStream
 *  com.google.protobuf.ExtensionRegistryLite
 *  com.google.protobuf.GeneratedMessageLite
 *  com.google.protobuf.GeneratedMessageLite$Builder
 *  com.google.protobuf.GeneratedMessageLite$DefaultInstanceBasedParser
 *  com.google.protobuf.GeneratedMessageLite$MergeFromVisitor
 *  com.google.protobuf.GeneratedMessageLite$MethodToInvoke
 *  com.google.protobuf.GeneratedMessageLite$Visitor
 *  com.google.protobuf.Internal
 *  com.google.protobuf.Internal$ProtobufList
 *  com.google.protobuf.InvalidProtocolBufferException
 *  com.google.protobuf.MessageLite
 *  com.google.protobuf.Parser
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Class
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 *  java.util.Collections
 *  java.util.List
 *  java.util.Objects
 */
package com.google.api;

import com.google.api.LabelDescriptor;
import com.google.api.LabelDescriptorOrBuilder;
import com.google.api.LogDescriptor;
import com.google.api.LogDescriptorOrBuilder;
import com.google.protobuf.AbstractMessageLite;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.CodedOutputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.Internal;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.MessageLite;
import com.google.protobuf.Parser;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

public final class LogDescriptor
extends GeneratedMessageLite<LogDescriptor, Builder>
implements LogDescriptorOrBuilder {
    private static final LogDescriptor DEFAULT_INSTANCE;
    public static final int DESCRIPTION_FIELD_NUMBER = 3;
    public static final int DISPLAY_NAME_FIELD_NUMBER = 4;
    public static final int LABELS_FIELD_NUMBER = 2;
    public static final int NAME_FIELD_NUMBER = 1;
    private static volatile Parser<LogDescriptor> PARSER;
    private int bitField0_;
    private String description_ = "";
    private String displayName_ = "";
    private Internal.ProtobufList<LabelDescriptor> labels_ = GeneratedMessageLite.emptyProtobufList();
    private String name_ = "";

    public static {
        LogDescriptor logDescriptor;
        DEFAULT_INSTANCE = logDescriptor = new LogDescriptor();
        logDescriptor.makeImmutable();
    }

    private LogDescriptor() {
    }

    private void addAllLabels(Iterable<? extends LabelDescriptor> iterable) {
        this.ensureLabelsIsMutable();
        AbstractMessageLite.addAll(iterable, this.labels_);
    }

    private void addLabels(int n, LabelDescriptor.Builder builder) {
        this.ensureLabelsIsMutable();
        this.labels_.add(n, (Object)((LabelDescriptor)builder.build()));
    }

    private void addLabels(int n, LabelDescriptor labelDescriptor) {
        Objects.requireNonNull((Object)((Object)labelDescriptor));
        this.ensureLabelsIsMutable();
        this.labels_.add(n, (Object)labelDescriptor);
    }

    private void addLabels(LabelDescriptor.Builder builder) {
        this.ensureLabelsIsMutable();
        this.labels_.add((Object)((LabelDescriptor)builder.build()));
    }

    private void addLabels(LabelDescriptor labelDescriptor) {
        Objects.requireNonNull((Object)((Object)labelDescriptor));
        this.ensureLabelsIsMutable();
        this.labels_.add((Object)labelDescriptor);
    }

    private void clearDescription() {
        this.description_ = LogDescriptor.getDefaultInstance().getDescription();
    }

    private void clearDisplayName() {
        this.displayName_ = LogDescriptor.getDefaultInstance().getDisplayName();
    }

    private void clearLabels() {
        this.labels_ = GeneratedMessageLite.emptyProtobufList();
    }

    private void clearName() {
        this.name_ = LogDescriptor.getDefaultInstance().getName();
    }

    private void ensureLabelsIsMutable() {
        if (!this.labels_.isModifiable()) {
            this.labels_ = GeneratedMessageLite.mutableCopy(this.labels_);
        }
    }

    public static LogDescriptor getDefaultInstance() {
        return DEFAULT_INSTANCE;
    }

    public static Builder newBuilder() {
        return (Builder)DEFAULT_INSTANCE.toBuilder();
    }

    public static Builder newBuilder(LogDescriptor logDescriptor) {
        return (Builder)((Builder)DEFAULT_INSTANCE.toBuilder()).mergeFrom((GeneratedMessageLite)logDescriptor);
    }

    public static LogDescriptor parseDelimitedFrom(InputStream inputStream) throws IOException {
        return (LogDescriptor)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static LogDescriptor parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (LogDescriptor)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static LogDescriptor parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
        return (LogDescriptor)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString);
    }

    public static LogDescriptor parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (LogDescriptor)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static LogDescriptor parseFrom(CodedInputStream codedInputStream) throws IOException {
        return (LogDescriptor)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream);
    }

    public static LogDescriptor parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (LogDescriptor)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static LogDescriptor parseFrom(InputStream inputStream) throws IOException {
        return (LogDescriptor)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static LogDescriptor parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (LogDescriptor)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static LogDescriptor parseFrom(byte[] arrby) throws InvalidProtocolBufferException {
        return (LogDescriptor)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby);
    }

    public static LogDescriptor parseFrom(byte[] arrby, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (LogDescriptor)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Parser<LogDescriptor> parser() {
        return DEFAULT_INSTANCE.getParserForType();
    }

    private void removeLabels(int n) {
        this.ensureLabelsIsMutable();
        this.labels_.remove(n);
    }

    private void setDescription(String string2) {
        Objects.requireNonNull((Object)string2);
        this.description_ = string2;
    }

    private void setDescriptionBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.description_ = byteString.toStringUtf8();
    }

    private void setDisplayName(String string2) {
        Objects.requireNonNull((Object)string2);
        this.displayName_ = string2;
    }

    private void setDisplayNameBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.displayName_ = byteString.toStringUtf8();
    }

    private void setLabels(int n, LabelDescriptor.Builder builder) {
        this.ensureLabelsIsMutable();
        this.labels_.set(n, (Object)((LabelDescriptor)builder.build()));
    }

    private void setLabels(int n, LabelDescriptor labelDescriptor) {
        Objects.requireNonNull((Object)((Object)labelDescriptor));
        this.ensureLabelsIsMutable();
        this.labels_.set(n, (Object)labelDescriptor);
    }

    private void setName(String string2) {
        Objects.requireNonNull((Object)string2);
        this.name_ = string2;
    }

    private void setNameBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.name_ = byteString.toStringUtf8();
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke var1_1, Object var2_2, Object var3_3) {
        switch (var1_1.ordinal()) {
            default: {
                throw new UnsupportedOperationException();
            }
            case 7: {
                if (LogDescriptor.PARSER != null) return LogDescriptor.PARSER;
                var15_4 = LogDescriptor.class;
                // MONITORENTER : com.google.api.LogDescriptor.class
                if (LogDescriptor.PARSER == null) {
                    LogDescriptor.PARSER = new GeneratedMessageLite.DefaultInstanceBasedParser((GeneratedMessageLite)LogDescriptor.DEFAULT_INSTANCE);
                }
                // MONITOREXIT : var15_4
                return LogDescriptor.PARSER;
            }
            case 2: {
                var6_5 = (CodedInputStream)var2_2;
                var7_6 = (ExtensionRegistryLite)var3_3;
                var8_7 = false;
                while (var8_7 == false) {
                    var12_8 = var6_5.readTag();
                    if (var12_8 == 0) ** GOTO lbl37
                    if (var12_8 == 10) ** GOTO lbl35
                    if (var12_8 == 18) ** GOTO lbl31
                    if (var12_8 == 26) ** GOTO lbl29
                    if (var12_8 != 34) {
                        if (var6_5.skipField(var12_8)) continue;
                    } else {
                        this.displayName_ = var6_5.readStringRequireUtf8();
                        continue;
lbl29: // 1 sources:
                        this.description_ = var6_5.readStringRequireUtf8();
                        continue;
lbl31: // 1 sources:
                        if (!this.labels_.isModifiable()) {
                            this.labels_ = GeneratedMessageLite.mutableCopy(this.labels_);
                        }
                        this.labels_.add((Object)((LabelDescriptor)var6_5.readMessage(LabelDescriptor.parser(), var7_6)));
                        continue;
lbl35: // 1 sources:
                        this.name_ = var6_5.readStringRequireUtf8();
                        continue;
                    }
lbl37: // 2 sources:
                    var8_7 = true;
                    continue;
                    catch (IOException var11_10) {
                        throw new RuntimeException((Throwable)new InvalidProtocolBufferException(var11_10.getMessage()).setUnfinishedMessage((MessageLite)this));
                    }
                    catch (InvalidProtocolBufferException var9_11) {
                        throw new RuntimeException((Throwable)var9_11.setUnfinishedMessage((MessageLite)this));
                    }
                }
                return LogDescriptor.DEFAULT_INSTANCE;
            }
            case 6: {
                return LogDescriptor.DEFAULT_INSTANCE;
            }
            case 1: {
                var4_12 = (GeneratedMessageLite.Visitor)var2_2;
                var5_13 = (LogDescriptor)var3_3;
                this.name_ = var4_12.visitString(true ^ this.name_.isEmpty(), this.name_, true ^ var5_13.name_.isEmpty(), var5_13.name_);
                this.labels_ = var4_12.visitList(this.labels_, var5_13.labels_);
                this.description_ = var4_12.visitString(true ^ this.description_.isEmpty(), this.description_, true ^ var5_13.description_.isEmpty(), var5_13.description_);
                this.displayName_ = var4_12.visitString(true ^ this.displayName_.isEmpty(), this.displayName_, true ^ var5_13.displayName_.isEmpty(), var5_13.displayName_);
                if (var4_12 != GeneratedMessageLite.MergeFromVisitor.INSTANCE) return this;
                this.bitField0_ |= var5_13.bitField0_;
                return this;
            }
            case 5: {
                return new Builder(null);
            }
            case 3: {
                this.labels_.makeImmutable();
                return null;
            }
            case 0: {
                return LogDescriptor.DEFAULT_INSTANCE;
            }
            case 4: 
        }
        return new LogDescriptor();
    }

    public String getDescription() {
        return this.description_;
    }

    public ByteString getDescriptionBytes() {
        return ByteString.copyFromUtf8((String)this.description_);
    }

    public String getDisplayName() {
        return this.displayName_;
    }

    public ByteString getDisplayNameBytes() {
        return ByteString.copyFromUtf8((String)this.displayName_);
    }

    public LabelDescriptor getLabels(int n) {
        return (LabelDescriptor)((Object)this.labels_.get(n));
    }

    public int getLabelsCount() {
        return this.labels_.size();
    }

    public List<LabelDescriptor> getLabelsList() {
        return this.labels_;
    }

    public LabelDescriptorOrBuilder getLabelsOrBuilder(int n) {
        return (LabelDescriptorOrBuilder)this.labels_.get(n);
    }

    public List<? extends LabelDescriptorOrBuilder> getLabelsOrBuilderList() {
        return this.labels_;
    }

    public String getName() {
        return this.name_;
    }

    public ByteString getNameBytes() {
        return ByteString.copyFromUtf8((String)this.name_);
    }

    public int getSerializedSize() {
        int n;
        int n2 = this.memoizedSerializedSize;
        if (n2 != -1) {
            return n2;
        }
        boolean bl = this.name_.isEmpty();
        int n3 = 0;
        if (!bl) {
            n = 0 + CodedOutputStream.computeStringSize((int)1, (String)this.getName());
            n3 = 0;
        } else {
            n = 0;
        }
        while (n3 < this.labels_.size()) {
            n += CodedOutputStream.computeMessageSize((int)2, (MessageLite)((MessageLite)this.labels_.get(n3)));
            ++n3;
        }
        if (!this.description_.isEmpty()) {
            n += CodedOutputStream.computeStringSize((int)3, (String)this.getDescription());
        }
        if (!this.displayName_.isEmpty()) {
            n += CodedOutputStream.computeStringSize((int)4, (String)this.getDisplayName());
        }
        this.memoizedSerializedSize = n;
        return n;
    }

    public void writeTo(CodedOutputStream codedOutputStream) throws IOException {
        if (!this.name_.isEmpty()) {
            codedOutputStream.writeString(1, this.getName());
        }
        for (int i = 0; i < this.labels_.size(); ++i) {
            codedOutputStream.writeMessage(2, (MessageLite)this.labels_.get(i));
        }
        if (!this.description_.isEmpty()) {
            codedOutputStream.writeString(3, this.getDescription());
        }
        if (!this.displayName_.isEmpty()) {
            codedOutputStream.writeString(4, this.getDisplayName());
        }
    }

    public static final class Builder
    extends GeneratedMessageLite.Builder<LogDescriptor, Builder>
    implements LogDescriptorOrBuilder {
        private Builder() {
            super((GeneratedMessageLite)DEFAULT_INSTANCE);
        }

        public /* synthetic */ Builder(1 var1_1) {
            this();
        }

        public Builder addAllLabels(Iterable<? extends LabelDescriptor> iterable) {
            this.copyOnWrite();
            ((LogDescriptor)this.instance).addAllLabels((Iterable<? extends LabelDescriptor>)iterable);
            return this;
        }

        public Builder addLabels(int n, LabelDescriptor.Builder builder) {
            this.copyOnWrite();
            ((LogDescriptor)this.instance).addLabels(n, builder);
            return this;
        }

        public Builder addLabels(int n, LabelDescriptor labelDescriptor) {
            this.copyOnWrite();
            ((LogDescriptor)this.instance).addLabels(n, labelDescriptor);
            return this;
        }

        public Builder addLabels(LabelDescriptor.Builder builder) {
            this.copyOnWrite();
            ((LogDescriptor)this.instance).addLabels(builder);
            return this;
        }

        public Builder addLabels(LabelDescriptor labelDescriptor) {
            this.copyOnWrite();
            ((LogDescriptor)this.instance).addLabels(labelDescriptor);
            return this;
        }

        public Builder clearDescription() {
            this.copyOnWrite();
            ((LogDescriptor)this.instance).clearDescription();
            return this;
        }

        public Builder clearDisplayName() {
            this.copyOnWrite();
            ((LogDescriptor)this.instance).clearDisplayName();
            return this;
        }

        public Builder clearLabels() {
            this.copyOnWrite();
            ((LogDescriptor)this.instance).clearLabels();
            return this;
        }

        public Builder clearName() {
            this.copyOnWrite();
            ((LogDescriptor)this.instance).clearName();
            return this;
        }

        public String getDescription() {
            return ((LogDescriptor)this.instance).getDescription();
        }

        public ByteString getDescriptionBytes() {
            return ((LogDescriptor)this.instance).getDescriptionBytes();
        }

        public String getDisplayName() {
            return ((LogDescriptor)this.instance).getDisplayName();
        }

        public ByteString getDisplayNameBytes() {
            return ((LogDescriptor)this.instance).getDisplayNameBytes();
        }

        public LabelDescriptor getLabels(int n) {
            return ((LogDescriptor)this.instance).getLabels(n);
        }

        public int getLabelsCount() {
            return ((LogDescriptor)this.instance).getLabelsCount();
        }

        public List<LabelDescriptor> getLabelsList() {
            return Collections.unmodifiableList(((LogDescriptor)this.instance).getLabelsList());
        }

        public String getName() {
            return ((LogDescriptor)this.instance).getName();
        }

        public ByteString getNameBytes() {
            return ((LogDescriptor)this.instance).getNameBytes();
        }

        public Builder removeLabels(int n) {
            this.copyOnWrite();
            ((LogDescriptor)this.instance).removeLabels(n);
            return this;
        }

        public Builder setDescription(String string2) {
            this.copyOnWrite();
            ((LogDescriptor)this.instance).setDescription(string2);
            return this;
        }

        public Builder setDescriptionBytes(ByteString byteString) {
            this.copyOnWrite();
            ((LogDescriptor)this.instance).setDescriptionBytes(byteString);
            return this;
        }

        public Builder setDisplayName(String string2) {
            this.copyOnWrite();
            ((LogDescriptor)this.instance).setDisplayName(string2);
            return this;
        }

        public Builder setDisplayNameBytes(ByteString byteString) {
            this.copyOnWrite();
            ((LogDescriptor)this.instance).setDisplayNameBytes(byteString);
            return this;
        }

        public Builder setLabels(int n, LabelDescriptor.Builder builder) {
            this.copyOnWrite();
            ((LogDescriptor)this.instance).setLabels(n, builder);
            return this;
        }

        public Builder setLabels(int n, LabelDescriptor labelDescriptor) {
            this.copyOnWrite();
            ((LogDescriptor)this.instance).setLabels(n, labelDescriptor);
            return this;
        }

        public Builder setName(String string2) {
            this.copyOnWrite();
            ((LogDescriptor)this.instance).setName(string2);
            return this;
        }

        public Builder setNameBytes(ByteString byteString) {
            this.copyOnWrite();
            ((LogDescriptor)this.instance).setNameBytes(byteString);
            return this;
        }
    }

}

