/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.api.HttpBody$1
 *  com.google.api.HttpBodyOrBuilder
 *  com.google.protobuf.AbstractMessageLite
 *  com.google.protobuf.ByteString
 *  com.google.protobuf.CodedInputStream
 *  com.google.protobuf.CodedOutputStream
 *  com.google.protobuf.ExtensionRegistryLite
 *  com.google.protobuf.GeneratedMessageLite
 *  com.google.protobuf.GeneratedMessageLite$Builder
 *  com.google.protobuf.GeneratedMessageLite$DefaultInstanceBasedParser
 *  com.google.protobuf.GeneratedMessageLite$MethodToInvoke
 *  com.google.protobuf.GeneratedMessageLite$Visitor
 *  com.google.protobuf.InvalidProtocolBufferException
 *  com.google.protobuf.MessageLite
 *  com.google.protobuf.Parser
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 *  java.util.Objects
 */
package com.google.api;

import com.google.api.HttpBody;
import com.google.api.HttpBodyOrBuilder;
import com.google.protobuf.AbstractMessageLite;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.CodedOutputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.MessageLite;
import com.google.protobuf.Parser;
import java.io.IOException;
import java.io.InputStream;
import java.util.Objects;

public final class HttpBody
extends GeneratedMessageLite<HttpBody, Builder>
implements HttpBodyOrBuilder {
    public static final int CONTENT_TYPE_FIELD_NUMBER = 1;
    public static final int DATA_FIELD_NUMBER = 2;
    private static final HttpBody DEFAULT_INSTANCE;
    private static volatile Parser<HttpBody> PARSER;
    private String contentType_ = "";
    private ByteString data_ = ByteString.EMPTY;

    public static {
        HttpBody httpBody;
        DEFAULT_INSTANCE = httpBody = new HttpBody();
        httpBody.makeImmutable();
    }

    private HttpBody() {
    }

    private void clearContentType() {
        this.contentType_ = HttpBody.getDefaultInstance().getContentType();
    }

    private void clearData() {
        this.data_ = HttpBody.getDefaultInstance().getData();
    }

    public static HttpBody getDefaultInstance() {
        return DEFAULT_INSTANCE;
    }

    public static Builder newBuilder() {
        return (Builder)DEFAULT_INSTANCE.toBuilder();
    }

    public static Builder newBuilder(HttpBody httpBody) {
        return (Builder)((Builder)DEFAULT_INSTANCE.toBuilder()).mergeFrom((GeneratedMessageLite)httpBody);
    }

    public static HttpBody parseDelimitedFrom(InputStream inputStream) throws IOException {
        return (HttpBody)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static HttpBody parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (HttpBody)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static HttpBody parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
        return (HttpBody)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString);
    }

    public static HttpBody parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (HttpBody)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static HttpBody parseFrom(CodedInputStream codedInputStream) throws IOException {
        return (HttpBody)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream);
    }

    public static HttpBody parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (HttpBody)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static HttpBody parseFrom(InputStream inputStream) throws IOException {
        return (HttpBody)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static HttpBody parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (HttpBody)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static HttpBody parseFrom(byte[] arrby) throws InvalidProtocolBufferException {
        return (HttpBody)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby);
    }

    public static HttpBody parseFrom(byte[] arrby, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (HttpBody)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Parser<HttpBody> parser() {
        return DEFAULT_INSTANCE.getParserForType();
    }

    private void setContentType(String string2) {
        Objects.requireNonNull((Object)string2);
        this.contentType_ = string2;
    }

    private void setContentTypeBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.contentType_ = byteString.toStringUtf8();
    }

    private void setData(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        this.data_ = byteString;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke var1_1, Object var2_2, Object var3_3) {
        var4_4 = var1_1.ordinal();
        var5_5 = false;
        switch (var4_4) {
            default: {
                throw new UnsupportedOperationException();
            }
            case 7: {
                if (HttpBody.PARSER != null) return HttpBody.PARSER;
                var21_6 = HttpBody.class;
                // MONITORENTER : com.google.api.HttpBody.class
                if (HttpBody.PARSER == null) {
                    HttpBody.PARSER = new GeneratedMessageLite.DefaultInstanceBasedParser((GeneratedMessageLite)HttpBody.DEFAULT_INSTANCE);
                }
                // MONITOREXIT : var21_6
                return HttpBody.PARSER;
            }
            case 2: {
                var14_7 = (CodedInputStream)var2_2;
                (ExtensionRegistryLite)var3_3;
                while (var5_5 == false) {
                    var19_8 = var14_7.readTag();
                    if (var19_8 == 0) ** GOTO lbl30
                    if (var19_8 == 10) ** GOTO lbl28
                    if (var19_8 != 18) {
                        if (var14_7.skipField(var19_8)) continue;
                    } else {
                        this.data_ = var14_7.readBytes();
                        continue;
lbl28: // 1 sources:
                        this.contentType_ = var14_7.readStringRequireUtf8();
                        continue;
                    }
lbl30: // 2 sources:
                    var5_5 = true;
                    continue;
                    catch (IOException var18_10) {
                        throw new RuntimeException((Throwable)new InvalidProtocolBufferException(var18_10.getMessage()).setUnfinishedMessage((MessageLite)this));
                    }
                    catch (InvalidProtocolBufferException var16_11) {
                        throw new RuntimeException((Throwable)var16_11.setUnfinishedMessage((MessageLite)this));
                    }
                }
                return HttpBody.DEFAULT_INSTANCE;
            }
            case 6: {
                return HttpBody.DEFAULT_INSTANCE;
            }
            case 1: {
                var6_12 = (GeneratedMessageLite.Visitor)var2_2;
                var7_13 = (HttpBody)var3_3;
                this.contentType_ = var6_12.visitString(true ^ this.contentType_.isEmpty(), this.contentType_, true ^ var7_13.contentType_.isEmpty(), var7_13.contentType_);
                var8_14 = this.data_;
                var9_15 = ByteString.EMPTY;
                var10_16 = var8_14 != var9_15;
                var11_17 = var7_13.data_;
                var12_18 = false;
                if (var11_17 != var9_15) {
                    var12_18 = true;
                }
                this.data_ = var6_12.visitByteString(var10_16, var8_14, var12_18, var11_17);
                return this;
            }
            case 5: {
                return new Builder(null);
            }
            case 3: {
                return null;
            }
            case 0: {
                return HttpBody.DEFAULT_INSTANCE;
            }
            case 4: 
        }
        return new HttpBody();
    }

    public String getContentType() {
        return this.contentType_;
    }

    public ByteString getContentTypeBytes() {
        return ByteString.copyFromUtf8((String)this.contentType_);
    }

    public ByteString getData() {
        return this.data_;
    }

    public int getSerializedSize() {
        int n = this.memoizedSerializedSize;
        if (n != -1) {
            return n;
        }
        boolean bl = this.contentType_.isEmpty();
        int n2 = 0;
        if (!bl) {
            n2 = 0 + CodedOutputStream.computeStringSize((int)1, (String)this.getContentType());
        }
        if (!this.data_.isEmpty()) {
            n2 += CodedOutputStream.computeBytesSize((int)2, (ByteString)this.data_);
        }
        this.memoizedSerializedSize = n2;
        return n2;
    }

    public void writeTo(CodedOutputStream codedOutputStream) throws IOException {
        if (!this.contentType_.isEmpty()) {
            codedOutputStream.writeString(1, this.getContentType());
        }
        if (!this.data_.isEmpty()) {
            codedOutputStream.writeBytes(2, this.data_);
        }
    }

    public static final class Builder
    extends GeneratedMessageLite.Builder<HttpBody, Builder>
    implements HttpBodyOrBuilder {
        private Builder() {
            super((GeneratedMessageLite)DEFAULT_INSTANCE);
        }

        public /* synthetic */ Builder(1 var1_1) {
            this();
        }

        public Builder clearContentType() {
            this.copyOnWrite();
            ((HttpBody)this.instance).clearContentType();
            return this;
        }

        public Builder clearData() {
            this.copyOnWrite();
            ((HttpBody)this.instance).clearData();
            return this;
        }

        public String getContentType() {
            return ((HttpBody)this.instance).getContentType();
        }

        public ByteString getContentTypeBytes() {
            return ((HttpBody)this.instance).getContentTypeBytes();
        }

        public ByteString getData() {
            return ((HttpBody)this.instance).getData();
        }

        public Builder setContentType(String string2) {
            this.copyOnWrite();
            ((HttpBody)this.instance).setContentType(string2);
            return this;
        }

        public Builder setContentTypeBytes(ByteString byteString) {
            this.copyOnWrite();
            ((HttpBody)this.instance).setContentTypeBytes(byteString);
            return this;
        }

        public Builder setData(ByteString byteString) {
            this.copyOnWrite();
            ((HttpBody)this.instance).setData(byteString);
            return this;
        }
    }

}

