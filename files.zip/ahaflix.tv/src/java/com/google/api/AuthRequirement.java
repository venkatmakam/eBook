/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.api.AuthRequirement$1
 *  com.google.api.AuthRequirementOrBuilder
 *  com.google.protobuf.AbstractMessageLite
 *  com.google.protobuf.ByteString
 *  com.google.protobuf.CodedInputStream
 *  com.google.protobuf.CodedOutputStream
 *  com.google.protobuf.ExtensionRegistryLite
 *  com.google.protobuf.GeneratedMessageLite
 *  com.google.protobuf.GeneratedMessageLite$Builder
 *  com.google.protobuf.GeneratedMessageLite$DefaultInstanceBasedParser
 *  com.google.protobuf.GeneratedMessageLite$MethodToInvoke
 *  com.google.protobuf.GeneratedMessageLite$Visitor
 *  com.google.protobuf.InvalidProtocolBufferException
 *  com.google.protobuf.MessageLite
 *  com.google.protobuf.Parser
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 *  java.util.Objects
 */
package com.google.api;

import com.google.api.AuthRequirement;
import com.google.api.AuthRequirementOrBuilder;
import com.google.protobuf.AbstractMessageLite;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.CodedOutputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.MessageLite;
import com.google.protobuf.Parser;
import java.io.IOException;
import java.io.InputStream;
import java.util.Objects;

public final class AuthRequirement
extends GeneratedMessageLite<AuthRequirement, Builder>
implements AuthRequirementOrBuilder {
    public static final int AUDIENCES_FIELD_NUMBER = 2;
    private static final AuthRequirement DEFAULT_INSTANCE;
    private static volatile Parser<AuthRequirement> PARSER;
    public static final int PROVIDER_ID_FIELD_NUMBER = 1;
    private String audiences_ = "";
    private String providerId_ = "";

    public static {
        AuthRequirement authRequirement;
        DEFAULT_INSTANCE = authRequirement = new AuthRequirement();
        authRequirement.makeImmutable();
    }

    private AuthRequirement() {
    }

    private void clearAudiences() {
        this.audiences_ = AuthRequirement.getDefaultInstance().getAudiences();
    }

    private void clearProviderId() {
        this.providerId_ = AuthRequirement.getDefaultInstance().getProviderId();
    }

    public static AuthRequirement getDefaultInstance() {
        return DEFAULT_INSTANCE;
    }

    public static Builder newBuilder() {
        return (Builder)DEFAULT_INSTANCE.toBuilder();
    }

    public static Builder newBuilder(AuthRequirement authRequirement) {
        return (Builder)((Builder)DEFAULT_INSTANCE.toBuilder()).mergeFrom((GeneratedMessageLite)authRequirement);
    }

    public static AuthRequirement parseDelimitedFrom(InputStream inputStream) throws IOException {
        return (AuthRequirement)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static AuthRequirement parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (AuthRequirement)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static AuthRequirement parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
        return (AuthRequirement)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString);
    }

    public static AuthRequirement parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (AuthRequirement)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static AuthRequirement parseFrom(CodedInputStream codedInputStream) throws IOException {
        return (AuthRequirement)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream);
    }

    public static AuthRequirement parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (AuthRequirement)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static AuthRequirement parseFrom(InputStream inputStream) throws IOException {
        return (AuthRequirement)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static AuthRequirement parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (AuthRequirement)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static AuthRequirement parseFrom(byte[] arrby) throws InvalidProtocolBufferException {
        return (AuthRequirement)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby);
    }

    public static AuthRequirement parseFrom(byte[] arrby, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (AuthRequirement)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Parser<AuthRequirement> parser() {
        return DEFAULT_INSTANCE.getParserForType();
    }

    private void setAudiences(String string2) {
        Objects.requireNonNull((Object)string2);
        this.audiences_ = string2;
    }

    private void setAudiencesBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.audiences_ = byteString.toStringUtf8();
    }

    private void setProviderId(String string2) {
        Objects.requireNonNull((Object)string2);
        this.providerId_ = string2;
    }

    private void setProviderIdBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.providerId_ = byteString.toStringUtf8();
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke var1_1, Object var2_2, Object var3_3) {
        switch (var1_1.ordinal()) {
            default: {
                throw new UnsupportedOperationException();
            }
            case 7: {
                if (AuthRequirement.PARSER != null) return AuthRequirement.PARSER;
                var15_4 = AuthRequirement.class;
                // MONITORENTER : com.google.api.AuthRequirement.class
                if (AuthRequirement.PARSER == null) {
                    AuthRequirement.PARSER = new GeneratedMessageLite.DefaultInstanceBasedParser((GeneratedMessageLite)AuthRequirement.DEFAULT_INSTANCE);
                }
                // MONITOREXIT : var15_4
                return AuthRequirement.PARSER;
            }
            case 2: {
                var7_5 = (CodedInputStream)var2_2;
                (ExtensionRegistryLite)var3_3;
                var9_6 = false;
                while (var9_6 == false) {
                    var13_7 = var7_5.readTag();
                    if (var13_7 == 0) ** GOTO lbl29
                    if (var13_7 == 10) ** GOTO lbl27
                    if (var13_7 != 18) {
                        if (var7_5.skipField(var13_7)) continue;
                    } else {
                        this.audiences_ = var7_5.readStringRequireUtf8();
                        continue;
lbl27: // 1 sources:
                        this.providerId_ = var7_5.readStringRequireUtf8();
                        continue;
                    }
lbl29: // 2 sources:
                    var9_6 = true;
                    continue;
                    catch (IOException var12_9) {
                        throw new RuntimeException((Throwable)new InvalidProtocolBufferException(var12_9.getMessage()).setUnfinishedMessage((MessageLite)this));
                    }
                    catch (InvalidProtocolBufferException var10_10) {
                        throw new RuntimeException((Throwable)var10_10.setUnfinishedMessage((MessageLite)this));
                    }
                }
                return AuthRequirement.DEFAULT_INSTANCE;
            }
            case 6: {
                return AuthRequirement.DEFAULT_INSTANCE;
            }
            case 1: {
                var4_11 = (GeneratedMessageLite.Visitor)var2_2;
                var5_12 = (AuthRequirement)var3_3;
                this.providerId_ = var4_11.visitString(true ^ this.providerId_.isEmpty(), this.providerId_, true ^ var5_12.providerId_.isEmpty(), var5_12.providerId_);
                this.audiences_ = var4_11.visitString(true ^ this.audiences_.isEmpty(), this.audiences_, true ^ var5_12.audiences_.isEmpty(), var5_12.audiences_);
                return this;
            }
            case 5: {
                return new Builder(null);
            }
            case 3: {
                return null;
            }
            case 0: {
                return AuthRequirement.DEFAULT_INSTANCE;
            }
            case 4: 
        }
        return new AuthRequirement();
    }

    public String getAudiences() {
        return this.audiences_;
    }

    public ByteString getAudiencesBytes() {
        return ByteString.copyFromUtf8((String)this.audiences_);
    }

    public String getProviderId() {
        return this.providerId_;
    }

    public ByteString getProviderIdBytes() {
        return ByteString.copyFromUtf8((String)this.providerId_);
    }

    public int getSerializedSize() {
        int n = this.memoizedSerializedSize;
        if (n != -1) {
            return n;
        }
        boolean bl = this.providerId_.isEmpty();
        int n2 = 0;
        if (!bl) {
            n2 = 0 + CodedOutputStream.computeStringSize((int)1, (String)this.getProviderId());
        }
        if (!this.audiences_.isEmpty()) {
            n2 += CodedOutputStream.computeStringSize((int)2, (String)this.getAudiences());
        }
        this.memoizedSerializedSize = n2;
        return n2;
    }

    public void writeTo(CodedOutputStream codedOutputStream) throws IOException {
        if (!this.providerId_.isEmpty()) {
            codedOutputStream.writeString(1, this.getProviderId());
        }
        if (!this.audiences_.isEmpty()) {
            codedOutputStream.writeString(2, this.getAudiences());
        }
    }

    public static final class Builder
    extends GeneratedMessageLite.Builder<AuthRequirement, Builder>
    implements AuthRequirementOrBuilder {
        private Builder() {
            super((GeneratedMessageLite)DEFAULT_INSTANCE);
        }

        public /* synthetic */ Builder(1 var1_1) {
            this();
        }

        public Builder clearAudiences() {
            this.copyOnWrite();
            ((AuthRequirement)this.instance).clearAudiences();
            return this;
        }

        public Builder clearProviderId() {
            this.copyOnWrite();
            ((AuthRequirement)this.instance).clearProviderId();
            return this;
        }

        public String getAudiences() {
            return ((AuthRequirement)this.instance).getAudiences();
        }

        public ByteString getAudiencesBytes() {
            return ((AuthRequirement)this.instance).getAudiencesBytes();
        }

        public String getProviderId() {
            return ((AuthRequirement)this.instance).getProviderId();
        }

        public ByteString getProviderIdBytes() {
            return ((AuthRequirement)this.instance).getProviderIdBytes();
        }

        public Builder setAudiences(String string2) {
            this.copyOnWrite();
            ((AuthRequirement)this.instance).setAudiences(string2);
            return this;
        }

        public Builder setAudiencesBytes(ByteString byteString) {
            this.copyOnWrite();
            ((AuthRequirement)this.instance).setAudiencesBytes(byteString);
            return this;
        }

        public Builder setProviderId(String string2) {
            this.copyOnWrite();
            ((AuthRequirement)this.instance).setProviderId(string2);
            return this;
        }

        public Builder setProviderIdBytes(ByteString byteString) {
            this.copyOnWrite();
            ((AuthRequirement)this.instance).setProviderIdBytes(byteString);
            return this;
        }
    }

}

