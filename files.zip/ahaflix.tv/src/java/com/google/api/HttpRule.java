/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.api.HttpRule$1
 *  com.google.api.HttpRule$PatternCase
 *  com.google.api.HttpRuleOrBuilder
 *  com.google.protobuf.AbstractMessageLite
 *  com.google.protobuf.ByteString
 *  com.google.protobuf.CodedInputStream
 *  com.google.protobuf.CodedOutputStream
 *  com.google.protobuf.ExtensionRegistryLite
 *  com.google.protobuf.GeneratedMessageLite
 *  com.google.protobuf.GeneratedMessageLite$Builder
 *  com.google.protobuf.GeneratedMessageLite$DefaultInstanceBasedParser
 *  com.google.protobuf.GeneratedMessageLite$MergeFromVisitor
 *  com.google.protobuf.GeneratedMessageLite$MethodToInvoke
 *  com.google.protobuf.GeneratedMessageLite$Visitor
 *  com.google.protobuf.Internal
 *  com.google.protobuf.Internal$ProtobufList
 *  com.google.protobuf.InvalidProtocolBufferException
 *  com.google.protobuf.MessageLite
 *  com.google.protobuf.Parser
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Class
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 *  java.util.Collections
 *  java.util.List
 *  java.util.Objects
 */
package com.google.api;

import com.google.api.CustomHttpPattern;
import com.google.api.HttpRule;
import com.google.api.HttpRuleOrBuilder;
import com.google.protobuf.AbstractMessageLite;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.CodedOutputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.Internal;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.MessageLite;
import com.google.protobuf.Parser;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

/*
 * Exception performing whole class analysis ignored.
 */
public final class HttpRule
extends GeneratedMessageLite<HttpRule, Builder>
implements HttpRuleOrBuilder {
    public static final int ADDITIONAL_BINDINGS_FIELD_NUMBER = 11;
    public static final int BODY_FIELD_NUMBER = 7;
    public static final int CUSTOM_FIELD_NUMBER = 8;
    private static final HttpRule DEFAULT_INSTANCE;
    public static final int DELETE_FIELD_NUMBER = 5;
    public static final int GET_FIELD_NUMBER = 2;
    private static volatile Parser<HttpRule> PARSER;
    public static final int PATCH_FIELD_NUMBER = 6;
    public static final int POST_FIELD_NUMBER = 4;
    public static final int PUT_FIELD_NUMBER = 3;
    public static final int SELECTOR_FIELD_NUMBER = 1;
    private Internal.ProtobufList<HttpRule> additionalBindings_ = GeneratedMessageLite.emptyProtobufList();
    private int bitField0_;
    private String body_ = "";
    private int patternCase_ = 0;
    private Object pattern_;
    private String selector_ = "";

    public static {
        HttpRule httpRule;
        DEFAULT_INSTANCE = httpRule = new HttpRule();
        httpRule.makeImmutable();
    }

    private HttpRule() {
    }

    private void addAdditionalBindings(int n, Builder builder) {
        this.ensureAdditionalBindingsIsMutable();
        this.additionalBindings_.add(n, (Object)((HttpRule)builder.build()));
    }

    private void addAdditionalBindings(int n, HttpRule httpRule) {
        Objects.requireNonNull((Object)((Object)httpRule));
        this.ensureAdditionalBindingsIsMutable();
        this.additionalBindings_.add(n, (Object)httpRule);
    }

    private void addAdditionalBindings(Builder builder) {
        this.ensureAdditionalBindingsIsMutable();
        this.additionalBindings_.add((Object)((HttpRule)builder.build()));
    }

    private void addAdditionalBindings(HttpRule httpRule) {
        Objects.requireNonNull((Object)((Object)httpRule));
        this.ensureAdditionalBindingsIsMutable();
        this.additionalBindings_.add((Object)httpRule);
    }

    private void addAllAdditionalBindings(Iterable<? extends HttpRule> iterable) {
        this.ensureAdditionalBindingsIsMutable();
        AbstractMessageLite.addAll(iterable, this.additionalBindings_);
    }

    private void clearAdditionalBindings() {
        this.additionalBindings_ = GeneratedMessageLite.emptyProtobufList();
    }

    private void clearBody() {
        this.body_ = HttpRule.getDefaultInstance().getBody();
    }

    private void clearCustom() {
        if (this.patternCase_ == 8) {
            this.patternCase_ = 0;
            this.pattern_ = null;
        }
    }

    private void clearDelete() {
        if (this.patternCase_ == 5) {
            this.patternCase_ = 0;
            this.pattern_ = null;
        }
    }

    private void clearGet() {
        if (this.patternCase_ == 2) {
            this.patternCase_ = 0;
            this.pattern_ = null;
        }
    }

    private void clearPatch() {
        if (this.patternCase_ == 6) {
            this.patternCase_ = 0;
            this.pattern_ = null;
        }
    }

    private void clearPattern() {
        this.patternCase_ = 0;
        this.pattern_ = null;
    }

    private void clearPost() {
        if (this.patternCase_ == 4) {
            this.patternCase_ = 0;
            this.pattern_ = null;
        }
    }

    private void clearPut() {
        if (this.patternCase_ == 3) {
            this.patternCase_ = 0;
            this.pattern_ = null;
        }
    }

    private void clearSelector() {
        this.selector_ = HttpRule.getDefaultInstance().getSelector();
    }

    private void ensureAdditionalBindingsIsMutable() {
        if (!this.additionalBindings_.isModifiable()) {
            this.additionalBindings_ = GeneratedMessageLite.mutableCopy(this.additionalBindings_);
        }
    }

    public static HttpRule getDefaultInstance() {
        return DEFAULT_INSTANCE;
    }

    private void mergeCustom(CustomHttpPattern customHttpPattern) {
        this.pattern_ = this.patternCase_ == 8 && this.pattern_ != CustomHttpPattern.getDefaultInstance() ? ((CustomHttpPattern.Builder)CustomHttpPattern.newBuilder((CustomHttpPattern)((Object)this.pattern_)).mergeFrom((GeneratedMessageLite)customHttpPattern)).buildPartial() : customHttpPattern;
        this.patternCase_ = 8;
    }

    public static Builder newBuilder() {
        return (Builder)DEFAULT_INSTANCE.toBuilder();
    }

    public static Builder newBuilder(HttpRule httpRule) {
        return (Builder)((Builder)DEFAULT_INSTANCE.toBuilder()).mergeFrom((GeneratedMessageLite)httpRule);
    }

    public static HttpRule parseDelimitedFrom(InputStream inputStream) throws IOException {
        return (HttpRule)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static HttpRule parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (HttpRule)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static HttpRule parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
        return (HttpRule)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString);
    }

    public static HttpRule parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (HttpRule)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static HttpRule parseFrom(CodedInputStream codedInputStream) throws IOException {
        return (HttpRule)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream);
    }

    public static HttpRule parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (HttpRule)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static HttpRule parseFrom(InputStream inputStream) throws IOException {
        return (HttpRule)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static HttpRule parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (HttpRule)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static HttpRule parseFrom(byte[] arrby) throws InvalidProtocolBufferException {
        return (HttpRule)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby);
    }

    public static HttpRule parseFrom(byte[] arrby, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (HttpRule)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Parser<HttpRule> parser() {
        return DEFAULT_INSTANCE.getParserForType();
    }

    private void removeAdditionalBindings(int n) {
        this.ensureAdditionalBindingsIsMutable();
        this.additionalBindings_.remove(n);
    }

    private void setAdditionalBindings(int n, Builder builder) {
        this.ensureAdditionalBindingsIsMutable();
        this.additionalBindings_.set(n, (Object)((HttpRule)builder.build()));
    }

    private void setAdditionalBindings(int n, HttpRule httpRule) {
        Objects.requireNonNull((Object)((Object)httpRule));
        this.ensureAdditionalBindingsIsMutable();
        this.additionalBindings_.set(n, (Object)httpRule);
    }

    private void setBody(String string2) {
        Objects.requireNonNull((Object)string2);
        this.body_ = string2;
    }

    private void setBodyBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.body_ = byteString.toStringUtf8();
    }

    private void setCustom(CustomHttpPattern.Builder builder) {
        this.pattern_ = builder.build();
        this.patternCase_ = 8;
    }

    private void setCustom(CustomHttpPattern customHttpPattern) {
        Objects.requireNonNull((Object)((Object)customHttpPattern));
        this.pattern_ = customHttpPattern;
        this.patternCase_ = 8;
    }

    private void setDelete(String string2) {
        Objects.requireNonNull((Object)string2);
        this.patternCase_ = 5;
        this.pattern_ = string2;
    }

    private void setDeleteBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.patternCase_ = 5;
        this.pattern_ = byteString.toStringUtf8();
    }

    private void setGet(String string2) {
        Objects.requireNonNull((Object)string2);
        this.patternCase_ = 2;
        this.pattern_ = string2;
    }

    private void setGetBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.patternCase_ = 2;
        this.pattern_ = byteString.toStringUtf8();
    }

    private void setPatch(String string2) {
        Objects.requireNonNull((Object)string2);
        this.patternCase_ = 6;
        this.pattern_ = string2;
    }

    private void setPatchBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.patternCase_ = 6;
        this.pattern_ = byteString.toStringUtf8();
    }

    private void setPost(String string2) {
        Objects.requireNonNull((Object)string2);
        this.patternCase_ = 4;
        this.pattern_ = string2;
    }

    private void setPostBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.patternCase_ = 4;
        this.pattern_ = byteString.toStringUtf8();
    }

    private void setPut(String string2) {
        Objects.requireNonNull((Object)string2);
        this.patternCase_ = 3;
        this.pattern_ = string2;
    }

    private void setPutBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.patternCase_ = 3;
        this.pattern_ = byteString.toStringUtf8();
    }

    private void setSelector(String string2) {
        Objects.requireNonNull((Object)string2);
        this.selector_ = string2;
    }

    private void setSelectorBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.selector_ = byteString.toStringUtf8();
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke var1_1, Object var2_2, Object var3_3) {
        var4_4 = var1_1.ordinal();
        var5_5 = false;
        switch (var4_4) {
            default: {
                throw new UnsupportedOperationException();
            }
            case 7: {
                if (HttpRule.PARSER != null) return HttpRule.PARSER;
                var39_6 = HttpRule.class;
                // MONITORENTER : com.google.api.HttpRule.class
                if (HttpRule.PARSER == null) {
                    HttpRule.PARSER = new GeneratedMessageLite.DefaultInstanceBasedParser((GeneratedMessageLite)HttpRule.DEFAULT_INSTANCE);
                }
                // MONITOREXIT : var39_6
                return HttpRule.PARSER;
            }
            case 2: {
                var23_7 = (CodedInputStream)var2_2;
                var24_8 = (ExtensionRegistryLite)var3_3;
lbl17: // 2 sources:
                do {
                    if (var5_5 != false) return HttpRule.DEFAULT_INSTANCE;
                    var28_13 = var23_7.readTag();
                    if (var28_13 == 0) ** GOTO lbl63
                    if (var28_13 == 10) ** GOTO lbl61
                    if (var28_13 == 18) ** GOTO lbl57
                    if (var28_13 == 26) ** GOTO lbl53
                    if (var28_13 == 34) ** GOTO lbl49
                    if (var28_13 == 42) ** GOTO lbl45
                    if (var28_13 == 50) ** GOTO lbl41
                    if (var28_13 == 58) ** GOTO lbl39
                    if (var28_13 == 66) ** GOTO lbl38
                    if (var28_13 != 90) {
                        if (var23_7.skipField(var28_13)) continue;
                    } else {
                        if (!this.additionalBindings_.isModifiable()) {
                            this.additionalBindings_ = GeneratedMessageLite.mutableCopy(this.additionalBindings_);
                        }
                        this.additionalBindings_.add((Object)((HttpRule)var23_7.readMessage(HttpRule.parser(), var24_8)));
                        continue;
lbl38: // 1 sources:
                        var34_11 = this.patternCase_ == 8 ? (CustomHttpPattern.Builder)((CustomHttpPattern)this.pattern_).toBuilder() : null;
lbl39: // 1 sources:
                        this.body_ = var23_7.readStringRequireUtf8();
                        continue;
lbl41: // 1 sources:
                        var33_10 = var23_7.readStringRequireUtf8();
                        this.patternCase_ = 6;
                        this.pattern_ = var33_10;
                        continue;
lbl45: // 1 sources:
                        var32_9 = var23_7.readStringRequireUtf8();
                        this.patternCase_ = 5;
                        this.pattern_ = var32_9;
                        continue;
lbl49: // 1 sources:
                        var31_16 = var23_7.readStringRequireUtf8();
                        this.patternCase_ = 4;
                        this.pattern_ = var31_16;
                        continue;
lbl53: // 1 sources:
                        var30_15 = var23_7.readStringRequireUtf8();
                        this.patternCase_ = 3;
                        this.pattern_ = var30_15;
                        continue;
lbl57: // 1 sources:
                        var29_14 = var23_7.readStringRequireUtf8();
                        this.patternCase_ = 2;
                        this.pattern_ = var29_14;
                        continue;
lbl61: // 1 sources:
                        this.selector_ = var23_7.readStringRequireUtf8();
                        continue;
                    }
lbl63: // 2 sources:
                    var5_5 = true;
                    continue;
                    catch (IOException var27_18) {
                        throw new RuntimeException((Throwable)new InvalidProtocolBufferException(var27_18.getMessage()).setUnfinishedMessage((MessageLite)this));
                    }
                    catch (InvalidProtocolBufferException var25_19) {
                        throw new RuntimeException((Throwable)var25_19.setUnfinishedMessage((MessageLite)this));
                    }
                    break;
                } while (true);
            }
            case 6: {
                return HttpRule.DEFAULT_INSTANCE;
            }
            case 1: {
                var6_20 = (GeneratedMessageLite.Visitor)var2_2;
                var7_21 = (HttpRule)var3_3;
                this.selector_ = var6_20.visitString(true ^ this.selector_.isEmpty(), this.selector_, true ^ var7_21.selector_.isEmpty(), var7_21.selector_);
                this.body_ = var6_20.visitString(true ^ this.body_.isEmpty(), this.body_, true ^ var7_21.body_.isEmpty(), var7_21.body_);
                this.additionalBindings_ = var6_20.visitList(this.additionalBindings_, var7_21.additionalBindings_);
                switch (var7_21.getPatternCase().ordinal()) {
                    default: {
                        ** break;
                    }
                    case 6: {
                        var21_22 = this.patternCase_;
                        var22_23 = false;
                        if (var21_22 != 0) {
                            var22_23 = true;
                        }
                        var6_20.visitOneofNotSet(var22_23);
                        ** break;
                    }
                    case 5: {
                        var19_24 = this.patternCase_;
                        var20_25 = false;
                        if (var19_24 == 8) {
                            var20_25 = true;
                        }
                        this.pattern_ = var6_20.visitOneofMessage(var20_25, this.pattern_, var7_21.pattern_);
                        ** break;
                    }
                    case 4: {
                        var17_26 = this.patternCase_;
                        var18_27 = false;
                        if (var17_26 == 6) {
                            var18_27 = true;
                        }
                        this.pattern_ = var6_20.visitOneofString(var18_27, this.pattern_, var7_21.pattern_);
                        ** break;
                    }
                    case 3: {
                        var15_28 = this.patternCase_;
                        var16_29 = false;
                        if (var15_28 == 5) {
                            var16_29 = true;
                        }
                        this.pattern_ = var6_20.visitOneofString(var16_29, this.pattern_, var7_21.pattern_);
                        ** break;
                    }
                    case 2: {
                        var13_30 = this.patternCase_;
                        var14_31 = false;
                        if (var13_30 == 4) {
                            var14_31 = true;
                        }
                        this.pattern_ = var6_20.visitOneofString(var14_31, this.pattern_, var7_21.pattern_);
                        ** break;
                    }
                    case 1: {
                        var11_32 = this.patternCase_;
                        var12_33 = false;
                        if (var11_32 == 3) {
                            var12_33 = true;
                        }
                        this.pattern_ = var6_20.visitOneofString(var12_33, this.pattern_, var7_21.pattern_);
                        ** break;
                    }
                    case 0: 
                }
                var8_34 = this.patternCase_;
                var9_35 = false;
                if (var8_34 == 2) {
                    var9_35 = true;
                }
                this.pattern_ = var6_20.visitOneofString(var9_35, this.pattern_, var7_21.pattern_);
lbl130: // 8 sources:
                if (var6_20 != GeneratedMessageLite.MergeFromVisitor.INSTANCE) return this;
                var10_36 = var7_21.patternCase_;
                if (var10_36 != 0) {
                    this.patternCase_ = var10_36;
                }
                this.bitField0_ |= var7_21.bitField0_;
                return this;
            }
            case 5: {
                return new Builder(null);
            }
            case 3: {
                this.additionalBindings_.makeImmutable();
                return null;
            }
            case 0: {
                return HttpRule.DEFAULT_INSTANCE;
            }
            case 4: {
                return new HttpRule();
            }
        }
        var35_12 = var23_7.readMessage(CustomHttpPattern.parser(), var24_8);
        this.pattern_ = var35_12;
        if (var34_11 != null) {
            var34_11.mergeFrom((GeneratedMessageLite)((CustomHttpPattern)var35_12));
            this.pattern_ = var34_11.buildPartial();
        }
        this.patternCase_ = 8;
        ** while (true)
    }

    public HttpRule getAdditionalBindings(int n) {
        return (HttpRule)((Object)this.additionalBindings_.get(n));
    }

    public int getAdditionalBindingsCount() {
        return this.additionalBindings_.size();
    }

    public List<HttpRule> getAdditionalBindingsList() {
        return this.additionalBindings_;
    }

    public HttpRuleOrBuilder getAdditionalBindingsOrBuilder(int n) {
        return (HttpRuleOrBuilder)this.additionalBindings_.get(n);
    }

    public List<? extends HttpRuleOrBuilder> getAdditionalBindingsOrBuilderList() {
        return this.additionalBindings_;
    }

    public String getBody() {
        return this.body_;
    }

    public ByteString getBodyBytes() {
        return ByteString.copyFromUtf8((String)this.body_);
    }

    public CustomHttpPattern getCustom() {
        if (this.patternCase_ == 8) {
            return (CustomHttpPattern)((Object)this.pattern_);
        }
        return CustomHttpPattern.getDefaultInstance();
    }

    public String getDelete() {
        if (this.patternCase_ == 5) {
            return (String)this.pattern_;
        }
        return "";
    }

    public ByteString getDeleteBytes() {
        String string2 = this.patternCase_ == 5 ? (String)this.pattern_ : "";
        return ByteString.copyFromUtf8((String)string2);
    }

    public String getGet() {
        if (this.patternCase_ == 2) {
            return (String)this.pattern_;
        }
        return "";
    }

    public ByteString getGetBytes() {
        String string2 = this.patternCase_ == 2 ? (String)this.pattern_ : "";
        return ByteString.copyFromUtf8((String)string2);
    }

    public String getPatch() {
        if (this.patternCase_ == 6) {
            return (String)this.pattern_;
        }
        return "";
    }

    public ByteString getPatchBytes() {
        String string2 = this.patternCase_ == 6 ? (String)this.pattern_ : "";
        return ByteString.copyFromUtf8((String)string2);
    }

    public PatternCase getPatternCase() {
        return PatternCase.forNumber((int)this.patternCase_);
    }

    public String getPost() {
        if (this.patternCase_ == 4) {
            return (String)this.pattern_;
        }
        return "";
    }

    public ByteString getPostBytes() {
        String string2 = this.patternCase_ == 4 ? (String)this.pattern_ : "";
        return ByteString.copyFromUtf8((String)string2);
    }

    public String getPut() {
        if (this.patternCase_ == 3) {
            return (String)this.pattern_;
        }
        return "";
    }

    public ByteString getPutBytes() {
        String string2 = this.patternCase_ == 3 ? (String)this.pattern_ : "";
        return ByteString.copyFromUtf8((String)string2);
    }

    public String getSelector() {
        return this.selector_;
    }

    public ByteString getSelectorBytes() {
        return ByteString.copyFromUtf8((String)this.selector_);
    }

    public int getSerializedSize() {
        int n = this.memoizedSerializedSize;
        if (n != -1) {
            return n;
        }
        int n2 = !this.selector_.isEmpty() ? 0 + CodedOutputStream.computeStringSize((int)1, (String)this.getSelector()) : 0;
        if (this.patternCase_ == 2) {
            n2 += CodedOutputStream.computeStringSize((int)2, (String)this.getGet());
        }
        if (this.patternCase_ == 3) {
            n2 += CodedOutputStream.computeStringSize((int)3, (String)this.getPut());
        }
        if (this.patternCase_ == 4) {
            n2 += CodedOutputStream.computeStringSize((int)4, (String)this.getPost());
        }
        if (this.patternCase_ == 5) {
            n2 += CodedOutputStream.computeStringSize((int)5, (String)this.getDelete());
        }
        if (this.patternCase_ == 6) {
            n2 += CodedOutputStream.computeStringSize((int)6, (String)this.getPatch());
        }
        if (!this.body_.isEmpty()) {
            n2 += CodedOutputStream.computeStringSize((int)7, (String)this.getBody());
        }
        int n3 = this.patternCase_;
        int n4 = 0;
        if (n3 == 8) {
            n2 += CodedOutputStream.computeMessageSize((int)8, (MessageLite)((CustomHttpPattern)((Object)this.pattern_)));
        }
        while (n4 < this.additionalBindings_.size()) {
            n2 += CodedOutputStream.computeMessageSize((int)11, (MessageLite)((MessageLite)this.additionalBindings_.get(n4)));
            ++n4;
        }
        this.memoizedSerializedSize = n2;
        return n2;
    }

    public void writeTo(CodedOutputStream codedOutputStream) throws IOException {
        if (!this.selector_.isEmpty()) {
            codedOutputStream.writeString(1, this.getSelector());
        }
        if (this.patternCase_ == 2) {
            codedOutputStream.writeString(2, this.getGet());
        }
        if (this.patternCase_ == 3) {
            codedOutputStream.writeString(3, this.getPut());
        }
        if (this.patternCase_ == 4) {
            codedOutputStream.writeString(4, this.getPost());
        }
        if (this.patternCase_ == 5) {
            codedOutputStream.writeString(5, this.getDelete());
        }
        if (this.patternCase_ == 6) {
            codedOutputStream.writeString(6, this.getPatch());
        }
        if (!this.body_.isEmpty()) {
            codedOutputStream.writeString(7, this.getBody());
        }
        if (this.patternCase_ == 8) {
            codedOutputStream.writeMessage(8, (MessageLite)((CustomHttpPattern)((Object)this.pattern_)));
        }
        for (int i = 0; i < this.additionalBindings_.size(); ++i) {
            codedOutputStream.writeMessage(11, (MessageLite)this.additionalBindings_.get(i));
        }
    }

    public static final class Builder
    extends GeneratedMessageLite.Builder<HttpRule, Builder>
    implements HttpRuleOrBuilder {
        private Builder() {
            super((GeneratedMessageLite)DEFAULT_INSTANCE);
        }

        public /* synthetic */ Builder(1 var1_1) {
            this();
        }

        public Builder addAdditionalBindings(int n, Builder builder) {
            this.copyOnWrite();
            ((HttpRule)this.instance).addAdditionalBindings(n, builder);
            return this;
        }

        public Builder addAdditionalBindings(int n, HttpRule httpRule) {
            this.copyOnWrite();
            ((HttpRule)this.instance).addAdditionalBindings(n, httpRule);
            return this;
        }

        public Builder addAdditionalBindings(Builder builder) {
            this.copyOnWrite();
            ((HttpRule)this.instance).addAdditionalBindings(builder);
            return this;
        }

        public Builder addAdditionalBindings(HttpRule httpRule) {
            this.copyOnWrite();
            ((HttpRule)this.instance).addAdditionalBindings(httpRule);
            return this;
        }

        public Builder addAllAdditionalBindings(Iterable<? extends HttpRule> iterable) {
            this.copyOnWrite();
            ((HttpRule)this.instance).addAllAdditionalBindings((Iterable<? extends HttpRule>)iterable);
            return this;
        }

        public Builder clearAdditionalBindings() {
            this.copyOnWrite();
            ((HttpRule)this.instance).clearAdditionalBindings();
            return this;
        }

        public Builder clearBody() {
            this.copyOnWrite();
            ((HttpRule)this.instance).clearBody();
            return this;
        }

        public Builder clearCustom() {
            this.copyOnWrite();
            ((HttpRule)this.instance).clearCustom();
            return this;
        }

        public Builder clearDelete() {
            this.copyOnWrite();
            ((HttpRule)this.instance).clearDelete();
            return this;
        }

        public Builder clearGet() {
            this.copyOnWrite();
            ((HttpRule)this.instance).clearGet();
            return this;
        }

        public Builder clearPatch() {
            this.copyOnWrite();
            ((HttpRule)this.instance).clearPatch();
            return this;
        }

        public Builder clearPattern() {
            this.copyOnWrite();
            ((HttpRule)this.instance).clearPattern();
            return this;
        }

        public Builder clearPost() {
            this.copyOnWrite();
            ((HttpRule)this.instance).clearPost();
            return this;
        }

        public Builder clearPut() {
            this.copyOnWrite();
            ((HttpRule)this.instance).clearPut();
            return this;
        }

        public Builder clearSelector() {
            this.copyOnWrite();
            ((HttpRule)this.instance).clearSelector();
            return this;
        }

        public HttpRule getAdditionalBindings(int n) {
            return ((HttpRule)this.instance).getAdditionalBindings(n);
        }

        public int getAdditionalBindingsCount() {
            return ((HttpRule)this.instance).getAdditionalBindingsCount();
        }

        public List<HttpRule> getAdditionalBindingsList() {
            return Collections.unmodifiableList(((HttpRule)this.instance).getAdditionalBindingsList());
        }

        public String getBody() {
            return ((HttpRule)this.instance).getBody();
        }

        public ByteString getBodyBytes() {
            return ((HttpRule)this.instance).getBodyBytes();
        }

        public CustomHttpPattern getCustom() {
            return ((HttpRule)this.instance).getCustom();
        }

        public String getDelete() {
            return ((HttpRule)this.instance).getDelete();
        }

        public ByteString getDeleteBytes() {
            return ((HttpRule)this.instance).getDeleteBytes();
        }

        public String getGet() {
            return ((HttpRule)this.instance).getGet();
        }

        public ByteString getGetBytes() {
            return ((HttpRule)this.instance).getGetBytes();
        }

        public String getPatch() {
            return ((HttpRule)this.instance).getPatch();
        }

        public ByteString getPatchBytes() {
            return ((HttpRule)this.instance).getPatchBytes();
        }

        public PatternCase getPatternCase() {
            return ((HttpRule)this.instance).getPatternCase();
        }

        public String getPost() {
            return ((HttpRule)this.instance).getPost();
        }

        public ByteString getPostBytes() {
            return ((HttpRule)this.instance).getPostBytes();
        }

        public String getPut() {
            return ((HttpRule)this.instance).getPut();
        }

        public ByteString getPutBytes() {
            return ((HttpRule)this.instance).getPutBytes();
        }

        public String getSelector() {
            return ((HttpRule)this.instance).getSelector();
        }

        public ByteString getSelectorBytes() {
            return ((HttpRule)this.instance).getSelectorBytes();
        }

        public Builder mergeCustom(CustomHttpPattern customHttpPattern) {
            this.copyOnWrite();
            ((HttpRule)this.instance).mergeCustom(customHttpPattern);
            return this;
        }

        public Builder removeAdditionalBindings(int n) {
            this.copyOnWrite();
            ((HttpRule)this.instance).removeAdditionalBindings(n);
            return this;
        }

        public Builder setAdditionalBindings(int n, Builder builder) {
            this.copyOnWrite();
            ((HttpRule)this.instance).setAdditionalBindings(n, builder);
            return this;
        }

        public Builder setAdditionalBindings(int n, HttpRule httpRule) {
            this.copyOnWrite();
            ((HttpRule)this.instance).setAdditionalBindings(n, httpRule);
            return this;
        }

        public Builder setBody(String string2) {
            this.copyOnWrite();
            ((HttpRule)this.instance).setBody(string2);
            return this;
        }

        public Builder setBodyBytes(ByteString byteString) {
            this.copyOnWrite();
            ((HttpRule)this.instance).setBodyBytes(byteString);
            return this;
        }

        public Builder setCustom(CustomHttpPattern.Builder builder) {
            this.copyOnWrite();
            ((HttpRule)this.instance).setCustom(builder);
            return this;
        }

        public Builder setCustom(CustomHttpPattern customHttpPattern) {
            this.copyOnWrite();
            ((HttpRule)this.instance).setCustom(customHttpPattern);
            return this;
        }

        public Builder setDelete(String string2) {
            this.copyOnWrite();
            ((HttpRule)this.instance).setDelete(string2);
            return this;
        }

        public Builder setDeleteBytes(ByteString byteString) {
            this.copyOnWrite();
            ((HttpRule)this.instance).setDeleteBytes(byteString);
            return this;
        }

        public Builder setGet(String string2) {
            this.copyOnWrite();
            ((HttpRule)this.instance).setGet(string2);
            return this;
        }

        public Builder setGetBytes(ByteString byteString) {
            this.copyOnWrite();
            ((HttpRule)this.instance).setGetBytes(byteString);
            return this;
        }

        public Builder setPatch(String string2) {
            this.copyOnWrite();
            ((HttpRule)this.instance).setPatch(string2);
            return this;
        }

        public Builder setPatchBytes(ByteString byteString) {
            this.copyOnWrite();
            ((HttpRule)this.instance).setPatchBytes(byteString);
            return this;
        }

        public Builder setPost(String string2) {
            this.copyOnWrite();
            ((HttpRule)this.instance).setPost(string2);
            return this;
        }

        public Builder setPostBytes(ByteString byteString) {
            this.copyOnWrite();
            ((HttpRule)this.instance).setPostBytes(byteString);
            return this;
        }

        public Builder setPut(String string2) {
            this.copyOnWrite();
            ((HttpRule)this.instance).setPut(string2);
            return this;
        }

        public Builder setPutBytes(ByteString byteString) {
            this.copyOnWrite();
            ((HttpRule)this.instance).setPutBytes(byteString);
            return this;
        }

        public Builder setSelector(String string2) {
            this.copyOnWrite();
            ((HttpRule)this.instance).setSelector(string2);
            return this;
        }

        public Builder setSelectorBytes(ByteString byteString) {
            this.copyOnWrite();
            ((HttpRule)this.instance).setSelectorBytes(byteString);
            return this;
        }
    }

}

