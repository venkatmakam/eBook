/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.api.AuthProvider$1
 *  com.google.api.AuthProviderOrBuilder
 *  com.google.protobuf.AbstractMessageLite
 *  com.google.protobuf.ByteString
 *  com.google.protobuf.CodedInputStream
 *  com.google.protobuf.CodedOutputStream
 *  com.google.protobuf.ExtensionRegistryLite
 *  com.google.protobuf.GeneratedMessageLite
 *  com.google.protobuf.GeneratedMessageLite$Builder
 *  com.google.protobuf.GeneratedMessageLite$DefaultInstanceBasedParser
 *  com.google.protobuf.GeneratedMessageLite$MethodToInvoke
 *  com.google.protobuf.GeneratedMessageLite$Visitor
 *  com.google.protobuf.InvalidProtocolBufferException
 *  com.google.protobuf.MessageLite
 *  com.google.protobuf.Parser
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 *  java.util.Objects
 */
package com.google.api;

import com.google.api.AuthProvider;
import com.google.api.AuthProviderOrBuilder;
import com.google.protobuf.AbstractMessageLite;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.CodedOutputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.MessageLite;
import com.google.protobuf.Parser;
import java.io.IOException;
import java.io.InputStream;
import java.util.Objects;

public final class AuthProvider
extends GeneratedMessageLite<AuthProvider, Builder>
implements AuthProviderOrBuilder {
    public static final int AUDIENCES_FIELD_NUMBER = 4;
    public static final int AUTHORIZATION_URL_FIELD_NUMBER = 5;
    private static final AuthProvider DEFAULT_INSTANCE;
    public static final int ID_FIELD_NUMBER = 1;
    public static final int ISSUER_FIELD_NUMBER = 2;
    public static final int JWKS_URI_FIELD_NUMBER = 3;
    private static volatile Parser<AuthProvider> PARSER;
    private String audiences_ = "";
    private String authorizationUrl_ = "";
    private String id_ = "";
    private String issuer_ = "";
    private String jwksUri_ = "";

    public static {
        AuthProvider authProvider;
        DEFAULT_INSTANCE = authProvider = new AuthProvider();
        authProvider.makeImmutable();
    }

    private AuthProvider() {
    }

    private void clearAudiences() {
        this.audiences_ = AuthProvider.getDefaultInstance().getAudiences();
    }

    private void clearAuthorizationUrl() {
        this.authorizationUrl_ = AuthProvider.getDefaultInstance().getAuthorizationUrl();
    }

    private void clearId() {
        this.id_ = AuthProvider.getDefaultInstance().getId();
    }

    private void clearIssuer() {
        this.issuer_ = AuthProvider.getDefaultInstance().getIssuer();
    }

    private void clearJwksUri() {
        this.jwksUri_ = AuthProvider.getDefaultInstance().getJwksUri();
    }

    public static AuthProvider getDefaultInstance() {
        return DEFAULT_INSTANCE;
    }

    public static Builder newBuilder() {
        return (Builder)DEFAULT_INSTANCE.toBuilder();
    }

    public static Builder newBuilder(AuthProvider authProvider) {
        return (Builder)((Builder)DEFAULT_INSTANCE.toBuilder()).mergeFrom((GeneratedMessageLite)authProvider);
    }

    public static AuthProvider parseDelimitedFrom(InputStream inputStream) throws IOException {
        return (AuthProvider)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static AuthProvider parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (AuthProvider)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static AuthProvider parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
        return (AuthProvider)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString);
    }

    public static AuthProvider parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (AuthProvider)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static AuthProvider parseFrom(CodedInputStream codedInputStream) throws IOException {
        return (AuthProvider)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream);
    }

    public static AuthProvider parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (AuthProvider)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static AuthProvider parseFrom(InputStream inputStream) throws IOException {
        return (AuthProvider)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static AuthProvider parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (AuthProvider)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static AuthProvider parseFrom(byte[] arrby) throws InvalidProtocolBufferException {
        return (AuthProvider)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby);
    }

    public static AuthProvider parseFrom(byte[] arrby, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (AuthProvider)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Parser<AuthProvider> parser() {
        return DEFAULT_INSTANCE.getParserForType();
    }

    private void setAudiences(String string2) {
        Objects.requireNonNull((Object)string2);
        this.audiences_ = string2;
    }

    private void setAudiencesBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.audiences_ = byteString.toStringUtf8();
    }

    private void setAuthorizationUrl(String string2) {
        Objects.requireNonNull((Object)string2);
        this.authorizationUrl_ = string2;
    }

    private void setAuthorizationUrlBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.authorizationUrl_ = byteString.toStringUtf8();
    }

    private void setId(String string2) {
        Objects.requireNonNull((Object)string2);
        this.id_ = string2;
    }

    private void setIdBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.id_ = byteString.toStringUtf8();
    }

    private void setIssuer(String string2) {
        Objects.requireNonNull((Object)string2);
        this.issuer_ = string2;
    }

    private void setIssuerBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.issuer_ = byteString.toStringUtf8();
    }

    private void setJwksUri(String string2) {
        Objects.requireNonNull((Object)string2);
        this.jwksUri_ = string2;
    }

    private void setJwksUriBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.jwksUri_ = byteString.toStringUtf8();
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke var1_1, Object var2_2, Object var3_3) {
        switch (var1_1.ordinal()) {
            default: {
                throw new UnsupportedOperationException();
            }
            case 7: {
                if (AuthProvider.PARSER != null) return AuthProvider.PARSER;
                var15_4 = AuthProvider.class;
                // MONITORENTER : com.google.api.AuthProvider.class
                if (AuthProvider.PARSER == null) {
                    AuthProvider.PARSER = new GeneratedMessageLite.DefaultInstanceBasedParser((GeneratedMessageLite)AuthProvider.DEFAULT_INSTANCE);
                }
                // MONITOREXIT : var15_4
                return AuthProvider.PARSER;
            }
            case 2: {
                var7_5 = (CodedInputStream)var2_2;
                (ExtensionRegistryLite)var3_3;
                var9_6 = false;
                while (var9_6 == false) {
                    var13_7 = var7_5.readTag();
                    if (var13_7 == 0) ** GOTO lbl38
                    if (var13_7 == 10) ** GOTO lbl36
                    if (var13_7 == 18) ** GOTO lbl34
                    if (var13_7 == 26) ** GOTO lbl32
                    if (var13_7 == 34) ** GOTO lbl30
                    if (var13_7 != 42) {
                        if (var7_5.skipField(var13_7)) continue;
                    } else {
                        this.authorizationUrl_ = var7_5.readStringRequireUtf8();
                        continue;
lbl30: // 1 sources:
                        this.audiences_ = var7_5.readStringRequireUtf8();
                        continue;
lbl32: // 1 sources:
                        this.jwksUri_ = var7_5.readStringRequireUtf8();
                        continue;
lbl34: // 1 sources:
                        this.issuer_ = var7_5.readStringRequireUtf8();
                        continue;
lbl36: // 1 sources:
                        this.id_ = var7_5.readStringRequireUtf8();
                        continue;
                    }
lbl38: // 2 sources:
                    var9_6 = true;
                    continue;
                    catch (IOException var12_9) {
                        throw new RuntimeException((Throwable)new InvalidProtocolBufferException(var12_9.getMessage()).setUnfinishedMessage((MessageLite)this));
                    }
                    catch (InvalidProtocolBufferException var10_10) {
                        throw new RuntimeException((Throwable)var10_10.setUnfinishedMessage((MessageLite)this));
                    }
                }
                return AuthProvider.DEFAULT_INSTANCE;
            }
            case 6: {
                return AuthProvider.DEFAULT_INSTANCE;
            }
            case 1: {
                var4_11 = (GeneratedMessageLite.Visitor)var2_2;
                var5_12 = (AuthProvider)var3_3;
                this.id_ = var4_11.visitString(true ^ this.id_.isEmpty(), this.id_, true ^ var5_12.id_.isEmpty(), var5_12.id_);
                this.issuer_ = var4_11.visitString(true ^ this.issuer_.isEmpty(), this.issuer_, true ^ var5_12.issuer_.isEmpty(), var5_12.issuer_);
                this.jwksUri_ = var4_11.visitString(true ^ this.jwksUri_.isEmpty(), this.jwksUri_, true ^ var5_12.jwksUri_.isEmpty(), var5_12.jwksUri_);
                this.audiences_ = var4_11.visitString(true ^ this.audiences_.isEmpty(), this.audiences_, true ^ var5_12.audiences_.isEmpty(), var5_12.audiences_);
                this.authorizationUrl_ = var4_11.visitString(true ^ this.authorizationUrl_.isEmpty(), this.authorizationUrl_, true ^ var5_12.authorizationUrl_.isEmpty(), var5_12.authorizationUrl_);
                return this;
            }
            case 5: {
                return new Builder(null);
            }
            case 3: {
                return null;
            }
            case 0: {
                return AuthProvider.DEFAULT_INSTANCE;
            }
            case 4: 
        }
        return new AuthProvider();
    }

    public String getAudiences() {
        return this.audiences_;
    }

    public ByteString getAudiencesBytes() {
        return ByteString.copyFromUtf8((String)this.audiences_);
    }

    public String getAuthorizationUrl() {
        return this.authorizationUrl_;
    }

    public ByteString getAuthorizationUrlBytes() {
        return ByteString.copyFromUtf8((String)this.authorizationUrl_);
    }

    public String getId() {
        return this.id_;
    }

    public ByteString getIdBytes() {
        return ByteString.copyFromUtf8((String)this.id_);
    }

    public String getIssuer() {
        return this.issuer_;
    }

    public ByteString getIssuerBytes() {
        return ByteString.copyFromUtf8((String)this.issuer_);
    }

    public String getJwksUri() {
        return this.jwksUri_;
    }

    public ByteString getJwksUriBytes() {
        return ByteString.copyFromUtf8((String)this.jwksUri_);
    }

    public int getSerializedSize() {
        int n = this.memoizedSerializedSize;
        if (n != -1) {
            return n;
        }
        boolean bl = this.id_.isEmpty();
        int n2 = 0;
        if (!bl) {
            n2 = 0 + CodedOutputStream.computeStringSize((int)1, (String)this.getId());
        }
        if (!this.issuer_.isEmpty()) {
            n2 += CodedOutputStream.computeStringSize((int)2, (String)this.getIssuer());
        }
        if (!this.jwksUri_.isEmpty()) {
            n2 += CodedOutputStream.computeStringSize((int)3, (String)this.getJwksUri());
        }
        if (!this.audiences_.isEmpty()) {
            n2 += CodedOutputStream.computeStringSize((int)4, (String)this.getAudiences());
        }
        if (!this.authorizationUrl_.isEmpty()) {
            n2 += CodedOutputStream.computeStringSize((int)5, (String)this.getAuthorizationUrl());
        }
        this.memoizedSerializedSize = n2;
        return n2;
    }

    public void writeTo(CodedOutputStream codedOutputStream) throws IOException {
        if (!this.id_.isEmpty()) {
            codedOutputStream.writeString(1, this.getId());
        }
        if (!this.issuer_.isEmpty()) {
            codedOutputStream.writeString(2, this.getIssuer());
        }
        if (!this.jwksUri_.isEmpty()) {
            codedOutputStream.writeString(3, this.getJwksUri());
        }
        if (!this.audiences_.isEmpty()) {
            codedOutputStream.writeString(4, this.getAudiences());
        }
        if (!this.authorizationUrl_.isEmpty()) {
            codedOutputStream.writeString(5, this.getAuthorizationUrl());
        }
    }

    public static final class Builder
    extends GeneratedMessageLite.Builder<AuthProvider, Builder>
    implements AuthProviderOrBuilder {
        private Builder() {
            super((GeneratedMessageLite)DEFAULT_INSTANCE);
        }

        public /* synthetic */ Builder(1 var1_1) {
            this();
        }

        public Builder clearAudiences() {
            this.copyOnWrite();
            ((AuthProvider)this.instance).clearAudiences();
            return this;
        }

        public Builder clearAuthorizationUrl() {
            this.copyOnWrite();
            ((AuthProvider)this.instance).clearAuthorizationUrl();
            return this;
        }

        public Builder clearId() {
            this.copyOnWrite();
            ((AuthProvider)this.instance).clearId();
            return this;
        }

        public Builder clearIssuer() {
            this.copyOnWrite();
            ((AuthProvider)this.instance).clearIssuer();
            return this;
        }

        public Builder clearJwksUri() {
            this.copyOnWrite();
            ((AuthProvider)this.instance).clearJwksUri();
            return this;
        }

        public String getAudiences() {
            return ((AuthProvider)this.instance).getAudiences();
        }

        public ByteString getAudiencesBytes() {
            return ((AuthProvider)this.instance).getAudiencesBytes();
        }

        public String getAuthorizationUrl() {
            return ((AuthProvider)this.instance).getAuthorizationUrl();
        }

        public ByteString getAuthorizationUrlBytes() {
            return ((AuthProvider)this.instance).getAuthorizationUrlBytes();
        }

        public String getId() {
            return ((AuthProvider)this.instance).getId();
        }

        public ByteString getIdBytes() {
            return ((AuthProvider)this.instance).getIdBytes();
        }

        public String getIssuer() {
            return ((AuthProvider)this.instance).getIssuer();
        }

        public ByteString getIssuerBytes() {
            return ((AuthProvider)this.instance).getIssuerBytes();
        }

        public String getJwksUri() {
            return ((AuthProvider)this.instance).getJwksUri();
        }

        public ByteString getJwksUriBytes() {
            return ((AuthProvider)this.instance).getJwksUriBytes();
        }

        public Builder setAudiences(String string2) {
            this.copyOnWrite();
            ((AuthProvider)this.instance).setAudiences(string2);
            return this;
        }

        public Builder setAudiencesBytes(ByteString byteString) {
            this.copyOnWrite();
            ((AuthProvider)this.instance).setAudiencesBytes(byteString);
            return this;
        }

        public Builder setAuthorizationUrl(String string2) {
            this.copyOnWrite();
            ((AuthProvider)this.instance).setAuthorizationUrl(string2);
            return this;
        }

        public Builder setAuthorizationUrlBytes(ByteString byteString) {
            this.copyOnWrite();
            ((AuthProvider)this.instance).setAuthorizationUrlBytes(byteString);
            return this;
        }

        public Builder setId(String string2) {
            this.copyOnWrite();
            ((AuthProvider)this.instance).setId(string2);
            return this;
        }

        public Builder setIdBytes(ByteString byteString) {
            this.copyOnWrite();
            ((AuthProvider)this.instance).setIdBytes(byteString);
            return this;
        }

        public Builder setIssuer(String string2) {
            this.copyOnWrite();
            ((AuthProvider)this.instance).setIssuer(string2);
            return this;
        }

        public Builder setIssuerBytes(ByteString byteString) {
            this.copyOnWrite();
            ((AuthProvider)this.instance).setIssuerBytes(byteString);
            return this;
        }

        public Builder setJwksUri(String string2) {
            this.copyOnWrite();
            ((AuthProvider)this.instance).setJwksUri(string2);
            return this;
        }

        public Builder setJwksUriBytes(ByteString byteString) {
            this.copyOnWrite();
            ((AuthProvider)this.instance).setJwksUriBytes(byteString);
            return this;
        }
    }

}

