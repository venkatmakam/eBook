/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.api.SystemParameter$1
 *  com.google.api.SystemParameterOrBuilder
 *  com.google.protobuf.AbstractMessageLite
 *  com.google.protobuf.ByteString
 *  com.google.protobuf.CodedInputStream
 *  com.google.protobuf.CodedOutputStream
 *  com.google.protobuf.ExtensionRegistryLite
 *  com.google.protobuf.GeneratedMessageLite
 *  com.google.protobuf.GeneratedMessageLite$Builder
 *  com.google.protobuf.GeneratedMessageLite$DefaultInstanceBasedParser
 *  com.google.protobuf.GeneratedMessageLite$MethodToInvoke
 *  com.google.protobuf.GeneratedMessageLite$Visitor
 *  com.google.protobuf.InvalidProtocolBufferException
 *  com.google.protobuf.MessageLite
 *  com.google.protobuf.Parser
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 *  java.util.Objects
 */
package com.google.api;

import com.google.api.SystemParameter;
import com.google.api.SystemParameterOrBuilder;
import com.google.protobuf.AbstractMessageLite;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.CodedOutputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.MessageLite;
import com.google.protobuf.Parser;
import java.io.IOException;
import java.io.InputStream;
import java.util.Objects;

public final class SystemParameter
extends GeneratedMessageLite<SystemParameter, Builder>
implements SystemParameterOrBuilder {
    private static final SystemParameter DEFAULT_INSTANCE;
    public static final int HTTP_HEADER_FIELD_NUMBER = 2;
    public static final int NAME_FIELD_NUMBER = 1;
    private static volatile Parser<SystemParameter> PARSER;
    public static final int URL_QUERY_PARAMETER_FIELD_NUMBER = 3;
    private String httpHeader_ = "";
    private String name_ = "";
    private String urlQueryParameter_ = "";

    public static {
        SystemParameter systemParameter;
        DEFAULT_INSTANCE = systemParameter = new SystemParameter();
        systemParameter.makeImmutable();
    }

    private SystemParameter() {
    }

    private void clearHttpHeader() {
        this.httpHeader_ = SystemParameter.getDefaultInstance().getHttpHeader();
    }

    private void clearName() {
        this.name_ = SystemParameter.getDefaultInstance().getName();
    }

    private void clearUrlQueryParameter() {
        this.urlQueryParameter_ = SystemParameter.getDefaultInstance().getUrlQueryParameter();
    }

    public static SystemParameter getDefaultInstance() {
        return DEFAULT_INSTANCE;
    }

    public static Builder newBuilder() {
        return (Builder)DEFAULT_INSTANCE.toBuilder();
    }

    public static Builder newBuilder(SystemParameter systemParameter) {
        return (Builder)((Builder)DEFAULT_INSTANCE.toBuilder()).mergeFrom((GeneratedMessageLite)systemParameter);
    }

    public static SystemParameter parseDelimitedFrom(InputStream inputStream) throws IOException {
        return (SystemParameter)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static SystemParameter parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (SystemParameter)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static SystemParameter parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
        return (SystemParameter)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString);
    }

    public static SystemParameter parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (SystemParameter)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static SystemParameter parseFrom(CodedInputStream codedInputStream) throws IOException {
        return (SystemParameter)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream);
    }

    public static SystemParameter parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (SystemParameter)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static SystemParameter parseFrom(InputStream inputStream) throws IOException {
        return (SystemParameter)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static SystemParameter parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (SystemParameter)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static SystemParameter parseFrom(byte[] arrby) throws InvalidProtocolBufferException {
        return (SystemParameter)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby);
    }

    public static SystemParameter parseFrom(byte[] arrby, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (SystemParameter)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Parser<SystemParameter> parser() {
        return DEFAULT_INSTANCE.getParserForType();
    }

    private void setHttpHeader(String string2) {
        Objects.requireNonNull((Object)string2);
        this.httpHeader_ = string2;
    }

    private void setHttpHeaderBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.httpHeader_ = byteString.toStringUtf8();
    }

    private void setName(String string2) {
        Objects.requireNonNull((Object)string2);
        this.name_ = string2;
    }

    private void setNameBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.name_ = byteString.toStringUtf8();
    }

    private void setUrlQueryParameter(String string2) {
        Objects.requireNonNull((Object)string2);
        this.urlQueryParameter_ = string2;
    }

    private void setUrlQueryParameterBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.urlQueryParameter_ = byteString.toStringUtf8();
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke var1_1, Object var2_2, Object var3_3) {
        switch (var1_1.ordinal()) {
            default: {
                throw new UnsupportedOperationException();
            }
            case 7: {
                if (SystemParameter.PARSER != null) return SystemParameter.PARSER;
                var15_4 = SystemParameter.class;
                // MONITORENTER : com.google.api.SystemParameter.class
                if (SystemParameter.PARSER == null) {
                    SystemParameter.PARSER = new GeneratedMessageLite.DefaultInstanceBasedParser((GeneratedMessageLite)SystemParameter.DEFAULT_INSTANCE);
                }
                // MONITOREXIT : var15_4
                return SystemParameter.PARSER;
            }
            case 2: {
                var7_5 = (CodedInputStream)var2_2;
                (ExtensionRegistryLite)var3_3;
                var9_6 = false;
                while (var9_6 == false) {
                    var13_7 = var7_5.readTag();
                    if (var13_7 == 0) ** GOTO lbl32
                    if (var13_7 == 10) ** GOTO lbl30
                    if (var13_7 == 18) ** GOTO lbl28
                    if (var13_7 != 26) {
                        if (var7_5.skipField(var13_7)) continue;
                    } else {
                        this.urlQueryParameter_ = var7_5.readStringRequireUtf8();
                        continue;
lbl28: // 1 sources:
                        this.httpHeader_ = var7_5.readStringRequireUtf8();
                        continue;
lbl30: // 1 sources:
                        this.name_ = var7_5.readStringRequireUtf8();
                        continue;
                    }
lbl32: // 2 sources:
                    var9_6 = true;
                    continue;
                    catch (IOException var12_9) {
                        throw new RuntimeException((Throwable)new InvalidProtocolBufferException(var12_9.getMessage()).setUnfinishedMessage((MessageLite)this));
                    }
                    catch (InvalidProtocolBufferException var10_10) {
                        throw new RuntimeException((Throwable)var10_10.setUnfinishedMessage((MessageLite)this));
                    }
                }
                return SystemParameter.DEFAULT_INSTANCE;
            }
            case 6: {
                return SystemParameter.DEFAULT_INSTANCE;
            }
            case 1: {
                var4_11 = (GeneratedMessageLite.Visitor)var2_2;
                var5_12 = (SystemParameter)var3_3;
                this.name_ = var4_11.visitString(true ^ this.name_.isEmpty(), this.name_, true ^ var5_12.name_.isEmpty(), var5_12.name_);
                this.httpHeader_ = var4_11.visitString(true ^ this.httpHeader_.isEmpty(), this.httpHeader_, true ^ var5_12.httpHeader_.isEmpty(), var5_12.httpHeader_);
                this.urlQueryParameter_ = var4_11.visitString(true ^ this.urlQueryParameter_.isEmpty(), this.urlQueryParameter_, true ^ var5_12.urlQueryParameter_.isEmpty(), var5_12.urlQueryParameter_);
                return this;
            }
            case 5: {
                return new Builder(null);
            }
            case 3: {
                return null;
            }
            case 0: {
                return SystemParameter.DEFAULT_INSTANCE;
            }
            case 4: 
        }
        return new SystemParameter();
    }

    public String getHttpHeader() {
        return this.httpHeader_;
    }

    public ByteString getHttpHeaderBytes() {
        return ByteString.copyFromUtf8((String)this.httpHeader_);
    }

    public String getName() {
        return this.name_;
    }

    public ByteString getNameBytes() {
        return ByteString.copyFromUtf8((String)this.name_);
    }

    public int getSerializedSize() {
        int n = this.memoizedSerializedSize;
        if (n != -1) {
            return n;
        }
        boolean bl = this.name_.isEmpty();
        int n2 = 0;
        if (!bl) {
            n2 = 0 + CodedOutputStream.computeStringSize((int)1, (String)this.getName());
        }
        if (!this.httpHeader_.isEmpty()) {
            n2 += CodedOutputStream.computeStringSize((int)2, (String)this.getHttpHeader());
        }
        if (!this.urlQueryParameter_.isEmpty()) {
            n2 += CodedOutputStream.computeStringSize((int)3, (String)this.getUrlQueryParameter());
        }
        this.memoizedSerializedSize = n2;
        return n2;
    }

    public String getUrlQueryParameter() {
        return this.urlQueryParameter_;
    }

    public ByteString getUrlQueryParameterBytes() {
        return ByteString.copyFromUtf8((String)this.urlQueryParameter_);
    }

    public void writeTo(CodedOutputStream codedOutputStream) throws IOException {
        if (!this.name_.isEmpty()) {
            codedOutputStream.writeString(1, this.getName());
        }
        if (!this.httpHeader_.isEmpty()) {
            codedOutputStream.writeString(2, this.getHttpHeader());
        }
        if (!this.urlQueryParameter_.isEmpty()) {
            codedOutputStream.writeString(3, this.getUrlQueryParameter());
        }
    }

    public static final class Builder
    extends GeneratedMessageLite.Builder<SystemParameter, Builder>
    implements SystemParameterOrBuilder {
        private Builder() {
            super((GeneratedMessageLite)DEFAULT_INSTANCE);
        }

        public /* synthetic */ Builder(1 var1_1) {
            this();
        }

        public Builder clearHttpHeader() {
            this.copyOnWrite();
            ((SystemParameter)this.instance).clearHttpHeader();
            return this;
        }

        public Builder clearName() {
            this.copyOnWrite();
            ((SystemParameter)this.instance).clearName();
            return this;
        }

        public Builder clearUrlQueryParameter() {
            this.copyOnWrite();
            ((SystemParameter)this.instance).clearUrlQueryParameter();
            return this;
        }

        public String getHttpHeader() {
            return ((SystemParameter)this.instance).getHttpHeader();
        }

        public ByteString getHttpHeaderBytes() {
            return ((SystemParameter)this.instance).getHttpHeaderBytes();
        }

        public String getName() {
            return ((SystemParameter)this.instance).getName();
        }

        public ByteString getNameBytes() {
            return ((SystemParameter)this.instance).getNameBytes();
        }

        public String getUrlQueryParameter() {
            return ((SystemParameter)this.instance).getUrlQueryParameter();
        }

        public ByteString getUrlQueryParameterBytes() {
            return ((SystemParameter)this.instance).getUrlQueryParameterBytes();
        }

        public Builder setHttpHeader(String string2) {
            this.copyOnWrite();
            ((SystemParameter)this.instance).setHttpHeader(string2);
            return this;
        }

        public Builder setHttpHeaderBytes(ByteString byteString) {
            this.copyOnWrite();
            ((SystemParameter)this.instance).setHttpHeaderBytes(byteString);
            return this;
        }

        public Builder setName(String string2) {
            this.copyOnWrite();
            ((SystemParameter)this.instance).setName(string2);
            return this;
        }

        public Builder setNameBytes(ByteString byteString) {
            this.copyOnWrite();
            ((SystemParameter)this.instance).setNameBytes(byteString);
            return this;
        }

        public Builder setUrlQueryParameter(String string2) {
            this.copyOnWrite();
            ((SystemParameter)this.instance).setUrlQueryParameter(string2);
            return this;
        }

        public Builder setUrlQueryParameterBytes(ByteString byteString) {
            this.copyOnWrite();
            ((SystemParameter)this.instance).setUrlQueryParameterBytes(byteString);
            return this;
        }
    }

}

