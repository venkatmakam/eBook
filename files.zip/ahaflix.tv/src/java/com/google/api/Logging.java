/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.api.Logging$1
 *  com.google.api.Logging$LoggingDestinationOrBuilder
 *  com.google.api.LoggingOrBuilder
 *  com.google.protobuf.AbstractMessageLite
 *  com.google.protobuf.ByteString
 *  com.google.protobuf.CodedInputStream
 *  com.google.protobuf.CodedOutputStream
 *  com.google.protobuf.ExtensionRegistryLite
 *  com.google.protobuf.GeneratedMessageLite
 *  com.google.protobuf.GeneratedMessageLite$Builder
 *  com.google.protobuf.GeneratedMessageLite$DefaultInstanceBasedParser
 *  com.google.protobuf.GeneratedMessageLite$MergeFromVisitor
 *  com.google.protobuf.GeneratedMessageLite$MethodToInvoke
 *  com.google.protobuf.GeneratedMessageLite$Visitor
 *  com.google.protobuf.Internal
 *  com.google.protobuf.Internal$ProtobufList
 *  com.google.protobuf.InvalidProtocolBufferException
 *  com.google.protobuf.MessageLite
 *  com.google.protobuf.Parser
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Class
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 *  java.util.Collections
 *  java.util.List
 *  java.util.Objects
 */
package com.google.api;

import com.google.api.Logging;
import com.google.api.LoggingOrBuilder;
import com.google.protobuf.AbstractMessageLite;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.CodedOutputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.Internal;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.MessageLite;
import com.google.protobuf.Parser;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

public final class Logging
extends GeneratedMessageLite<Logging, Builder>
implements LoggingOrBuilder {
    public static final int CONSUMER_DESTINATIONS_FIELD_NUMBER = 2;
    private static final Logging DEFAULT_INSTANCE;
    private static volatile Parser<Logging> PARSER;
    public static final int PRODUCER_DESTINATIONS_FIELD_NUMBER = 1;
    private Internal.ProtobufList<LoggingDestination> consumerDestinations_ = GeneratedMessageLite.emptyProtobufList();
    private Internal.ProtobufList<LoggingDestination> producerDestinations_ = GeneratedMessageLite.emptyProtobufList();

    public static {
        Logging logging;
        DEFAULT_INSTANCE = logging = new Logging();
        logging.makeImmutable();
    }

    private Logging() {
    }

    private void addAllConsumerDestinations(Iterable<? extends LoggingDestination> iterable) {
        this.ensureConsumerDestinationsIsMutable();
        AbstractMessageLite.addAll(iterable, this.consumerDestinations_);
    }

    private void addAllProducerDestinations(Iterable<? extends LoggingDestination> iterable) {
        this.ensureProducerDestinationsIsMutable();
        AbstractMessageLite.addAll(iterable, this.producerDestinations_);
    }

    private void addConsumerDestinations(int n, LoggingDestination.Builder builder) {
        this.ensureConsumerDestinationsIsMutable();
        this.consumerDestinations_.add(n, (Object)((LoggingDestination)builder.build()));
    }

    private void addConsumerDestinations(int n, LoggingDestination loggingDestination) {
        Objects.requireNonNull((Object)((Object)loggingDestination));
        this.ensureConsumerDestinationsIsMutable();
        this.consumerDestinations_.add(n, (Object)loggingDestination);
    }

    private void addConsumerDestinations(LoggingDestination.Builder builder) {
        this.ensureConsumerDestinationsIsMutable();
        this.consumerDestinations_.add((Object)((LoggingDestination)builder.build()));
    }

    private void addConsumerDestinations(LoggingDestination loggingDestination) {
        Objects.requireNonNull((Object)((Object)loggingDestination));
        this.ensureConsumerDestinationsIsMutable();
        this.consumerDestinations_.add((Object)loggingDestination);
    }

    private void addProducerDestinations(int n, LoggingDestination.Builder builder) {
        this.ensureProducerDestinationsIsMutable();
        this.producerDestinations_.add(n, (Object)((LoggingDestination)builder.build()));
    }

    private void addProducerDestinations(int n, LoggingDestination loggingDestination) {
        Objects.requireNonNull((Object)((Object)loggingDestination));
        this.ensureProducerDestinationsIsMutable();
        this.producerDestinations_.add(n, (Object)loggingDestination);
    }

    private void addProducerDestinations(LoggingDestination.Builder builder) {
        this.ensureProducerDestinationsIsMutable();
        this.producerDestinations_.add((Object)((LoggingDestination)builder.build()));
    }

    private void addProducerDestinations(LoggingDestination loggingDestination) {
        Objects.requireNonNull((Object)((Object)loggingDestination));
        this.ensureProducerDestinationsIsMutable();
        this.producerDestinations_.add((Object)loggingDestination);
    }

    private void clearConsumerDestinations() {
        this.consumerDestinations_ = GeneratedMessageLite.emptyProtobufList();
    }

    private void clearProducerDestinations() {
        this.producerDestinations_ = GeneratedMessageLite.emptyProtobufList();
    }

    private void ensureConsumerDestinationsIsMutable() {
        if (!this.consumerDestinations_.isModifiable()) {
            this.consumerDestinations_ = GeneratedMessageLite.mutableCopy(this.consumerDestinations_);
        }
    }

    private void ensureProducerDestinationsIsMutable() {
        if (!this.producerDestinations_.isModifiable()) {
            this.producerDestinations_ = GeneratedMessageLite.mutableCopy(this.producerDestinations_);
        }
    }

    public static Logging getDefaultInstance() {
        return DEFAULT_INSTANCE;
    }

    public static Builder newBuilder() {
        return (Builder)DEFAULT_INSTANCE.toBuilder();
    }

    public static Builder newBuilder(Logging logging) {
        return (Builder)((Builder)DEFAULT_INSTANCE.toBuilder()).mergeFrom((GeneratedMessageLite)logging);
    }

    public static Logging parseDelimitedFrom(InputStream inputStream) throws IOException {
        return (Logging)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static Logging parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (Logging)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Logging parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
        return (Logging)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString);
    }

    public static Logging parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (Logging)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Logging parseFrom(CodedInputStream codedInputStream) throws IOException {
        return (Logging)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream);
    }

    public static Logging parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (Logging)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Logging parseFrom(InputStream inputStream) throws IOException {
        return (Logging)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static Logging parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (Logging)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Logging parseFrom(byte[] arrby) throws InvalidProtocolBufferException {
        return (Logging)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby);
    }

    public static Logging parseFrom(byte[] arrby, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (Logging)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Parser<Logging> parser() {
        return DEFAULT_INSTANCE.getParserForType();
    }

    private void removeConsumerDestinations(int n) {
        this.ensureConsumerDestinationsIsMutable();
        this.consumerDestinations_.remove(n);
    }

    private void removeProducerDestinations(int n) {
        this.ensureProducerDestinationsIsMutable();
        this.producerDestinations_.remove(n);
    }

    private void setConsumerDestinations(int n, LoggingDestination.Builder builder) {
        this.ensureConsumerDestinationsIsMutable();
        this.consumerDestinations_.set(n, (Object)((LoggingDestination)builder.build()));
    }

    private void setConsumerDestinations(int n, LoggingDestination loggingDestination) {
        Objects.requireNonNull((Object)((Object)loggingDestination));
        this.ensureConsumerDestinationsIsMutable();
        this.consumerDestinations_.set(n, (Object)loggingDestination);
    }

    private void setProducerDestinations(int n, LoggingDestination.Builder builder) {
        this.ensureProducerDestinationsIsMutable();
        this.producerDestinations_.set(n, (Object)((LoggingDestination)builder.build()));
    }

    private void setProducerDestinations(int n, LoggingDestination loggingDestination) {
        Objects.requireNonNull((Object)((Object)loggingDestination));
        this.ensureProducerDestinationsIsMutable();
        this.producerDestinations_.set(n, (Object)loggingDestination);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke var1_1, Object var2_2, Object var3_3) {
        switch (var1_1.ordinal()) {
            default: {
                throw new UnsupportedOperationException();
            }
            case 7: {
                if (Logging.PARSER != null) return Logging.PARSER;
                var17_4 = Logging.class;
                // MONITORENTER : com.google.api.Logging.class
                if (Logging.PARSER == null) {
                    Logging.PARSER = new GeneratedMessageLite.DefaultInstanceBasedParser((GeneratedMessageLite)Logging.DEFAULT_INSTANCE);
                }
                // MONITOREXIT : var17_4
                return Logging.PARSER;
            }
            case 2: {
                var7_5 = (CodedInputStream)var2_2;
                var8_6 = (ExtensionRegistryLite)var3_3;
                var9_7 = false;
                while (var9_7 == false) {
                    var13_8 = var7_5.readTag();
                    if (var13_8 == 0) ** GOTO lbl33
                    if (var13_8 == 10) ** GOTO lbl29
                    if (var13_8 != 18) {
                        if (var7_5.skipField(var13_8)) continue;
                    } else {
                        if (!this.consumerDestinations_.isModifiable()) {
                            this.consumerDestinations_ = GeneratedMessageLite.mutableCopy(this.consumerDestinations_);
                        }
                        this.consumerDestinations_.add((Object)((LoggingDestination)var7_5.readMessage(LoggingDestination.parser(), var8_6)));
                        continue;
lbl29: // 1 sources:
                        if (!this.producerDestinations_.isModifiable()) {
                            this.producerDestinations_ = GeneratedMessageLite.mutableCopy(this.producerDestinations_);
                        }
                        this.producerDestinations_.add((Object)((LoggingDestination)var7_5.readMessage(LoggingDestination.parser(), var8_6)));
                        continue;
                    }
lbl33: // 2 sources:
                    var9_7 = true;
                    continue;
                    catch (IOException var12_10) {
                        throw new RuntimeException((Throwable)new InvalidProtocolBufferException(var12_10.getMessage()).setUnfinishedMessage((MessageLite)this));
                    }
                    catch (InvalidProtocolBufferException var10_11) {
                        throw new RuntimeException((Throwable)var10_11.setUnfinishedMessage((MessageLite)this));
                    }
                }
                return Logging.DEFAULT_INSTANCE;
            }
            case 6: {
                return Logging.DEFAULT_INSTANCE;
            }
            case 1: {
                var4_12 = (GeneratedMessageLite.Visitor)var2_2;
                var5_13 = (Logging)var3_3;
                this.producerDestinations_ = var4_12.visitList(this.producerDestinations_, var5_13.producerDestinations_);
                this.consumerDestinations_ = var4_12.visitList(this.consumerDestinations_, var5_13.consumerDestinations_);
                return this;
            }
            case 5: {
                return new Builder(null);
            }
            case 3: {
                this.producerDestinations_.makeImmutable();
                this.consumerDestinations_.makeImmutable();
                return null;
            }
            case 0: {
                return Logging.DEFAULT_INSTANCE;
            }
            case 4: 
        }
        return new Logging();
    }

    public LoggingDestination getConsumerDestinations(int n) {
        return (LoggingDestination)((Object)this.consumerDestinations_.get(n));
    }

    public int getConsumerDestinationsCount() {
        return this.consumerDestinations_.size();
    }

    public List<LoggingDestination> getConsumerDestinationsList() {
        return this.consumerDestinations_;
    }

    public LoggingDestinationOrBuilder getConsumerDestinationsOrBuilder(int n) {
        return this.consumerDestinations_.get(n);
    }

    public List<? extends LoggingDestinationOrBuilder> getConsumerDestinationsOrBuilderList() {
        return this.consumerDestinations_;
    }

    public LoggingDestination getProducerDestinations(int n) {
        return (LoggingDestination)((Object)this.producerDestinations_.get(n));
    }

    public int getProducerDestinationsCount() {
        return this.producerDestinations_.size();
    }

    public List<LoggingDestination> getProducerDestinationsList() {
        return this.producerDestinations_;
    }

    public LoggingDestinationOrBuilder getProducerDestinationsOrBuilder(int n) {
        return this.producerDestinations_.get(n);
    }

    public List<? extends LoggingDestinationOrBuilder> getProducerDestinationsOrBuilderList() {
        return this.producerDestinations_;
    }

    public int getSerializedSize() {
        int n = this.memoizedSerializedSize;
        if (n != -1) {
            return n;
        }
        int n2 = 0;
        int n3 = 0;
        do {
            int n4 = this.producerDestinations_.size();
            if (n2 >= n4) break;
            n3 += CodedOutputStream.computeMessageSize((int)1, (MessageLite)((MessageLite)this.producerDestinations_.get(n2)));
            ++n2;
        } while (true);
        for (int i = 0; i < this.consumerDestinations_.size(); ++i) {
            n3 += CodedOutputStream.computeMessageSize((int)2, (MessageLite)((MessageLite)this.consumerDestinations_.get(i)));
        }
        this.memoizedSerializedSize = n3;
        return n3;
    }

    public void writeTo(CodedOutputStream codedOutputStream) throws IOException {
        int n = 0;
        do {
            int n2 = this.producerDestinations_.size();
            if (n >= n2) break;
            codedOutputStream.writeMessage(1, (MessageLite)this.producerDestinations_.get(n));
            ++n;
        } while (true);
        for (int i = 0; i < this.consumerDestinations_.size(); ++i) {
            codedOutputStream.writeMessage(2, (MessageLite)this.consumerDestinations_.get(i));
        }
    }

    public static final class Builder
    extends GeneratedMessageLite.Builder<Logging, Builder>
    implements LoggingOrBuilder {
        private Builder() {
            super((GeneratedMessageLite)DEFAULT_INSTANCE);
        }

        public /* synthetic */ Builder(1 var1_1) {
            this();
        }

        public Builder addAllConsumerDestinations(Iterable<? extends LoggingDestination> iterable) {
            this.copyOnWrite();
            ((Logging)this.instance).addAllConsumerDestinations((Iterable<? extends LoggingDestination>)iterable);
            return this;
        }

        public Builder addAllProducerDestinations(Iterable<? extends LoggingDestination> iterable) {
            this.copyOnWrite();
            ((Logging)this.instance).addAllProducerDestinations((Iterable<? extends LoggingDestination>)iterable);
            return this;
        }

        public Builder addConsumerDestinations(int n, LoggingDestination.Builder builder) {
            this.copyOnWrite();
            ((Logging)this.instance).addConsumerDestinations(n, builder);
            return this;
        }

        public Builder addConsumerDestinations(int n, LoggingDestination loggingDestination) {
            this.copyOnWrite();
            ((Logging)this.instance).addConsumerDestinations(n, loggingDestination);
            return this;
        }

        public Builder addConsumerDestinations(LoggingDestination.Builder builder) {
            this.copyOnWrite();
            ((Logging)this.instance).addConsumerDestinations(builder);
            return this;
        }

        public Builder addConsumerDestinations(LoggingDestination loggingDestination) {
            this.copyOnWrite();
            ((Logging)this.instance).addConsumerDestinations(loggingDestination);
            return this;
        }

        public Builder addProducerDestinations(int n, LoggingDestination.Builder builder) {
            this.copyOnWrite();
            ((Logging)this.instance).addProducerDestinations(n, builder);
            return this;
        }

        public Builder addProducerDestinations(int n, LoggingDestination loggingDestination) {
            this.copyOnWrite();
            ((Logging)this.instance).addProducerDestinations(n, loggingDestination);
            return this;
        }

        public Builder addProducerDestinations(LoggingDestination.Builder builder) {
            this.copyOnWrite();
            ((Logging)this.instance).addProducerDestinations(builder);
            return this;
        }

        public Builder addProducerDestinations(LoggingDestination loggingDestination) {
            this.copyOnWrite();
            ((Logging)this.instance).addProducerDestinations(loggingDestination);
            return this;
        }

        public Builder clearConsumerDestinations() {
            this.copyOnWrite();
            ((Logging)this.instance).clearConsumerDestinations();
            return this;
        }

        public Builder clearProducerDestinations() {
            this.copyOnWrite();
            ((Logging)this.instance).clearProducerDestinations();
            return this;
        }

        public LoggingDestination getConsumerDestinations(int n) {
            return ((Logging)this.instance).getConsumerDestinations(n);
        }

        public int getConsumerDestinationsCount() {
            return ((Logging)this.instance).getConsumerDestinationsCount();
        }

        public List<LoggingDestination> getConsumerDestinationsList() {
            return Collections.unmodifiableList(((Logging)this.instance).getConsumerDestinationsList());
        }

        public LoggingDestination getProducerDestinations(int n) {
            return ((Logging)this.instance).getProducerDestinations(n);
        }

        public int getProducerDestinationsCount() {
            return ((Logging)this.instance).getProducerDestinationsCount();
        }

        public List<LoggingDestination> getProducerDestinationsList() {
            return Collections.unmodifiableList(((Logging)this.instance).getProducerDestinationsList());
        }

        public Builder removeConsumerDestinations(int n) {
            this.copyOnWrite();
            ((Logging)this.instance).removeConsumerDestinations(n);
            return this;
        }

        public Builder removeProducerDestinations(int n) {
            this.copyOnWrite();
            ((Logging)this.instance).removeProducerDestinations(n);
            return this;
        }

        public Builder setConsumerDestinations(int n, LoggingDestination.Builder builder) {
            this.copyOnWrite();
            ((Logging)this.instance).setConsumerDestinations(n, builder);
            return this;
        }

        public Builder setConsumerDestinations(int n, LoggingDestination loggingDestination) {
            this.copyOnWrite();
            ((Logging)this.instance).setConsumerDestinations(n, loggingDestination);
            return this;
        }

        public Builder setProducerDestinations(int n, LoggingDestination.Builder builder) {
            this.copyOnWrite();
            ((Logging)this.instance).setProducerDestinations(n, builder);
            return this;
        }

        public Builder setProducerDestinations(int n, LoggingDestination loggingDestination) {
            this.copyOnWrite();
            ((Logging)this.instance).setProducerDestinations(n, loggingDestination);
            return this;
        }
    }

    public static final class LoggingDestination
    extends GeneratedMessageLite<LoggingDestination, Builder>
    implements LoggingDestinationOrBuilder {
        private static final LoggingDestination DEFAULT_INSTANCE;
        public static final int LOGS_FIELD_NUMBER = 1;
        public static final int MONITORED_RESOURCE_FIELD_NUMBER = 3;
        private static volatile Parser<LoggingDestination> PARSER;
        private int bitField0_;
        private Internal.ProtobufList<String> logs_ = GeneratedMessageLite.emptyProtobufList();
        private String monitoredResource_ = "";

        public static {
            LoggingDestination loggingDestination;
            DEFAULT_INSTANCE = loggingDestination = new LoggingDestination();
            loggingDestination.makeImmutable();
        }

        private LoggingDestination() {
        }

        private void addAllLogs(Iterable<String> iterable) {
            this.ensureLogsIsMutable();
            AbstractMessageLite.addAll(iterable, this.logs_);
        }

        private void addLogs(String string2) {
            Objects.requireNonNull((Object)string2);
            this.ensureLogsIsMutable();
            this.logs_.add((Object)string2);
        }

        private void addLogsBytes(ByteString byteString) {
            Objects.requireNonNull((Object)byteString);
            AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
            this.ensureLogsIsMutable();
            this.logs_.add((Object)byteString.toStringUtf8());
        }

        private void clearLogs() {
            this.logs_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearMonitoredResource() {
            this.monitoredResource_ = LoggingDestination.getDefaultInstance().getMonitoredResource();
        }

        private void ensureLogsIsMutable() {
            if (!this.logs_.isModifiable()) {
                this.logs_ = GeneratedMessageLite.mutableCopy(this.logs_);
            }
        }

        public static LoggingDestination getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder)DEFAULT_INSTANCE.toBuilder();
        }

        public static Builder newBuilder(LoggingDestination loggingDestination) {
            return (Builder)((Builder)DEFAULT_INSTANCE.toBuilder()).mergeFrom((GeneratedMessageLite)loggingDestination);
        }

        public static LoggingDestination parseDelimitedFrom(InputStream inputStream) throws IOException {
            return (LoggingDestination)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
        }

        public static LoggingDestination parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return (LoggingDestination)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
        }

        public static LoggingDestination parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
            return (LoggingDestination)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString);
        }

        public static LoggingDestination parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return (LoggingDestination)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString, (ExtensionRegistryLite)extensionRegistryLite);
        }

        public static LoggingDestination parseFrom(CodedInputStream codedInputStream) throws IOException {
            return (LoggingDestination)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream);
        }

        public static LoggingDestination parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return (LoggingDestination)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream, (ExtensionRegistryLite)extensionRegistryLite);
        }

        public static LoggingDestination parseFrom(InputStream inputStream) throws IOException {
            return (LoggingDestination)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
        }

        public static LoggingDestination parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return (LoggingDestination)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
        }

        public static LoggingDestination parseFrom(byte[] arrby) throws InvalidProtocolBufferException {
            return (LoggingDestination)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby);
        }

        public static LoggingDestination parseFrom(byte[] arrby, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return (LoggingDestination)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby, (ExtensionRegistryLite)extensionRegistryLite);
        }

        public static Parser<LoggingDestination> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setLogs(int n, String string2) {
            Objects.requireNonNull((Object)string2);
            this.ensureLogsIsMutable();
            this.logs_.set(n, (Object)string2);
        }

        private void setMonitoredResource(String string2) {
            Objects.requireNonNull((Object)string2);
            this.monitoredResource_ = string2;
        }

        private void setMonitoredResourceBytes(ByteString byteString) {
            Objects.requireNonNull((Object)byteString);
            AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
            this.monitoredResource_ = byteString.toStringUtf8();
        }

        /*
         * Unable to fully structure code
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         * Converted monitor instructions to comments
         * Lifted jumps to return sites
         */
        public final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke var1_1, Object var2_2, Object var3_3) {
            switch (var1_1.ordinal()) {
                default: {
                    throw new UnsupportedOperationException();
                }
                case 7: {
                    if (LoggingDestination.PARSER != null) return LoggingDestination.PARSER;
                    var16_4 = LoggingDestination.class;
                    // MONITORENTER : com.google.api.Logging$LoggingDestination.class
                    if (LoggingDestination.PARSER == null) {
                        LoggingDestination.PARSER = new GeneratedMessageLite.DefaultInstanceBasedParser((GeneratedMessageLite)LoggingDestination.DEFAULT_INSTANCE);
                    }
                    // MONITOREXIT : var16_4
                    return LoggingDestination.PARSER;
                }
                case 2: {
                    var6_5 = (CodedInputStream)var2_2;
                    (ExtensionRegistryLite)var3_3;
                    var8_6 = false;
                    while (var8_6 == false) {
                        var12_7 = var6_5.readTag();
                        if (var12_7 == 0) ** GOTO lbl32
                        if (var12_7 == 10) ** GOTO lbl27
                        if (var12_7 != 26) {
                            if (var6_5.skipField(var12_7)) continue;
                        } else {
                            this.monitoredResource_ = var6_5.readStringRequireUtf8();
                            continue;
lbl27: // 1 sources:
                            var13_8 = var6_5.readStringRequireUtf8();
                            if (!this.logs_.isModifiable()) {
                                this.logs_ = GeneratedMessageLite.mutableCopy(this.logs_);
                            }
                            this.logs_.add((Object)var13_8);
                            continue;
                        }
lbl32: // 2 sources:
                        var8_6 = true;
                        continue;
                        catch (IOException var11_10) {
                            throw new RuntimeException((Throwable)new InvalidProtocolBufferException(var11_10.getMessage()).setUnfinishedMessage((MessageLite)this));
                        }
                        catch (InvalidProtocolBufferException var9_11) {
                            throw new RuntimeException((Throwable)var9_11.setUnfinishedMessage((MessageLite)this));
                        }
                    }
                    return LoggingDestination.DEFAULT_INSTANCE;
                }
                case 6: {
                    return LoggingDestination.DEFAULT_INSTANCE;
                }
                case 1: {
                    var4_12 = (GeneratedMessageLite.Visitor)var2_2;
                    var5_13 = (LoggingDestination)var3_3;
                    this.monitoredResource_ = var4_12.visitString(true ^ this.monitoredResource_.isEmpty(), this.monitoredResource_, true ^ var5_13.monitoredResource_.isEmpty(), var5_13.monitoredResource_);
                    this.logs_ = var4_12.visitList(this.logs_, var5_13.logs_);
                    if (var4_12 != GeneratedMessageLite.MergeFromVisitor.INSTANCE) return this;
                    this.bitField0_ |= var5_13.bitField0_;
                    return this;
                }
                case 5: {
                    return new Builder(null);
                }
                case 3: {
                    this.logs_.makeImmutable();
                    return null;
                }
                case 0: {
                    return LoggingDestination.DEFAULT_INSTANCE;
                }
                case 4: 
            }
            return new LoggingDestination();
        }

        public String getLogs(int n) {
            return (String)this.logs_.get(n);
        }

        public ByteString getLogsBytes(int n) {
            return ByteString.copyFromUtf8((String)((String)this.logs_.get(n)));
        }

        public int getLogsCount() {
            return this.logs_.size();
        }

        public List<String> getLogsList() {
            return this.logs_;
        }

        public String getMonitoredResource() {
            return this.monitoredResource_;
        }

        public ByteString getMonitoredResourceBytes() {
            return ByteString.copyFromUtf8((String)this.monitoredResource_);
        }

        public int getSerializedSize() {
            int n = this.memoizedSerializedSize;
            if (n != -1) {
                return n;
            }
            int n2 = 0;
            for (int i = 0; i < this.logs_.size(); ++i) {
                n2 += CodedOutputStream.computeStringSizeNoTag((String)((String)this.logs_.get(i)));
            }
            int n3 = 0 + n2 + 1 * this.getLogsList().size();
            if (!this.monitoredResource_.isEmpty()) {
                n3 += CodedOutputStream.computeStringSize((int)3, (String)this.getMonitoredResource());
            }
            this.memoizedSerializedSize = n3;
            return n3;
        }

        public void writeTo(CodedOutputStream codedOutputStream) throws IOException {
            for (int i = 0; i < this.logs_.size(); ++i) {
                codedOutputStream.writeString(1, (String)this.logs_.get(i));
            }
            if (!this.monitoredResource_.isEmpty()) {
                codedOutputStream.writeString(3, this.getMonitoredResource());
            }
        }

        public static final class Builder
        extends GeneratedMessageLite.Builder<LoggingDestination, Builder>
        implements LoggingDestinationOrBuilder {
            private Builder() {
                super((GeneratedMessageLite)DEFAULT_INSTANCE);
            }

            public /* synthetic */ Builder(1 var1_1) {
                this();
            }

            public Builder addAllLogs(Iterable<String> iterable) {
                this.copyOnWrite();
                ((LoggingDestination)this.instance).addAllLogs((Iterable<String>)iterable);
                return this;
            }

            public Builder addLogs(String string2) {
                this.copyOnWrite();
                ((LoggingDestination)this.instance).addLogs(string2);
                return this;
            }

            public Builder addLogsBytes(ByteString byteString) {
                this.copyOnWrite();
                ((LoggingDestination)this.instance).addLogsBytes(byteString);
                return this;
            }

            public Builder clearLogs() {
                this.copyOnWrite();
                ((LoggingDestination)this.instance).clearLogs();
                return this;
            }

            public Builder clearMonitoredResource() {
                this.copyOnWrite();
                ((LoggingDestination)this.instance).clearMonitoredResource();
                return this;
            }

            public String getLogs(int n) {
                return ((LoggingDestination)this.instance).getLogs(n);
            }

            public ByteString getLogsBytes(int n) {
                return ((LoggingDestination)this.instance).getLogsBytes(n);
            }

            public int getLogsCount() {
                return ((LoggingDestination)this.instance).getLogsCount();
            }

            public List<String> getLogsList() {
                return Collections.unmodifiableList(((LoggingDestination)this.instance).getLogsList());
            }

            public String getMonitoredResource() {
                return ((LoggingDestination)this.instance).getMonitoredResource();
            }

            public ByteString getMonitoredResourceBytes() {
                return ((LoggingDestination)this.instance).getMonitoredResourceBytes();
            }

            public Builder setLogs(int n, String string2) {
                this.copyOnWrite();
                ((LoggingDestination)this.instance).setLogs(n, string2);
                return this;
            }

            public Builder setMonitoredResource(String string2) {
                this.copyOnWrite();
                ((LoggingDestination)this.instance).setMonitoredResource(string2);
                return this;
            }

            public Builder setMonitoredResourceBytes(ByteString byteString) {
                this.copyOnWrite();
                ((LoggingDestination)this.instance).setMonitoredResourceBytes(byteString);
                return this;
            }
        }

    }

}

