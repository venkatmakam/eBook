/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.api.MetricRuleOrBuilder
 *  com.google.api.Quota$1
 *  com.google.api.QuotaLimitOrBuilder
 *  com.google.api.QuotaOrBuilder
 *  com.google.protobuf.AbstractMessageLite
 *  com.google.protobuf.ByteString
 *  com.google.protobuf.CodedInputStream
 *  com.google.protobuf.CodedOutputStream
 *  com.google.protobuf.ExtensionRegistryLite
 *  com.google.protobuf.GeneratedMessageLite
 *  com.google.protobuf.GeneratedMessageLite$Builder
 *  com.google.protobuf.GeneratedMessageLite$DefaultInstanceBasedParser
 *  com.google.protobuf.GeneratedMessageLite$MethodToInvoke
 *  com.google.protobuf.GeneratedMessageLite$Visitor
 *  com.google.protobuf.Internal
 *  com.google.protobuf.Internal$ProtobufList
 *  com.google.protobuf.InvalidProtocolBufferException
 *  com.google.protobuf.MessageLite
 *  com.google.protobuf.Parser
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Class
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 *  java.util.Collections
 *  java.util.List
 *  java.util.Objects
 */
package com.google.api;

import com.google.api.MetricRule;
import com.google.api.MetricRuleOrBuilder;
import com.google.api.Quota;
import com.google.api.QuotaLimit;
import com.google.api.QuotaLimitOrBuilder;
import com.google.api.QuotaOrBuilder;
import com.google.protobuf.AbstractMessageLite;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.CodedOutputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.Internal;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.MessageLite;
import com.google.protobuf.Parser;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

public final class Quota
extends GeneratedMessageLite<Quota, Builder>
implements QuotaOrBuilder {
    private static final Quota DEFAULT_INSTANCE;
    public static final int LIMITS_FIELD_NUMBER = 3;
    public static final int METRIC_RULES_FIELD_NUMBER = 4;
    private static volatile Parser<Quota> PARSER;
    private Internal.ProtobufList<QuotaLimit> limits_ = GeneratedMessageLite.emptyProtobufList();
    private Internal.ProtobufList<MetricRule> metricRules_ = GeneratedMessageLite.emptyProtobufList();

    public static {
        Quota quota;
        DEFAULT_INSTANCE = quota = new Quota();
        quota.makeImmutable();
    }

    private Quota() {
    }

    private void addAllLimits(Iterable<? extends QuotaLimit> iterable) {
        this.ensureLimitsIsMutable();
        AbstractMessageLite.addAll(iterable, this.limits_);
    }

    private void addAllMetricRules(Iterable<? extends MetricRule> iterable) {
        this.ensureMetricRulesIsMutable();
        AbstractMessageLite.addAll(iterable, this.metricRules_);
    }

    private void addLimits(int n, QuotaLimit.Builder builder) {
        this.ensureLimitsIsMutable();
        this.limits_.add(n, (Object)((QuotaLimit)builder.build()));
    }

    private void addLimits(int n, QuotaLimit quotaLimit) {
        Objects.requireNonNull((Object)((Object)quotaLimit));
        this.ensureLimitsIsMutable();
        this.limits_.add(n, (Object)quotaLimit);
    }

    private void addLimits(QuotaLimit.Builder builder) {
        this.ensureLimitsIsMutable();
        this.limits_.add((Object)((QuotaLimit)builder.build()));
    }

    private void addLimits(QuotaLimit quotaLimit) {
        Objects.requireNonNull((Object)((Object)quotaLimit));
        this.ensureLimitsIsMutable();
        this.limits_.add((Object)quotaLimit);
    }

    private void addMetricRules(int n, MetricRule.Builder builder) {
        this.ensureMetricRulesIsMutable();
        this.metricRules_.add(n, (Object)((MetricRule)builder.build()));
    }

    private void addMetricRules(int n, MetricRule metricRule) {
        Objects.requireNonNull((Object)((Object)metricRule));
        this.ensureMetricRulesIsMutable();
        this.metricRules_.add(n, (Object)metricRule);
    }

    private void addMetricRules(MetricRule.Builder builder) {
        this.ensureMetricRulesIsMutable();
        this.metricRules_.add((Object)((MetricRule)builder.build()));
    }

    private void addMetricRules(MetricRule metricRule) {
        Objects.requireNonNull((Object)((Object)metricRule));
        this.ensureMetricRulesIsMutable();
        this.metricRules_.add((Object)metricRule);
    }

    private void clearLimits() {
        this.limits_ = GeneratedMessageLite.emptyProtobufList();
    }

    private void clearMetricRules() {
        this.metricRules_ = GeneratedMessageLite.emptyProtobufList();
    }

    private void ensureLimitsIsMutable() {
        if (!this.limits_.isModifiable()) {
            this.limits_ = GeneratedMessageLite.mutableCopy(this.limits_);
        }
    }

    private void ensureMetricRulesIsMutable() {
        if (!this.metricRules_.isModifiable()) {
            this.metricRules_ = GeneratedMessageLite.mutableCopy(this.metricRules_);
        }
    }

    public static Quota getDefaultInstance() {
        return DEFAULT_INSTANCE;
    }

    public static Builder newBuilder() {
        return (Builder)DEFAULT_INSTANCE.toBuilder();
    }

    public static Builder newBuilder(Quota quota) {
        return (Builder)((Builder)DEFAULT_INSTANCE.toBuilder()).mergeFrom((GeneratedMessageLite)quota);
    }

    public static Quota parseDelimitedFrom(InputStream inputStream) throws IOException {
        return (Quota)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static Quota parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (Quota)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Quota parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
        return (Quota)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString);
    }

    public static Quota parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (Quota)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Quota parseFrom(CodedInputStream codedInputStream) throws IOException {
        return (Quota)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream);
    }

    public static Quota parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (Quota)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Quota parseFrom(InputStream inputStream) throws IOException {
        return (Quota)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static Quota parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (Quota)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Quota parseFrom(byte[] arrby) throws InvalidProtocolBufferException {
        return (Quota)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby);
    }

    public static Quota parseFrom(byte[] arrby, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (Quota)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Parser<Quota> parser() {
        return DEFAULT_INSTANCE.getParserForType();
    }

    private void removeLimits(int n) {
        this.ensureLimitsIsMutable();
        this.limits_.remove(n);
    }

    private void removeMetricRules(int n) {
        this.ensureMetricRulesIsMutable();
        this.metricRules_.remove(n);
    }

    private void setLimits(int n, QuotaLimit.Builder builder) {
        this.ensureLimitsIsMutable();
        this.limits_.set(n, (Object)((QuotaLimit)builder.build()));
    }

    private void setLimits(int n, QuotaLimit quotaLimit) {
        Objects.requireNonNull((Object)((Object)quotaLimit));
        this.ensureLimitsIsMutable();
        this.limits_.set(n, (Object)quotaLimit);
    }

    private void setMetricRules(int n, MetricRule.Builder builder) {
        this.ensureMetricRulesIsMutable();
        this.metricRules_.set(n, (Object)((MetricRule)builder.build()));
    }

    private void setMetricRules(int n, MetricRule metricRule) {
        Objects.requireNonNull((Object)((Object)metricRule));
        this.ensureMetricRulesIsMutable();
        this.metricRules_.set(n, (Object)metricRule);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke var1_1, Object var2_2, Object var3_3) {
        switch (var1_1.ordinal()) {
            default: {
                throw new UnsupportedOperationException();
            }
            case 7: {
                if (Quota.PARSER != null) return Quota.PARSER;
                var17_4 = Quota.class;
                // MONITORENTER : com.google.api.Quota.class
                if (Quota.PARSER == null) {
                    Quota.PARSER = new GeneratedMessageLite.DefaultInstanceBasedParser((GeneratedMessageLite)Quota.DEFAULT_INSTANCE);
                }
                // MONITOREXIT : var17_4
                return Quota.PARSER;
            }
            case 2: {
                var7_5 = (CodedInputStream)var2_2;
                var8_6 = (ExtensionRegistryLite)var3_3;
                var9_7 = false;
                while (var9_7 == false) {
                    var13_8 = var7_5.readTag();
                    if (var13_8 == 0) ** GOTO lbl33
                    if (var13_8 == 26) ** GOTO lbl29
                    if (var13_8 != 34) {
                        if (var7_5.skipField(var13_8)) continue;
                    } else {
                        if (!this.metricRules_.isModifiable()) {
                            this.metricRules_ = GeneratedMessageLite.mutableCopy(this.metricRules_);
                        }
                        this.metricRules_.add((Object)((MetricRule)var7_5.readMessage(MetricRule.parser(), var8_6)));
                        continue;
lbl29: // 1 sources:
                        if (!this.limits_.isModifiable()) {
                            this.limits_ = GeneratedMessageLite.mutableCopy(this.limits_);
                        }
                        this.limits_.add((Object)((QuotaLimit)var7_5.readMessage(QuotaLimit.parser(), var8_6)));
                        continue;
                    }
lbl33: // 2 sources:
                    var9_7 = true;
                    continue;
                    catch (IOException var12_10) {
                        throw new RuntimeException((Throwable)new InvalidProtocolBufferException(var12_10.getMessage()).setUnfinishedMessage((MessageLite)this));
                    }
                    catch (InvalidProtocolBufferException var10_11) {
                        throw new RuntimeException((Throwable)var10_11.setUnfinishedMessage((MessageLite)this));
                    }
                }
                return Quota.DEFAULT_INSTANCE;
            }
            case 6: {
                return Quota.DEFAULT_INSTANCE;
            }
            case 1: {
                var4_12 = (GeneratedMessageLite.Visitor)var2_2;
                var5_13 = (Quota)var3_3;
                this.limits_ = var4_12.visitList(this.limits_, var5_13.limits_);
                this.metricRules_ = var4_12.visitList(this.metricRules_, var5_13.metricRules_);
                return this;
            }
            case 5: {
                return new Builder(null);
            }
            case 3: {
                this.limits_.makeImmutable();
                this.metricRules_.makeImmutable();
                return null;
            }
            case 0: {
                return Quota.DEFAULT_INSTANCE;
            }
            case 4: 
        }
        return new Quota();
    }

    public QuotaLimit getLimits(int n) {
        return (QuotaLimit)((Object)this.limits_.get(n));
    }

    public int getLimitsCount() {
        return this.limits_.size();
    }

    public List<QuotaLimit> getLimitsList() {
        return this.limits_;
    }

    public QuotaLimitOrBuilder getLimitsOrBuilder(int n) {
        return (QuotaLimitOrBuilder)this.limits_.get(n);
    }

    public List<? extends QuotaLimitOrBuilder> getLimitsOrBuilderList() {
        return this.limits_;
    }

    public MetricRule getMetricRules(int n) {
        return (MetricRule)((Object)this.metricRules_.get(n));
    }

    public int getMetricRulesCount() {
        return this.metricRules_.size();
    }

    public List<MetricRule> getMetricRulesList() {
        return this.metricRules_;
    }

    public MetricRuleOrBuilder getMetricRulesOrBuilder(int n) {
        return (MetricRuleOrBuilder)this.metricRules_.get(n);
    }

    public List<? extends MetricRuleOrBuilder> getMetricRulesOrBuilderList() {
        return this.metricRules_;
    }

    public int getSerializedSize() {
        int n = this.memoizedSerializedSize;
        if (n != -1) {
            return n;
        }
        int n2 = 0;
        int n3 = 0;
        do {
            int n4 = this.limits_.size();
            if (n2 >= n4) break;
            n3 += CodedOutputStream.computeMessageSize((int)3, (MessageLite)((MessageLite)this.limits_.get(n2)));
            ++n2;
        } while (true);
        for (int i = 0; i < this.metricRules_.size(); ++i) {
            n3 += CodedOutputStream.computeMessageSize((int)4, (MessageLite)((MessageLite)this.metricRules_.get(i)));
        }
        this.memoizedSerializedSize = n3;
        return n3;
    }

    public void writeTo(CodedOutputStream codedOutputStream) throws IOException {
        int n = 0;
        do {
            int n2 = this.limits_.size();
            if (n >= n2) break;
            codedOutputStream.writeMessage(3, (MessageLite)this.limits_.get(n));
            ++n;
        } while (true);
        for (int i = 0; i < this.metricRules_.size(); ++i) {
            codedOutputStream.writeMessage(4, (MessageLite)this.metricRules_.get(i));
        }
    }

    public static final class Builder
    extends GeneratedMessageLite.Builder<Quota, Builder>
    implements QuotaOrBuilder {
        private Builder() {
            super((GeneratedMessageLite)DEFAULT_INSTANCE);
        }

        public /* synthetic */ Builder(1 var1_1) {
            this();
        }

        public Builder addAllLimits(Iterable<? extends QuotaLimit> iterable) {
            this.copyOnWrite();
            ((Quota)this.instance).addAllLimits((Iterable<? extends QuotaLimit>)iterable);
            return this;
        }

        public Builder addAllMetricRules(Iterable<? extends MetricRule> iterable) {
            this.copyOnWrite();
            ((Quota)this.instance).addAllMetricRules((Iterable<? extends MetricRule>)iterable);
            return this;
        }

        public Builder addLimits(int n, QuotaLimit.Builder builder) {
            this.copyOnWrite();
            ((Quota)this.instance).addLimits(n, builder);
            return this;
        }

        public Builder addLimits(int n, QuotaLimit quotaLimit) {
            this.copyOnWrite();
            ((Quota)this.instance).addLimits(n, quotaLimit);
            return this;
        }

        public Builder addLimits(QuotaLimit.Builder builder) {
            this.copyOnWrite();
            ((Quota)this.instance).addLimits(builder);
            return this;
        }

        public Builder addLimits(QuotaLimit quotaLimit) {
            this.copyOnWrite();
            ((Quota)this.instance).addLimits(quotaLimit);
            return this;
        }

        public Builder addMetricRules(int n, MetricRule.Builder builder) {
            this.copyOnWrite();
            ((Quota)this.instance).addMetricRules(n, builder);
            return this;
        }

        public Builder addMetricRules(int n, MetricRule metricRule) {
            this.copyOnWrite();
            ((Quota)this.instance).addMetricRules(n, metricRule);
            return this;
        }

        public Builder addMetricRules(MetricRule.Builder builder) {
            this.copyOnWrite();
            ((Quota)this.instance).addMetricRules(builder);
            return this;
        }

        public Builder addMetricRules(MetricRule metricRule) {
            this.copyOnWrite();
            ((Quota)this.instance).addMetricRules(metricRule);
            return this;
        }

        public Builder clearLimits() {
            this.copyOnWrite();
            ((Quota)this.instance).clearLimits();
            return this;
        }

        public Builder clearMetricRules() {
            this.copyOnWrite();
            ((Quota)this.instance).clearMetricRules();
            return this;
        }

        public QuotaLimit getLimits(int n) {
            return ((Quota)this.instance).getLimits(n);
        }

        public int getLimitsCount() {
            return ((Quota)this.instance).getLimitsCount();
        }

        public List<QuotaLimit> getLimitsList() {
            return Collections.unmodifiableList(((Quota)this.instance).getLimitsList());
        }

        public MetricRule getMetricRules(int n) {
            return ((Quota)this.instance).getMetricRules(n);
        }

        public int getMetricRulesCount() {
            return ((Quota)this.instance).getMetricRulesCount();
        }

        public List<MetricRule> getMetricRulesList() {
            return Collections.unmodifiableList(((Quota)this.instance).getMetricRulesList());
        }

        public Builder removeLimits(int n) {
            this.copyOnWrite();
            ((Quota)this.instance).removeLimits(n);
            return this;
        }

        public Builder removeMetricRules(int n) {
            this.copyOnWrite();
            ((Quota)this.instance).removeMetricRules(n);
            return this;
        }

        public Builder setLimits(int n, QuotaLimit.Builder builder) {
            this.copyOnWrite();
            ((Quota)this.instance).setLimits(n, builder);
            return this;
        }

        public Builder setLimits(int n, QuotaLimit quotaLimit) {
            this.copyOnWrite();
            ((Quota)this.instance).setLimits(n, quotaLimit);
            return this;
        }

        public Builder setMetricRules(int n, MetricRule.Builder builder) {
            this.copyOnWrite();
            ((Quota)this.instance).setMetricRules(n, builder);
            return this;
        }

        public Builder setMetricRules(int n, MetricRule metricRule) {
            this.copyOnWrite();
            ((Quota)this.instance).setMetricRules(n, metricRule);
            return this;
        }
    }

}

