/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.api.UsageRule$1
 *  com.google.api.UsageRuleOrBuilder
 *  com.google.protobuf.AbstractMessageLite
 *  com.google.protobuf.ByteString
 *  com.google.protobuf.CodedInputStream
 *  com.google.protobuf.CodedOutputStream
 *  com.google.protobuf.ExtensionRegistryLite
 *  com.google.protobuf.GeneratedMessageLite
 *  com.google.protobuf.GeneratedMessageLite$Builder
 *  com.google.protobuf.GeneratedMessageLite$DefaultInstanceBasedParser
 *  com.google.protobuf.GeneratedMessageLite$MethodToInvoke
 *  com.google.protobuf.GeneratedMessageLite$Visitor
 *  com.google.protobuf.InvalidProtocolBufferException
 *  com.google.protobuf.MessageLite
 *  com.google.protobuf.Parser
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 *  java.util.Objects
 */
package com.google.api;

import com.google.api.UsageRule;
import com.google.api.UsageRuleOrBuilder;
import com.google.protobuf.AbstractMessageLite;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.CodedOutputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.MessageLite;
import com.google.protobuf.Parser;
import java.io.IOException;
import java.io.InputStream;
import java.util.Objects;

public final class UsageRule
extends GeneratedMessageLite<UsageRule, Builder>
implements UsageRuleOrBuilder {
    public static final int ALLOW_UNREGISTERED_CALLS_FIELD_NUMBER = 2;
    private static final UsageRule DEFAULT_INSTANCE;
    private static volatile Parser<UsageRule> PARSER;
    public static final int SELECTOR_FIELD_NUMBER = 1;
    public static final int SKIP_SERVICE_CONTROL_FIELD_NUMBER = 3;
    private boolean allowUnregisteredCalls_;
    private String selector_ = "";
    private boolean skipServiceControl_;

    public static {
        UsageRule usageRule;
        DEFAULT_INSTANCE = usageRule = new UsageRule();
        usageRule.makeImmutable();
    }

    private UsageRule() {
    }

    private void clearAllowUnregisteredCalls() {
        this.allowUnregisteredCalls_ = false;
    }

    private void clearSelector() {
        this.selector_ = UsageRule.getDefaultInstance().getSelector();
    }

    private void clearSkipServiceControl() {
        this.skipServiceControl_ = false;
    }

    public static UsageRule getDefaultInstance() {
        return DEFAULT_INSTANCE;
    }

    public static Builder newBuilder() {
        return (Builder)DEFAULT_INSTANCE.toBuilder();
    }

    public static Builder newBuilder(UsageRule usageRule) {
        return (Builder)((Builder)DEFAULT_INSTANCE.toBuilder()).mergeFrom((GeneratedMessageLite)usageRule);
    }

    public static UsageRule parseDelimitedFrom(InputStream inputStream) throws IOException {
        return (UsageRule)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static UsageRule parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (UsageRule)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static UsageRule parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
        return (UsageRule)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString);
    }

    public static UsageRule parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (UsageRule)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static UsageRule parseFrom(CodedInputStream codedInputStream) throws IOException {
        return (UsageRule)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream);
    }

    public static UsageRule parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (UsageRule)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static UsageRule parseFrom(InputStream inputStream) throws IOException {
        return (UsageRule)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static UsageRule parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (UsageRule)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static UsageRule parseFrom(byte[] arrby) throws InvalidProtocolBufferException {
        return (UsageRule)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby);
    }

    public static UsageRule parseFrom(byte[] arrby, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (UsageRule)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Parser<UsageRule> parser() {
        return DEFAULT_INSTANCE.getParserForType();
    }

    private void setAllowUnregisteredCalls(boolean bl) {
        this.allowUnregisteredCalls_ = bl;
    }

    private void setSelector(String string2) {
        Objects.requireNonNull((Object)string2);
        this.selector_ = string2;
    }

    private void setSelectorBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.selector_ = byteString.toStringUtf8();
    }

    private void setSkipServiceControl(boolean bl) {
        this.skipServiceControl_ = bl;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke var1_1, Object var2_2, Object var3_3) {
        switch (var1_1.ordinal()) {
            default: {
                throw new UnsupportedOperationException();
            }
            case 7: {
                if (UsageRule.PARSER != null) return UsageRule.PARSER;
                var19_4 = UsageRule.class;
                // MONITORENTER : com.google.api.UsageRule.class
                if (UsageRule.PARSER == null) {
                    UsageRule.PARSER = new GeneratedMessageLite.DefaultInstanceBasedParser((GeneratedMessageLite)UsageRule.DEFAULT_INSTANCE);
                }
                // MONITOREXIT : var19_4
                return UsageRule.PARSER;
            }
            case 2: {
                var11_5 = (CodedInputStream)var2_2;
                (ExtensionRegistryLite)var3_3;
                var13_6 = false;
                while (var13_6 == false) {
                    var17_7 = var11_5.readTag();
                    if (var17_7 == 0) ** GOTO lbl32
                    if (var17_7 == 10) ** GOTO lbl30
                    if (var17_7 == 16) ** GOTO lbl28
                    if (var17_7 != 24) {
                        if (var11_5.skipField(var17_7)) continue;
                    } else {
                        this.skipServiceControl_ = var11_5.readBool();
                        continue;
lbl28: // 1 sources:
                        this.allowUnregisteredCalls_ = var11_5.readBool();
                        continue;
lbl30: // 1 sources:
                        this.selector_ = var11_5.readStringRequireUtf8();
                        continue;
                    }
lbl32: // 2 sources:
                    var13_6 = true;
                    continue;
                    catch (IOException var16_9) {
                        throw new RuntimeException((Throwable)new InvalidProtocolBufferException(var16_9.getMessage()).setUnfinishedMessage((MessageLite)this));
                    }
                    catch (InvalidProtocolBufferException var14_10) {
                        throw new RuntimeException((Throwable)var14_10.setUnfinishedMessage((MessageLite)this));
                    }
                }
                return UsageRule.DEFAULT_INSTANCE;
            }
            case 6: {
                return UsageRule.DEFAULT_INSTANCE;
            }
            case 1: {
                var4_11 = (GeneratedMessageLite.Visitor)var2_2;
                var5_12 = (UsageRule)var3_3;
                this.selector_ = var4_11.visitString(true ^ this.selector_.isEmpty(), this.selector_, true ^ var5_12.selector_.isEmpty(), var5_12.selector_);
                var6_13 = this.allowUnregisteredCalls_;
                var7_14 = var5_12.allowUnregisteredCalls_;
                this.allowUnregisteredCalls_ = var4_11.visitBoolean(var6_13, var6_13, var7_14, var7_14);
                var8_15 = this.skipServiceControl_;
                var9_16 = var5_12.skipServiceControl_;
                this.skipServiceControl_ = var4_11.visitBoolean(var8_15, var8_15, var9_16, var9_16);
                return this;
            }
            case 5: {
                return new Builder(null);
            }
            case 3: {
                return null;
            }
            case 0: {
                return UsageRule.DEFAULT_INSTANCE;
            }
            case 4: 
        }
        return new UsageRule();
    }

    public boolean getAllowUnregisteredCalls() {
        return this.allowUnregisteredCalls_;
    }

    public String getSelector() {
        return this.selector_;
    }

    public ByteString getSelectorBytes() {
        return ByteString.copyFromUtf8((String)this.selector_);
    }

    public int getSerializedSize() {
        boolean bl;
        boolean bl2;
        int n = this.memoizedSerializedSize;
        if (n != -1) {
            return n;
        }
        boolean bl3 = this.selector_.isEmpty();
        int n2 = 0;
        if (!bl3) {
            n2 = 0 + CodedOutputStream.computeStringSize((int)1, (String)this.getSelector());
        }
        if (bl2 = this.allowUnregisteredCalls_) {
            n2 += CodedOutputStream.computeBoolSize((int)2, (boolean)bl2);
        }
        if (bl = this.skipServiceControl_) {
            n2 += CodedOutputStream.computeBoolSize((int)3, (boolean)bl);
        }
        this.memoizedSerializedSize = n2;
        return n2;
    }

    public boolean getSkipServiceControl() {
        return this.skipServiceControl_;
    }

    public void writeTo(CodedOutputStream codedOutputStream) throws IOException {
        boolean bl;
        boolean bl2;
        if (!this.selector_.isEmpty()) {
            codedOutputStream.writeString(1, this.getSelector());
        }
        if (bl = this.allowUnregisteredCalls_) {
            codedOutputStream.writeBool(2, bl);
        }
        if (bl2 = this.skipServiceControl_) {
            codedOutputStream.writeBool(3, bl2);
        }
    }

    public static final class Builder
    extends GeneratedMessageLite.Builder<UsageRule, Builder>
    implements UsageRuleOrBuilder {
        private Builder() {
            super((GeneratedMessageLite)DEFAULT_INSTANCE);
        }

        public /* synthetic */ Builder(1 var1_1) {
            this();
        }

        public Builder clearAllowUnregisteredCalls() {
            this.copyOnWrite();
            ((UsageRule)this.instance).clearAllowUnregisteredCalls();
            return this;
        }

        public Builder clearSelector() {
            this.copyOnWrite();
            ((UsageRule)this.instance).clearSelector();
            return this;
        }

        public Builder clearSkipServiceControl() {
            this.copyOnWrite();
            ((UsageRule)this.instance).clearSkipServiceControl();
            return this;
        }

        public boolean getAllowUnregisteredCalls() {
            return ((UsageRule)this.instance).getAllowUnregisteredCalls();
        }

        public String getSelector() {
            return ((UsageRule)this.instance).getSelector();
        }

        public ByteString getSelectorBytes() {
            return ((UsageRule)this.instance).getSelectorBytes();
        }

        public boolean getSkipServiceControl() {
            return ((UsageRule)this.instance).getSkipServiceControl();
        }

        public Builder setAllowUnregisteredCalls(boolean bl) {
            this.copyOnWrite();
            ((UsageRule)this.instance).setAllowUnregisteredCalls(bl);
            return this;
        }

        public Builder setSelector(String string2) {
            this.copyOnWrite();
            ((UsageRule)this.instance).setSelector(string2);
            return this;
        }

        public Builder setSelectorBytes(ByteString byteString) {
            this.copyOnWrite();
            ((UsageRule)this.instance).setSelectorBytes(byteString);
            return this;
        }

        public Builder setSkipServiceControl(boolean bl) {
            this.copyOnWrite();
            ((UsageRule)this.instance).setSkipServiceControl(bl);
            return this;
        }
    }

}

