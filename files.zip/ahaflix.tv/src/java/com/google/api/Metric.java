/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.api.Metric$1
 *  com.google.api.Metric$LabelsDefaultEntryHolder
 *  com.google.api.MetricOrBuilder
 *  com.google.protobuf.AbstractMessageLite
 *  com.google.protobuf.ByteString
 *  com.google.protobuf.CodedInputStream
 *  com.google.protobuf.CodedOutputStream
 *  com.google.protobuf.ExtensionRegistryLite
 *  com.google.protobuf.GeneratedMessageLite
 *  com.google.protobuf.GeneratedMessageLite$Builder
 *  com.google.protobuf.GeneratedMessageLite$DefaultInstanceBasedParser
 *  com.google.protobuf.GeneratedMessageLite$MergeFromVisitor
 *  com.google.protobuf.GeneratedMessageLite$MethodToInvoke
 *  com.google.protobuf.GeneratedMessageLite$Visitor
 *  com.google.protobuf.InvalidProtocolBufferException
 *  com.google.protobuf.MapEntryLite
 *  com.google.protobuf.MapFieldLite
 *  com.google.protobuf.MessageLite
 *  com.google.protobuf.Parser
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Class
 *  java.lang.Deprecated
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 *  java.util.Collections
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Objects
 *  java.util.Set
 */
package com.google.api;

import com.google.api.Metric;
import com.google.api.MetricOrBuilder;
import com.google.protobuf.AbstractMessageLite;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.CodedOutputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.MapEntryLite;
import com.google.protobuf.MapFieldLite;
import com.google.protobuf.MessageLite;
import com.google.protobuf.Parser;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

public final class Metric
extends GeneratedMessageLite<Metric, Builder>
implements MetricOrBuilder {
    private static final Metric DEFAULT_INSTANCE;
    public static final int LABELS_FIELD_NUMBER = 2;
    private static volatile Parser<Metric> PARSER;
    public static final int TYPE_FIELD_NUMBER = 3;
    private int bitField0_;
    private MapFieldLite<String, String> labels_ = MapFieldLite.emptyMapField();
    private String type_ = "";

    public static {
        Metric metric;
        DEFAULT_INSTANCE = metric = new Metric();
        metric.makeImmutable();
    }

    private Metric() {
    }

    private void clearType() {
        this.type_ = Metric.getDefaultInstance().getType();
    }

    public static Metric getDefaultInstance() {
        return DEFAULT_INSTANCE;
    }

    private Map<String, String> getMutableLabelsMap() {
        return this.internalGetMutableLabels();
    }

    private MapFieldLite<String, String> internalGetLabels() {
        return this.labels_;
    }

    private MapFieldLite<String, String> internalGetMutableLabels() {
        if (!this.labels_.isMutable()) {
            this.labels_ = this.labels_.mutableCopy();
        }
        return this.labels_;
    }

    public static Builder newBuilder() {
        return (Builder)DEFAULT_INSTANCE.toBuilder();
    }

    public static Builder newBuilder(Metric metric) {
        return (Builder)((Builder)DEFAULT_INSTANCE.toBuilder()).mergeFrom((GeneratedMessageLite)metric);
    }

    public static Metric parseDelimitedFrom(InputStream inputStream) throws IOException {
        return (Metric)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static Metric parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (Metric)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Metric parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
        return (Metric)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString);
    }

    public static Metric parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (Metric)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Metric parseFrom(CodedInputStream codedInputStream) throws IOException {
        return (Metric)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream);
    }

    public static Metric parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (Metric)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Metric parseFrom(InputStream inputStream) throws IOException {
        return (Metric)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static Metric parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (Metric)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Metric parseFrom(byte[] arrby) throws InvalidProtocolBufferException {
        return (Metric)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby);
    }

    public static Metric parseFrom(byte[] arrby, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (Metric)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Parser<Metric> parser() {
        return DEFAULT_INSTANCE.getParserForType();
    }

    private void setType(String string2) {
        Objects.requireNonNull((Object)string2);
        this.type_ = string2;
    }

    private void setTypeBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.type_ = byteString.toStringUtf8();
    }

    public boolean containsLabels(String string2) {
        Objects.requireNonNull((Object)string2);
        return this.internalGetLabels().containsKey((Object)string2);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke var1_1, Object var2_2, Object var3_3) {
        switch (var1_1.ordinal()) {
            default: {
                throw new UnsupportedOperationException();
            }
            case 7: {
                if (Metric.PARSER != null) return Metric.PARSER;
                var14_4 = Metric.class;
                // MONITORENTER : com.google.api.Metric.class
                if (Metric.PARSER == null) {
                    Metric.PARSER = new GeneratedMessageLite.DefaultInstanceBasedParser((GeneratedMessageLite)Metric.DEFAULT_INSTANCE);
                }
                // MONITOREXIT : var14_4
                return Metric.PARSER;
            }
            case 2: {
                var6_5 = (CodedInputStream)var2_2;
                var7_6 = (ExtensionRegistryLite)var3_3;
                var8_7 = false;
                while (var8_7 == false) {
                    var12_8 = var6_5.readTag();
                    if (var12_8 == 0) ** GOTO lbl31
                    if (var12_8 == 18) ** GOTO lbl27
                    if (var12_8 != 26) {
                        if (var6_5.skipField(var12_8)) continue;
                    } else {
                        this.type_ = var6_5.readStringRequireUtf8();
                        continue;
lbl27: // 1 sources:
                        if (!this.labels_.isMutable()) {
                            this.labels_ = this.labels_.mutableCopy();
                        }
                        LabelsDefaultEntryHolder.defaultEntry.parseInto(this.labels_, var6_5, var7_6);
                        continue;
                    }
lbl31: // 2 sources:
                    var8_7 = true;
                    continue;
                    catch (IOException var11_10) {
                        throw new RuntimeException((Throwable)new InvalidProtocolBufferException(var11_10.getMessage()).setUnfinishedMessage((MessageLite)this));
                    }
                    catch (InvalidProtocolBufferException var9_11) {
                        throw new RuntimeException((Throwable)var9_11.setUnfinishedMessage((MessageLite)this));
                    }
                }
                return Metric.DEFAULT_INSTANCE;
            }
            case 6: {
                return Metric.DEFAULT_INSTANCE;
            }
            case 1: {
                var4_12 = (GeneratedMessageLite.Visitor)var2_2;
                var5_13 = (Metric)var3_3;
                this.type_ = var4_12.visitString(true ^ this.type_.isEmpty(), this.type_, true ^ var5_13.type_.isEmpty(), var5_13.type_);
                this.labels_ = var4_12.visitMap(this.labels_, var5_13.internalGetLabels());
                if (var4_12 != GeneratedMessageLite.MergeFromVisitor.INSTANCE) return this;
                this.bitField0_ |= var5_13.bitField0_;
                return this;
            }
            case 5: {
                return new Builder(null);
            }
            case 3: {
                this.labels_.makeImmutable();
                return null;
            }
            case 0: {
                return Metric.DEFAULT_INSTANCE;
            }
            case 4: 
        }
        return new Metric();
    }

    @Deprecated
    public Map<String, String> getLabels() {
        return this.getLabelsMap();
    }

    public int getLabelsCount() {
        return this.internalGetLabels().size();
    }

    public Map<String, String> getLabelsMap() {
        return Collections.unmodifiableMap(this.internalGetLabels());
    }

    public String getLabelsOrDefault(String string2, String string3) {
        Objects.requireNonNull((Object)string2);
        MapFieldLite<String, String> mapFieldLite = this.internalGetLabels();
        if (mapFieldLite.containsKey((Object)string2)) {
            string3 = (String)mapFieldLite.get((Object)string2);
        }
        return string3;
    }

    public String getLabelsOrThrow(String string2) {
        Objects.requireNonNull((Object)string2);
        MapFieldLite<String, String> mapFieldLite = this.internalGetLabels();
        if (mapFieldLite.containsKey((Object)string2)) {
            return (String)mapFieldLite.get((Object)string2);
        }
        throw new IllegalArgumentException();
    }

    public int getSerializedSize() {
        int n = this.memoizedSerializedSize;
        if (n != -1) {
            return n;
        }
        int n2 = 0;
        for (Map.Entry entry : this.internalGetLabels().entrySet()) {
            n2 += LabelsDefaultEntryHolder.defaultEntry.computeMessageSize(2, (Object)((String)entry.getKey()), (Object)((String)entry.getValue()));
        }
        if (!this.type_.isEmpty()) {
            n2 += CodedOutputStream.computeStringSize((int)3, (String)this.getType());
        }
        this.memoizedSerializedSize = n2;
        return n2;
    }

    public String getType() {
        return this.type_;
    }

    public ByteString getTypeBytes() {
        return ByteString.copyFromUtf8((String)this.type_);
    }

    public void writeTo(CodedOutputStream codedOutputStream) throws IOException {
        for (Map.Entry entry : this.internalGetLabels().entrySet()) {
            LabelsDefaultEntryHolder.defaultEntry.serializeTo(codedOutputStream, 2, (Object)((String)entry.getKey()), (Object)((String)entry.getValue()));
        }
        if (!this.type_.isEmpty()) {
            codedOutputStream.writeString(3, this.getType());
        }
    }

    public static final class Builder
    extends GeneratedMessageLite.Builder<Metric, Builder>
    implements MetricOrBuilder {
        private Builder() {
            super((GeneratedMessageLite)DEFAULT_INSTANCE);
        }

        public /* synthetic */ Builder(1 var1_1) {
            this();
        }

        public Builder clearLabels() {
            this.copyOnWrite();
            ((Metric)this.instance).getMutableLabelsMap().clear();
            return this;
        }

        public Builder clearType() {
            this.copyOnWrite();
            ((Metric)this.instance).clearType();
            return this;
        }

        public boolean containsLabels(String string2) {
            Objects.requireNonNull((Object)string2);
            return ((Metric)this.instance).getLabelsMap().containsKey((Object)string2);
        }

        @Deprecated
        public Map<String, String> getLabels() {
            return this.getLabelsMap();
        }

        public int getLabelsCount() {
            return ((Metric)this.instance).getLabelsMap().size();
        }

        public Map<String, String> getLabelsMap() {
            return Collections.unmodifiableMap(((Metric)this.instance).getLabelsMap());
        }

        public String getLabelsOrDefault(String string2, String string3) {
            Objects.requireNonNull((Object)string2);
            Map<String, String> map = ((Metric)this.instance).getLabelsMap();
            if (map.containsKey((Object)string2)) {
                string3 = (String)map.get((Object)string2);
            }
            return string3;
        }

        public String getLabelsOrThrow(String string2) {
            Objects.requireNonNull((Object)string2);
            Map<String, String> map = ((Metric)this.instance).getLabelsMap();
            if (map.containsKey((Object)string2)) {
                return (String)map.get((Object)string2);
            }
            throw new IllegalArgumentException();
        }

        public String getType() {
            return ((Metric)this.instance).getType();
        }

        public ByteString getTypeBytes() {
            return ((Metric)this.instance).getTypeBytes();
        }

        public Builder putAllLabels(Map<String, String> map) {
            this.copyOnWrite();
            ((Metric)this.instance).getMutableLabelsMap().putAll(map);
            return this;
        }

        public Builder putLabels(String string2, String string3) {
            Objects.requireNonNull((Object)string2);
            Objects.requireNonNull((Object)string3);
            this.copyOnWrite();
            ((Metric)this.instance).getMutableLabelsMap().put((Object)string2, (Object)string3);
            return this;
        }

        public Builder removeLabels(String string2) {
            Objects.requireNonNull((Object)string2);
            this.copyOnWrite();
            ((Metric)this.instance).getMutableLabelsMap().remove((Object)string2);
            return this;
        }

        public Builder setType(String string2) {
            this.copyOnWrite();
            ((Metric)this.instance).setType(string2);
            return this;
        }

        public Builder setTypeBytes(ByteString byteString) {
            this.copyOnWrite();
            ((Metric)this.instance).setTypeBytes(byteString);
            return this;
        }
    }

}

