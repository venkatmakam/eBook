/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.protobuf.AbstractMessageLite
 *  com.google.protobuf.ByteString
 *  com.google.protobuf.CodedInputStream
 *  com.google.protobuf.CodedOutputStream
 *  com.google.protobuf.ExtensionRegistryLite
 *  com.google.protobuf.GeneratedMessageLite
 *  com.google.protobuf.GeneratedMessageLite$Builder
 *  com.google.protobuf.GeneratedMessageLite$DefaultInstanceBasedParser
 *  com.google.protobuf.GeneratedMessageLite$MergeFromVisitor
 *  com.google.protobuf.GeneratedMessageLite$MethodToInvoke
 *  com.google.protobuf.GeneratedMessageLite$Visitor
 *  com.google.protobuf.Internal
 *  com.google.protobuf.Internal$ProtobufList
 *  com.google.protobuf.InvalidProtocolBufferException
 *  com.google.protobuf.MessageLite
 *  com.google.protobuf.Parser
 *  com.google.rpc.DebugInfo$1
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Class
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 *  java.util.Collections
 *  java.util.List
 *  java.util.Objects
 */
package com.google.rpc;

import com.google.protobuf.AbstractMessageLite;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.CodedOutputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.Internal;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.MessageLite;
import com.google.protobuf.Parser;
import com.google.rpc.DebugInfo;
import com.google.rpc.DebugInfoOrBuilder;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

public final class DebugInfo
extends GeneratedMessageLite<DebugInfo, Builder>
implements DebugInfoOrBuilder {
    private static final DebugInfo DEFAULT_INSTANCE;
    public static final int DETAIL_FIELD_NUMBER = 2;
    private static volatile Parser<DebugInfo> PARSER;
    public static final int STACK_ENTRIES_FIELD_NUMBER = 1;
    private int bitField0_;
    private String detail_ = "";
    private Internal.ProtobufList<String> stackEntries_ = GeneratedMessageLite.emptyProtobufList();

    public static {
        DebugInfo debugInfo;
        DEFAULT_INSTANCE = debugInfo = new DebugInfo();
        debugInfo.makeImmutable();
    }

    private DebugInfo() {
    }

    private void addAllStackEntries(Iterable<String> iterable) {
        this.ensureStackEntriesIsMutable();
        AbstractMessageLite.addAll(iterable, this.stackEntries_);
    }

    private void addStackEntries(String string) {
        Objects.requireNonNull((Object)string);
        this.ensureStackEntriesIsMutable();
        this.stackEntries_.add((Object)string);
    }

    private void addStackEntriesBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.ensureStackEntriesIsMutable();
        this.stackEntries_.add((Object)byteString.toStringUtf8());
    }

    private void clearDetail() {
        this.detail_ = DebugInfo.getDefaultInstance().getDetail();
    }

    private void clearStackEntries() {
        this.stackEntries_ = GeneratedMessageLite.emptyProtobufList();
    }

    private void ensureStackEntriesIsMutable() {
        if (!this.stackEntries_.isModifiable()) {
            this.stackEntries_ = GeneratedMessageLite.mutableCopy(this.stackEntries_);
        }
    }

    public static DebugInfo getDefaultInstance() {
        return DEFAULT_INSTANCE;
    }

    public static Builder newBuilder() {
        return (Builder)DEFAULT_INSTANCE.toBuilder();
    }

    public static Builder newBuilder(DebugInfo debugInfo) {
        return (Builder)((Builder)DEFAULT_INSTANCE.toBuilder()).mergeFrom((GeneratedMessageLite)debugInfo);
    }

    public static DebugInfo parseDelimitedFrom(InputStream inputStream) throws IOException {
        return (DebugInfo)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static DebugInfo parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (DebugInfo)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static DebugInfo parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
        return (DebugInfo)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString);
    }

    public static DebugInfo parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (DebugInfo)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static DebugInfo parseFrom(CodedInputStream codedInputStream) throws IOException {
        return (DebugInfo)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream);
    }

    public static DebugInfo parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (DebugInfo)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static DebugInfo parseFrom(InputStream inputStream) throws IOException {
        return (DebugInfo)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static DebugInfo parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (DebugInfo)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static DebugInfo parseFrom(byte[] arrby) throws InvalidProtocolBufferException {
        return (DebugInfo)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby);
    }

    public static DebugInfo parseFrom(byte[] arrby, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (DebugInfo)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Parser<DebugInfo> parser() {
        return DEFAULT_INSTANCE.getParserForType();
    }

    private void setDetail(String string) {
        Objects.requireNonNull((Object)string);
        this.detail_ = string;
    }

    private void setDetailBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.detail_ = byteString.toStringUtf8();
    }

    private void setStackEntries(int n, String string) {
        Objects.requireNonNull((Object)string);
        this.ensureStackEntriesIsMutable();
        this.stackEntries_.set(n, (Object)string);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke var1_1, Object var2_2, Object var3_3) {
        switch (var1_1.ordinal()) {
            default: {
                throw new UnsupportedOperationException();
            }
            case 7: {
                if (DebugInfo.PARSER != null) return DebugInfo.PARSER;
                var16_4 = DebugInfo.class;
                // MONITORENTER : com.google.rpc.DebugInfo.class
                if (DebugInfo.PARSER == null) {
                    DebugInfo.PARSER = new GeneratedMessageLite.DefaultInstanceBasedParser((GeneratedMessageLite)DebugInfo.DEFAULT_INSTANCE);
                }
                // MONITOREXIT : var16_4
                return DebugInfo.PARSER;
            }
            case 2: {
                var6_5 = (CodedInputStream)var2_2;
                (ExtensionRegistryLite)var3_3;
                var8_6 = false;
                while (var8_6 == false) {
                    var12_7 = var6_5.readTag();
                    if (var12_7 == 0) ** GOTO lbl32
                    if (var12_7 == 10) ** GOTO lbl27
                    if (var12_7 != 18) {
                        if (var6_5.skipField(var12_7)) continue;
                    } else {
                        this.detail_ = var6_5.readStringRequireUtf8();
                        continue;
lbl27: // 1 sources:
                        var13_8 = var6_5.readStringRequireUtf8();
                        if (!this.stackEntries_.isModifiable()) {
                            this.stackEntries_ = GeneratedMessageLite.mutableCopy(this.stackEntries_);
                        }
                        this.stackEntries_.add((Object)var13_8);
                        continue;
                    }
lbl32: // 2 sources:
                    var8_6 = true;
                    continue;
                    catch (IOException var11_10) {
                        throw new RuntimeException((Throwable)new InvalidProtocolBufferException(var11_10.getMessage()).setUnfinishedMessage((MessageLite)this));
                    }
                    catch (InvalidProtocolBufferException var9_11) {
                        throw new RuntimeException((Throwable)var9_11.setUnfinishedMessage((MessageLite)this));
                    }
                }
                return DebugInfo.DEFAULT_INSTANCE;
            }
            case 6: {
                return DebugInfo.DEFAULT_INSTANCE;
            }
            case 1: {
                var4_12 = (GeneratedMessageLite.Visitor)var2_2;
                var5_13 = (DebugInfo)var3_3;
                this.stackEntries_ = var4_12.visitList(this.stackEntries_, var5_13.stackEntries_);
                this.detail_ = var4_12.visitString(true ^ this.detail_.isEmpty(), this.detail_, true ^ var5_13.detail_.isEmpty(), var5_13.detail_);
                if (var4_12 != GeneratedMessageLite.MergeFromVisitor.INSTANCE) return this;
                this.bitField0_ |= var5_13.bitField0_;
                return this;
            }
            case 5: {
                return new Builder(null);
            }
            case 3: {
                this.stackEntries_.makeImmutable();
                return null;
            }
            case 0: {
                return DebugInfo.DEFAULT_INSTANCE;
            }
            case 4: 
        }
        return new DebugInfo();
    }

    @Override
    public String getDetail() {
        return this.detail_;
    }

    @Override
    public ByteString getDetailBytes() {
        return ByteString.copyFromUtf8((String)this.detail_);
    }

    public int getSerializedSize() {
        int n = this.memoizedSerializedSize;
        if (n != -1) {
            return n;
        }
        int n2 = 0;
        for (int i = 0; i < this.stackEntries_.size(); ++i) {
            n2 += CodedOutputStream.computeStringSizeNoTag((String)((String)this.stackEntries_.get(i)));
        }
        int n3 = 0 + n2 + 1 * this.getStackEntriesList().size();
        if (!this.detail_.isEmpty()) {
            n3 += CodedOutputStream.computeStringSize((int)2, (String)this.getDetail());
        }
        this.memoizedSerializedSize = n3;
        return n3;
    }

    @Override
    public String getStackEntries(int n) {
        return (String)this.stackEntries_.get(n);
    }

    @Override
    public ByteString getStackEntriesBytes(int n) {
        return ByteString.copyFromUtf8((String)((String)this.stackEntries_.get(n)));
    }

    @Override
    public int getStackEntriesCount() {
        return this.stackEntries_.size();
    }

    @Override
    public List<String> getStackEntriesList() {
        return this.stackEntries_;
    }

    public void writeTo(CodedOutputStream codedOutputStream) throws IOException {
        for (int i = 0; i < this.stackEntries_.size(); ++i) {
            codedOutputStream.writeString(1, (String)this.stackEntries_.get(i));
        }
        if (!this.detail_.isEmpty()) {
            codedOutputStream.writeString(2, this.getDetail());
        }
    }

    public static final class Builder
    extends GeneratedMessageLite.Builder<DebugInfo, Builder>
    implements DebugInfoOrBuilder {
        private Builder() {
            super((GeneratedMessageLite)DEFAULT_INSTANCE);
        }

        public /* synthetic */ Builder(1 var1_1) {
            this();
        }

        public Builder addAllStackEntries(Iterable<String> iterable) {
            this.copyOnWrite();
            ((DebugInfo)this.instance).addAllStackEntries((Iterable<String>)iterable);
            return this;
        }

        public Builder addStackEntries(String string) {
            this.copyOnWrite();
            ((DebugInfo)this.instance).addStackEntries(string);
            return this;
        }

        public Builder addStackEntriesBytes(ByteString byteString) {
            this.copyOnWrite();
            ((DebugInfo)this.instance).addStackEntriesBytes(byteString);
            return this;
        }

        public Builder clearDetail() {
            this.copyOnWrite();
            ((DebugInfo)this.instance).clearDetail();
            return this;
        }

        public Builder clearStackEntries() {
            this.copyOnWrite();
            ((DebugInfo)this.instance).clearStackEntries();
            return this;
        }

        @Override
        public String getDetail() {
            return ((DebugInfo)this.instance).getDetail();
        }

        @Override
        public ByteString getDetailBytes() {
            return ((DebugInfo)this.instance).getDetailBytes();
        }

        @Override
        public String getStackEntries(int n) {
            return ((DebugInfo)this.instance).getStackEntries(n);
        }

        @Override
        public ByteString getStackEntriesBytes(int n) {
            return ((DebugInfo)this.instance).getStackEntriesBytes(n);
        }

        @Override
        public int getStackEntriesCount() {
            return ((DebugInfo)this.instance).getStackEntriesCount();
        }

        @Override
        public List<String> getStackEntriesList() {
            return Collections.unmodifiableList(((DebugInfo)this.instance).getStackEntriesList());
        }

        public Builder setDetail(String string) {
            this.copyOnWrite();
            ((DebugInfo)this.instance).setDetail(string);
            return this;
        }

        public Builder setDetailBytes(ByteString byteString) {
            this.copyOnWrite();
            ((DebugInfo)this.instance).setDetailBytes(byteString);
            return this;
        }

        public Builder setStackEntries(int n, String string) {
            this.copyOnWrite();
            ((DebugInfo)this.instance).setStackEntries(n, string);
            return this;
        }
    }

}

