/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.protobuf.ExtensionRegistryLite
 *  java.lang.Object
 */
package com.google.rpc;

import com.google.protobuf.ExtensionRegistryLite;

public final class CodeProto {
    private CodeProto() {
    }

    public static void registerAllExtensions(ExtensionRegistryLite extensionRegistryLite) {
    }
}

