/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.protobuf.AbstractMessageLite
 *  com.google.protobuf.ByteString
 *  com.google.protobuf.CodedInputStream
 *  com.google.protobuf.CodedOutputStream
 *  com.google.protobuf.ExtensionRegistryLite
 *  com.google.protobuf.GeneratedMessageLite
 *  com.google.protobuf.GeneratedMessageLite$Builder
 *  com.google.protobuf.GeneratedMessageLite$DefaultInstanceBasedParser
 *  com.google.protobuf.GeneratedMessageLite$MethodToInvoke
 *  com.google.protobuf.GeneratedMessageLite$Visitor
 *  com.google.protobuf.InvalidProtocolBufferException
 *  com.google.protobuf.MessageLite
 *  com.google.protobuf.Parser
 *  com.google.rpc.RequestInfo$1
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 *  java.util.Objects
 */
package com.google.rpc;

import com.google.protobuf.AbstractMessageLite;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.CodedOutputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.MessageLite;
import com.google.protobuf.Parser;
import com.google.rpc.RequestInfo;
import com.google.rpc.RequestInfoOrBuilder;
import java.io.IOException;
import java.io.InputStream;
import java.util.Objects;

public final class RequestInfo
extends GeneratedMessageLite<RequestInfo, Builder>
implements RequestInfoOrBuilder {
    private static final RequestInfo DEFAULT_INSTANCE;
    private static volatile Parser<RequestInfo> PARSER;
    public static final int REQUEST_ID_FIELD_NUMBER = 1;
    public static final int SERVING_DATA_FIELD_NUMBER = 2;
    private String requestId_ = "";
    private String servingData_ = "";

    public static {
        RequestInfo requestInfo;
        DEFAULT_INSTANCE = requestInfo = new RequestInfo();
        requestInfo.makeImmutable();
    }

    private RequestInfo() {
    }

    private void clearRequestId() {
        this.requestId_ = RequestInfo.getDefaultInstance().getRequestId();
    }

    private void clearServingData() {
        this.servingData_ = RequestInfo.getDefaultInstance().getServingData();
    }

    public static RequestInfo getDefaultInstance() {
        return DEFAULT_INSTANCE;
    }

    public static Builder newBuilder() {
        return (Builder)DEFAULT_INSTANCE.toBuilder();
    }

    public static Builder newBuilder(RequestInfo requestInfo) {
        return (Builder)((Builder)DEFAULT_INSTANCE.toBuilder()).mergeFrom((GeneratedMessageLite)requestInfo);
    }

    public static RequestInfo parseDelimitedFrom(InputStream inputStream) throws IOException {
        return (RequestInfo)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static RequestInfo parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (RequestInfo)GeneratedMessageLite.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static RequestInfo parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
        return (RequestInfo)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString);
    }

    public static RequestInfo parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (RequestInfo)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static RequestInfo parseFrom(CodedInputStream codedInputStream) throws IOException {
        return (RequestInfo)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream);
    }

    public static RequestInfo parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (RequestInfo)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static RequestInfo parseFrom(InputStream inputStream) throws IOException {
        return (RequestInfo)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static RequestInfo parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (RequestInfo)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static RequestInfo parseFrom(byte[] arrby) throws InvalidProtocolBufferException {
        return (RequestInfo)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby);
    }

    public static RequestInfo parseFrom(byte[] arrby, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (RequestInfo)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Parser<RequestInfo> parser() {
        return DEFAULT_INSTANCE.getParserForType();
    }

    private void setRequestId(String string) {
        Objects.requireNonNull((Object)string);
        this.requestId_ = string;
    }

    private void setRequestIdBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.requestId_ = byteString.toStringUtf8();
    }

    private void setServingData(String string) {
        Objects.requireNonNull((Object)string);
        this.servingData_ = string;
    }

    private void setServingDataBytes(ByteString byteString) {
        Objects.requireNonNull((Object)byteString);
        AbstractMessageLite.checkByteStringIsUtf8((ByteString)byteString);
        this.servingData_ = byteString.toStringUtf8();
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke var1_1, Object var2_2, Object var3_3) {
        switch (var1_1.ordinal()) {
            default: {
                throw new UnsupportedOperationException();
            }
            case 7: {
                if (RequestInfo.PARSER != null) return RequestInfo.PARSER;
                var15_4 = RequestInfo.class;
                // MONITORENTER : com.google.rpc.RequestInfo.class
                if (RequestInfo.PARSER == null) {
                    RequestInfo.PARSER = new GeneratedMessageLite.DefaultInstanceBasedParser((GeneratedMessageLite)RequestInfo.DEFAULT_INSTANCE);
                }
                // MONITOREXIT : var15_4
                return RequestInfo.PARSER;
            }
            case 2: {
                var7_5 = (CodedInputStream)var2_2;
                (ExtensionRegistryLite)var3_3;
                var9_6 = false;
                while (var9_6 == false) {
                    var13_7 = var7_5.readTag();
                    if (var13_7 == 0) ** GOTO lbl29
                    if (var13_7 == 10) ** GOTO lbl27
                    if (var13_7 != 18) {
                        if (var7_5.skipField(var13_7)) continue;
                    } else {
                        this.servingData_ = var7_5.readStringRequireUtf8();
                        continue;
lbl27: // 1 sources:
                        this.requestId_ = var7_5.readStringRequireUtf8();
                        continue;
                    }
lbl29: // 2 sources:
                    var9_6 = true;
                    continue;
                    catch (IOException var12_9) {
                        throw new RuntimeException((Throwable)new InvalidProtocolBufferException(var12_9.getMessage()).setUnfinishedMessage((MessageLite)this));
                    }
                    catch (InvalidProtocolBufferException var10_10) {
                        throw new RuntimeException((Throwable)var10_10.setUnfinishedMessage((MessageLite)this));
                    }
                }
                return RequestInfo.DEFAULT_INSTANCE;
            }
            case 6: {
                return RequestInfo.DEFAULT_INSTANCE;
            }
            case 1: {
                var4_11 = (GeneratedMessageLite.Visitor)var2_2;
                var5_12 = (RequestInfo)var3_3;
                this.requestId_ = var4_11.visitString(true ^ this.requestId_.isEmpty(), this.requestId_, true ^ var5_12.requestId_.isEmpty(), var5_12.requestId_);
                this.servingData_ = var4_11.visitString(true ^ this.servingData_.isEmpty(), this.servingData_, true ^ var5_12.servingData_.isEmpty(), var5_12.servingData_);
                return this;
            }
            case 5: {
                return new Builder(null);
            }
            case 3: {
                return null;
            }
            case 0: {
                return RequestInfo.DEFAULT_INSTANCE;
            }
            case 4: 
        }
        return new RequestInfo();
    }

    @Override
    public String getRequestId() {
        return this.requestId_;
    }

    @Override
    public ByteString getRequestIdBytes() {
        return ByteString.copyFromUtf8((String)this.requestId_);
    }

    public int getSerializedSize() {
        int n = this.memoizedSerializedSize;
        if (n != -1) {
            return n;
        }
        boolean bl = this.requestId_.isEmpty();
        int n2 = 0;
        if (!bl) {
            n2 = 0 + CodedOutputStream.computeStringSize((int)1, (String)this.getRequestId());
        }
        if (!this.servingData_.isEmpty()) {
            n2 += CodedOutputStream.computeStringSize((int)2, (String)this.getServingData());
        }
        this.memoizedSerializedSize = n2;
        return n2;
    }

    @Override
    public String getServingData() {
        return this.servingData_;
    }

    @Override
    public ByteString getServingDataBytes() {
        return ByteString.copyFromUtf8((String)this.servingData_);
    }

    public void writeTo(CodedOutputStream codedOutputStream) throws IOException {
        if (!this.requestId_.isEmpty()) {
            codedOutputStream.writeString(1, this.getRequestId());
        }
        if (!this.servingData_.isEmpty()) {
            codedOutputStream.writeString(2, this.getServingData());
        }
    }

    public static final class Builder
    extends GeneratedMessageLite.Builder<RequestInfo, Builder>
    implements RequestInfoOrBuilder {
        private Builder() {
            super((GeneratedMessageLite)DEFAULT_INSTANCE);
        }

        public /* synthetic */ Builder(1 var1_1) {
            this();
        }

        public Builder clearRequestId() {
            this.copyOnWrite();
            ((RequestInfo)this.instance).clearRequestId();
            return this;
        }

        public Builder clearServingData() {
            this.copyOnWrite();
            ((RequestInfo)this.instance).clearServingData();
            return this;
        }

        @Override
        public String getRequestId() {
            return ((RequestInfo)this.instance).getRequestId();
        }

        @Override
        public ByteString getRequestIdBytes() {
            return ((RequestInfo)this.instance).getRequestIdBytes();
        }

        @Override
        public String getServingData() {
            return ((RequestInfo)this.instance).getServingData();
        }

        @Override
        public ByteString getServingDataBytes() {
            return ((RequestInfo)this.instance).getServingDataBytes();
        }

        public Builder setRequestId(String string) {
            this.copyOnWrite();
            ((RequestInfo)this.instance).setRequestId(string);
            return this;
        }

        public Builder setRequestIdBytes(ByteString byteString) {
            this.copyOnWrite();
            ((RequestInfo)this.instance).setRequestIdBytes(byteString);
            return this;
        }

        public Builder setServingData(String string) {
            this.copyOnWrite();
            ((RequestInfo)this.instance).setServingData(string);
            return this;
        }

        public Builder setServingDataBytes(ByteString byteString) {
            this.copyOnWrite();
            ((RequestInfo)this.instance).setServingDataBytes(byteString);
            return this;
        }
    }

}

