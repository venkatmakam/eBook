/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.UnsupportedOperationException
 *  java.util.Collection
 *  java.util.Iterator
 *  java.util.LinkedHashMap
 *  java.util.Map
 *  java.util.Set
 */
package com.zendesk.collection;

import com.zendesk.util.CollectionUtils;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

public class CountedSet<E>
implements Set<E> {
    public static final int NOT_FOUND;
    private Map<E, Integer> countingMap;

    public CountedSet() {
        this.countingMap = new LinkedHashMap();
    }

    public CountedSet(int n4) {
        this.countingMap = new LinkedHashMap(n4);
    }

    public boolean add(E e7) {
        if (e7 != null) {
            if (this.countingMap.containsKey(e7)) {
                Integer n4 = 1 + (Integer)this.countingMap.get(e7);
                this.countingMap.put(e7, (Object)n4);
                return true;
            }
            this.countingMap.put(e7, (Object)1);
            return true;
        }
        return false;
    }

    public boolean addAll(Collection<? extends E> collection) {
        if (CollectionUtils.isNotEmpty(collection)) {
            Iterator iterator = collection.iterator();
            while (iterator.hasNext()) {
                if (this.add(iterator.next())) continue;
                return false;
            }
            return true;
        }
        return false;
    }

    public void clear() {
        this.countingMap.clear();
    }

    public boolean contains(Object object) {
        return this.countingMap.containsKey(object);
    }

    public boolean containsAll(Collection<?> collection) {
        if (CollectionUtils.isNotEmpty(collection)) {
            for (Object object : collection) {
                if (this.countingMap.containsKey(object)) continue;
                return false;
            }
            return true;
        }
        return false;
    }

    public int getCount(E e7) {
        if (e7 != null && this.countingMap.containsKey(e7)) {
            return (Integer)this.countingMap.get(e7);
        }
        return 0;
    }

    public boolean isEmpty() {
        return this.countingMap.isEmpty();
    }

    public Iterator<E> iterator() {
        return this.countingMap.keySet().iterator();
    }

    public boolean remove(Object object) {
        if (this.countingMap.containsKey(object)) {
            int n4 = (Integer)this.countingMap.get(object);
            if (n4 > 1) {
                int n5 = n4 - 1;
                this.countingMap.put(object, (Object)n5);
                return true;
            }
            this.countingMap.remove(object);
            return true;
        }
        return false;
    }

    public boolean removeAll(Collection<?> collection) {
        if (CollectionUtils.isNotEmpty(collection)) {
            for (Object object : collection) {
                if (this.countingMap.containsKey(object)) continue;
                return false;
            }
            for (Object object : collection) {
                this.countingMap.remove(object);
            }
            return true;
        }
        return false;
    }

    public boolean retainAll(Collection<?> collection) {
        throw new UnsupportedOperationException();
    }

    public int size() {
        return this.countingMap.size();
    }

    public Object[] toArray() {
        return this.countingMap.keySet().toArray();
    }

    public <T> T[] toArray(T[] arrT) {
        return this.countingMap.keySet().toArray((Object[])arrT);
    }
}

