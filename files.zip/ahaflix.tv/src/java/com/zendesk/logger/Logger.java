/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.util.Log
 *  e.a.a.a.a
 *  java.io.PrintStream
 *  java.lang.Enum
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Throwable
 *  java.text.SimpleDateFormat
 *  java.util.ArrayList
 *  java.util.Date
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Locale
 *  java.util.TimeZone
 */
package com.zendesk.logger;

import android.util.Log;
import com.zendesk.logger.LoggerHelper;
import com.zendesk.service.ErrorResponse;
import com.zendesk.util.StringUtils;
import e.a.a.a.a;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

public class Logger {
    private static final String ISO_8601_FORMAT = "yyyy-MM-dd'T'HH:mm:ss'Z'";
    private static final List<LogAppender> USER_DEFINED_APPENDER;
    private static final TimeZone UTC_TIMEZONE;
    private static boolean loggable;
    private static LogAppender platformLogger;

    /*
     * Exception decompiling
     */
    public static {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl39 : ALOAD_0 : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    private Logger() {
    }

    public static void addLogAppender(LogAppender logAppender) {
        if (logAppender != null) {
            USER_DEFINED_APPENDER.add((Object)logAppender);
        }
    }

    public static /* varargs */ void d(String string2, String string3, Throwable throwable, Object ... arrobject) {
        Logger.logInternal(Priority.DEBUG, string2, string3, throwable, arrobject);
    }

    public static /* varargs */ void d(String string2, String string3, Object ... arrobject) {
        Logger.logInternal(Priority.DEBUG, string2, string3, null, arrobject);
    }

    public static void e(String string2, ErrorResponse errorResponse) {
        StringBuilder stringBuilder = new StringBuilder();
        if (errorResponse != null) {
            stringBuilder.append("Network Error: ");
            stringBuilder.append(errorResponse.isNetworkError());
            stringBuilder.append(", Status Code: ");
            stringBuilder.append(errorResponse.getStatus());
            if (StringUtils.hasLength(errorResponse.getReason())) {
                stringBuilder.append(", Reason: ");
                stringBuilder.append(errorResponse.getReason());
            }
        }
        String string3 = stringBuilder.toString();
        Priority priority = Priority.ERROR;
        if (!StringUtils.hasLength(string3)) {
            string3 = "Unknown error";
        }
        Logger.logInternal(priority, string2, string3, null, new Object[0]);
    }

    public static /* varargs */ void e(String string2, String string3, Throwable throwable, Object ... arrobject) {
        Logger.logInternal(Priority.ERROR, string2, string3, throwable, arrobject);
    }

    public static /* varargs */ void e(String string2, String string3, Object ... arrobject) {
        Logger.logInternal(Priority.ERROR, string2, string3, null, arrobject);
    }

    public static /* varargs */ void i(String string2, String string3, Throwable throwable, Object ... arrobject) {
        Logger.logInternal(Priority.INFO, string2, string3, throwable, arrobject);
    }

    public static /* varargs */ void i(String string2, String string3, Object ... arrobject) {
        Logger.logInternal(Priority.INFO, string2, string3, null, arrobject);
    }

    public static boolean isLoggable() {
        return loggable;
    }

    private static /* varargs */ void logInternal(Priority priority, String string2, String string3, Throwable throwable, Object ... arrobject) {
        if (arrobject != null && arrobject.length > 0) {
            string3 = String.format((Locale)Locale.US, (String)string3, (Object[])arrobject);
        }
        if (loggable) {
            platformLogger.log(priority, string2, string3, throwable);
            Iterator iterator = USER_DEFINED_APPENDER.iterator();
            while (iterator.hasNext()) {
                ((LogAppender)iterator.next()).log(priority, string2, string3, throwable);
            }
        }
    }

    public static void removeAllLogAppender() {
        USER_DEFINED_APPENDER.clear();
    }

    public static void setLoggable(boolean bl2) {
        loggable = bl2;
    }

    public static /* varargs */ void v(String string2, String string3, Throwable throwable, Object ... arrobject) {
        Logger.logInternal(Priority.VERBOSE, string2, string3, throwable, arrobject);
    }

    public static /* varargs */ void v(String string2, String string3, Object ... arrobject) {
        Logger.logInternal(Priority.VERBOSE, string2, string3, null, arrobject);
    }

    public static /* varargs */ void w(String string2, String string3, Throwable throwable, Object ... arrobject) {
        Logger.logInternal(Priority.WARN, string2, string3, throwable, arrobject);
    }

    public static /* varargs */ void w(String string2, String string3, Object ... arrobject) {
        Logger.logInternal(Priority.WARN, string2, string3, null, arrobject);
    }

    public static interface LogAppender {
        public void log(Priority var1, String var2, String var3, Throwable var4);
    }

    public static final class Priority
    extends Enum<Priority> {
        private static final /* synthetic */ Priority[] $VALUES;
        public static final /* enum */ Priority DEBUG;
        public static final /* enum */ Priority ERROR;
        public static final /* enum */ Priority INFO;
        public static final /* enum */ Priority VERBOSE;
        public static final /* enum */ Priority WARN;
        private final int priority;

        public static {
            Priority priority;
            Priority priority2;
            Priority priority3;
            Priority priority4;
            Priority priority5;
            VERBOSE = priority = new Priority(2);
            DEBUG = priority2 = new Priority(3);
            INFO = priority4 = new Priority(4);
            WARN = priority5 = new Priority(5);
            ERROR = priority3 = new Priority(6);
            $VALUES = new Priority[]{priority, priority2, priority4, priority5, priority3};
        }

        private Priority(int n5) {
            this.priority = n5;
        }

        public static Priority valueOf(String string2) {
            return (Priority)Enum.valueOf(Priority.class, (String)string2);
        }

        public static Priority[] values() {
            return (Priority[])$VALUES.clone();
        }
    }

}

