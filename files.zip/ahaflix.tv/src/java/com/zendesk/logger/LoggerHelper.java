/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.zendesk.logger;

public class LoggerHelper {
    private static final String DEFAULT_LOG_TAG = "Zendesk";
    private static final int MAXIMUM_ANDROID_LOG_TAG_LENGTH = 23;

    private LoggerHelper() {
    }

    public static char a(int n4) {
        if (n4 != 2) {
            if (n4 != 3) {
                if (n4 != 5) {
                    if (n4 != 6) {
                        if (n4 != 7) {
                            return 'I';
                        }
                        return 'A';
                    }
                    return 'E';
                }
                return 'W';
            }
            return 'D';
        }
        return 'V';
    }
}

