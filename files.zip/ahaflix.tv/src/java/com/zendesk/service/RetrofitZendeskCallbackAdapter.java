/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.zendesk.service.ErrorResponse
 *  com.zendesk.service.RetrofitZendeskCallbackAdapter$RequestExtractor
 *  com.zendesk.service.ZendeskCallback
 *  java.lang.Object
 *  java.lang.Throwable
 *  retrofit2.Call
 *  retrofit2.Callback
 *  retrofit2.Response
 */
package com.zendesk.service;

import com.zendesk.service.ErrorResponse;
import com.zendesk.service.RetrofitErrorResponse;
import com.zendesk.service.RetrofitZendeskCallbackAdapter;
import com.zendesk.service.ZendeskCallback;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RetrofitZendeskCallbackAdapter<E, F>
implements Callback<E> {
    public static final RequestExtractor a = new DefaultExtractor();
    private final ZendeskCallback<F> mCallback;
    private final RequestExtractor<E, F> mExtractor;

    public RetrofitZendeskCallbackAdapter(ZendeskCallback<F> zendeskCallback) {
        this(zendeskCallback, a);
    }

    public RetrofitZendeskCallbackAdapter(ZendeskCallback<F> zendeskCallback, RequestExtractor<E, F> requestExtractor) {
        this.mCallback = zendeskCallback;
        this.mExtractor = requestExtractor;
    }

    public void onFailure(Call<E> call, Throwable throwable) {
        ZendeskCallback<F> zendeskCallback = this.mCallback;
        if (zendeskCallback != null) {
            zendeskCallback.onError((ErrorResponse)RetrofitErrorResponse.throwable(throwable));
        }
    }

    public void onResponse(Call<E> call, Response<E> response) {
        if (this.mCallback != null) {
            if (response.isSuccessful()) {
                this.mCallback.onSuccess(this.mExtractor.extract(response.body()));
                return;
            }
            this.mCallback.onError((ErrorResponse)RetrofitErrorResponse.response(response));
        }
    }

    public static final class DefaultExtractor<E>
    implements RequestExtractor<E, E> {
        public E extract(E e2) {
            return e2;
        }
    }

}

