/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.zendesk.service;

import com.zendesk.service.ErrorResponse;

public abstract class ZendeskCallback<T> {
    public abstract void onError(ErrorResponse var1);

    public abstract void onSuccess(T var1);
}

