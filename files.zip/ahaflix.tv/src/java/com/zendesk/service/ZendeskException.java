/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  retrofit2.Response
 */
package com.zendesk.service;

import com.zendesk.service.ErrorResponse;
import com.zendesk.service.ErrorResponseAdapter;
import com.zendesk.service.RetrofitErrorResponse;
import com.zendesk.util.ObjectUtils;
import com.zendesk.util.StringUtils;
import retrofit2.Response;

public class ZendeskException
extends Exception {
    private final ErrorResponse errorResponse;

    public ZendeskException(ErrorResponse errorResponse) {
        super(errorResponse.getReason());
        this.errorResponse = errorResponse;
    }

    public ZendeskException(String string2) {
        super(string2);
        this.errorResponse = new ErrorResponseAdapter(this.getMessage());
    }

    public ZendeskException(Throwable throwable) {
        super(throwable);
        this.errorResponse = ErrorResponseAdapter.fromException(throwable);
    }

    public ZendeskException(Response response) {
        super(ZendeskException.message(response));
        this.errorResponse = RetrofitErrorResponse.response(response);
    }

    private static String message(Response response) {
        StringBuilder stringBuilder = new StringBuilder();
        if (response != null) {
            if (StringUtils.hasLength(response.message())) {
                stringBuilder.append(response.message());
            } else {
                stringBuilder.append(response.code());
            }
        }
        return stringBuilder.toString();
    }

    public ErrorResponse errorResponse() {
        return this.errorResponse;
    }

    public String toString() {
        ErrorResponse errorResponse = this.errorResponse;
        String string2 = errorResponse == null ? "null" : errorResponse.getReason();
        Object[] arrobject = new Object[]{super.toString(), string2, ObjectUtils.toString((Object)this.getCause())};
        return String.format((String)"ZendeskException{details=%s,errorResponse=%s,cause=%s}", (Object[])arrobject);
    }
}

