/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Deprecated
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 */
package com.zendesk.service;

import com.zendesk.service.Header;
import java.util.List;

public interface ErrorResponse {
    public static final int NON_HTTP_ERROR = -1;

    public String getReason();

    public String getResponseBody();

    public String getResponseBodyType();

    public List<Header> getResponseHeaders();

    public int getStatus();

    public String getUrl();

    @Deprecated
    public boolean isConversionError();

    public boolean isHTTPError();

    @Deprecated
    public boolean isNetworkError();
}

