/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.zendesk.service.ErrorResponse
 *  com.zendesk.service.ZendeskCallback
 *  java.lang.Object
 *  java.util.Iterator
 *  java.util.LinkedHashSet
 *  java.util.Set
 */
package com.zendesk.service;

import com.zendesk.service.ErrorResponse;
import com.zendesk.service.SafeZendeskCallback;
import com.zendesk.service.ZendeskCallback;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;

public class CancellableCompositeZendeskCallback<T>
extends ZendeskCallback<T> {
    private Set<SafeZendeskCallback<T>> callbacks = new LinkedHashSet();

    public void add(SafeZendeskCallback<T> safeZendeskCallback) {
        this.callbacks.add(safeZendeskCallback);
    }

    public void cancel() {
        Iterator iterator = this.callbacks.iterator();
        while (iterator.hasNext()) {
            ((SafeZendeskCallback)((Object)iterator.next())).cancel();
        }
        this.callbacks.clear();
    }

    public void onError(ErrorResponse errorResponse) {
        Iterator iterator = this.callbacks.iterator();
        while (iterator.hasNext()) {
            ((SafeZendeskCallback)((Object)iterator.next())).onError(errorResponse);
        }
        this.callbacks.clear();
    }

    public void onSuccess(T t2) {
        Iterator iterator = this.callbacks.iterator();
        while (iterator.hasNext()) {
            ((SafeZendeskCallback)((Object)iterator.next())).onSuccess(t2);
        }
        this.callbacks.clear();
    }

    public void remove(SafeZendeskCallback<T> safeZendeskCallback) {
        this.callbacks.remove(safeZendeskCallback);
    }
}

