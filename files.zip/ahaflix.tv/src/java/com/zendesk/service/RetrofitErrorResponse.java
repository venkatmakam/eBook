/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.zendesk.service.ErrorResponse
 *  com.zendesk.service.Header
 *  com.zendesk.util.StringUtils
 *  java.io.IOException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.List
 *  java.util.Set
 *  okhttp3.Headers
 *  okhttp3.HttpUrl
 *  okhttp3.MediaType
 *  okhttp3.Request
 *  okhttp3.Response
 *  okhttp3.ResponseBody
 *  retrofit2.Response
 */
package com.zendesk.service;

import com.zendesk.service.ErrorResponse;
import com.zendesk.service.Header;
import com.zendesk.util.StringUtils;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import okhttp3.Headers;
import okhttp3.HttpUrl;
import okhttp3.MediaType;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;

public class RetrofitErrorResponse
implements ErrorResponse {
    private static final String LOG_TAG = "RetrofitErrorResponse";
    private retrofit2.Response mResponse;
    private Throwable mThrowable;

    private RetrofitErrorResponse(Throwable throwable) {
        this.mThrowable = throwable;
    }

    private RetrofitErrorResponse(retrofit2.Response response) {
        this.mResponse = response;
    }

    public static RetrofitErrorResponse response(retrofit2.Response response) {
        return new RetrofitErrorResponse(response);
    }

    public static RetrofitErrorResponse throwable(Throwable throwable) {
        return new RetrofitErrorResponse(throwable);
    }

    public String getReason() {
        Throwable throwable = this.mThrowable;
        if (throwable != null) {
            return throwable.getMessage();
        }
        StringBuilder stringBuilder = new StringBuilder();
        retrofit2.Response response = this.mResponse;
        if (response != null) {
            if (StringUtils.hasLength((String)response.message())) {
                stringBuilder.append(this.mResponse.message());
            } else {
                stringBuilder.append(this.mResponse.code());
            }
        }
        return stringBuilder.toString();
    }

    /*
     * Exception decompiling
     */
    public String getResponseBody() {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl25.1 : LDC : trying to set 0 previously set to 1
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    public String getResponseBodyType() {
        retrofit2.Response response = this.mResponse;
        if (response != null && response.errorBody() != null) {
            return this.mResponse.errorBody().contentType().toString();
        }
        return "";
    }

    public List<Header> getResponseHeaders() {
        if (this.mThrowable != null) {
            return new ArrayList();
        }
        ArrayList arrayList = new ArrayList();
        retrofit2.Response response = this.mResponse;
        if (response != null && response.headers() != null && this.mResponse.headers().size() > 0) {
            Headers headers = this.mResponse.headers();
            for (String string : headers.names()) {
                arrayList.add((Object)new Header(string, headers.get(string)));
            }
        }
        return arrayList;
    }

    public int getStatus() {
        retrofit2.Response response = this.mResponse;
        if (response != null) {
            return response.code();
        }
        return -1;
    }

    public String getUrl() {
        retrofit2.Response response = this.mResponse;
        if (response != null && response.raw().request() != null && this.mResponse.raw().request().url() != null) {
            return this.mResponse.raw().request().url().toString();
        }
        return "";
    }

    public boolean isConversionError() {
        return this.isNetworkError();
    }

    public boolean isHTTPError() {
        retrofit2.Response response;
        return this.mThrowable == null && (response = this.mResponse) != null && !response.isSuccessful();
    }

    public boolean isNetworkError() {
        Throwable throwable = this.mThrowable;
        return throwable != null && throwable instanceof IOException;
    }
}

