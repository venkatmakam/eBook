/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  e.a.a.a.a
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.zendesk.service;

import e.a.a.a.a;

public class Header {
    private final String name;
    private final String value;

    public Header(String string2, String string3) {
        this.name = string2;
        this.value = string3;
    }

    public boolean equals(Object object) {
        block4 : {
            boolean bl2;
            block6 : {
                block7 : {
                    String string2;
                    block5 : {
                        bl2 = true;
                        if (this == object) {
                            return bl2;
                        }
                        if (object == null) break block4;
                        if (this.getClass() != object.getClass()) {
                            return false;
                        }
                        Header header = (Header)object;
                        String string3 = this.name;
                        if (string3 != null ? !string3.equals((Object)header.name) : header.name != null) {
                            return false;
                        }
                        String string4 = this.value;
                        string2 = header.value;
                        if (string4 == null) break block5;
                        if (string4.equals((Object)string2)) break block6;
                        break block7;
                    }
                    if (string2 == null) {
                        return bl2;
                    }
                }
                bl2 = false;
            }
            return bl2;
        }
        return false;
    }

    public String getName() {
        return this.name;
    }

    public String getValue() {
        return this.value;
    }

    public int hashCode() {
        String string2 = this.name;
        int n4 = string2 != null ? string2.hashCode() : 0;
        int n5 = n4 * 31;
        String string3 = this.value;
        int n6 = 0;
        if (string3 != null) {
            n6 = string3.hashCode();
        }
        return n5 + n6;
    }

    public String toString() {
        StringBuilder stringBuilder = a.F1((String)"Header{name='");
        a.H((StringBuilder)stringBuilder, (String)this.name, (char)'\'', (String)", value='");
        stringBuilder.append(this.value);
        stringBuilder.append('\'');
        stringBuilder.append('}');
        return stringBuilder.toString();
    }
}

