/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.gson.TypeAdapter
 *  com.google.gson.stream.JsonReader
 *  com.google.gson.stream.JsonToken
 *  com.google.gson.stream.JsonWriter
 *  com.zendesk.logger.Logger
 *  e.a.a.a.a
 *  java.io.IOException
 *  java.lang.Character
 *  java.lang.Class
 *  java.lang.IllegalArgumentException
 *  java.lang.IndexOutOfBoundsException
 *  java.lang.Integer
 *  java.lang.Math
 *  java.lang.NumberFormatException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.text.ParseException
 *  java.text.ParsePosition
 *  java.util.Date
 *  java.util.GregorianCalendar
 *  java.util.Locale
 *  java.util.TimeZone
 */
package com.zendesk.service;

import com.google.gson.TypeAdapter;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;
import com.google.gson.stream.JsonWriter;
import com.zendesk.logger.Logger;
import e.a.a.a.a;
import java.io.IOException;
import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;

public class ZendeskDateTypeAdapter
extends TypeAdapter<Date> {
    private static final String LOG_TAG = "ZendeskDateTypeAdapter";
    private static final String PARSING_ERROR_FORMAT = "Failed to parse Date from: %s";
    private static final TimeZone TIMEZONE_UTC = TimeZone.getTimeZone((String)"UTC");
    private static final String UTC_ID = "UTC";

    private boolean checkOffset(String string, int n5, char c3) {
        return n5 < string.length() && string.charAt(n5) == c3;
    }

    private String format(Date date) {
        GregorianCalendar gregorianCalendar = new GregorianCalendar(TIMEZONE_UTC, Locale.US);
        gregorianCalendar.setTime(date);
        StringBuilder stringBuilder = new StringBuilder(21);
        this.padInt(stringBuilder, gregorianCalendar.get(1), 4);
        stringBuilder.append('-');
        this.padInt(stringBuilder, 1 + gregorianCalendar.get(2), 2);
        stringBuilder.append('-');
        this.padInt(stringBuilder, gregorianCalendar.get(5), 2);
        stringBuilder.append('T');
        this.padInt(stringBuilder, gregorianCalendar.get(11), 2);
        stringBuilder.append(':');
        this.padInt(stringBuilder, gregorianCalendar.get(12), 2);
        stringBuilder.append(':');
        this.padInt(stringBuilder, gregorianCalendar.get(13), 2);
        stringBuilder.append('Z');
        return stringBuilder.toString();
    }

    private static int indexOfNonDigit(String string, int n5) {
        while (n5 < string.length()) {
            char c3 = string.charAt(n5);
            if (c3 >= '0') {
                if (c3 > '9') {
                    return n5;
                }
                ++n5;
                continue;
            }
            return n5;
        }
        return string.length();
    }

    private void padInt(StringBuilder stringBuilder, int n5, int n6) {
        String string = Integer.toString((int)n5);
        for (int i5 = n6 - string.length(); i5 > 0; --i5) {
            stringBuilder.append('0');
        }
        stringBuilder.append(string);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private Date parse(String string, ParsePosition parsePosition) throws ParseException {
        int n5;
        int n6;
        int n7;
        int n8;
        int n9;
        int n10;
        int n11;
        int n12;
        block24 : {
            block23 : {
                int n13;
                block22 : {
                    int n14;
                    block19 : {
                        char c3;
                        block21 : {
                            int n15;
                            block20 : {
                                int n16;
                                block18 : {
                                    int n17;
                                    block17 : {
                                        try {
                                            int n18 = parsePosition.getIndex();
                                            n17 = n18 + 4;
                                            n11 = this.parseInt(string, n18, n17);
                                            if (!this.checkOffset(string, n17, '-')) break block17;
                                            ++n17;
                                        }
                                        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                                            String string2;
                                            if (string == null) {
                                                string2 = null;
                                            } else {
                                                StringBuilder stringBuilder = new StringBuilder();
                                                stringBuilder.append('\"');
                                                stringBuilder.append(string);
                                                stringBuilder.append("'");
                                                string2 = stringBuilder.toString();
                                            }
                                            String string3 = indexOutOfBoundsException.getMessage();
                                            if (string3 == null || string3.isEmpty()) {
                                                StringBuilder stringBuilder = a.F1((String)"(");
                                                stringBuilder.append(indexOutOfBoundsException.getClass().getName());
                                                stringBuilder.append(")");
                                                string3 = stringBuilder.toString();
                                            }
                                            ParseException parseException = new ParseException(a.j1((String)"Failed to parse date [", string2, (String)"]: ", (String)string3), parsePosition.getIndex());
                                            parseException.initCause((Throwable)indexOutOfBoundsException);
                                            throw parseException;
                                        }
                                    }
                                    n16 = n17 + 2;
                                    n10 = this.parseInt(string, n17, n16);
                                    if (!this.checkOffset(string, n16, '-')) break block18;
                                    ++n16;
                                }
                                n14 = n16 + 2;
                                n9 = this.parseInt(string, n16, n14);
                                boolean bl = this.checkOffset(string, n14, 'T');
                                if (!bl && string.length() <= n14) {
                                    GregorianCalendar gregorianCalendar = new GregorianCalendar(n11, n10 - 1, n9);
                                    parsePosition.setIndex(n14);
                                    return gregorianCalendar.getTime();
                                }
                                if (!bl) break block19;
                                int n19 = n14 + 1;
                                n15 = n19 + 2;
                                n5 = this.parseInt(string, n19, n15);
                                if (!this.checkOffset(string, n15, ':')) break block20;
                                ++n15;
                            }
                            n13 = n15 + 2;
                            n8 = this.parseInt(string, n15, n13);
                            if (!this.checkOffset(string, n13, ':')) break block21;
                            ++n13;
                        }
                        if (string.length() <= n13 || (c3 = string.charAt(n13)) == 'Z' || c3 == '+' || c3 == '-') break block22;
                        n12 = n13 + 2;
                        n7 = this.parseInt(string, n13, n12);
                        if (n7 > 59 && n7 < 63) {
                            n7 = 59;
                        }
                        if (!this.checkOffset(string, n12, '.')) break block23;
                        int n20 = n12 + 1;
                        int n21 = ZendeskDateTypeAdapter.indexOfNonDigit(string, n20 + 1);
                        int n22 = Math.min((int)n21, (int)(n20 + 3));
                        int n23 = this.parseInt(string, n20, n22);
                        int n24 = n22 - n20;
                        if (n24 != 1) {
                            if (n24 == 2) {
                                n23 *= 10;
                            }
                        } else {
                            n23 *= 100;
                        }
                        n12 = n21;
                        n6 = n23;
                        break block24;
                    }
                    n8 = 0;
                    n13 = n14;
                    n5 = 0;
                }
                n7 = 0;
                n12 = n13;
            }
            n6 = 0;
        }
        if (string.length() <= n12) {
            throw new IllegalArgumentException("No time zone indicator");
        }
        char c5 = string.charAt(n12);
        if (c5 == 'Z') {
            TimeZone timeZone = TIMEZONE_UTC;
            int n25 = n12 + 1;
            GregorianCalendar gregorianCalendar = new GregorianCalendar(timeZone);
            gregorianCalendar.setLenient(false);
            gregorianCalendar.set(1, n11);
            gregorianCalendar.set(2, n10 - 1);
            gregorianCalendar.set(5, n9);
            gregorianCalendar.set(11, n5);
            gregorianCalendar.set(12, n8);
            gregorianCalendar.set(13, n7);
            gregorianCalendar.set(14, n6);
            parsePosition.setIndex(n25);
            return gregorianCalendar.getTime();
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Invalid time zone indicator '");
        stringBuilder.append(c5);
        stringBuilder.append("'");
        throw new IndexOutOfBoundsException(stringBuilder.toString());
    }

    /*
     * Enabled aggressive block sorting
     */
    private int parseInt(String string, int n5, int n6) throws NumberFormatException {
        if (n5 >= 0 && n6 <= string.length() && n5 <= n6) {
            int n7;
            int n8;
            if (n5 < n6) {
                n8 = n5 + 1;
                int n9 = Character.digit((char)string.charAt(n5), (int)10);
                if (n9 < 0) {
                    StringBuilder stringBuilder = a.F1((String)"Invalid number: ");
                    stringBuilder.append(string.substring(n5, n6));
                    throw new NumberFormatException(stringBuilder.toString());
                }
                n7 = -n9;
            } else {
                n7 = 0;
                n8 = n5;
            }
            do {
                if (n8 >= n6) {
                    return -n7;
                }
                int n10 = n8 + 1;
                int n11 = Character.digit((char)string.charAt(n8), (int)10);
                if (n11 < 0) {
                    StringBuilder stringBuilder = a.F1((String)"Invalid number: ");
                    stringBuilder.append(string.substring(n5, n6));
                    throw new NumberFormatException(stringBuilder.toString());
                }
                n7 = n7 * 10 - n11;
                n8 = n10;
            } while (true);
        }
        throw new NumberFormatException(string);
    }

    public Date read(JsonReader jsonReader) throws IOException {
        if (jsonReader.peek() == JsonToken.NULL) {
            jsonReader.nextNull();
            return null;
        }
        String string = jsonReader.nextString();
        try {
            Date date = this.parse(string, new ParsePosition(0));
            return date;
        }
        catch (ParseException parseException) {
            Logger.e((String)LOG_TAG, (String)String.format((Locale)Locale.US, (String)PARSING_ERROR_FORMAT, (Object[])new Object[]{string}), (Throwable)parseException, (Object[])new Object[0]);
            return null;
        }
    }

    public void write(JsonWriter jsonWriter, Date date) throws IOException {
        if (date == null) {
            jsonWriter.nullValue();
            return;
        }
        jsonWriter.value(this.format(date));
    }
}

