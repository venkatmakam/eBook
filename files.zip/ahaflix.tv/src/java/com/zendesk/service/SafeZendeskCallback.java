/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.zendesk.logger.Logger
 *  com.zendesk.service.ErrorResponse
 *  com.zendesk.service.ZendeskCallback
 *  java.lang.Object
 *  java.lang.String
 */
package com.zendesk.service;

import com.zendesk.logger.Logger;
import com.zendesk.service.ErrorResponse;
import com.zendesk.service.ZendeskCallback;

public class SafeZendeskCallback<T>
extends ZendeskCallback<T> {
    private static final String LOG_TAG = "SafeZendeskCallback";
    private final ZendeskCallback<T> callback;
    private boolean cancelled;

    public SafeZendeskCallback(ZendeskCallback<T> zendeskCallback) {
        this.callback = zendeskCallback;
        this.cancelled = false;
    }

    public static <T> SafeZendeskCallback<T> from(ZendeskCallback<T> zendeskCallback) {
        return new SafeZendeskCallback<T>(zendeskCallback);
    }

    public void cancel() {
        this.cancelled = true;
    }

    public void onError(ErrorResponse errorResponse) {
        ZendeskCallback<T> zendeskCallback;
        if (!this.cancelled && (zendeskCallback = this.callback) != null) {
            zendeskCallback.onError(errorResponse);
            return;
        }
        Logger.e((String)LOG_TAG, (ErrorResponse)errorResponse);
    }

    public void onSuccess(T t2) {
        ZendeskCallback<T> zendeskCallback;
        if (!this.cancelled && (zendeskCallback = this.callback) != null) {
            zendeskCallback.onSuccess(t2);
            return;
        }
        Logger.w((String)LOG_TAG, (String)"Operation was a success but callback is null or was cancelled", (Object[])new Object[0]);
    }
}

