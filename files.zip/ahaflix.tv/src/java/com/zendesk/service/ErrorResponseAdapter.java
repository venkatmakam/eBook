/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.zendesk.service.ErrorResponse
 *  com.zendesk.service.Header
 *  com.zendesk.service.ZendeskException
 *  com.zendesk.util.CollectionUtils
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.List
 *  retrofit2.HttpException
 */
package com.zendesk.service;

import com.zendesk.service.ErrorResponse;
import com.zendesk.service.Header;
import com.zendesk.service.RetrofitErrorResponse;
import com.zendesk.service.ZendeskException;
import com.zendesk.util.CollectionUtils;
import java.util.ArrayList;
import java.util.List;
import retrofit2.HttpException;

public class ErrorResponseAdapter
implements ErrorResponse {
    private final String errorMessage;

    public ErrorResponseAdapter() {
        this("");
    }

    public ErrorResponseAdapter(String string) {
        this.errorMessage = string;
    }

    public static ErrorResponse fromException(Throwable throwable) {
        if (throwable instanceof ZendeskException) {
            return ((ZendeskException)throwable).errorResponse();
        }
        if (throwable instanceof HttpException) {
            return RetrofitErrorResponse.throwable(throwable);
        }
        return new ErrorResponseAdapter(throwable.getMessage());
    }

    public String getReason() {
        return this.errorMessage;
    }

    public String getResponseBody() {
        return this.errorMessage;
    }

    public String getResponseBodyType() {
        return "text/plain; charset=UTF8";
    }

    public List<Header> getResponseHeaders() {
        return CollectionUtils.unmodifiableList((List)new ArrayList());
    }

    public int getStatus() {
        return -1;
    }

    public String getUrl() {
        return "";
    }

    public boolean isConversionError() {
        return false;
    }

    public boolean isHTTPError() {
        return false;
    }

    public boolean isNetworkError() {
        return false;
    }
}

