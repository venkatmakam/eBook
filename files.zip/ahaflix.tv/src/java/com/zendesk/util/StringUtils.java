/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Character
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.text.SimpleDateFormat
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.Date
 *  java.util.HashMap
 *  java.util.List
 *  java.util.Map
 */
package com.zendesk.util;

import com.zendesk.util.CollectionUtils;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class StringUtils {
    public static final String EMPTY_STRING = "";
    private static final String ISO_8601_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss'Z'";
    private static Map<Character, String> JS_ESCAPE_LOOKUP_MAP;
    public static final String LINE_SEPARATOR;

    public static {
        HashMap hashMap;
        JS_ESCAPE_LOOKUP_MAP = hashMap = new HashMap();
        hashMap.put((Object)Character.valueOf((char)'\''), (Object)"\\'");
        JS_ESCAPE_LOOKUP_MAP.put((Object)Character.valueOf((char)'\"'), (Object)"\\\"");
        JS_ESCAPE_LOOKUP_MAP.put((Object)Character.valueOf((char)'\\'), (Object)"\\\\");
        JS_ESCAPE_LOOKUP_MAP.put((Object)Character.valueOf((char)'/'), (Object)"\\/");
        JS_ESCAPE_LOOKUP_MAP.put((Object)Character.valueOf((char)'\b'), (Object)"\\b");
        JS_ESCAPE_LOOKUP_MAP.put((Object)Character.valueOf((char)'\n'), (Object)"\\n");
        JS_ESCAPE_LOOKUP_MAP.put((Object)Character.valueOf((char)'\t'), (Object)"\\t");
        JS_ESCAPE_LOOKUP_MAP.put((Object)Character.valueOf((char)'\f'), (Object)"\\f");
        JS_ESCAPE_LOOKUP_MAP.put((Object)Character.valueOf((char)'\r'), (Object)"\\r");
        LINE_SEPARATOR = System.getProperty((String)"line.separator");
    }

    private StringUtils() {
    }

    public static String capitalize(String string2) {
        if (StringUtils.hasLength(string2)) {
            if (Character.isUpperCase((char)string2.charAt(0))) {
                return string2;
            }
            StringBuilder stringBuilder = new StringBuilder(string2.length());
            stringBuilder.append(Character.toTitleCase((char)string2.charAt(0)));
            stringBuilder.append(string2.substring(1));
            return stringBuilder.toString();
        }
        if (string2 != null) {
            return string2;
        }
        return null;
    }

    public static String ensureEmpty(String string2) {
        if (StringUtils.hasLength(string2)) {
            return string2;
        }
        return EMPTY_STRING;
    }

    public static String escapeEcmaScript(String string2) {
        if (StringUtils.isEmpty(string2)) {
            return string2;
        }
        StringBuilder stringBuilder = new StringBuilder(2 * string2.length());
        int n4 = string2.length();
        for (int i6 = 0; i6 < n4; ++i6) {
            char c5 = string2.charAt(i6);
            if (JS_ESCAPE_LOOKUP_MAP.containsKey((Object)Character.valueOf((char)c5))) {
                stringBuilder.append((String)JS_ESCAPE_LOOKUP_MAP.get((Object)Character.valueOf((char)c5)));
                continue;
            }
            stringBuilder.append(c5);
        }
        return stringBuilder.toString();
    }

    public static List<String> fromCsv(String string2) {
        boolean bl2 = StringUtils.hasLength(string2);
        if (bl2) {
            String[] arrstring = string2.split(",");
            ArrayList arrayList = new ArrayList();
            for (String string3 : arrstring) {
                if (!StringUtils.hasLength(string3)) continue;
                arrayList.add((Object)string3);
            }
            return CollectionUtils.unmodifiableList(arrayList);
        }
        return CollectionUtils.unmodifiableList(new ArrayList(0));
    }

    public static boolean hasLength(String string2) {
        return string2 != null && string2.trim().length() > 0;
    }

    public static /* varargs */ boolean hasLengthMany(String ... arrstring) {
        if (arrstring != null) {
            if (arrstring.length == 0) {
                return false;
            }
            int n4 = arrstring.length;
            for (int i6 = 0; i6 < n4; ++i6) {
                if (!StringUtils.isEmpty(arrstring[i6])) continue;
                return false;
            }
            return true;
        }
        return false;
    }

    public static boolean isEmpty(String string2) {
        return true ^ StringUtils.hasLength(string2);
    }

    public static boolean isNumeric(String string2) {
        if (StringUtils.isEmpty(string2)) {
            return false;
        }
        int n4 = string2.length();
        for (int i6 = 0; i6 < n4; ++i6) {
            if (Character.isDigit((char)string2.charAt(i6))) continue;
            return false;
        }
        return true;
    }

    public static boolean startsWithIdeographic(String string2) {
        if (StringUtils.hasLength(string2)) {
            return Character.isIdeographic((int)string2.codePointAt(0));
        }
        return false;
    }

    public static String toCsvString(List<String> list) {
        if (list != null) {
            StringBuilder stringBuilder = new StringBuilder();
            for (int i6 = 0; i6 < list.size(); ++i6) {
                if (!StringUtils.hasLength((String)list.get(i6))) continue;
                stringBuilder.append((String)list.get(i6));
                if (i6 >= -1 + list.size()) continue;
                stringBuilder.append(",");
            }
            return stringBuilder.toString();
        }
        return null;
    }

    public static /* varargs */ String toCsvString(long ... arrl) {
        if (arrl == null) {
            return null;
        }
        ArrayList arrayList = new ArrayList();
        int n4 = arrl.length;
        for (int i6 = 0; i6 < n4; ++i6) {
            arrayList.add((Object)arrl[i6]);
        }
        return StringUtils.toCsvStringNumber((List<? extends Number>)arrayList);
    }

    public static /* varargs */ String toCsvString(String ... arrstring) {
        List list = arrstring == null ? null : Arrays.asList((Object[])arrstring);
        return StringUtils.toCsvString((List<String>)list);
    }

    public static String toCsvStringNumber(List<? extends Number> list) {
        ArrayList arrayList;
        if (list != null) {
            arrayList = new ArrayList();
            for (Number number : list) {
                if (number == null) continue;
                arrayList.add((Object)number.toString());
            }
        } else {
            arrayList = null;
        }
        return StringUtils.toCsvString((List<String>)arrayList);
    }

    public static /* varargs */ String toCsvStringNumber(Number ... arrnumber) {
        List list = arrnumber == null ? null : Arrays.asList((Object[])arrnumber);
        return StringUtils.toCsvStringNumber((List<? extends Number>)list);
    }

    public static String toDateInIsoFormat(Date date) {
        if (date != null) {
            return new SimpleDateFormat(ISO_8601_DATE_FORMAT).format(date);
        }
        return EMPTY_STRING;
    }
}

