/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.CharSequence
 *  java.lang.Character
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.regex.Matcher
 *  java.util.regex.Pattern
 */
package com.zendesk.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexUtils {
    private static final Pattern QUANTIFIER_PATTERN = Pattern.compile((String)"^\\{\\d{1,},?\\d*\\}");
    private static final String QUANTIFIER_VALIDATION_REGEX = "^\\{\\d{1,},?\\d*\\}";

    private RegexUtils() {
    }

    public static String escape(String string2) {
        if (string2 == null) {
            return "";
        }
        StringBuilder stringBuilder = new StringBuilder();
        char[] arrc = string2.toCharArray();
        for (int i6 = 0; i6 < arrc.length; ++i6) {
            char c5 = arrc[i6];
            if (c5 == '{') {
                String string3 = string2.substring(i6);
                Matcher matcher = QUANTIFIER_PATTERN.matcher((CharSequence)string3);
                String string4 = matcher.find() ? matcher.group() : null;
                if (string4 != null) {
                    stringBuilder.append(string4);
                    i6 += -1 + string4.length();
                    continue;
                }
                stringBuilder.append(Pattern.quote((String)Character.toString((char)c5)));
                continue;
            }
            stringBuilder.append(c5);
        }
        return stringBuilder.toString();
    }
}

