/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Object
 */
package com.zendesk.util;

public class BooleanUtils {
    private BooleanUtils() {
    }

    public static boolean isTrue(Boolean bl2) {
        return Boolean.TRUE.equals((Object)bl2);
    }
}

