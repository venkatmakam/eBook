/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Long
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.Locale
 */
package com.zendesk.util;

import com.zendesk.util.StringUtils;
import java.util.Locale;

public class FileUtils {
    private static final String BINARY_PREFIXES = "KMGTPE";
    private static final int BINARY_UNIT = 1024;
    private static final String SI_PREFIXES = "kMGTPE";
    private static final int SI_UNIT = 1000;

    private FileUtils() {
    }

    public static String getFileExtension(String string2) {
        int n4;
        boolean bl2 = StringUtils.hasLength(string2);
        String string3 = "";
        if (bl2 && (n4 = string2.lastIndexOf(".")) != -1) {
            string3 = string2.substring(n4 + 1).toLowerCase(Locale.US).trim();
        }
        return string3;
    }

    public static String humanReadableFileSize(Long l3) {
        return FileUtils.humanReadableFileSize(l3, true);
    }

    public static String humanReadableFileSize(Long l3, boolean bl2) {
        String string2 = "";
        if (l3 != null && l3 >= 0L) {
            int n4 = bl2 ? 1000 : 1024;
            if (l3 < (long)n4) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append((Object)l3);
                stringBuilder.append(" B");
                return stringBuilder.toString();
            }
            double d7 = Math.log((double)l3.longValue());
            double d8 = n4;
            int n5 = (int)(d7 / Math.log((double)d8));
            StringBuilder stringBuilder = new StringBuilder();
            String string3 = bl2 ? SI_PREFIXES : BINARY_PREFIXES;
            stringBuilder.append(string3.charAt(n5 - 1));
            if (!bl2) {
                string2 = "i";
            }
            stringBuilder.append(string2);
            String string4 = stringBuilder.toString();
            Locale locale = Locale.US;
            Object[] arrobject = new Object[]{(double)l3.longValue() / Math.pow((double)d8, (double)n5), string4};
            return String.format((Locale)locale, (String)"%.1f %sB", (Object[])arrobject);
        }
        return string2;
    }
}

