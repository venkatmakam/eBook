/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.SafeVarargs
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 *  java.util.concurrent.CopyOnWriteArrayList
 */
package com.zendesk.util;

import com.zendesk.func.ZFunc1;
import com.zendesk.func.ZFunc2;
import com.zendesk.util.CollectionUtils;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;

public class CollectionUtils {
    private static final ZFunc1 NOOP_FUNCTION;
    public static final long[] a;

    public static {
        a = new long[0];
        NOOP_FUNCTION = new ZFunc1(){

            public Object apply(Object object) {
                return object;
            }
        };
    }

    private CollectionUtils() {
    }

    public static <Type> List<Type> appendOrReplace(Collection<Type> collection, Type Type, ZFunc2<Type, Type, Boolean> zFunc2) {
        if (collection == null) {
            return new ArrayList(0);
        }
        ArrayList arrayList = new ArrayList(collection);
        boolean bl2 = false;
        for (int i6 = 0; i6 < arrayList.size(); ++i6) {
            if (!zFunc2.apply(arrayList.get(i6), Type).booleanValue()) continue;
            arrayList.set(i6, Type);
            bl2 = true;
        }
        if (!bl2) {
            arrayList.add(Type);
        }
        return arrayList;
    }

    public static <Type, Key> Map<Key, Type> associate(Collection<Type> collection, ZFunc1<Type, Key> zFunc1) {
        if (collection == null) {
            return new HashMap(0);
        }
        HashMap hashMap = new HashMap(collection.size());
        for (Object object : collection) {
            hashMap.put(zFunc1.apply(object), object);
        }
        return hashMap;
    }

    @SafeVarargs
    public static /* varargs */ <Type> List<Type> combineLists(List<Type> ... arrlist) {
        if (arrlist != null && arrlist.length != 0) {
            ArrayList arrayList = new ArrayList();
            for (List list : new CopyOnWriteArrayList((Object[])arrlist)) {
                if (!CollectionUtils.isNotEmpty(list)) continue;
                Iterator iterator = new CopyOnWriteArrayList((Collection)list).iterator();
                while (iterator.hasNext()) {
                    arrayList.add(iterator.next());
                }
            }
            return arrayList;
        }
        return new ArrayList();
    }

    public static <Type> List<Type> copyOf(List<Type> list) {
        if (list == null) {
            return new ArrayList();
        }
        CopyOnWriteArrayList copyOnWriteArrayList = new CopyOnWriteArrayList(list);
        ArrayList arrayList = new ArrayList(copyOnWriteArrayList.size());
        Iterator iterator = copyOnWriteArrayList.iterator();
        while (iterator.hasNext()) {
            arrayList.add(iterator.next());
        }
        return arrayList;
    }

    public static <Key, Value> Map<Key, Value> copyOf(Map<Key, Value> map) {
        if (map == null) {
            return new HashMap();
        }
        Map map2 = Collections.synchronizedMap(map);
        HashMap hashMap = new HashMap();
        hashMap.putAll(map2);
        return hashMap;
    }

    public static <Type> List<Type> ensureEmpty(List<Type> arrayList) {
        if (CollectionUtils.isEmpty(arrayList)) {
            arrayList = new ArrayList();
        }
        return arrayList;
    }

    public static <Type> boolean equalsByContents(Collection<Type> collection, Collection<Type> collection2) {
        if (CollectionUtils.isEmpty(collection)) {
            return CollectionUtils.isEmpty(collection2);
        }
        if (CollectionUtils.isEmpty(collection2)) {
            return false;
        }
        boolean bl2 = collection.containsAll(collection2);
        boolean bl3 = false;
        if (bl2) {
            boolean bl4 = collection2.containsAll(collection);
            bl3 = false;
            if (bl4) {
                bl3 = true;
            }
        }
        return bl3;
    }

    public static <Type> List<Type> filter(Collection<Type> collection, ZFunc1<Type, Boolean> zFunc1) {
        if (collection == null) {
            return new ArrayList(0);
        }
        ArrayList arrayList = new ArrayList(collection.size());
        for (Object object : collection) {
            if (!zFunc1.apply(object).booleanValue()) continue;
            arrayList.add(object);
        }
        return arrayList;
    }

    public static <Key, Value> Map<Key, Value> filter(Map<Key, Value> map, ZFunc2<Key, Value, Boolean> zFunc2) {
        if (map == null) {
            return new HashMap(0);
        }
        HashMap hashMap = new HashMap(map.size());
        for (Map.Entry entry : map.entrySet()) {
            if (!zFunc2.apply(entry.getKey(), entry.getValue()).booleanValue()) continue;
            hashMap.put(entry.getKey(), entry.getValue());
        }
        return hashMap;
    }

    public static <Type> Type findFirst(Collection<Type> collection, ZFunc1<Type, Boolean> zFunc1) {
        if (collection == null) {
            return null;
        }
        for (Object object : collection) {
            if (!zFunc1.apply(object).booleanValue()) continue;
            return (Type)object;
        }
        return null;
    }

    public static <Key, Value> Value getOrDefault(Map<Key, Value> map, Key Key2, Value Value) {
        Object object = map.get(Key2);
        if (object != null) {
            return (Value)object;
        }
        return Value;
    }

    public static <Type, Key> Map<Key, List<Type>> groupingBy(Collection<Type> collection, ZFunc1<Type, Key> zFunc1) {
        if (collection == null) {
            return new HashMap(0);
        }
        HashMap hashMap = new HashMap(collection.size());
        for (Object object : collection) {
            Key Key2 = zFunc1.apply(object);
            List list = (List)hashMap.get(Key2);
            if (list == null) {
                list = new ArrayList();
            }
            list.add(object);
            hashMap.put(Key2, (Object)list);
        }
        return hashMap;
    }

    public static <Type> boolean isEmpty(Collection<Type> collection) {
        return collection == null || collection.isEmpty();
        {
        }
    }

    public static <Type> boolean isEmpty(Type[] arrType) {
        return arrType == null || arrType.length == 0;
        {
        }
    }

    public static <Type> boolean isNotEmpty(Collection<Type> collection) {
        return true ^ CollectionUtils.isEmpty(collection);
    }

    public static <Type> boolean isNotEmpty(Type[] arrType) {
        return true ^ CollectionUtils.isEmpty(arrType);
    }

    public static <Type, Return> List<Return> map(Collection<Type> collection, ZFunc1<Type, Return> zFunc1) {
        if (collection == null) {
            return new ArrayList(0);
        }
        ArrayList arrayList = new ArrayList(collection.size());
        Iterator iterator = collection.iterator();
        while (iterator.hasNext()) {
            arrayList.add(zFunc1.apply(iterator.next()));
        }
        return arrayList;
    }

    public static <Key, Value, ReturnKey, ReturnValue> Map<ReturnKey, ReturnValue> map(Map<Key, Value> map, ZFunc1<Key, ReturnKey> zFunc1, ZFunc1<Value, ReturnValue> zFunc12) {
        if (map == null) {
            return new HashMap(0);
        }
        HashMap hashMap = new HashMap(map.size());
        for (Map.Entry entry : map.entrySet()) {
            hashMap.put(zFunc1.apply(entry.getKey()), zFunc12.apply(entry.getValue()));
        }
        return hashMap;
    }

    public static <Key, Value, ReturnKey, ReturnValue> Map<ReturnKey, ReturnValue> mapKeys(Map<Key, Value> map, ZFunc1<Key, ReturnKey> zFunc1) {
        return CollectionUtils.map(map, zFunc1, NOOP_FUNCTION);
    }

    public static <Key, Value, ReturnKey, ReturnValue> Map<ReturnKey, ReturnValue> mapValues(Map<Key, Value> map, ZFunc1<Value, ReturnValue> zFunc1) {
        return CollectionUtils.map(map, NOOP_FUNCTION, zFunc1);
    }

    public static long[] toPrimitiveLong(Long[] arrlong) {
        if (arrlong == null) {
            return null;
        }
        if (arrlong.length == 0) {
            return a;
        }
        long[] arrl = new long[arrlong.length];
        for (int i6 = 0; i6 < arrlong.length; ++i6) {
            arrl[i6] = arrlong[i6];
        }
        return arrl;
    }

    public static long[] toPrimitiveLong(Long[] arrlong, long l3) {
        if (arrlong == null) {
            return null;
        }
        if (arrlong.length == 0) {
            return a;
        }
        long[] arrl = new long[arrlong.length];
        for (int i6 = 0; i6 < arrlong.length; ++i6) {
            Long l4 = arrlong[i6];
            long l5 = l4 == null ? l3 : l4;
            arrl[i6] = l5;
        }
        return arrl;
    }

    public static <Type> List<Type> unmodifiableList(List<Type> list) {
        return Collections.unmodifiableList(CollectionUtils.ensureEmpty(list));
    }
}

