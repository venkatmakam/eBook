/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.text.DateFormat
 *  java.text.ParseException
 *  java.text.SimpleDateFormat
 *  java.util.Calendar
 *  java.util.Date
 *  java.util.GregorianCalendar
 *  java.util.Locale
 *  java.util.TimeZone
 */
package com.zendesk.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;

public class DateUtils {
    private static final DateFormat ISO_8601_DATE_FORMAT;
    private static final String ISO_8601_PATTERN = "yyyy-MM-dd'T'HH:mm:ssZ";
    private static final TimeZone TIME_ZONE_UTC;

    public static {
        TimeZone timeZone;
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(ISO_8601_PATTERN, Locale.US);
        ISO_8601_DATE_FORMAT = simpleDateFormat;
        TIME_ZONE_UTC = timeZone = TimeZone.getTimeZone((String)"UTC");
        simpleDateFormat.setTimeZone(timeZone);
    }

    private DateUtils() {
    }

    public static Date deserialiseFromISO8601(String string2) {
        try {
            Date date = ISO_8601_DATE_FORMAT.parse(string2);
            return date;
        }
        catch (ParseException parseException) {
            parseException.printStackTrace();
            return null;
        }
    }

    public static Date getBeginOfDay(Date date) {
        Calendar calendar = DateUtils.getCalendar(date);
        calendar.set(11, 0);
        calendar.set(12, 0);
        calendar.set(13, 0);
        calendar.set(14, 0);
        return calendar.getTime();
    }

    private static Calendar getCalendar(Date date) {
        GregorianCalendar gregorianCalendar = new GregorianCalendar(TimeZone.getDefault(), Locale.getDefault());
        gregorianCalendar.setTime(date);
        return gregorianCalendar;
    }

    public static boolean isSameDay(Date date, Date date2) {
        Calendar calendar = DateUtils.getCalendar(date);
        Calendar calendar2 = DateUtils.getCalendar(date2);
        boolean bl2 = calendar.get(1) == calendar2.get(1);
        boolean bl3 = calendar.get(2) == calendar2.get(2);
        boolean bl4 = calendar.get(5) == calendar2.get(5);
        return bl2 && bl3 && bl4;
    }

    public static boolean isToday(Date date) {
        return DateUtils.isSameDay(date, DateUtils.getCalendar(new Date()).getTime());
    }

    public static boolean isYesterday(Date date) {
        Calendar calendar = DateUtils.getCalendar(new Date());
        calendar.add(5, -1);
        return DateUtils.isSameDay(date, calendar.getTime());
    }

    public static String serialiseToISO8601(Date date) {
        return ISO_8601_DATE_FORMAT.format(date);
    }
}

