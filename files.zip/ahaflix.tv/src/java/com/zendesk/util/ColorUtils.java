/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Color
 *  e.a.a.a.a
 *  java.lang.IllegalArgumentException
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 */
package com.zendesk.util;

import android.graphics.Color;
import com.zendesk.logger.Logger;
import com.zendesk.util.StringUtils;
import e.a.a.a.a;

public class ColorUtils {
    public static final String LOG_TAG = "ColorUtils";

    private ColorUtils() {
    }

    public static Integer apiColorToAndroidColor(String string2) {
        if (StringUtils.isEmpty(string2)) {
            Logger.e(LOG_TAG, "The supplied hex value is null or empty, returning null", new Object[0]);
            return null;
        }
        if (!string2.startsWith("#")) {
            string2 = a.h1((String)"#", (String)string2);
        }
        if (string2.length() != 7) {
            Logger.e(LOG_TAG, a.h1((String)"The hex value is malformed, returning null for input: ", (String)string2), new Object[0]);
            return null;
        }
        try {
            Integer n4 = Color.parseColor((String)string2);
            return n4;
        }
        catch (IllegalArgumentException illegalArgumentException) {
            Logger.e(LOG_TAG, illegalArgumentException.getMessage(), illegalArgumentException, new Object[0]);
            return null;
        }
    }
}

