/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Long
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Locale
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.NavigableMap
 *  java.util.TreeMap
 */
package com.zendesk.util;

import java.util.Locale;
import java.util.Map;
import java.util.NavigableMap;
import java.util.TreeMap;

public class NumberFormatUtil {
    private static long MILLION_PRECISION = 1000000L;
    private static final NavigableMap<Long, NumberSuffix> SUFFIXES;

    public static {
        TreeMap treeMap;
        SUFFIXES = treeMap = new TreeMap();
        treeMap.put((Object)1000L, (Object)NumberSuffix.KILO);
        treeMap.put((Object)1000000L, (Object)NumberSuffix.MEGA);
        treeMap.put((Object)1000000000L, (Object)NumberSuffix.GIGA);
        treeMap.put((Object)1000000000000L, (Object)NumberSuffix.TERA);
        treeMap.put((Object)1000000000000000L, (Object)NumberSuffix.PETA);
        treeMap.put((Object)1000000000000000000L, (Object)NumberSuffix.EXA);
    }

    private NumberFormatUtil() {
    }

    public static String format(long l3) {
        return NumberFormatUtil.processValue(l3, null);
    }

    public static String format(long l3, SuffixFormatDelegate suffixFormatDelegate) {
        return NumberFormatUtil.processValue(l3, suffixFormatDelegate);
    }

    private static String formatValue(String string2, NumberSuffix numberSuffix, SuffixFormatDelegate suffixFormatDelegate) {
        String string3 = numberSuffix.getSuffix();
        if (suffixFormatDelegate != null) {
            string3 = suffixFormatDelegate.getSuffix(numberSuffix);
        }
        return String.format((Locale)Locale.US, (String)"%1$s%2$s", (Object[])new Object[]{string2, string3});
    }

    private static String processValue(long l3, SuffixFormatDelegate suffixFormatDelegate) {
        long l4 = l3;
        if (l4 == Long.MIN_VALUE) {
            return NumberFormatUtil.processValue(-9223372036854775807L, suffixFormatDelegate);
        }
        boolean bl2 = true;
        boolean bl3 = l4 < 0L;
        if (bl3) {
            l4 = -l4;
        }
        if (l4 < 1000L) {
            return NumberFormatUtil.formatValue(NumberFormatUtil.stringValue(l4), NumberSuffix.NONE, suffixFormatDelegate);
        }
        Map.Entry entry = SUFFIXES.floorEntry((Object)l4);
        Long l5 = (Long)entry.getKey();
        NumberSuffix numberSuffix = (NumberSuffix)((Object)entry.getValue());
        long l6 = l5 <= MILLION_PRECISION ? (long)Math.ceil((double)((double)l4 / ((double)l5.longValue() / 10.0))) : l4 / (l5 / 10L);
        if (l6 >= 100L || (double)l6 / 10.0 == (double)(l6 / 10L)) {
            bl2 = false;
        }
        double d7 = bl2 ? (double)l6 / 10.0 : (double)(l6 / 10L);
        if (bl3) {
            d7 = -d7;
        }
        return NumberFormatUtil.formatValue(NumberFormatUtil.stringValue(d7), numberSuffix, suffixFormatDelegate);
    }

    private static String stringValue(double d7) {
        if (d7 % 1.0 == 0.0) {
            Locale locale = Locale.US;
            Object[] arrobject = new Object[]{d7};
            return String.format((Locale)locale, (String)"%1.0f", (Object[])arrobject);
        }
        Locale locale = Locale.US;
        Object[] arrobject = new Object[]{d7};
        return String.format((Locale)locale, (String)"%.1f", (Object[])arrobject);
    }

    public static final class NumberSuffix
    extends Enum<NumberSuffix> {
        private static final /* synthetic */ NumberSuffix[] $VALUES;
        public static final /* enum */ NumberSuffix EXA;
        public static final /* enum */ NumberSuffix GIGA;
        public static final /* enum */ NumberSuffix KILO;
        public static final /* enum */ NumberSuffix MEGA;
        public static final /* enum */ NumberSuffix NONE;
        public static final /* enum */ NumberSuffix PETA;
        public static final /* enum */ NumberSuffix TERA;
        private String suffix;

        public static {
            NumberSuffix numberSuffix;
            NumberSuffix numberSuffix2;
            NumberSuffix numberSuffix3;
            NumberSuffix numberSuffix4;
            NumberSuffix numberSuffix5;
            NumberSuffix numberSuffix6;
            NumberSuffix numberSuffix7;
            NONE = numberSuffix7 = new NumberSuffix("");
            KILO = numberSuffix4 = new NumberSuffix("k");
            MEGA = numberSuffix = new NumberSuffix("M");
            GIGA = numberSuffix5 = new NumberSuffix("G");
            TERA = numberSuffix3 = new NumberSuffix("T");
            PETA = numberSuffix6 = new NumberSuffix("P");
            EXA = numberSuffix2 = new NumberSuffix("E");
            $VALUES = new NumberSuffix[]{numberSuffix7, numberSuffix4, numberSuffix, numberSuffix5, numberSuffix3, numberSuffix6, numberSuffix2};
        }

        private NumberSuffix(String string3) {
            this.suffix = string3;
        }

        public static NumberSuffix valueOf(String string2) {
            return (NumberSuffix)Enum.valueOf(NumberSuffix.class, (String)string2);
        }

        public static NumberSuffix[] values() {
            return (NumberSuffix[])$VALUES.clone();
        }

        public String getSuffix() {
            return this.suffix;
        }
    }

    public static interface SuffixFormatDelegate {
        public String getSuffix(NumberSuffix var1);
    }

}

