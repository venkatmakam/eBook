/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.reflect.Constructor
 *  java.lang.reflect.Method
 *  java.util.Arrays
 *  java.util.List
 *  java.util.Locale
 *  java.util.StringTokenizer
 */
package com.zendesk.util;

import com.zendesk.logger.Logger;
import com.zendesk.util.StringUtils;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.StringTokenizer;

public class LocaleUtil {
    private static final String LOG_TAG = "LocaleUtil";
    private static final List<String> NEW_ISO_CODES = Arrays.asList((Object[])new String[]{"he", "yi", "id"});

    private LocaleUtil() {
    }

    private static Locale createIso639Alpha3LocaleAndroid(String string2, String string3) {
        try {
            Class[] arrclass = new Class[]{Boolean.TYPE, String.class, String.class};
            Constructor constructor = Locale.class.getDeclaredConstructor(arrclass);
            constructor.setAccessible(true);
            Object[] arrobject = new Object[]{Boolean.TRUE, string2, string3};
            Locale locale = (Locale)constructor.newInstance(arrobject);
            return locale;
        }
        catch (Exception exception) {
            Logger.e(LOG_TAG, "Unable to create ISO-6390-Alpha3 per reflection", exception, new Object[0]);
            return null;
        }
    }

    private static Locale createIso639Alpha3LocaleJdk(String string2, String string3) {
        try {
            Method method = Locale.class.getDeclaredMethod("createConstant", new Class[]{String.class, String.class});
            method.setAccessible(true);
            Locale locale = (Locale)method.invoke(null, new Object[]{string2, string3});
            return locale;
        }
        catch (Exception exception) {
            Logger.e(LOG_TAG, "Unable to create ISO-6390-Alpha3 per reflection", exception, new Object[0]);
            return null;
        }
    }

    public static Locale forLanguageTag(String string2) {
        String string3 = LOG_TAG;
        Logger.d(string3, "Assuming Locale.getDefault()", new Object[0]);
        Locale locale = Locale.getDefault();
        if (StringUtils.hasLength(string2)) {
            StringTokenizer stringTokenizer = new StringTokenizer(string2, "-");
            int n4 = stringTokenizer.countTokens();
            int n5 = 2;
            boolean bl2 = n4 == 1 || n4 == n5;
            if (bl2) {
                Locale locale2;
                if (n4 != 1) {
                    n5 = 5;
                }
                if (n5 != string2.length()) {
                    Logger.d(string3, "number of tokens is correct but the length of the locale string does not match the expected length", new Object[0]);
                    return locale;
                }
                String string4 = stringTokenizer.nextToken();
                String string5 = stringTokenizer.hasMoreTokens() ? stringTokenizer.nextToken() : "";
                String string6 = string5.toUpperCase(Locale.US);
                if (NEW_ISO_CODES.contains((Object)string4)) {
                    Logger.d(string3, "New ISO-6390-Alpha3 locale detected trying to create new locale per reflection", new Object[0]);
                    locale2 = LocaleUtil.createIso639Alpha3LocaleJdk(string4, string6);
                    if (locale2 == null) {
                        locale2 = LocaleUtil.createIso639Alpha3LocaleAndroid(string4, string6);
                    }
                    if (locale2 == null) {
                        locale2 = new Locale(string4, string6);
                    }
                } else {
                    locale2 = new Locale(string4, string6);
                }
                return locale2;
            }
            Logger.w(string3, "Unexpected number of tokens, must be at least one and at most two", new Object[0]);
        }
        return locale;
    }

    public static String toLanguageTag(Locale locale) {
        if (locale != null) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(locale.getLanguage());
            if (StringUtils.hasLength(locale.getCountry())) {
                stringBuilder.append("-");
                stringBuilder.append(locale.getCountry().toLowerCase(Locale.US));
            }
            return stringBuilder.toString();
        }
        return null;
    }
}

