/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.security.MessageDigest
 *  java.security.NoSuchAlgorithmException
 *  java.util.Locale
 */
package com.zendesk.util;

import com.zendesk.util.StringUtils;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Locale;

public class DigestUtils {
    private static final String MD5 = "MD5";
    private static final String SHA1 = "SHA-1";
    private static final String SHA256 = "SHA-256";
    private static final String SHA384 = "SHA-384";
    private static final String SHA512 = "SHA-512";

    private static byte[] digest(String string2, String string3) {
        if (StringUtils.hasLength(string2) && StringUtils.hasLength(string3)) {
            try {
                MessageDigest messageDigest = MessageDigest.getInstance((String)string2);
                messageDigest.update(string3.getBytes());
                byte[] arrby = messageDigest.digest();
                return arrby;
            }
            catch (NoSuchAlgorithmException noSuchAlgorithmException) {
                return new byte[0];
            }
        }
        return new byte[0];
    }

    private static String hexString(byte[] arrby) {
        StringBuilder stringBuilder = new StringBuilder(2 * arrby.length);
        for (byte by : arrby) {
            Locale locale = Locale.US;
            Object[] arrobject = new Object[]{by & 255};
            stringBuilder.append(String.format((Locale)locale, (String)"%02x", (Object[])arrobject));
        }
        return stringBuilder.toString();
    }

    public static String md5(String string2) {
        if (StringUtils.hasLength(string2)) {
            return DigestUtils.hexString(DigestUtils.digest(MD5, string2));
        }
        return "";
    }

    public static String sha1(String string2) {
        if (StringUtils.hasLength(string2)) {
            return DigestUtils.hexString(DigestUtils.digest(SHA1, string2));
        }
        return "";
    }

    public static String sha256(String string2) {
        if (StringUtils.hasLength(string2)) {
            return DigestUtils.hexString(DigestUtils.digest(SHA256, string2));
        }
        return "";
    }

    public static String sha384(String string2) {
        if (StringUtils.hasLength(string2)) {
            return DigestUtils.hexString(DigestUtils.digest(SHA384, string2));
        }
        return "";
    }

    public static String sha512(String string2) {
        if (StringUtils.hasLength(string2)) {
            return DigestUtils.hexString(DigestUtils.digest(SHA512, string2));
        }
        return "";
    }
}

