/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.zendesk.func;

public interface ZFunc2<Param1, Param2, Return> {
    public Return apply(Param1 var1, Param2 var2);
}

