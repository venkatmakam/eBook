/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.zendesk.func;

public interface ZFunc1<Param1, Return> {
    public Return apply(Param1 var1);
}

