/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.xiaomi.push;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class hx
extends Enum<hx> {
    public static final /* enum */ hx a;
    private static final /* synthetic */ hx[] a;
    public static final /* enum */ hx b;
    public static final /* enum */ hx c;
    public static final /* enum */ hx d;
    private final int a;

    public static {
        hx hx2;
        hx hx3;
        hx hx4;
        hx hx5;
        a = hx2 = new hx(1);
        b = hx3 = new hx(2);
        c = hx5 = new hx(3);
        d = hx4 = new hx(4);
        a = new hx[]{hx2, hx3, hx5, hx4};
    }

    private hx(int n5) {
        this.a = n5;
    }

    public static hx a(int n4) {
        if (n4 != 1) {
            if (n4 != 2) {
                if (n4 != 3) {
                    if (n4 != 4) {
                        return null;
                    }
                    return d;
                }
                return c;
            }
            return b;
        }
        return a;
    }

    public static hx valueOf(String string2) {
        return (hx)Enum.valueOf(hx.class, (String)string2);
    }

    public static hx[] values() {
        return (hx[])a.clone();
    }
}

