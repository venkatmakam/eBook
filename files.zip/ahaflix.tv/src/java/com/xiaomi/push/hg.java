/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.xiaomi.push.fl
 *  com.xiaomi.push.fy
 *  com.xiaomi.push.gh
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.net.UnknownHostException
 *  java.util.Objects
 */
package com.xiaomi.push;

import com.xiaomi.push.fl;
import com.xiaomi.push.fy;
import com.xiaomi.push.gh;
import java.net.UnknownHostException;
import java.util.Objects;

public final class hg {
    private static void a(Exception exception) {
        Objects.requireNonNull((Object)((Object)exception));
    }

    public static a b(Exception exception) {
        gh gh2;
        hg.a(exception);
        if (exception instanceof gh && (gh2 = (gh)exception).a() != null) {
            exception = gh2.a();
        }
        a a2 = new a();
        String string2 = exception.getMessage();
        if (exception.getCause() != null) {
            string2 = exception.getCause().getMessage();
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(exception.getClass().getSimpleName());
        stringBuilder.append(":");
        stringBuilder.append(string2);
        String string3 = stringBuilder.toString();
        int n4 = fy.a((Throwable)exception);
        if (n4 != 0) {
            a2.a = fl.a((int)(n4 + fl.i.a()));
        }
        if (a2.a == null) {
            a2.a = fl.q;
        }
        if (a2.a == fl.q) {
            a2.b = string3;
        }
        return a2;
    }

    public static a c(Exception exception) {
        fl fl2;
        String string2;
        a a2;
        block4 : {
            fl fl3;
            block5 : {
                block3 : {
                    gh gh2;
                    Throwable throwable;
                    fl fl4;
                    hg.a(exception);
                    if (exception instanceof gh && (gh2 = (gh)exception).a() != null) {
                        exception = gh2.a();
                    }
                    a2 = new a();
                    String string3 = exception.getMessage();
                    if (exception.getCause() != null) {
                        string3 = exception.getCause().getMessage();
                    }
                    int n4 = fy.a((Throwable)exception);
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(exception.getClass().getSimpleName());
                    stringBuilder.append(":");
                    stringBuilder.append(string3);
                    string2 = stringBuilder.toString();
                    if (n4 == 0) break block3;
                    a2.a = fl4 = fl.a((int)(n4 + fl.s.a()));
                    if (fl4 != fl.D || (throwable = exception.getCause()) == null || !(throwable instanceof UnknownHostException)) break block4;
                    fl3 = fl.C;
                    break block5;
                }
                fl3 = fl.B;
            }
            a2.a = fl3;
        }
        if ((fl2 = a2.a) == fl.A || fl2 == fl.B || fl2 == fl.D) {
            a2.b = string2;
        }
        return a2;
    }

    public static a d(Exception exception) {
        fl fl2;
        String string2;
        a a2;
        block7 : {
            fl fl3;
            block6 : {
                block3 : {
                    block4 : {
                        String string3;
                        block5 : {
                            gh gh2;
                            hg.a(exception);
                            if (exception instanceof gh && (gh2 = (gh)exception).a() != null) {
                                exception = gh2.a();
                            }
                            a2 = new a();
                            string3 = exception.getMessage();
                            if (exception.getCause() != null) {
                                string3 = exception.getCause().getMessage();
                            }
                            int n4 = fy.a((Throwable)exception);
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append(exception.getClass().getSimpleName());
                            stringBuilder.append(":");
                            stringBuilder.append(string3);
                            string2 = stringBuilder.toString();
                            if (n4 == 105) break block3;
                            if (n4 == 199) break block4;
                            if (n4 == 499) break block5;
                            fl3 = n4 != 109 ? (n4 != 110 ? fl.M : fl.K) : fl.J;
                            break block6;
                        }
                        a2.a = fl.O;
                        if (!string3.startsWith("Terminal binding condition encountered: item-not-found")) break block7;
                        fl3 = fl.N;
                        break block6;
                    }
                    fl3 = fl.L;
                    break block6;
                }
                fl3 = fl.I;
            }
            a2.a = fl3;
        }
        if ((fl2 = a2.a) == fl.L || fl2 == fl.M || fl2 == fl.O) {
            a2.b = string2;
        }
        return a2;
    }

    public static a e(Exception exception) {
        fl fl2;
        String string2;
        a a2;
        block6 : {
            fl fl3;
            block5 : {
                block2 : {
                    block3 : {
                        String string3;
                        block4 : {
                            gh gh2;
                            hg.a(exception);
                            if (exception instanceof gh && (gh2 = (gh)exception).a() != null) {
                                exception = gh2.a();
                            }
                            a2 = new a();
                            string3 = exception.getMessage();
                            int n4 = fy.a((Throwable)exception);
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append(exception.getClass().getSimpleName());
                            stringBuilder.append(":");
                            stringBuilder.append(string3);
                            string2 = stringBuilder.toString();
                            if (n4 == 105) break block2;
                            if (n4 == 199) break block3;
                            if (n4 == 499) break block4;
                            fl3 = n4 != 109 ? (n4 != 110 ? fl.Y : fl.W) : fl.V;
                            break block5;
                        }
                        a2.a = fl.aa;
                        if (!string3.startsWith("Terminal binding condition encountered: item-not-found")) break block6;
                        fl3 = fl.Z;
                        break block5;
                    }
                    fl3 = fl.X;
                    break block5;
                }
                fl3 = fl.U;
            }
            a2.a = fl3;
        }
        if ((fl2 = a2.a) == fl.X || fl2 == fl.Y || fl2 == fl.aa) {
            a2.b = string2;
        }
        return a2;
    }

    public static class a {
        public fl a;
        public String b;
    }

}

