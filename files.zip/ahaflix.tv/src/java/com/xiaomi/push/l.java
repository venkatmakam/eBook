/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.text.TextUtils
 *  com.xiaomi.channel.commonutils.logger.b
 *  com.xiaomi.push.bd
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.HashMap
 *  java.util.Locale
 *  java.util.Map
 */
package com.xiaomi.push;

import android.text.TextUtils;
import com.xiaomi.channel.commonutils.logger.b;
import com.xiaomi.push.bd;
import com.xiaomi.push.o;
import com.xiaomi.push.s;
import com.xiaomi.push.t;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class l {
    private static int a = 0;
    private static Map<String, o> a;
    private static int b = -1;

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static int a() {
        Class<l> class_ = l.class;
        synchronized (l.class) {
            block8 : {
                boolean bl2;
                int n4;
                block9 : {
                    block7 : {
                        block6 : {
                            int n5 = a;
                            if (n5 != 0) return a;
                            try {
                                boolean bl3 = TextUtils.isEmpty((CharSequence)l.a("ro.miui.ui.version.code"));
                                n4 = 1;
                                if (bl3 && TextUtils.isEmpty((CharSequence)l.a("ro.miui.ui.version.name"))) break block6;
                                break block7;
                            }
                            catch (Throwable throwable) {
                                b.a((String)"get isMIUI failed", (Throwable)throwable);
                                a = 0;
                                break block8;
                            }
                        }
                        bl2 = false;
                        break block9;
                    }
                    bl2 = true;
                }
                if (!bl2) {
                    n4 = 2;
                }
                a = n4;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("isMIUI's value is: ");
            stringBuilder.append(a);
            b.b((String)stringBuilder.toString());
            return a;
        }
    }

    public static o a(String string2) {
        o o2 = l.b(string2);
        if (o2 == null) {
            o2 = o.b;
        }
        return o2;
    }

    public static String a() {
        Class<l> class_ = l.class;
        synchronized (l.class) {
            block4 : {
                int n4;
                block5 : {
                    n4 = t.a();
                    if (!l.a() || n4 <= 0) break block4;
                    if (n4 >= 2) break block5;
                    return "alpha";
                }
                if (n4 < 3) {
                    // ** MonitorExit[var2] (shouldn't be in output)
                    return "development";
                }
                // ** MonitorExit[var2] (shouldn't be in output)
                return "stable";
            }
            // ** MonitorExit[var2] (shouldn't be in output)
            return "";
        }
    }

    public static String a(String string2) {
        try {
            String string3 = (String)bd.a((String)"android.os.SystemProperties", (String)"get", (Object[])new Object[]{string2, ""});
            return string3;
        }
        catch (Exception exception) {
            try {
                b.a((Throwable)exception);
            }
            catch (Throwable throwable) {}
        }
        return null;
    }

    private static void a() {
        if (a != null) {
            return;
        }
        HashMap hashMap = new HashMap();
        a = (int)hashMap;
        hashMap.put((Object)"CN", (Object)o.a);
        int n4 = a;
        o o2 = o.c;
        n4.put((Object)"FI", (Object)o2);
        a.put((Object)"SE", (Object)o2);
        a.put((Object)"NO", (Object)o2);
        a.put((Object)"FO", (Object)o2);
        a.put((Object)"EE", (Object)o2);
        a.put((Object)"LV", (Object)o2);
        a.put((Object)"LT", (Object)o2);
        a.put((Object)"BY", (Object)o2);
        a.put((Object)"MD", (Object)o2);
        a.put((Object)"UA", (Object)o2);
        a.put((Object)"PL", (Object)o2);
        a.put((Object)"CZ", (Object)o2);
        a.put((Object)"SK", (Object)o2);
        a.put((Object)"HU", (Object)o2);
        a.put((Object)"DE", (Object)o2);
        a.put((Object)"AT", (Object)o2);
        a.put((Object)"CH", (Object)o2);
        a.put((Object)"LI", (Object)o2);
        a.put((Object)"GB", (Object)o2);
        a.put((Object)"IE", (Object)o2);
        a.put((Object)"NL", (Object)o2);
        a.put((Object)"BE", (Object)o2);
        a.put((Object)"LU", (Object)o2);
        a.put((Object)"FR", (Object)o2);
        a.put((Object)"RO", (Object)o2);
        a.put((Object)"BG", (Object)o2);
        a.put((Object)"RS", (Object)o2);
        a.put((Object)"MK", (Object)o2);
        a.put((Object)"AL", (Object)o2);
        a.put((Object)"GR", (Object)o2);
        a.put((Object)"SI", (Object)o2);
        a.put((Object)"HR", (Object)o2);
        a.put((Object)"IT", (Object)o2);
        a.put((Object)"SM", (Object)o2);
        a.put((Object)"MT", (Object)o2);
        a.put((Object)"ES", (Object)o2);
        a.put((Object)"PT", (Object)o2);
        a.put((Object)"AD", (Object)o2);
        a.put((Object)"CY", (Object)o2);
        a.put((Object)"DK", (Object)o2);
        a.put((Object)"RU", (Object)o.d);
        a.put((Object)"IN", (Object)o.e);
    }

    public static boolean a() {
        Class<l> class_ = l.class;
        synchronized (l.class) {
            boolean bl2;
            block3 : {
                boolean bl3 = l.a();
                bl2 = true;
                if (bl3 == bl2) break block3;
                bl2 = false;
            }
            // ** MonitorExit[var3] (shouldn't be in output)
            return bl2;
        }
    }

    private static o b(String string2) {
        l.a();
        return (o)((Object)a.get((Object)string2.toUpperCase()));
    }

    public static String b() {
        String string2 = s.a("ro.miui.region", "");
        if (TextUtils.isEmpty((CharSequence)string2)) {
            string2 = s.a("persist.sys.oppo.region", "");
        }
        if (TextUtils.isEmpty((CharSequence)string2)) {
            string2 = s.a("ro.oppo.regionmark", "");
        }
        if (TextUtils.isEmpty((CharSequence)string2)) {
            string2 = s.a("ro.hw.country", "");
        }
        if (TextUtils.isEmpty((CharSequence)string2)) {
            string2 = s.a("ro.csc.countryiso_code", "");
        }
        if (TextUtils.isEmpty((CharSequence)string2)) {
            string2 = s.a("ro.product.country.region", "");
        }
        if (TextUtils.isEmpty((CharSequence)string2)) {
            string2 = s.a("gsm.vivo.countrycode", "");
        }
        if (TextUtils.isEmpty((CharSequence)string2)) {
            string2 = s.a("persist.sys.oem.region", "");
        }
        if (TextUtils.isEmpty((CharSequence)string2)) {
            string2 = s.a("ro.product.locale.region", "");
        }
        if (TextUtils.isEmpty((CharSequence)string2)) {
            string2 = s.a("persist.sys.country", "");
        }
        if (!TextUtils.isEmpty((CharSequence)string2)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("get region from system, region = ");
            stringBuilder.append(string2);
            b.a((String)stringBuilder.toString());
        }
        if (TextUtils.isEmpty((CharSequence)string2)) {
            string2 = Locale.getDefault().getCountry();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("locale.default.country = ");
            stringBuilder.append(string2);
            b.a((String)stringBuilder.toString());
        }
        return string2;
    }

    public static boolean b() {
        Class<l> class_ = l.class;
        synchronized (l.class) {
            int n4 = l.a();
            boolean bl2 = n4 == 2;
            return bl2;
        }
    }

    public static boolean c() {
        if (b < 0) {
            Object object = bd.a((String)"miui.external.SdkHelper", (String)"isMiuiSystem", (Object[])new Object[0]);
            b = 0;
            if (object != null && object instanceof Boolean && !((Boolean)Boolean.class.cast(object)).booleanValue()) {
                b = 1;
            }
        }
        return b > 0;
    }

    public static boolean d() {
        return true ^ o.a.name().equalsIgnoreCase(l.a(l.b()).name());
    }
}

