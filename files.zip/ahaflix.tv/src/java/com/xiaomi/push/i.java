/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.content.BroadcastReceiver
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.IntentFilter
 *  android.content.pm.PackageManager
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Environment
 *  android.os.PowerManager
 *  android.os.StatFs
 *  android.provider.Settings
 *  android.provider.Settings$Secure
 *  android.telephony.TelephonyManager
 *  android.text.TextUtils
 *  com.xiaomi.channel.commonutils.logger.b
 *  com.xiaomi.push.ax
 *  com.xiaomi.push.bd
 *  com.xiaomi.push.bi
 *  e.a.a.a.a
 *  java.io.File
 *  java.io.IOException
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.InterruptedException
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Thread
 *  java.lang.Throwable
 *  java.util.Map
 */
package com.xiaomi.push;

import android.annotation.TargetApi;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Environment;
import android.os.PowerManager;
import android.os.StatFs;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import com.xiaomi.channel.commonutils.logger.b;
import com.xiaomi.push.ax;
import com.xiaomi.push.bd;
import com.xiaomi.push.bi;
import com.xiaomi.push.j;
import com.xiaomi.push.l;
import com.xiaomi.push.m;
import com.xiaomi.push.t;
import com.xiaomi.push.u;
import com.xiaomi.push.y;
import e.a.a.a.a;
import java.io.File;
import java.io.IOException;
import java.util.Map;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class i {
    private static String a;
    private static volatile boolean a = false;
    private static final String[] a;
    private static String b = "";
    private static String c;
    private static String d;
    private static final String e;
    private static String f;

    public static {
        e = String.valueOf((char)'\u0002');
        a = new String[]{"--", "a-", "u-", "v-", "o-", "g-"};
        f = null;
        a = false;
    }

    private static double a(double d7) {
        double d8;
        int n4 = 1;
        while ((d8 = (double)n4) < d7) {
            n4 <<= 1;
        }
        return d8;
    }

    private static float a(int n4) {
        float f7 = (float)(1024 * (512 * (1 + (n4 + 102400) / 524288))) / 1024.0f / 1024.0f;
        double d7 = f7;
        if (d7 > 0.5) {
            f7 = (float)Math.ceil((double)d7);
        }
        return f7;
    }

    @TargetApi(value=17)
    public static int a() {
        Object object = bd.a((String)"android.os.UserHandle", (String)"myUserId", (Object[])new Object[0]);
        if (object == null) {
            return -1;
        }
        return (Integer)Integer.class.cast(object);
    }

    private static int a(String string2) {
        boolean bl2 = TextUtils.isEmpty((CharSequence)string2);
        if (bl2) {
            return 0;
        }
        int n4 = string2.length();
        int n5 = 0;
        for (int i6 = 0; i6 < n4; ++i6) {
            n5 = n5 * 31 + string2.charAt(i6);
        }
        return n5;
    }

    private static long a(File file) {
        StatFs statFs = new StatFs(file.getPath());
        return statFs.getBlockCountLong() * statFs.getBlockSizeLong();
    }

    public static String a() {
        int n4 = Build.VERSION.SDK_INT;
        if (n4 < 26) {
            return Build.SERIAL;
        }
        String string2 = null;
        if (n4 >= 26) {
            string2 = (String)bd.a((String)"android.os.Build", (String)"getSerial", null);
        }
        return string2;
    }

    private static String a(int n4) {
        String[] arrstring;
        if (n4 > 0 && n4 < (arrstring = a).length) {
            return arrstring[n4];
        }
        return a[0];
    }

    public static String a(Context context) {
        String string2 = i.e(context);
        StringBuilder stringBuilder = a.F1((String)"a-");
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append(null);
        stringBuilder2.append(string2);
        stringBuilder2.append(null);
        stringBuilder.append(bi.b((String)stringBuilder2.toString()));
        return stringBuilder.toString();
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static String a(Context var0, boolean var1_1) {
        block6 : {
            block4 : {
                block7 : {
                    block5 : {
                        if (i.c != null) return i.c;
                        var2_2 = i.e(var0);
                        var3_3 = !l.d() ? (var1_1 ? i.f(var0) : i.p(var0)) : "";
                        var4_4 = i.a();
                        var5_5 = Build.VERSION.SDK_INT;
                        var6_6 = 1;
                        var7_7 = var5_5 < 26;
                        if (var7_7 || !i.b(var3_3) || !i.b(var4_4)) break block4;
                        var14_8 = ax.a((Context)var0).a();
                        if (TextUtils.isEmpty((CharSequence)var14_8)) break block5;
                        var2_2 = a.h1((String)var14_8, (String)var2_2);
                        var6_6 = 2;
                        break block6;
                    }
                    var15_9 = i.o(var0);
                    if (TextUtils.isEmpty((CharSequence)var15_9)) break block7;
                    var6_6 = 3;
                    ** GOTO lbl23
                }
                var15_9 = ax.a((Context)var0).b();
                if (!TextUtils.isEmpty((CharSequence)var15_9)) {
                    var6_6 = 4;
lbl23: // 2 sources:
                    var2_2 = var15_9;
                } else {
                    var6_6 = 5;
                }
                break block6;
            }
            var2_2 = a.i1((String)var3_3, (String)var2_2, (String)var4_4);
        }
        var8_10 = new StringBuilder();
        var8_10.append("devid rule select:");
        var8_10.append(var6_6);
        b.b((String)var8_10.toString());
        if (var6_6 == 3) {
            i.c = var2_2;
        } else {
            var11_11 = new StringBuilder();
            var11_11.append(i.a(var6_6));
            var11_11.append(bi.b((String)var2_2));
            i.c = var11_11.toString();
        }
        i.b(var0, i.c);
        return i.c;
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static void a(Context context, String string2) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("update vdevid = ");
        stringBuilder.append(string2);
        b.c((String)stringBuilder.toString());
        if (TextUtils.isEmpty((CharSequence)string2)) {
            return;
        }
        i.f = string2;
        u3 = null;
        bl2 = i.c(context);
        u3 = null;
        if (bl2) {
            file = new File(Environment.getExternalStorageDirectory(), "/.vdevdir/");
            bl3 = file.exists();
            u3 = null;
            if (bl3) {
                bl4 = file.isFile();
                u3 = null;
                if (bl4) {
                    file.delete();
                }
            }
            file2 = new File(file, ".vdevid");
            u3 = u.a(context, file2);
            y.a(file2);
            y.a(file2, i.f);
        }
        y.a(new File(context.getFilesDir(), ".vdevid"), i.f);
        if (u3 == null) return;
lbl27: // 2 sources:
        do {
            u3.a();
            return;
            break;
        } while (true);
        {
            catch (Throwable throwable22) {
            }
            catch (IOException iOException) {}
            {
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append("update vdevid failure :");
                stringBuilder2.append(iOException.getMessage());
                b.a((String)stringBuilder2.toString());
                if (u3 == null) return;
                ** continue;
            }
        }
        if (u3 == null) throw throwable22;
        u3.a();
        throw throwable22;
    }

    public static void a(Context context, Map<String, String> map) {
        if (map != null) {
            if (context == null) {
                return;
            }
            String string2 = i.o(context);
            if (!TextUtils.isEmpty((CharSequence)string2)) {
                map.put((Object)"local_virt_devid", (Object)string2);
            }
        }
    }

    public static boolean a(Context context) {
        boolean bl2;
        block2 : {
            block3 : {
                Intent intent = context.registerReceiver(null, new IntentFilter("android.intent.action.BATTERY_CHANGED"));
                bl2 = false;
                if (intent == null) break block2;
                int n4 = intent.getIntExtra("status", -1);
                if (n4 == 2) break block3;
                bl2 = false;
                if (n4 != 5) break block2;
            }
            bl2 = true;
        }
        return bl2;
    }

    public static boolean a(String string2) {
        String[] arrstring;
        if (TextUtils.isEmpty((CharSequence)string2)) {
            return false;
        }
        for (int i6 = 0; i6 < (arrstring = a).length; ++i6) {
            if (!string2.startsWith(arrstring[i6])) continue;
            return true;
        }
        return false;
    }

    /*
     * Exception decompiling
     */
    public static int b() {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Underrun type stack
        // org.benf.cfr.reader.b.a.c.e.a(StackSim.java:35)
        // org.benf.cfr.reader.b.b.af.a(OperationFactoryPop.java:20)
        // org.benf.cfr.reader.b.b.e.a(JVMInstr.java:315)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:195)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    public static String b() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(i.a(i.b()));
        stringBuilder.append("GB");
        return stringBuilder.toString();
    }

    public static String b(Context context) {
        try {
            String string2 = j.a(context).a();
            return string2;
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = a.F1((String)"failure to get gaid:");
            stringBuilder.append(exception.getMessage());
            b.a((String)stringBuilder.toString());
            return null;
        }
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private static void b(Context context, String string2) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("write lvdd = ");
        stringBuilder.append(string2);
        b.c((String)stringBuilder.toString());
        if (TextUtils.isEmpty((CharSequence)string2)) {
            return;
        }
        u3 = null;
        bl2 = i.c(context);
        u3 = null;
        if (bl2) {
            file = new File(Environment.getExternalStorageDirectory(), "/.vdevdir/");
            bl3 = file.exists();
            u3 = null;
            if (bl3) {
                bl4 = file.isFile();
                u3 = null;
                if (bl4) {
                    file.delete();
                }
            }
            file2 = new File(file, ".vdevidlocal");
            bl5 = file2.exists();
            u3 = null;
            if (bl5 && file2.isFile()) {
                b.b((String)"vdr exists, not rewrite.");
                return;
            }
            u3 = u.a(context, file2);
            y.a(file2);
            stringBuilder2 = new StringBuilder();
            stringBuilder2.append(i.c);
            stringBuilder2.append(i.e);
            stringBuilder2.append(i.a(i.c));
            y.a(file2, stringBuilder2.toString());
            b.b((String)"lvdd write succ.");
        } else {
            b.a((String)"not support write lvdd.");
        }
        if (u3 == null) return;
lbl37: // 2 sources:
        do {
            u3.a();
            return;
            break;
        } while (true);
        {
            catch (Throwable throwable22) {
            }
            catch (IOException iOException) {}
            {
                stringBuilder3 = new StringBuilder();
                stringBuilder3.append("write lvdd failure :");
                stringBuilder3.append(iOException.getMessage());
                b.a((String)stringBuilder3.toString());
                if (u3 == null) return;
                ** continue;
            }
        }
        if (u3 == null) throw throwable22;
        u3.a();
        throw throwable22;
    }

    public static boolean b(Context context) {
        PowerManager powerManager = (PowerManager)context.getSystemService("power");
        return powerManager == null || powerManager.isScreenOn();
        {
        }
    }

    private static boolean b(String string2) {
        boolean bl2 = true;
        if (string2 == null) {
            return bl2;
        }
        String string3 = string2.trim();
        if (string3.length() != 0 && !string3.equalsIgnoreCase("null")) {
            if (string3.equalsIgnoreCase("unknown")) {
                return bl2;
            }
            bl2 = false;
        }
        return bl2;
    }

    private static int c() {
        if (Build.VERSION.SDK_INT < 29) {
            return 10;
        }
        return 0;
    }

    public static String c() {
        double d7 = i.a((double)i.a(Environment.getDataDirectory()) / 1024.0 / 1024.0 / 1024.0);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(d7);
        stringBuilder.append("GB");
        return stringBuilder.toString();
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static String c(Context context) {
        String string3;
        Throwable throwable2222;
        boolean bl2 = i.c(context);
        u u3 = null;
        if (!bl2) {
            return null;
        }
        if (!TextUtils.isEmpty((CharSequence)f)) {
            return f;
        }
        f = string3 = y.a(new File(context.getFilesDir(), ".vdevid"));
        if (!TextUtils.isEmpty((CharSequence)string3)) {
            return f;
        }
        File file = new File(new File(Environment.getExternalStorageDirectory(), "/.vdevdir/"), ".vdevid");
        u3 = u.a(context, file);
        f = "";
        String string4 = y.a(file);
        if (string4 != null) {
            f = string4;
        }
        String string2 = f;
        if (u3 == null) return string2;
        u3.a();
        return string2;
        {
            catch (Throwable throwable2222) {
            }
            catch (IOException iOException) {}
            {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("getVDevID failure :");
                stringBuilder.append(iOException.getMessage());
                b.a((String)stringBuilder.toString());
                if (u3 == null) return f;
            }
            u3.a();
            return f;
        }
        if (u3 == null) throw throwable2222;
        u3.a();
        throw throwable2222;
    }

    private static boolean c(Context context) {
        if (!m.a(context, "android.permission.WRITE_EXTERNAL_STORAGE")) {
            return false;
        }
        if (l.a()) {
            return false;
        }
        int n4 = Build.VERSION.SDK_INT;
        boolean bl2 = false;
        if (n4 >= 26) {
            bl2 = true;
        }
        if (!bl2) {
            return t.a(context);
        }
        return bl2;
    }

    private static boolean c(String string2) {
        if (TextUtils.isEmpty((CharSequence)string2)) {
            return false;
        }
        if (string2.length() <= 15) {
            if (string2.length() < 14) {
                return false;
            }
            if (!bi.b((String)string2)) {
                return false;
            }
            return !bi.c((String)string2);
        }
        return false;
    }

    public static String d() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(i.b());
        stringBuilder.append("KB");
        return stringBuilder.toString();
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static String d(Context var0) {
        block15 : {
            block13 : {
                block16 : {
                    block14 : {
                        if (i.c(var0) == false) return null;
                        if (i.a) {
                            return null;
                        }
                        i.a = true;
                        var1_1 = y.a(new File(var0.getFilesDir(), ".vdevid"));
                        var2_2 = new File(new File(Environment.getExternalStorageDirectory(), "/.vdevdir/"), ".vdevid");
                        var5_3 = u.a(var0, var2_2);
                        try {
                            var11_4 = y.a(var2_2);
                            ** if (var5_3 == null) goto lbl-1000
                        }
                        catch (IOException var4_5) {
                            break block14;
                        }
lbl-1000: // 1 sources:
                        {
                            var5_3.a();
                        }
lbl-1000: // 2 sources:
                        {
                            break block13;
                        }
                        catch (Throwable var7_7) {
                            var8_10 = null;
                            break block15;
                        }
                        catch (IOException var3_11) {
                            var4_6 = var3_11;
                            var5_3 = null;
                        }
                    }
                    try {
                        var6_12 = new StringBuilder();
                        var6_12.append("check id failure :");
                        var6_12.append(var4_6.getMessage());
                        b.a((String)var6_12.toString());
                        if (var5_3 == null) break block16;
                    }
                    catch (Throwable var7_8) {
                        var8_10 = var5_3;
                    }
                    var5_3.a();
                }
                var11_4 = null;
            }
            if (TextUtils.isEmpty((CharSequence)var1_1)) {
                b.a((String)"empty local vid");
                return "F*";
            }
            i.f = var1_1;
            if (!TextUtils.isEmpty((CharSequence)var11_4) && var11_4.length() <= 128) {
                if (!TextUtils.equals((CharSequence)var1_1, (CharSequence)var11_4)) {
                    b.a((String)"vid changed, need sync");
                    return var11_4;
                }
            } else {
                var12_13 = new StringBuilder();
                var12_13.append("recover vid :");
                var12_13.append(var11_4);
                b.a((String)var12_13.toString());
                i.a(var0, var1_1);
            }
            var15_14 = a.F1((String)"vdevid = ");
            var15_14.append(i.f);
            var15_14.append(" ");
            var15_14.append(var11_4);
            b.c((String)var15_14.toString());
            return null;
        }
        if (var8_10 == null) throw var7_9;
        var8_10.a();
        throw var7_9;
    }

    private static boolean d(Context context) {
        String string2 = context.getPackageName();
        return context.getPackageManager().checkPermission("android.permission.READ_PHONE_STATE", string2) == 0;
    }

    public static String e() {
        long l3 = i.a(Environment.getDataDirectory());
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(l3 / 1024L);
        stringBuilder.append("KB");
        return stringBuilder.toString();
    }

    public static String e(Context context) {
        try {
            String string2 = Settings.Secure.getString((ContentResolver)context.getContentResolver(), (String)"android_id");
            return string2;
        }
        catch (Throwable throwable) {
            b.a((Throwable)throwable);
            return null;
        }
    }

    public static String f(Context context) {
        int n4 = i.c();
        String string2 = i.g(context);
        while (string2 == null) {
            int n5;
            n5 = n4 - 1;
            if (n4 <= 0) break;
            try {
                Thread.sleep((long)500L);
            }
            catch (InterruptedException interruptedException) {}
            string2 = i.g(context);
            n4 = n5;
        }
        return string2;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static String g(Context context) {
        String string2;
        block8 : {
            Object object;
            block11 : {
                TelephonyManager telephonyManager;
                block10 : {
                    block9 : {
                        if (l.d()) {
                            return "";
                        }
                        String string3 = a;
                        if (string3 != null) {
                            return string3;
                        }
                        try {
                            Object object2;
                            Object object3;
                            string2 = l.a() && (object2 = bd.a((String)"miui.telephony.TelephonyManager", (String)"getDefault", (Object[])new Object[0])) != null && (object3 = bd.a((Object)object2, (String)"getMiuiDeviceId", (Object[])new Object[0])) != null && object3 instanceof String ? (String)String.class.cast(object3) : null;
                        }
                        catch (Throwable throwable) {
                            b.a((Throwable)throwable);
                            return null;
                        }
                        if (string2 != null || !i.d(context)) break block8;
                        telephonyManager = (TelephonyManager)context.getSystemService("phone");
                        if (Build.VERSION.SDK_INT >= 26) break block9;
                        string2 = telephonyManager.getDeviceId();
                        break block8;
                    }
                    if (1 != telephonyManager.getPhoneType()) break block10;
                    object = bd.a((Object)telephonyManager, (String)"getImei", null);
                    break block11;
                }
                if (2 != telephonyManager.getPhoneType()) break block8;
                object = bd.a((Object)telephonyManager, (String)"getMeid", null);
            }
            string2 = (String)object;
        }
        if (i.c(string2)) {
            a = string2;
            return string2;
        }
        return "";
    }

    public static String h(Context context) {
        int n4 = i.c();
        String string2 = i.j(context);
        while (string2 == null) {
            int n5;
            n5 = n4 - 1;
            if (n4 <= 0) break;
            try {
                Thread.sleep((long)500L);
            }
            catch (InterruptedException interruptedException) {}
            string2 = i.j(context);
            n4 = n5;
        }
        return string2;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static String i(Context context) {
        Integer n4;
        String string2;
        TelephonyManager telephonyManager;
        int n5;
        int n6 = Build.VERSION.SDK_INT;
        if (l.d()) {
            return "";
        }
        if (n6 < 22) {
            return "";
        }
        if (!TextUtils.isEmpty((CharSequence)b)) {
            return b;
        }
        if (!i.d(context)) {
            return "";
        }
        i.g(context);
        if (TextUtils.isEmpty((CharSequence)a)) {
            return "";
        }
        try {
            telephonyManager = (TelephonyManager)context.getSystemService("phone");
            n4 = (Integer)bd.a((Object)telephonyManager, (String)"getPhoneCount", (Object[])new Object[0]);
            if (n4 == null) return "";
            if (n4 <= 1) return "";
            string2 = null;
            n5 = 0;
        }
        catch (Exception exception) {
            b.d((String)exception.toString());
            return "";
        }
        do {
            block18 : {
                block13 : {
                    block17 : {
                        Object object;
                        block15 : {
                            block16 : {
                                block14 : {
                                    if (n5 >= n4) break block13;
                                    if (n6 >= 26) break block14;
                                    Object[] arrobject = new Object[]{n5};
                                    object = bd.a((Object)telephonyManager, (String)"getDeviceId", (Object[])arrobject);
                                    break block15;
                                }
                                if (1 != telephonyManager.getPhoneType()) break block16;
                                Object[] arrobject = new Object[]{n5};
                                object = bd.a((Object)telephonyManager, (String)"getImei", (Object[])arrobject);
                                break block15;
                            }
                            if (2 != telephonyManager.getPhoneType()) break block17;
                            Object[] arrobject = new Object[]{n5};
                            object = bd.a((Object)telephonyManager, (String)"getMeid", (Object[])arrobject);
                        }
                        string2 = (String)object;
                    }
                    if (!TextUtils.isEmpty(string2) && !TextUtils.equals((CharSequence)a, string2) && i.c(string2)) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append(b);
                        stringBuilder.append(string2);
                        stringBuilder.append(",");
                        b = stringBuilder.toString();
                    }
                    break block18;
                }
                int n7 = b.length();
                if (n7 <= 0) return b;
                b = b.substring(0, n7 - 1);
                return b;
            }
            ++n5;
        } while (true);
    }

    public static String j(Context context) {
        i.i(context);
        boolean bl2 = TextUtils.isEmpty((CharSequence)b);
        String string2 = "";
        if (bl2) {
            return string2;
        }
        for (String string3 : b.split(",")) {
            if (!i.c(string3)) continue;
            StringBuilder stringBuilder = a.F1((String)string2);
            stringBuilder.append(bi.a((String)string3));
            stringBuilder.append(",");
            string2 = stringBuilder.toString();
        }
        int n4 = string2.length();
        if (n4 > 0) {
            string2 = string2.substring(0, n4 - 1);
        }
        return string2;
    }

    public static String k(Context context) {
        Class<i> class_ = i.class;
        synchronized (i.class) {
            String string2;
            block4 : {
                String string3 = d;
                if (string3 == null) break block4;
                return string3;
            }
            String string4 = i.e(context);
            String string5 = i.a();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(string4);
            stringBuilder.append(string5);
            d = string2 = bi.b((String)stringBuilder.toString());
            // ** MonitorExit[var9_1] (shouldn't be in output)
            return string2;
        }
    }

    public static String l(Context context) {
        Class<i> class_ = i.class;
        synchronized (i.class) {
            String string2 = i.e(context);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(string2);
            stringBuilder.append(null);
            String string3 = bi.b((String)stringBuilder.toString());
            // ** MonitorExit[var7_1] (shouldn't be in output)
            return string3;
        }
    }

    public static String m(Context context) {
        return ((TelephonyManager)context.getSystemService("phone")).getSimOperatorName();
    }

    public static String n(Context context) {
        return "";
    }

    /*
     * Exception decompiling
     */
    private static String o(Context var0) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Underrun type stack
        // org.benf.cfr.reader.b.a.c.e.a(StackSim.java:35)
        // org.benf.cfr.reader.b.b.af.a(OperationFactoryPop.java:20)
        // org.benf.cfr.reader.b.b.e.a(JVMInstr.java:315)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:195)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    private static String p(Context context) {
        int n4 = i.c();
        String string2 = i.g(context);
        while (TextUtils.isEmpty((CharSequence)string2)) {
            int n5;
            n5 = n4 - 1;
            if (n4 <= 0) break;
            try {
                Thread.sleep((long)500L);
            }
            catch (InterruptedException interruptedException) {}
            string2 = i.g(context);
            n4 = n5;
        }
        return string2;
    }
}

