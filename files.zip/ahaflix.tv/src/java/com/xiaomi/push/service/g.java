/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.SystemClock
 *  com.xiaomi.channel.commonutils.logger.b
 *  e.a.a.a.a
 *  java.lang.Class
 *  java.lang.IllegalArgumentException
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Thread
 *  java.lang.Throwable
 *  java.util.Objects
 *  java.util.concurrent.RejectedExecutionException
 */
package com.xiaomi.push.service;

import android.os.SystemClock;
import com.xiaomi.push.service.h;
import java.util.Objects;
import java.util.concurrent.RejectedExecutionException;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class g {
    private static long a;
    private static long b;
    private static long c;
    private final a a;
    private final c a;

    public static {
        long l3;
        long l4 = SystemClock.elapsedRealtime();
        if (l4 > (l3 = 0L)) {
            l3 = SystemClock.elapsedRealtime();
        }
        a = l3;
        b = l3;
    }

    public g() {
        this(false);
    }

    public g(String string2) {
        this(string2, false);
    }

    public g(String string2, boolean bl2) {
        c c5;
        Objects.requireNonNull((Object)string2, (String)"name == null");
        this.a = c5 = new c(string2, bl2);
        this.a = new a(c5);
    }

    public g(boolean bl2) {
        StringBuilder stringBuilder = e.a.a.a.a.F1((String)"Timer-");
        stringBuilder.append(g.b());
        this(stringBuilder.toString(), bl2);
    }

    private static long b() {
        Class<g> class_ = g.class;
        synchronized (g.class) {
            long l3 = c;
            c = 1L + l3;
            // ** MonitorExit[var3] (shouldn't be in output)
            return l3;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void b(b b7, long l3) {
        c c5;
        c c7 = c5 = this.a;
        synchronized (c7) {
            if (this.a.b) {
                throw new IllegalStateException("Timer was canceled");
            }
            long l4 = l3 + g.c();
            if (l4 >= 0L) {
                d d7 = new d();
                d7.f = b7.d;
                d7.e = b7;
                d7.d = l4;
                this.a.a(d7);
                return;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Illegal delay to start the TimerTask: ");
            stringBuilder.append(l4);
            throw new IllegalArgumentException(stringBuilder.toString());
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static long c() {
        Class<g> class_ = g.class;
        synchronized (g.class) {
            long l3 = SystemClock.elapsedRealtime();
            long l4 = b;
            if (l3 > l4) {
                // empty if block
            }
            b = l3;
            return a += l3 - l4;
        }
    }

    public void a() {
        StringBuilder stringBuilder = e.a.a.a.a.F1((String)"quit. finalizer:");
        stringBuilder.append((Object)this.a);
        com.xiaomi.channel.commonutils.logger.b.a((String)stringBuilder.toString());
        this.a.a();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void a(int n4) {
        c c5;
        c c7 = c5 = this.a;
        synchronized (c7) {
            this.a.a.a(n4);
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void a(int n4, b b7) {
        c c5;
        c c7 = c5 = this.a;
        synchronized (c7) {
            this.a.a.a(n4, b7);
            return;
        }
    }

    public void a(b b7) {
        if (com.xiaomi.channel.commonutils.logger.b.a() < 1 && Thread.currentThread() != this.a) {
            com.xiaomi.channel.commonutils.logger.b.d((String)"run job outside job job thread");
            throw new RejectedExecutionException("Run job outside job thread");
        }
        b7.run();
    }

    public void a(b b7, long l3) {
        if (l3 >= 0L) {
            this.b(b7, l3);
            return;
        }
        throw new IllegalArgumentException(e.a.a.a.a.a1((String)"delay < 0: ", (long)l3));
    }

    public boolean a() {
        return this.a.a();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public boolean a(int n4) {
        c c5;
        c c7 = c5 = this.a;
        synchronized (c7) {
            return this.a.a.a(n4);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void b() {
        c c5;
        c c7 = c5 = this.a;
        synchronized (c7) {
            this.a.a.a();
            return;
        }
    }

    public static final class a {
        private final c a;

        public a(c c5) {
            this.a = c5;
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         * Converted monitor instructions to comments
         * Lifted jumps to return sites
         */
        public void finalize() {
            try {
                c c5;
                c c7 = c5 = this.a;
                // MONITORENTER : c7
            }
            catch (Throwable throwable) {
                super.finalize();
                throw throwable;
            }
            this.a.c = true;
            this.a.notify();
            // MONITOREXIT : c7
            super.finalize();
        }
    }

    public static abstract class b
    implements Runnable {
        public int d;

        public b(int n4) {
            this.d = n4;
        }
    }

    /*
     * Duplicate member names - consider using --renamedupmembers true
     */
    public static final class c
    extends Thread {
        private volatile long a;
        private a a;
        private volatile boolean a = new a(null);
        private long b;
        private boolean b = 50L;
        private boolean c;

        public c(String string2, boolean bl2) {
            this.setName(string2);
            this.setDaemon(bl2);
            this.start();
        }

        private void a(d d7) {
            this.a.a(d7);
            this.notify();
        }

        public void a() {
            c c5 = this;
            synchronized (c5) {
                this.b = true;
                this.a.a();
                this.notify();
                return;
            }
        }

        public boolean a() {
            return this.a && SystemClock.uptimeMillis() - this.a > 600000L;
        }

        /*
         * Exception decompiling
         */
        public void run() {
            // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
            // org.benf.cfr.reader.util.ConfusedCFRException: Underrun type stack
            // org.benf.cfr.reader.b.a.c.e.a(StackSim.java:35)
            // org.benf.cfr.reader.b.b.af.a(OperationFactoryPop.java:20)
            // org.benf.cfr.reader.b.b.e.a(JVMInstr.java:315)
            // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:195)
            // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
            // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
            // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
            // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
            // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
            // org.benf.cfr.reader.entities.g.p(Method.java:396)
            // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
            // org.benf.cfr.reader.entities.d.c(ClassFile.java:773)
            // org.benf.cfr.reader.entities.d.e(ClassFile.java:870)
            // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
            // org.benf.cfr.reader.b.a(Driver.java:128)
            // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
            // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
            // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
            // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
            // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
            // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
            // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
            // java.lang.Thread.run(Thread.java:923)
            throw new IllegalStateException("Decompilation failed");
        }

        /*
         * Duplicate member names - consider using --renamedupmembers true
         */
        public static final class a {
            private int a;
            private d[] a = new d[256];
            private int b = 0;
            private int c = 0;

            private a() {
            }

            public /* synthetic */ a(h h2) {
                this();
            }

            public static /* synthetic */ int a(a a2, d d7) {
                return a2.a(d7);
            }

            private int a(d d7) {
                d[] arrd;
                for (int i6 = 0; i6 < (arrd = this.a).length; ++i6) {
                    if (arrd[i6] != d7) continue;
                    return i6;
                }
                return -1;
            }

            private void c() {
                int n4 = -1 + this.b;
                int n5 = (n4 - 1) / 2;
                do {
                    d[] arrd = this.a;
                    if (arrd[n4].d >= arrd[n5].d) break;
                    d d7 = arrd[n4];
                    arrd[n4] = arrd[n5];
                    arrd[n5] = d7;
                    int n6 = (n5 - 1) / 2;
                    int n7 = n5;
                    n5 = n6;
                    n4 = n7;
                } while (true);
            }

            private void c(int n4) {
                int n5;
                int n6 = 1 + n4 * 2;
                while (n6 < (n5 = this.b) && n5 > 0) {
                    int n7 = n6 + 1;
                    if (n7 < n5) {
                        d[] arrd = this.a;
                        if (arrd[n7].d < arrd[n6].d) {
                            n6 = n7;
                        }
                    }
                    d[] arrd = this.a;
                    if (arrd[n4].d < arrd[n6].d) {
                        return;
                    }
                    d d7 = arrd[n4];
                    arrd[n4] = arrd[n6];
                    arrd[n6] = d7;
                    int n8 = 1 + n6 * 2;
                    int n9 = n6;
                    n6 = n8;
                    n4 = n9;
                }
            }

            public d a() {
                return this.a[0];
            }

            public void a() {
                this.a = new d[this.a];
                this.b = 0;
            }

            public void a(int n4) {
                for (int i6 = 0; i6 < this.b; ++i6) {
                    d[] arrd = this.a;
                    if (arrd[i6].f != n4) continue;
                    arrd[i6].a();
                }
                this.b();
            }

            public void a(int n4, b b7) {
                for (int i6 = 0; i6 < this.b; ++i6) {
                    d[] arrd = this.a;
                    if (arrd[i6].e != b7) continue;
                    arrd[i6].a();
                }
                this.b();
            }

            public void a(d d7) {
                d[] arrd = this.a;
                int n4 = arrd.length;
                int n5 = this.b;
                if (n4 == n5) {
                    d[] arrd2 = new d[n5 * 2];
                    System.arraycopy((Object)arrd, (int)0, (Object)arrd2, (int)0, (int)n5);
                    this.a = arrd2;
                }
                d[] arrd3 = this.a;
                int n6 = this.b;
                this.b = n6 + 1;
                arrd3[n6] = d7;
                this.c();
            }

            public boolean a() {
                return this.b == 0;
            }

            public boolean a(int n4) {
                for (int i6 = 0; i6 < this.b; ++i6) {
                    if (this.a[i6].f != n4) continue;
                    return true;
                }
                return false;
            }

            public void b() {
                for (int i6 = 0; i6 < this.b; ++i6) {
                    if (!this.a[i6].c) continue;
                    this.c = 1 + this.c;
                    this.b(i6);
                    --i6;
                }
            }

            public void b(int n4) {
                int n5;
                if (n4 >= 0 && n4 < (n5 = this.b)) {
                    int n6;
                    d[] arrd = this.a;
                    this.b = n6 = n5 - 1;
                    arrd[n4] = arrd[n6];
                    arrd[n6] = null;
                    this.c(n4);
                }
            }
        }

    }

    public static class d {
        public final Object a = new Object();
        private long b;
        public boolean c;
        public long d;
        public b e;
        public int f;

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        public void a(long l3) {
            Object object;
            Object object2 = object = this.a;
            synchronized (object2) {
                this.b = l3;
                return;
            }
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        public boolean a() {
            Object object;
            Object object2 = object = this.a;
            synchronized (object2) {
                boolean bl2 = !this.c && this.d > 0L;
                this.c = true;
                return bl2;
            }
        }
    }

}

