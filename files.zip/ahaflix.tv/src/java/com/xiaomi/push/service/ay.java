/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.xiaomi.push.service;

public abstract class ay {
    public static String a = "com.xiaomi.xmsf.push.UNINSTALL";
    public static String b = "com.xiaomi.xmsf.push.PACKAGE_DATA_CLEARED";
}

