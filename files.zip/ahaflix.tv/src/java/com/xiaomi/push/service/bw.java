/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.xiaomi.push.service.l
 *  com.xiaomi.push.service.l$a
 *  java.lang.Object
 */
package com.xiaomi.push.service;

import com.xiaomi.push.service.XMPushService;
import com.xiaomi.push.service.l;

public class bw
implements l.a {
    public final /* synthetic */ XMPushService.i a;
    public final /* synthetic */ XMPushService b;

    public bw(XMPushService xMPushService, XMPushService.i i5) {
        this.b = xMPushService;
        this.a = i5;
    }

    public void a() {
        this.b.a(this.a);
    }
}

