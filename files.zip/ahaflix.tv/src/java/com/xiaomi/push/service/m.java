/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.text.TextUtils
 *  com.xiaomi.push.bi
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.List
 */
package com.xiaomi.push.service;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;
import com.xiaomi.push.bi;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class m {
    private static m a;
    private Context a;
    private List<String> a = new ArrayList();
    private final List<String> b = new ArrayList();
    private final List<String> c = new ArrayList();

    private m(Context context) {
        Context context2;
        this.a = context2 = context.getApplicationContext();
        if (context2 == null) {
            this.a = context;
        }
        Context context3 = this.a;
        int n4 = 0;
        SharedPreferences sharedPreferences = context3.getSharedPreferences("mipush_app_info", 0);
        for (String string2 : sharedPreferences.getString("unregistered_pkg_names", "").split(",")) {
            if (!TextUtils.isEmpty((CharSequence)string2)) continue;
            this.a.add((Object)string2);
        }
        for (String string3 : sharedPreferences.getString("disable_push_pkg_names", "").split(",")) {
            if (TextUtils.isEmpty((CharSequence)string3)) continue;
            this.b.add((Object)string3);
        }
        String[] arrstring = sharedPreferences.getString("disable_push_pkg_names_cache", "").split(",");
        int n5 = arrstring.length;
        while (n4 < n5) {
            String string4 = arrstring[n4];
            if (!TextUtils.isEmpty((CharSequence)string4)) {
                this.c.add((Object)string4);
            }
            ++n4;
        }
    }

    public static m a(Context context) {
        if (a == null) {
            a = new m(context);
        }
        return a;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void a(String string2) {
        m m4;
        m m5 = m4 = this.a;
        synchronized (m5) {
            if (!this.a.contains((Object)string2)) {
                this.a.add((Object)string2);
                String string3 = bi.a((Collection)this.a, (String)",");
                this.a.getSharedPreferences("mipush_app_info", 0).edit().putString("unregistered_pkg_names", string3).commit();
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public boolean a(String string2) {
        m m4;
        m m5 = m4 = this.a;
        synchronized (m5) {
            return this.a.contains((Object)string2);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void b(String string2) {
        List<String> list;
        List<String> list2 = list = this.b;
        synchronized (list2) {
            if (!this.b.contains((Object)string2)) {
                this.b.add((Object)string2);
                String string3 = bi.a(this.b, (String)",");
                this.a.getSharedPreferences("mipush_app_info", 0).edit().putString("disable_push_pkg_names", string3).commit();
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public boolean b(String string2) {
        List<String> list;
        List<String> list2 = list = this.b;
        synchronized (list2) {
            return this.b.contains((Object)string2);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void c(String string2) {
        List<String> list;
        List<String> list2 = list = this.c;
        synchronized (list2) {
            if (!this.c.contains((Object)string2)) {
                this.c.add((Object)string2);
                String string3 = bi.a(this.c, (String)",");
                this.a.getSharedPreferences("mipush_app_info", 0).edit().putString("disable_push_pkg_names_cache", string3).commit();
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public boolean c(String string2) {
        List<String> list;
        List<String> list2 = list = this.c;
        synchronized (list2) {
            return this.c.contains((Object)string2);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void d(String string2) {
        m m4;
        m m5 = m4 = this.a;
        synchronized (m5) {
            if (this.a.contains((Object)string2)) {
                this.a.remove((Object)string2);
                String string3 = bi.a((Collection)this.a, (String)",");
                this.a.getSharedPreferences("mipush_app_info", 0).edit().putString("unregistered_pkg_names", string3).commit();
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void e(String string2) {
        List<String> list;
        List<String> list2 = list = this.b;
        synchronized (list2) {
            if (this.b.contains((Object)string2)) {
                this.b.remove((Object)string2);
                String string3 = bi.a(this.b, (String)",");
                this.a.getSharedPreferences("mipush_app_info", 0).edit().putString("disable_push_pkg_names", string3).commit();
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void f(String string2) {
        List<String> list;
        List<String> list2 = list = this.c;
        synchronized (list2) {
            if (this.c.contains((Object)string2)) {
                this.c.remove((Object)string2);
                String string3 = bi.a(this.c, (String)",");
                this.a.getSharedPreferences("mipush_app_info", 0).edit().putString("disable_push_pkg_names_cache", string3).commit();
            }
            return;
        }
    }
}

