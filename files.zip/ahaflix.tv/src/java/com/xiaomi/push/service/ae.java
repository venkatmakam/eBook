/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.util.Iterator
 *  java.util.List
 */
package com.xiaomi.push.service;

import com.xiaomi.push.hk;
import com.xiaomi.push.service.ad;
import java.util.Iterator;
import java.util.List;

public final class ae
implements Runnable {
    public final /* synthetic */ List a;
    public final /* synthetic */ boolean b;

    public ae(List list, boolean bl2) {
        this.a = list;
        this.b = bl2;
    }

    public void run() {
        int n4;
        boolean bl2 = ad.c("www.baidu.com:80");
        Iterator iterator = this.a.iterator();
        do {
            boolean bl3 = iterator.hasNext();
            n4 = 1;
            if (!bl3) break;
            String string2 = (String)iterator.next();
            if (!bl2 && !ad.c(string2)) {
                bl2 = false;
                continue;
            }
            bl2 = true;
        } while (!bl2 || this.b);
        if (!bl2) {
            n4 = 2;
        }
        hk.a(n4);
    }
}

