/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.xiaomi.channel.commonutils.logger.b
 *  com.xiaomi.push.eo
 *  com.xiaomi.push.eo$b
 *  com.xiaomi.push.fx
 *  com.xiaomi.push.ga
 *  com.xiaomi.push.service.bf
 *  e.a.a.a.a
 *  java.lang.Exception
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.Map
 */
package com.xiaomi.push.service;

import com.xiaomi.channel.commonutils.logger.b;
import com.xiaomi.push.eo;
import com.xiaomi.push.fx;
import com.xiaomi.push.ga;
import com.xiaomi.push.service.XMPushService;
import com.xiaomi.push.service.bf;
import e.a.a.a.a;
import java.util.Map;

public class br
extends fx {
    public br(XMPushService xMPushService, Map map, int n5, String string, ga ga2) {
        super(null, n5, string, null);
    }

    public byte[] a() {
        try {
            eo.b b5 = new eo.b();
            b5.a(bf.a().f());
            byte[] arrby = b5.a();
            return arrby;
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = a.F1((String)"getOBBString err: ");
            stringBuilder.append(exception.toString());
            b.a((String)stringBuilder.toString());
            return null;
        }
    }
}

