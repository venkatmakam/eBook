/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.database.ContentObserver
 *  android.os.Handler
 *  com.xiaomi.channel.commonutils.logger.b
 *  com.xiaomi.push.service.XMPushService$f
 *  java.lang.Exception
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.xiaomi.push.service;

import android.database.ContentObserver;
import android.os.Handler;
import com.xiaomi.channel.commonutils.logger.b;
import com.xiaomi.push.service.XMPushService;

/*
 * Exception performing whole class analysis.
 */
public class bt
extends ContentObserver {
    public final /* synthetic */ XMPushService a;

    public bt(XMPushService xMPushService, Handler handler) {
        this.a = xMPushService;
        super(handler);
    }

    public void onChange(boolean bl2) {
        super.onChange(bl2);
        boolean bl3 = XMPushService.p(this.a);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("ExtremePowerMode:");
        stringBuilder.append(bl3);
        b.a((String)stringBuilder.toString());
        if (bl3) {
            XMPushService xMPushService = this.a;
            xMPushService.a((XMPushService.i)new /* Unavailable Anonymous Inner Class!! */);
            return;
        }
        this.a.a(true);
    }
}

