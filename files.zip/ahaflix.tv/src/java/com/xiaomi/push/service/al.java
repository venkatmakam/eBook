/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.util.Pair
 *  com.xiaomi.channel.commonutils.logger.b
 *  com.xiaomi.push.ad
 *  com.xiaomi.push.bf
 *  e.a.a.a.a
 *  java.lang.Boolean
 *  java.lang.Class
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.util.Collection
 *  java.util.HashSet
 *  java.util.Iterator
 *  java.util.List
 */
package com.xiaomi.push.service;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Pair;
import com.xiaomi.channel.commonutils.logger.b;
import com.xiaomi.push.ad;
import com.xiaomi.push.bf;
import com.xiaomi.push.hv;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class al {
    private static volatile al a;
    private HashSet<a> a = new HashSet();
    public SharedPreferences b;

    private al(Context context) {
        this.b = context.getSharedPreferences("mipush_oc", 0);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static al a(Context context) {
        if (a != null) return a;
        Class<al> class_ = al.class;
        synchronized (al.class) {
            if (a != null) return a;
            a = new al(context);
            // ** MonitorExit[var2_1] (shouldn't be in output)
            return a;
        }
    }

    private String a(int n4) {
        return e.a.a.a.a.V0((String)"normal_oc_", (int)n4);
    }

    private void a(SharedPreferences.Editor editor, Pair<Integer, Object> pair, String string2) {
        Object object = pair.second;
        if (object instanceof Integer) {
            editor.putInt(string2, ((Integer)object).intValue());
            return;
        }
        if (object instanceof Long) {
            editor.putLong(string2, ((Long)object).longValue());
            return;
        }
        if (object instanceof String) {
            String string3 = (String)object;
            if (string2.equals((Object)this.a(hv.aQ.a()))) {
                string3 = bf.a((String)string3);
            }
            editor.putString(string2, string3);
            return;
        }
        if (object instanceof Boolean) {
            editor.putBoolean(string2, ((Boolean)object).booleanValue());
        }
    }

    private String b(int n4) {
        return e.a.a.a.a.V0((String)"custom_oc_", (int)n4);
    }

    public int a(int n4, int n5) {
        String string2 = this.b(n4);
        if (this.b.contains(string2)) {
            return this.b.getInt(string2, 0);
        }
        String string3 = this.a(n4);
        if (this.b.contains(string3)) {
            return this.b.getInt(string3, 0);
        }
        return n5;
    }

    public String a(int n4, String string2) {
        String string3 = this.b(n4);
        if (this.b.contains(string3)) {
            return this.b.getString(string3, null);
        }
        String string4 = this.a(n4);
        if (this.b.contains(string4)) {
            return this.b.getString(string4, null);
        }
        return string2;
    }

    public void a() {
        al al2 = this;
        synchronized (al2) {
            this.a.clear();
            return;
        }
    }

    public void a(a a2) {
        al al2 = this;
        synchronized (al2) {
            if (!this.a.contains((Object)a2)) {
                this.a.add((Object)a2);
            }
            return;
        }
    }

    public void a(List<Pair<Integer, Object>> list) {
        if (ad.a(list)) {
            return;
        }
        SharedPreferences.Editor editor = this.b.edit();
        for (Pair pair : list) {
            Object object = pair.first;
            if (object == null || pair.second == null) continue;
            this.a(editor, (Pair<Integer, Object>)pair, this.a((Integer)object));
        }
        editor.commit();
    }

    public boolean a(int n4, boolean bl2) {
        String string2 = this.b(n4);
        if (this.b.contains(string2)) {
            return this.b.getBoolean(string2, false);
        }
        String string3 = this.a(n4);
        if (this.b.contains(string3)) {
            return this.b.getBoolean(string3, false);
        }
        return bl2;
    }

    public void b(List<Pair<Integer, Object>> list) {
        if (ad.a(list)) {
            return;
        }
        SharedPreferences.Editor editor = this.b.edit();
        for (Pair pair : list) {
            Object object = pair.first;
            if (object == null) continue;
            String string2 = this.b((Integer)object);
            if (pair.second == null) {
                editor.remove(string2);
                continue;
            }
            this.a(editor, (Pair<Integer, Object>)pair, string2);
        }
        editor.commit();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void c() {
        b.c((String)"OC_Callback : receive new oc data");
        HashSet hashSet = new HashSet();
        al al2 = this;
        synchronized (al2) {
            hashSet.addAll((Collection)this.a);
        }
        Iterator iterator = hashSet.iterator();
        do {
            if (!iterator.hasNext()) {
                hashSet.clear();
                return;
            }
            a a2 = (a)iterator.next();
            if (a2 == null) continue;
            a2.run();
        } while (true);
    }

    public static abstract class a
    implements Runnable {
        private String mDescription;
        private int mId;

        public a(int n4, String string2) {
            this.mId = n4;
            this.mDescription = string2;
        }

        public boolean equals(Object object) {
            boolean bl2 = object instanceof a;
            boolean bl3 = false;
            if (bl2) {
                int n4 = this.mId;
                int n5 = ((a)object).mId;
                bl3 = false;
                if (n4 == n5) {
                    bl3 = true;
                }
            }
            return bl3;
        }

        public int hashCode() {
            return this.mId;
        }

        public abstract void onCallback();

        public final void run() {
            this.onCallback();
        }
    }

}

