/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.annotation.SuppressLint
 *  android.annotation.TargetApi
 *  android.app.ActivityManager
 *  android.app.ActivityManager$RunningAppProcessInfo
 *  android.app.Notification
 *  android.app.Notification$BigPictureStyle
 *  android.app.Notification$BigTextStyle
 *  android.app.Notification$Builder
 *  android.app.Notification$Style
 *  android.app.NotificationChannel
 *  android.app.PendingIntent
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.content.SharedPreferences
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.content.pm.ResolveInfo
 *  android.content.res.Resources
 *  android.graphics.Bitmap
 *  android.graphics.Bitmap$Config
 *  android.graphics.Canvas
 *  android.graphics.Color
 *  android.graphics.drawable.BitmapDrawable
 *  android.graphics.drawable.Drawable
 *  android.graphics.drawable.Icon
 *  android.media.AudioAttributes
 *  android.net.Uri
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.os.Parcelable
 *  android.text.TextUtils
 *  android.util.DisplayMetrics
 *  android.util.Pair
 *  android.widget.RemoteViews
 *  com.xiaomi.channel.commonutils.logger.b
 *  com.xiaomi.push.ai
 *  com.xiaomi.push.ai$a
 *  com.xiaomi.push.bd
 *  com.xiaomi.push.ff
 *  com.xiaomi.push.g
 *  com.xiaomi.push.g$a
 *  com.xiaomi.push.id
 *  com.xiaomi.push.im
 *  e.a.a.a.a
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Float
 *  java.lang.Integer
 *  java.lang.InterruptedException
 *  java.lang.NumberFormatException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Throwable
 *  java.lang.reflect.Constructor
 *  java.lang.reflect.Field
 *  java.lang.reflect.Method
 *  java.net.MalformedURLException
 *  java.net.URISyntaxException
 *  java.net.URL
 *  java.text.SimpleDateFormat
 *  java.util.Arrays
 *  java.util.Collection
 *  java.util.Date
 *  java.util.Iterator
 *  java.util.LinkedList
 *  java.util.List
 *  java.util.Map
 *  java.util.concurrent.Callable
 *  java.util.concurrent.ExecutionException
 *  java.util.concurrent.ExecutorService
 *  java.util.concurrent.Executors
 *  java.util.concurrent.Future
 *  java.util.concurrent.TimeUnit
 *  java.util.concurrent.TimeoutException
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.xiaomi.push.service;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.ActivityManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Icon;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Pair;
import android.widget.RemoteViews;
import com.xiaomi.push.ai;
import com.xiaomi.push.bd;
import com.xiaomi.push.ff;
import com.xiaomi.push.g;
import com.xiaomi.push.hq;
import com.xiaomi.push.hv;
import com.xiaomi.push.id;
import com.xiaomi.push.im;
import com.xiaomi.push.l;
import com.xiaomi.push.service.ab;
import com.xiaomi.push.service.ag;
import com.xiaomi.push.service.ai;
import com.xiaomi.push.service.aj;
import com.xiaomi.push.service.ak;
import com.xiaomi.push.service.al;
import com.xiaomi.push.service.au;
import com.xiaomi.push.service.bj;
import com.xiaomi.push.service.f;
import com.xiaomi.push.t;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import org.json.JSONException;
import org.json.JSONObject;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class aa {
    public static long a = (long)new LinkedList();
    private static final LinkedList<Pair<Integer, im>> a;
    private static ExecutorService a;
    public static final /* synthetic */ int b;

    public static {
        a = Executors.newCachedThreadPool();
    }

    private static int a(Context context, String string2, String string3) {
        if (string2.equals((Object)context.getPackageName())) {
            return context.getResources().getIdentifier(string3, "drawable", string2);
        }
        return 0;
    }

    /*
     * Exception decompiling
     */
    private static int a(Map<String, String> var0) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Underrun type stack
        // org.benf.cfr.reader.b.a.c.e.a(StackSim.java:35)
        // org.benf.cfr.reader.b.b.af.a(OperationFactoryPop.java:20)
        // org.benf.cfr.reader.b.b.e.a(JVMInstr.java:315)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:195)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    @TargetApi(value=16)
    private static Notification.Builder a(Notification.Builder builder, Context context, String string2, Map<String, String> map) {
        PendingIntent pendingIntent;
        PendingIntent pendingIntent2;
        PendingIntent pendingIntent3 = aa.a(context, string2, 1, map);
        if (pendingIntent3 != null && !TextUtils.isEmpty((CharSequence)((CharSequence)map.get((Object)"notification_style_button_left_name")))) {
            builder.addAction(0, (CharSequence)map.get((Object)"notification_style_button_left_name"), pendingIntent3);
        }
        if ((pendingIntent2 = aa.a(context, string2, 2, map)) != null && !TextUtils.isEmpty((CharSequence)((CharSequence)map.get((Object)"notification_style_button_mid_name")))) {
            builder.addAction(0, (CharSequence)map.get((Object)"notification_style_button_mid_name"), pendingIntent2);
        }
        if ((pendingIntent = aa.a(context, string2, 3, map)) != null && !TextUtils.isEmpty((CharSequence)((CharSequence)map.get((Object)"notification_style_button_right_name")))) {
            builder.addAction(0, (CharSequence)map.get((Object)"notification_style_button_right_name"), pendingIntent);
        }
        return builder;
    }

    @TargetApi(value=16)
    private static Notification.Builder a(Context context, Map<String, String> map, Notification.Builder builder, String string2) {
        if ("2".equals(map.get((Object)"notification_style_type"))) {
            Bitmap bitmap = aa.a(context, (String)map.get((Object)"notification_bigPic_uri"), false);
            if (bitmap == null) {
                com.xiaomi.channel.commonutils.logger.b.a((String)"can not get big picture.");
                return builder;
            }
            Notification.BigPictureStyle bigPictureStyle = new Notification.BigPictureStyle(builder);
            bigPictureStyle.bigPicture(bitmap);
            bigPictureStyle.setSummaryText((CharSequence)string2);
            bigPictureStyle.bigLargeIcon(null);
            builder.setStyle((Notification.Style)bigPictureStyle);
            return builder;
        }
        if ("1".equals(map.get((Object)"notification_style_type"))) {
            builder.setStyle((Notification.Style)new Notification.BigTextStyle().bigText((CharSequence)string2));
        }
        return builder;
    }

    private static Notification a(Notification notification) {
        Object object = bd.a((Object)notification, (String)"extraNotification");
        if (object != null) {
            Object[] arrobject = new Object[]{Boolean.TRUE};
            bd.a((Object)object, (String)"setCustomizedIcon", (Object[])arrobject);
        }
        return notification;
    }

    private static Notification a(Notification notification, String string2) {
        try {
            Field field = Notification.class.getDeclaredField("extraNotification");
            field.setAccessible(true);
            Object object = field.get((Object)notification);
            Method method = object.getClass().getDeclaredMethod("setTargetPkg", new Class[]{CharSequence.class});
            method.setAccessible(true);
            method.invoke(object, new Object[]{string2});
            return notification;
        }
        catch (Exception exception) {
            com.xiaomi.channel.commonutils.logger.b.a((Throwable)exception);
            return notification;
        }
    }

    private static PendingIntent a(Context context, im im2, id id2, byte[] arrby, int n4) {
        ComponentName componentName;
        Intent intent;
        int n5 = aa.c(im2) ? 1000 : (aa.a(im2) ? 3000 : -1);
        String string2 = id2 != null ? id2.a() : "";
        if (id2 != null && !TextUtils.isEmpty((CharSequence)id2.e)) {
            Intent intent2 = new Intent("android.intent.action.VIEW");
            intent2.setData(Uri.parse((String)id2.e));
            intent2.addFlags(268435456);
            intent2.putExtra("messageId", string2);
            intent2.putExtra("eventMessageType", n5);
            return PendingIntent.getActivity((Context)context, (int)0, (Intent)intent2, (int)134217728);
        }
        if (aa.a(im2)) {
            intent = new Intent();
            componentName = new ComponentName("com.xiaomi.xmsf", "com.xiaomi.mipush.sdk.PushMessageHandler");
        } else {
            intent = new Intent("com.xiaomi.mipush.RECEIVE_MESSAGE");
            componentName = new ComponentName(im2.b, "com.xiaomi.mipush.sdk.PushMessageHandler");
        }
        intent.setComponent(componentName);
        intent.putExtra("mipush_payload", arrby);
        intent.putExtra("mipush_notified", true);
        intent.addCategory(String.valueOf((int)n4));
        intent.addCategory(String.valueOf((Object)string2));
        intent.putExtra("messageId", string2);
        intent.putExtra("eventMessageType", n5);
        if (f.b(context, im2.b, "com.xiaomi.mipush.MESSAGE_CLICKED")) {
            Intent intent3 = new Intent();
            intent3.setAction("com.xiaomi.mipush.MESSAGE_CLICKED");
            intent3.setClassName(im2.b, "com.xiaomi.mipush.sdk.BridgeActivity");
            intent3.addFlags(276824064);
            intent3.putExtra("mipush_serviceIntent", (Parcelable)intent);
            intent3.addCategory(String.valueOf((int)n4));
            intent3.addCategory(String.valueOf((Object)string2));
            return PendingIntent.getActivity((Context)context, (int)0, (Intent)intent3, (int)134217728);
        }
        return PendingIntent.getService((Context)context, (int)0, (Intent)intent, (int)134217728);
    }

    private static PendingIntent a(Context context, String string2, int n4, Map<String, String> map) {
        if (map == null) {
            return null;
        }
        Intent intent = aa.a(context, string2, n4, map);
        if (intent != null) {
            return PendingIntent.getActivity((Context)context, (int)0, (Intent)intent, (int)0);
        }
        return null;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private static Intent a(Context context, String string2, int n4, Map<String, String> map) {
        block17 : {
            block22 : {
                block23 : {
                    block20 : {
                        string6 = n4 < 2 ? "notification_style_button_left_notify_effect" : (n4 < 3 ? "notification_style_button_mid_notify_effect" : "notification_style_button_right_notify_effect");
                        string4 = (String)map.get((Object)string6);
                        if (TextUtils.isEmpty((CharSequence)string4)) {
                            return null;
                        }
                        if (au.a.equals((Object)string4)) {
                            try {
                                intent = context.getPackageManager().getLaunchIntentForPackage(string2);
                                break block17;
                            }
                            catch (Exception exception) {
                                stringBuilder2 = e.a.a.a.a.F1((String)"Cause: ");
                                stringBuilder2.append(exception.getMessage());
                                com.xiaomi.channel.commonutils.logger.b.d((String)stringBuilder2.toString());
                                ** break block18
                            }
                        }
                        if (!au.b.equals((Object)string4)) break block22;
                        string7 = n4 < 2 ? "notification_style_button_left_intent_uri" : (n4 < 3 ? "notification_style_button_mid_intent_uri" : "notification_style_button_right_intent_uri");
                        string5 = n4 < 2 ? "notification_style_button_left_intent_class" : (n4 < 3 ? "notification_style_button_mid_intent_class" : "notification_style_button_right_intent_class");
                        if (!map.containsKey((Object)string7)) break block23;
                        string8 = (String)map.get((Object)string7);
                        if (string8 == null) ** GOTO lbl-1000
                        intent2 = Intent.parseUri((String)string8, (int)1);
                        try {
                            intent2.setPackage(string2);
                            break block19;
                        }
                        catch (URISyntaxException uRISyntaxException) {
                            break block20;
                        }
                        catch (URISyntaxException uRISyntaxException) {
                            intent2 = null;
                        }
                    }
                    stringBuilder = e.a.a.a.a.F1((String)"Cause: ");
                    string3 = var28_15.getMessage();
                    ** GOTO lbl60
                }
                if (!map.containsKey((Object)string5)) ** GOTO lbl-1000
                string9 = (String)map.get((Object)string5);
                intent3 = new Intent();
                intent3.setComponent(new ComponentName(string2, string9));
                intent = intent3;
                break block17;
            }
            if (au.c.equals((Object)string4) && !TextUtils.isEmpty((CharSequence)(string11 = (String)map.get((Object)(string10 = n4 < 2 ? "notification_style_button_left_web_uri" : (n4 < 3 ? "notification_style_button_mid_web_uri" : "notification_style_button_right_web_uri")))))) {
                block19 : {
                    block21 : {
                        string12 = string11.trim();
                        if (!string12.startsWith("http://") && !string12.startsWith("https://")) {
                            string12 = e.a.a.a.a.h1((String)"http://", (String)string12);
                        }
                        string13 = new URL(string12).getProtocol();
                        if (!"http".equals((Object)string13) && !"https".equals((Object)string13)) ** break block18
                        intent2 = new Intent("android.intent.action.VIEW");
                        try {
                            intent2.setData(Uri.parse((String)string12));
                            ak.b(context, intent2);
                            break block19;
                        }
                        catch (MalformedURLException malformedURLException) {
                            break block21;
                        }
                        catch (MalformedURLException malformedURLException) {
                            intent2 = null;
                        }
                    }
                    stringBuilder = e.a.a.a.a.F1((String)"Cause: ");
                    string3 = var15_26.getMessage();
lbl60: // 2 sources:
                    stringBuilder.append(string3);
                    com.xiaomi.channel.commonutils.logger.b.d((String)stringBuilder.toString());
                }
                intent = intent2;
            } else lbl-1000: // 5 sources:
            {
                
                intent = null;
            }
        }
        if (intent == null) return null;
        intent.addFlags(268435456);
        try {
            resolveInfo = context.getPackageManager().resolveActivity(intent, 65536);
            if (resolveInfo == null) return null;
            return intent;
        }
        catch (Exception exception) {
            stringBuilder = e.a.a.a.a.F1((String)"Cause: ");
            stringBuilder.append(exception.getMessage());
            com.xiaomi.channel.commonutils.logger.b.d((String)stringBuilder.toString());
        }
        return null;
    }

    private static Bitmap a(Context context, int n4) {
        return aa.a(context.getResources().getDrawable(n4));
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static Bitmap a(Context context, String string2, boolean bl2) {
        Future future;
        Throwable throwable2;
        block6 : {
            Bitmap bitmap;
            future = a.submit((Callable)new a(string2, context, bl2));
            try {
                bitmap = (Bitmap)future.get(180L, TimeUnit.SECONDS);
                if (bitmap != null) return bitmap;
            }
            catch (Throwable throwable2) {
                break block6;
            }
            catch (TimeoutException timeoutException) {
            }
            catch (ExecutionException executionException) {
            }
            catch (InterruptedException interruptedException) {
                // empty catch block
            }
            future.cancel(true);
            return bitmap;
            {
                void var4_9;
                com.xiaomi.channel.commonutils.logger.b.a((Throwable)var4_9);
            }
            future.cancel(true);
            return null;
        }
        future.cancel(true);
        throw throwable2;
    }

    public static Bitmap a(Drawable drawable2) {
        if (drawable2 instanceof BitmapDrawable) {
            return ((BitmapDrawable)drawable2).getBitmap();
        }
        int n4 = drawable2.getIntrinsicWidth();
        int n5 = 1;
        if (n4 <= 0) {
            n4 = 1;
        }
        int n6 = drawable2.getIntrinsicHeight();
        if (n6 > 0) {
            n5 = n6;
        }
        Bitmap bitmap = Bitmap.createBitmap((int)n4, (int)n5, (Bitmap.Config)Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        drawable2.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        drawable2.draw(canvas);
        return bitmap;
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private static RemoteViews a(Context context, im im2, byte[] arrby) {
        id id2 = im2.a();
        String string2 = aa.f(im2);
        Map map = id2.a();
        if (map == null) {
            return null;
        }
        String string3 = (String)map.get((Object)"layout_name");
        String string4 = (String)map.get((Object)"layout_value");
        if (TextUtils.isEmpty((CharSequence)string3)) return null;
        if (TextUtils.isEmpty((CharSequence)string4)) {
            return null;
        }
        PackageManager packageManager = context.getPackageManager();
        Resources resources = packageManager.getResourcesForApplication(string2);
        int n4 = resources.getIdentifier(string3, "layout", string2);
        if (n4 == 0) {
            return null;
        }
        RemoteViews remoteViews = new RemoteViews(string2, n4);
        try {
            JSONObject jSONObject = new JSONObject(string4);
            boolean bl2 = jSONObject.has("text");
            if (bl2) {
                JSONObject jSONObject2 = jSONObject.getJSONObject("text");
                Iterator iterator = jSONObject2.keys();
                while (iterator.hasNext()) {
                    String string5 = (String)iterator.next();
                    String string6 = jSONObject2.getString(string5);
                    int n5 = resources.getIdentifier(string5, "id", string2);
                    if (n5 <= 0) continue;
                    remoteViews.setTextViewText(n5, (CharSequence)string6);
                }
            }
            if (jSONObject.has("image")) {
                JSONObject jSONObject3 = jSONObject.getJSONObject("image");
                Iterator iterator = jSONObject3.keys();
                while (iterator.hasNext()) {
                    String string7 = (String)iterator.next();
                    String string8 = jSONObject3.getString(string7);
                    int n6 = resources.getIdentifier(string7, "id", string2);
                    int n7 = resources.getIdentifier(string8, "drawable", string2);
                    if (n6 <= 0) continue;
                    remoteViews.setImageViewResource(n6, n7);
                }
            }
            if (!jSONObject.has("time")) return remoteViews;
            JSONObject jSONObject4 = jSONObject.getJSONObject("time");
            Iterator iterator = jSONObject4.keys();
            while (iterator.hasNext()) {
                int n8;
                String string9 = (String)iterator.next();
                String string10 = jSONObject4.getString(string9);
                if (string10.length() == 0) {
                    string10 = "yy-MM-dd hh:mm";
                }
                if ((n8 = resources.getIdentifier(string9, "id", string2)) <= 0) continue;
                long l3 = System.currentTimeMillis();
                remoteViews.setTextViewText(n8, (CharSequence)new SimpleDateFormat(string10).format(new Date(l3)));
            }
            return remoteViews;
        }
        catch (JSONException jSONException) {
            com.xiaomi.channel.commonutils.logger.b.a((Throwable)jSONException);
            return null;
        }
        catch (PackageManager.NameNotFoundException nameNotFoundException) {
            com.xiaomi.channel.commonutils.logger.b.a((Throwable)nameNotFoundException);
        }
        return null;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @SuppressLint(value={"NewApi"})
    private static b a(Context var0, im var1_1, byte[] var2_2, RemoteViews var3_3, PendingIntent var4_4) {
        block74 : {
            block68 : {
                block57 : {
                    block56 : {
                        block66 : {
                            block58 : {
                                block73 : {
                                    block69 : {
                                        block72 : {
                                            block71 : {
                                                block70 : {
                                                    block67 : {
                                                        block65 : {
                                                            block64 : {
                                                                block63 : {
                                                                    block59 : {
                                                                        block62 : {
                                                                            block60 : {
                                                                                block61 : {
                                                                                    var5_5 = Build.VERSION.SDK_INT;
                                                                                    var6_6 = new b();
                                                                                    var7_7 = var1_1.a();
                                                                                    var8_8 = aa.f(var1_1);
                                                                                    var9_9 = var7_7.a();
                                                                                    var10_10 = new Notification.Builder(var0);
                                                                                    var11_11 = aa.a(var0, var7_7);
                                                                                    var10_10.setContentTitle((CharSequence)var11_11[0]);
                                                                                    var10_10.setContentText((CharSequence)var11_11[1]);
                                                                                    if (var3_3 != null) {
                                                                                        var10_10.setContent(var3_3);
                                                                                    } else if (var9_9 != null && var9_9.containsKey((Object)"notification_style_type")) {
                                                                                        var10_10 = aa.a(var0, (Map<String, String>)var9_9, var10_10, var11_11[1]);
                                                                                    }
                                                                                    var14_12 = aa.a(var10_10, var0, var1_1.b(), (Map<String, String>)var9_9);
                                                                                    var15_13 = System.currentTimeMillis();
                                                                                    var14_12.setWhen(var15_13);
                                                                                    var18_14 = var9_9 == null ? null : (String)var9_9.get((Object)"notification_show_when");
                                                                                    if (TextUtils.isEmpty(var18_14)) {
                                                                                        if (var5_5 >= 24) {
                                                                                            var14_12.setShowWhen(true);
                                                                                        }
                                                                                    } else {
                                                                                        var14_12.setShowWhen(Boolean.parseBoolean((String)var18_14));
                                                                                    }
                                                                                    var14_12.setContentIntent(var4_4);
                                                                                    var21_15 = aa.a(var0, var8_8, "mipush_notification");
                                                                                    var22_16 = aa.a(var0, var8_8, "mipush_small_notification");
                                                                                    if (var21_15 > 0 && var22_16 > 0) {
                                                                                        var14_12.setLargeIcon(aa.a(var0, var21_15));
                                                                                        var14_12.setSmallIcon(var22_16);
                                                                                    } else if (var5_5 >= 23) {
                                                                                        var14_12.setSmallIcon(Icon.createWithResource((String)var8_8, (int)ak.a(var0, var8_8)));
                                                                                    } else {
                                                                                        var14_12.setSmallIcon(aa.b(var0, var8_8));
                                                                                    }
                                                                                    if (var5_5 < 23) break block59;
                                                                                    var137_17 = var9_9 == null ? null : aa.a(var0, (String)var9_9.get((Object)"notification_small_icon_uri"), true);
                                                                                    if (var137_17 == null) break block60;
                                                                                    var146_18 = bd.a((String)"android.graphics.drawable.Icon", (String)"createWithBitmap", (Object[])new Object[]{var137_17});
                                                                                    if (var146_18 == null) break block61;
                                                                                    bd.a((Object)var14_12, (String)"setSmallIcon", (Object[])new Object[]{var146_18});
                                                                                    var148_19 = new Bundle();
                                                                                    var148_19.putBoolean("miui.isGrayscaleIcon", true);
                                                                                    var14_12.addExtras(var148_19);
                                                                                    break block62;
                                                                                }
                                                                                var138_20 = e.a.a.a.a.F1((String)"failed te get small icon with url:");
                                                                                ** GOTO lbl-1000
                                                                            }
                                                                            var138_20 = e.a.a.a.a.F1((String)"failed to get small icon url:");
                                                                            if (var9_9 == null) {
                                                                                var139_21 = null;
                                                                            } else lbl-1000: // 2 sources:
                                                                            {
                                                                                var139_21 = (String)var9_9.get((Object)"notification_small_icon_uri");
                                                                            }
                                                                            var138_20.append(var139_21);
                                                                            com.xiaomi.channel.commonutils.logger.b.a((String)var138_20.toString());
                                                                        }
                                                                        var141_22 = var9_9 == null ? null : (String)var9_9.get((Object)"notification_small_icon_color");
                                                                        if (!TextUtils.isEmpty(var141_22)) {
                                                                            try {
                                                                                var143_23 = Color.parseColor((String)var141_22);
                                                                                var144_24 = new Object[]{var143_23};
                                                                                bd.a((Object)var14_12, (String)"setColor", (Object[])var144_24);
                                                                            }
                                                                            catch (Exception var142_25) {
                                                                                com.xiaomi.channel.commonutils.logger.b.a((Throwable)var142_25);
                                                                            }
                                                                        }
                                                                    }
                                                                    var24_26 = var9_9 == null ? null : (String)var9_9.get((Object)"__dynamic_icon_uri");
                                                                    var25_27 = var9_9 != null && Boolean.parseBoolean((String)((String)var9_9.get((Object)"__adiom"))) != false;
                                                                    var26_28 = var25_27 || !l.a();
                                                                    if (TextUtils.isEmpty((CharSequence)var24_26) || !var26_28) ** GOTO lbl-1000
                                                                    if (var24_26.startsWith("http")) {
                                                                        var136_29 = com.xiaomi.push.service.ai.a(var0, var24_26, true);
                                                                        if (var136_29 != null) {
                                                                            var134_30 = var136_29.a;
                                                                            var6_6.b = var136_29.a;
                                                                        } else {
                                                                            var134_30 = null;
                                                                        }
                                                                    } else {
                                                                        var134_30 = com.xiaomi.push.service.ai.a(var0, var24_26);
                                                                    }
                                                                    if (var134_30 != null) {
                                                                        var14_12.setLargeIcon(var134_30);
                                                                        var27_31 = true;
                                                                    } else lbl-1000: // 2 sources:
                                                                    {
                                                                        var27_31 = false;
                                                                    }
                                                                    var28_32 = var9_9 == null ? null : aa.a(var0, (String)var9_9.get((Object)"notification_large_icon_uri"), true);
                                                                    if (var28_32 != null) {
                                                                        var14_12.setLargeIcon(var28_32);
                                                                    }
                                                                    if (var9_9 != null && var5_5 >= 24) {
                                                                        var29_33 = (String)var9_9.get((Object)"notification_group");
                                                                        var130_34 = Boolean.parseBoolean((String)((String)var9_9.get((Object)"notification_is_summary")));
                                                                        if (TextUtils.isEmpty((CharSequence)var29_33)) {
                                                                            var29_33 = aa.f(var1_1);
                                                                        }
                                                                        var131_35 = new Object[]{var130_34};
                                                                        bd.a((Object)var14_12, (String)"setGroupSummary", (Object[])var131_35);
                                                                    } else {
                                                                        var29_33 = null;
                                                                    }
                                                                    var14_12.setAutoCancel(true);
                                                                    var31_36 = System.currentTimeMillis();
                                                                    if (var9_9 != null && var9_9.containsKey((Object)"ticker")) {
                                                                        var14_12.setTicker((CharSequence)var9_9.get((Object)"ticker"));
                                                                    }
                                                                    if (var31_36 - aa.a <= 10000L) break block63;
                                                                    aa.a = var31_36;
                                                                    var33_37 = var7_7.a;
                                                                    if (var0.getSharedPreferences("pref_notify_type", 0).contains(var8_8)) {
                                                                        var33_37 = var0.getSharedPreferences("pref_notify_type", 0).getInt(var8_8, Integer.MAX_VALUE);
                                                                    }
                                                                    var14_12.setDefaults(var33_37);
                                                                    if (var9_9 == null || (var33_37 & 1) == 0 || TextUtils.isEmpty((CharSequence)(var123_38 = (String)var9_9.get((Object)"sound_uri")))) break block64;
                                                                    var124_39 = new StringBuilder();
                                                                    var124_39.append("android.resource://");
                                                                    var124_39.append(var8_8);
                                                                    if (!var123_38.startsWith(var124_39.toString())) break block64;
                                                                    var14_12.setDefaults(var33_37 ^ 1);
                                                                    var34_40 = Uri.parse((String)var123_38);
                                                                    var14_12.setSound(var34_40);
                                                                    break block65;
                                                                }
                                                                var33_37 = -100;
                                                            }
                                                            var34_40 = null;
                                                        }
                                                        if (var9_9 == null || var5_5 < 26) break block66;
                                                        var59_41 = aj.a(var0, var8_8);
                                                        var60_42 = aa.a((Map<String, String>)var9_9);
                                                        var61_43 = var29_33;
                                                        if (var60_42 > 0) {
                                                            var119_44 = new Object[1];
                                                            var120_45 = var60_42 * 1000;
                                                            var38_46 = var27_31;
                                                            var62_47 = var34_40;
                                                            var119_44[0] = (long)var120_45;
                                                            bd.a((Object)var14_12, (String)"setTimeoutAfter", (Object[])var119_44);
                                                        } else {
                                                            var38_46 = var27_31;
                                                            var62_47 = var34_40;
                                                        }
                                                        var63_48 = (String)var9_9.get((Object)"channel_id");
                                                        if (!TextUtils.isEmpty((CharSequence)var63_48) || var0.getApplicationInfo().targetSdkVersion >= 26) break block67;
                                                        var76_49 = var61_43;
                                                        var36_50 = var6_6;
                                                        var37_51 = var9_9;
                                                        var39_52 = false;
                                                        break block68;
                                                    }
                                                    var64_53 = var59_41.b("default");
                                                    if (TextUtils.isEmpty((CharSequence)var63_48)) {
                                                        var63_48 = var64_53;
                                                    } else if (l.a()) {
                                                        var63_48 = var59_41.b(var63_48);
                                                    }
                                                    bd.a((Object)var14_12, (String)"setChannelId", (Object[])new Object[]{var63_48});
                                                    var66_54 = aa.a(var0, var8_8, (Map<String, String>)var9_9);
                                                    var67_55 = aa.b((Map<String, String>)var9_9);
                                                    var36_50 = var6_6;
                                                    if (var67_55 < 4) break block69;
                                                    var68_56 = new StringBuilder();
                                                    var69_57 = var64_53;
                                                    var68_56.append(aa.f(var1_1));
                                                    var68_56.append("_top_");
                                                    var68_56.append(var15_13);
                                                    var73_58 = var68_56.toString();
                                                    if (!"com.xiaomi.xmsf".equals((Object)var0.getPackageName())) break block70;
                                                    var111_59 = al.a(var0);
                                                    var112_60 = hv.aT.a();
                                                    var61_43 = var73_58;
                                                    if (!var111_59.a(var112_60, true) || (var113_61 = al.a(var0).a(hv.aR.a(), 14400)) <= 0) break block71;
                                                    var114_62 = new Object[1];
                                                    var115_63 = var113_61 * 1000;
                                                    var74_64 = var8_8;
                                                    var75_65 = var9_9;
                                                    var114_62[0] = (long)var115_63;
                                                    bd.a((Object)var14_12, (String)"setTimeoutAfter", (Object[])var114_62);
                                                    var117_66 = new Bundle();
                                                    var117_66.putLong("mipush_org_when", var15_13);
                                                    var14_12.addExtras(var117_66);
                                                    break block72;
                                                }
                                                var61_43 = var73_58;
                                            }
                                            var74_64 = var8_8;
                                            var75_65 = var9_9;
                                        }
                                        var39_52 = true;
                                        break block73;
                                    }
                                    var74_64 = var8_8;
                                    var75_65 = var9_9;
                                    var69_57 = var64_53;
                                    var39_52 = false;
                                }
                                var76_49 = var61_43;
                                if (var59_41.a(var63_48) != null) break block56;
                                var92_67 = t.a(var0, "android.app.NotificationChannel");
                                var93_68 = new Class[]{String.class, CharSequence.class, Integer.TYPE};
                                var94_69 = var92_67.getConstructor(var93_68);
                                var95_70 = new Object[]{var63_48, var66_54, var67_55};
                                var96_71 = var94_69.newInstance(var95_70);
                                if (var33_37 > -100) {
                                    var14_12.setSound(null, null);
                                    var14_12.setDefaults(0);
                                    var99_72 = var33_37 & 1;
                                    var100_73 = var33_37 & 2;
                                    var101_74 = var33_37 & 4;
                                    if (var99_72 != 1) {
                                        bd.a((Object)var96_71, (String)"setSound", (Object[])new Object[]{null, null});
                                    }
                                    if (var62_47 != null) {
                                        var102_75 = new Object[]{var62_47, Notification.AUDIO_ATTRIBUTES_DEFAULT};
                                        bd.a((Object)var96_71, (String)"setSound", (Object[])var102_75);
                                    }
                                    var104_76 = new Object[1];
                                    var105_77 = var100_73 == 2;
                                    var104_76[0] = var105_77;
                                    bd.a((Object)var96_71, (String)"enableVibration", (Object[])var104_76);
                                    var107_78 = new Object[1];
                                    var108_79 = var101_74 == 4;
                                    var107_78[0] = var108_79;
                                    bd.a((Object)var96_71, (String)"enableLights", (Object[])var107_78);
                                }
                                var37_51 = var75_65;
                                try {
                                    aa.a(var96_71, (Map<String, String>)var37_51);
                                    var59_41.f((NotificationChannel)var96_71);
                                    break block57;
                                }
                                catch (Exception var77_87) {
                                    break block58;
                                }
                                catch (Exception var77_88) {
                                    var37_51 = var75_65;
                                }
                            }
                            com.xiaomi.channel.commonutils.logger.b.a((Throwable)var77_89);
                            break block68;
                        }
                        var35_95 = var29_33;
                        var36_50 = var6_6;
                        var37_51 = var9_9;
                        var38_46 = var27_31;
                        if (var37_51 == null || var5_5 >= 26) ** GOTO lbl-1000
                        var52_96 = aa.c((Map<String, String>)var37_51);
                        var53_97 = new Object[]{var52_96};
                        bd.a((Object)var14_12, (String)"setPriority", (Object[])var53_97);
                        if (var52_96 >= 1) {
                            var55_98 = new StringBuilder();
                            var55_98.append(aa.f(var1_1));
                            var55_98.append("_top_");
                            var55_98.append(var15_13);
                            var40_94 = var55_98.toString();
                            var39_52 = true;
                        } else lbl-1000: // 2 sources:
                        {
                            var39_52 = false;
                            var40_94 = var35_95;
                        }
                        break block74;
                    }
                    var37_51 = var75_65;
                }
                if ((var85_80 = var59_41.d()) != null && var85_80.size() > 0) {
                    for (var86_81 = 0; var86_81 < var85_80.size(); ++var86_81) {
                        var87_82 = (NotificationChannel)var85_80.get(var86_81);
                        var88_83 = var87_82.getName();
                        var89_84 = var87_82.getId();
                        var90_85 = var74_64;
                        if (var88_83.equals((Object)g.b((Context)var0, (String)var90_85))) {
                            var91_86 = var69_57;
                            if (!var89_84.equals((Object)var91_86)) {
                                var59_41.g(var89_84);
                            }
                        } else {
                            var91_86 = var69_57;
                        }
                        var69_57 = var91_86;
                        var74_64 = var90_85;
                    }
                }
            }
            var78_90 = (String)var37_51.get((Object)"background_color");
            if (!TextUtils.isEmpty((CharSequence)var78_90)) {
                try {
                    var80_91 = Integer.parseInt((String)var78_90);
                    var14_12.setOngoing(true);
                    var14_12.setColor(var80_91);
                    var83_92 = new Object[]{Boolean.TRUE};
                    bd.a((Object)var14_12, (String)"setColorized", (Object[])var83_92);
                }
                catch (Exception var79_93) {
                    com.xiaomi.channel.commonutils.logger.b.a((Throwable)var79_93);
                }
            }
            var40_94 = var76_49;
        }
        if (var40_94 != null) {
            if (!var39_52) {
                var40_94 = ag.a().a(var0, var14_12, var40_94);
            }
            bd.a((Object)var14_12, (String)"setGroup", (Object[])new Object[]{var40_94});
        }
        if (l.c() && "com.xiaomi.xmsf".equals((Object)var0.getPackageName())) {
            var49_99 = new Object[]{var0, var14_12, aa.f(var1_1)};
            bd.a((String)"miui.util.NotificationHelper", (String)"setTargetPkg", (Object[])var49_99);
        }
        var41_100 = var14_12.getNotification();
        if (var38_46 && l.a()) {
            aa.a(var41_100);
        }
        if (var37_51 != null && (var43_101 = bd.a((Object)var41_100, (String)"extraNotification")) != null) {
            if (!TextUtils.isEmpty((CharSequence)((CharSequence)var37_51.get((Object)"enable_keyguard")))) {
                var46_102 = new Object[]{Boolean.parseBoolean((String)((String)var37_51.get((Object)"enable_keyguard")))};
                bd.a((Object)var43_101, (String)"setEnableKeyguard", (Object[])var46_102);
            }
            if (!TextUtils.isEmpty((CharSequence)((CharSequence)var37_51.get((Object)"enable_float")))) {
                var44_103 = new Object[]{Boolean.parseBoolean((String)((String)var37_51.get((Object)"enable_float")))};
                bd.a((Object)var43_101, (String)"setEnableFloat", (Object[])var44_103);
            }
        }
        var42_104 = var36_50;
        var42_104.a = var41_100;
        return var42_104;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static c a(Context context, im im2, byte[] arrby) {
        RemoteViews remoteViews;
        PendingIntent pendingIntent;
        id id2;
        c c5;
        int n4;
        long l3;
        block27 : {
            String string2;
            block26 : {
                block25 : {
                    c5 = new c();
                    String string3 = aa.f(im2);
                    boolean bl2 = true;
                    g.a a2 = g.a((Context)context, (String)string3, (boolean)bl2);
                    if (context == null || !"com.xiaomi.xmsf".equals((Object)context.getPackageName())) {
                        bl2 = false;
                    }
                    if (!bl2 || a2 != g.a.c) break block25;
                    id id3 = im2.a();
                    if (id3 != null) {
                        ff ff2 = ff.a((Context)context.getApplicationContext());
                        String string4 = im2.b();
                        String string5 = aa.b(im2);
                        String string6 = id3.a();
                        StringBuilder stringBuilder = e.a.a.a.a.F1((String)"10:");
                        stringBuilder.append(aa.f(im2));
                        ff2.a(string4, string5, string6, stringBuilder.toString());
                    }
                    StringBuilder stringBuilder = e.a.a.a.a.F1((String)"Do not notify because user block ");
                    stringBuilder.append(aa.f(im2));
                    stringBuilder.append("\u2018s notification");
                    string2 = stringBuilder.toString();
                    break block26;
                }
                id2 = im2.a();
                remoteViews = aa.a(context, im2, arrby);
                int n5 = 0;
                if (id2 != null) {
                    n5 = id2.c();
                }
                if ((pendingIntent = aa.a(context, im2, id2, arrby, n4 = n5 + 10 * (aa.f(im2).hashCode() / 10))) != null) break block27;
                if (id2 != null) {
                    ff.a((Context)context.getApplicationContext()).a(im2.b(), aa.b(im2), id2.a(), "11");
                }
                string2 = "The click PendingIntent is null. ";
            }
            com.xiaomi.channel.commonutils.logger.b.a((String)string2);
            return c5;
        }
        b b7 = aa.a(context, im2, arrby, remoteViews, pendingIntent);
        c5.a = b7.b;
        c5.a = aa.f(im2);
        Notification notification = b7.a;
        if (l.a()) {
            String string7;
            if (!TextUtils.isEmpty((CharSequence)id2.a())) {
                notification.extras.putString("message_id", id2.a());
            }
            if (!TextUtils.isEmpty(string7 = id2.b() == null ? null : (String)id2.b().get((Object)"score_info"))) {
                notification.extras.putString("score_info", string7);
            }
            int n6 = -1;
            if (aa.c(im2)) {
                n6 = 1000;
            } else if (aa.a(im2)) {
                n6 = 3000;
            }
            notification.extras.putString("eventMessageType", String.valueOf((int)n6));
            notification.extras.putString("target_package", aa.f(im2));
        }
        String string8 = id2.a() == null ? null : (String)id2.a().get((Object)"message_count");
        if (l.a() && string8 != null) {
            try {
                aa.a(notification, Integer.parseInt((String)string8));
            }
            catch (NumberFormatException numberFormatException) {
                ff.a((Context)context.getApplicationContext()).b(im2.b(), aa.b(im2), id2.a(), "8");
                com.xiaomi.channel.commonutils.logger.b.a((Throwable)numberFormatException);
            }
        }
        if (!l.c() && "com.xiaomi.xmsf".equals((Object)context.getPackageName())) {
            aa.a(notification, aa.f(im2));
        }
        aj aj2 = aj.a(context, aa.f(im2));
        aj2.a(n4, notification);
        if (l.a() && "com.xiaomi.xmsf".equals((Object)context.getPackageName())) {
            ag.a().a(context, n4, notification);
        }
        if (aa.a(im2)) {
            ff.a((Context)context.getApplicationContext()).a(im2.b(), aa.b(im2), id2.a(), 3002, null);
        }
        if (aa.c(im2)) {
            ff.a((Context)context.getApplicationContext()).a(im2.b(), aa.b(im2), id2.a(), 1002, null);
        }
        if (Build.VERSION.SDK_INT < 26) {
            ai ai2 = ai.a((Context)context);
            ai2.a(n4);
            int n7 = aa.a((Map<String, String>)id2.a());
            if (n7 > 0) {
                ai2.b((ai.a)new ab(n4, aj2), n7);
            }
        }
        Pair pair = new Pair((Object)n4, (Object)im2);
        long l4 = l3 = a;
        synchronized (l4) {
            l3.add((Object)pair);
            if (l3.size() > 100) {
                l3.remove();
            }
            return c5;
        }
    }

    private static String a(Context context, String string2, Map<String, String> map) {
        if (map != null && !TextUtils.isEmpty((CharSequence)((CharSequence)map.get((Object)"channel_name")))) {
            return (String)map.get((Object)"channel_name");
        }
        return g.b((Context)context, (String)string2);
    }

    private static void a(Notification notification, int n4) {
        Object object = bd.a((Object)notification, (String)"extraNotification");
        if (object != null) {
            Object[] arrobject = new Object[]{n4};
            bd.a((Object)object, (String)"setMessageCount", (Object[])arrobject);
        }
    }

    public static void a(Context context, String string2) {
        aa.a(context, string2, -1);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static void a(Context context, String string2, int n4) {
        long l3;
        aj aj2 = aj.a(context, string2);
        int n5 = n4 + 10 * (string2.hashCode() / 10);
        LinkedList linkedList = new LinkedList();
        if (n4 >= 0) {
            aj2.e(n5);
        }
        long l4 = l3 = a;
        synchronized (l4) {
            for (Pair pair : l3) {
                im im2 = (im)pair.second;
                if (im2 == null) continue;
                String string3 = aa.f(im2);
                if (n4 >= 0) {
                    if (n5 != (Integer)pair.first || !TextUtils.equals((CharSequence)string3, (CharSequence)string2)) continue;
                } else {
                    if (n4 != -1 || !TextUtils.equals((CharSequence)string3, (CharSequence)string2)) continue;
                    aj2.e((Integer)pair.first);
                }
                linkedList.add((Object)pair);
            }
            long l5 = a;
            if (l5 != null) {
                l5.removeAll((Collection)linkedList);
                aa.a(context, (LinkedList<? extends Object>)linkedList);
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static void a(Context context, String string2, String string3, String string4) {
        long l3;
        if (TextUtils.isEmpty((CharSequence)string3) && TextUtils.isEmpty((CharSequence)string4)) {
            return;
        }
        LinkedList linkedList = new LinkedList();
        long l4 = l3 = a;
        synchronized (l4) {
            for (Pair pair : l3) {
                im im2 = (im)pair.second;
                if (im2 == null) continue;
                String string5 = aa.f(im2);
                id id2 = im2.a();
                if (id2 == null || !TextUtils.equals((CharSequence)string5, (CharSequence)string2)) continue;
                String string6 = id2.c();
                String string7 = id2.d();
                if (TextUtils.isEmpty((CharSequence)string6) || TextUtils.isEmpty((CharSequence)string7) || !aa.a(string3, string6) || !aa.a(string4, string7)) continue;
                aj.a(context, string2).e((Integer)pair.first);
                linkedList.add((Object)pair);
            }
            long l5 = a;
            if (l5 != null) {
                l5.removeAll((Collection)linkedList);
                aa.a(context, (LinkedList<? extends Object>)linkedList);
            }
            return;
        }
    }

    public static void a(Context context, LinkedList<? extends Object> linkedList) {
        if (linkedList != null && linkedList.size() > 0) {
            bj.a(context, "category_clear_notification", "clear_notification", linkedList.size(), "");
        }
    }

    private static void a(Object object, Map<String, String> map) {
        if (map != null) {
            if (TextUtils.isEmpty((CharSequence)((CharSequence)map.get((Object)"channel_description")))) {
                return;
            }
            Object[] arrobject = new Object[]{map.get((Object)"channel_description")};
            bd.a((Object)object, (String)"setDescription", (Object[])arrobject);
        }
    }

    public static boolean a(Context context, String string2) {
        List list = ((ActivityManager)context.getSystemService("activity")).getRunningAppProcesses();
        if (list != null) {
            for (ActivityManager.RunningAppProcessInfo runningAppProcessInfo : list) {
                if (runningAppProcessInfo.importance != 100 || !Arrays.asList((Object[])runningAppProcessInfo.pkgList).contains((Object)string2)) continue;
                return true;
            }
        }
        return false;
    }

    private static boolean a(id id2) {
        boolean bl2 = false;
        if (id2 != null) {
            String string2 = id2.a();
            boolean bl3 = TextUtils.isEmpty((CharSequence)string2);
            bl2 = false;
            if (!bl3) {
                int n4 = string2.length();
                bl2 = false;
                if (n4 == 22) {
                    int n5 = "satuigmo".indexOf((int)string2.charAt(0));
                    bl2 = false;
                    if (n5 >= 0) {
                        bl2 = true;
                    }
                }
            }
        }
        return bl2;
    }

    public static boolean a(im im2) {
        id id2 = im2.a();
        return aa.a(id2) && id2.l();
    }

    private static boolean a(String string2, String string3) {
        return TextUtils.isEmpty((CharSequence)string2) || string3.contains((CharSequence)string2);
        {
        }
    }

    public static boolean a(Map<String, String> map) {
        if (map != null && map.containsKey((Object)"notify_foreground")) {
            return "1".equals((Object)((String)map.get((Object)"notify_foreground")));
        }
        return true;
    }

    private static String[] a(Context context, id id2) {
        String string2;
        String string3;
        block5 : {
            String string4;
            block7 : {
                int n4;
                Map map;
                block6 : {
                    string3 = id2.c();
                    string2 = id2.d();
                    map = id2.a();
                    if (map == null) break block5;
                    int n5 = context.getResources().getDisplayMetrics().widthPixels;
                    float f7 = context.getResources().getDisplayMetrics().density;
                    n4 = Float.valueOf((float)(0.5f + (float)n5 / f7)).intValue();
                    if (n4 > 320) break block6;
                    String string5 = (String)map.get((Object)"title_short");
                    if (!TextUtils.isEmpty((CharSequence)string5)) {
                        string3 = string5;
                    }
                    if (TextUtils.isEmpty((CharSequence)(string4 = (String)map.get((Object)"description_short")))) break block5;
                    break block7;
                }
                if (n4 <= 360) break block5;
                String string6 = (String)map.get((Object)"title_long");
                if (!TextUtils.isEmpty((CharSequence)string6)) {
                    string3 = string6;
                }
                if (TextUtils.isEmpty((CharSequence)(string4 = (String)map.get((Object)"description_long")))) break block5;
            }
            string2 = string4;
        }
        return new String[]{string3, string2};
    }

    private static int b(Context context, String string2) {
        int n4 = aa.a(context, string2, "mipush_notification");
        int n5 = aa.a(context, string2, "mipush_small_notification");
        if (n4 <= 0) {
            n4 = n5 > 0 ? n5 : context.getApplicationInfo().icon;
        }
        if (n4 == 0) {
            n4 = context.getApplicationInfo().logo;
        }
        return n4;
    }

    private static int b(Map<String, String> map) {
        String string2;
        if (map != null && !TextUtils.isEmpty((CharSequence)(string2 = (String)map.get((Object)"channel_importance")))) {
            try {
                com.xiaomi.channel.commonutils.logger.b.c((String)"importance=3");
                int n4 = Integer.parseInt((String)string2);
                return n4;
            }
            catch (Exception exception) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("parsing channel importance error: ");
                stringBuilder.append((Object)exception);
                com.xiaomi.channel.commonutils.logger.b.d((String)stringBuilder.toString());
            }
        }
        return 3;
    }

    public static String b(im im2) {
        if (aa.a(im2)) {
            return "E100002";
        }
        if (aa.c(im2)) {
            return "E100000";
        }
        if (aa.b(im2)) {
            return "E100001";
        }
        if (aa.d(im2)) {
            return "E100003";
        }
        return "";
    }

    public static boolean b(im im2) {
        id id2 = im2.a();
        return aa.a(id2) && id2.b == 1 && !aa.a(im2);
    }

    private static int c(Map<String, String> map) {
        String string2;
        if (map != null && !TextUtils.isEmpty((CharSequence)(string2 = (String)map.get((Object)"notification_priority")))) {
            try {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("priority=");
                stringBuilder.append(string2);
                com.xiaomi.channel.commonutils.logger.b.c((String)stringBuilder.toString());
                int n4 = Integer.parseInt((String)string2);
                return n4;
            }
            catch (Exception exception) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("parsing notification priority error: ");
                stringBuilder.append((Object)exception);
                com.xiaomi.channel.commonutils.logger.b.d((String)stringBuilder.toString());
            }
        }
        return 0;
    }

    public static boolean c(im im2) {
        id id2 = im2.a();
        return aa.a(id2) && id2.b == 0 && !aa.a(im2);
    }

    public static boolean d(im im2) {
        return im2.a() == hq.a;
    }

    public static boolean e(im im2) {
        return aa.a(im2) || aa.c(im2) || aa.b(im2);
        {
        }
    }

    public static String f(im im2) {
        String string2;
        id id2;
        if ("com.xiaomi.xmsf".equals((Object)im2.b) && (id2 = im2.a()) != null && id2.a() != null && !TextUtils.isEmpty((CharSequence)(string2 = (String)id2.a().get((Object)"miui_package_name")))) {
            return string2;
        }
        return im2.b;
    }

    /*
     * Duplicate member names - consider using --renamedupmembers true
     */
    public static class a
    implements Callable<Bitmap> {
        private Context a;
        private String a;
        private boolean a;

        public a(String string2, Context context, boolean bl2) {
            this.a = context;
            this.a = string2;
            this.a = bl2;
        }

        /*
         * Enabled aggressive block sorting
         */
        public Bitmap a() {
            boolean bl2 = TextUtils.isEmpty((CharSequence)this.a);
            Bitmap bitmap = null;
            if (!bl2) {
                if (this.a.startsWith("http")) {
                    ai.b b7 = com.xiaomi.push.service.ai.a(this.a, this.a, this.a);
                    bitmap = null;
                    if (b7 != null) {
                        return b7.a;
                    }
                } else {
                    bitmap = com.xiaomi.push.service.ai.a(this.a, this.a);
                    if (bitmap != null) return bitmap;
                }
                com.xiaomi.channel.commonutils.logger.b.a((String)"Failed get online picture/icon resource");
                return bitmap;
            }
            com.xiaomi.channel.commonutils.logger.b.a((String)"Failed get online picture/icon resource cause picUrl is empty");
            return bitmap;
        }

        public /* synthetic */ Object call() {
            return this.a();
        }
    }

    public static class b {
        public Notification a;
        public long b = 0L;
    }

    /*
     * Duplicate member names - consider using --renamedupmembers true
     */
    public static class c {
        public long a;
        public String a = 0L;
    }

}

