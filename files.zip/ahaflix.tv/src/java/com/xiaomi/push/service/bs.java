/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.xiaomi.push.service.XMPushService$f
 *  com.xiaomi.push.service.aq
 *  com.xiaomi.push.service.aq$a
 *  java.lang.Exception
 *  java.lang.Object
 */
package com.xiaomi.push.service;

import com.xiaomi.push.service.XMPushService;
import com.xiaomi.push.service.aq;

/*
 * Exception performing whole class analysis.
 */
public class bs
implements aq.a {
    public final /* synthetic */ XMPushService a;

    public bs(XMPushService xMPushService) {
        this.a = xMPushService;
    }

    public void a() {
        XMPushService.m(this.a);
        if (aq.a().a() <= 0) {
            XMPushService xMPushService = this.a;
            xMPushService.a((XMPushService.i)new /* Unavailable Anonymous Inner Class!! */);
        }
    }
}

