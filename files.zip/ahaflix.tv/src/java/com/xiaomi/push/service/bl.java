/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  com.xiaomi.channel.commonutils.logger.b
 *  com.xiaomi.push.hu
 *  java.io.File
 *  java.io.IOException
 *  java.io.RandomAccessFile
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.Throwable
 *  java.nio.channels.FileChannel
 *  java.nio.channels.FileLock
 */
package com.xiaomi.push.service;

import android.content.Context;
import com.xiaomi.channel.commonutils.logger.b;
import com.xiaomi.push.hu;
import com.xiaomi.push.service.bk;
import com.xiaomi.push.y;
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;

public final class bl
implements Runnable {
    public final /* synthetic */ Context a;
    public final /* synthetic */ hu b;

    public bl(Context context, hu hu2) {
        this.a = context;
        this.b = hu2;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public void run() {
        block21 : {
            var15_2 = var1_1 = bk.a;
            // MONITORENTER : var15_2
            var2_3 = null;
            var3_4 = new File(this.a.getFilesDir(), "tiny_data.lock");
            y.a(var3_4);
            var5_5 = new RandomAccessFile(var3_4, "rw");
            try {
                var2_3 = var5_5.getChannel().lock();
                bk.b(this.a, this.b);
                ** if (var2_3 == null) goto lbl20
            }
            catch (Throwable var6_13) {}
lbl-1000: // 1 sources:
            {
                var13_6 = var2_3.isValid();
                if (var13_6) {
                    try {
                        var2_3.release();
                    }
                    catch (IOException var14_7) {
                        b.a((Throwable)var14_7);
                    }
                }
            }
lbl20: // 4 sources:
            ** GOTO lbl-1000
            {
                block20 : {
                    catch (Exception var4_8) {
                        break block20;
                    }
                    catch (Throwable var6_11) {
                        var2_3 = null;
                        var5_5 = null;
                        break block21;
                    }
                    catch (Exception var4_9) {
                        var5_5 = null;
                    }
                }
                b.a((Throwable)var4_10);
                if (var2_3 == null) ** break block22
                var10_14 = var2_3.isValid();
                if (!var10_14) ** break block22
                try {
                    var2_3.release();
                }
                catch (IOException var11_15) {
                    b.a((Throwable)var11_15);
                }
            }
            catch (Throwable var8_18) {
                throw var8_18;
            }
lbl-1000: // 6 sources:
            {
                
                y.a(var5_5);
                return;
            }
        }
        if (var2_3 != null && (var7_16 = var2_3.isValid())) {
            try {
                var2_3.release();
            }
            catch (IOException var9_17) {
                b.a((Throwable)var9_17);
            }
        }
        y.a(var5_5);
        throw var6_12;
    }
}

