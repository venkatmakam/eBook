/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Handler
 *  android.os.Looper
 *  android.os.Message
 */
package com.xiaomi.push.service;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import com.xiaomi.push.service.bc;

public class bd
extends Handler {
    public bd(bc bc2, Looper looper) {
        super(looper);
    }

    public void handleMessage(Message message) {
        super.handleMessage(message);
    }
}

