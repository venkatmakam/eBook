/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  com.xiaomi.channel.commonutils.logger.b
 *  com.xiaomi.push.al
 *  com.xiaomi.push.al$b
 *  com.xiaomi.push.b
 *  com.xiaomi.push.c
 *  com.xiaomi.push.en
 *  com.xiaomi.push.en$a
 *  com.xiaomi.push.eo
 *  com.xiaomi.push.eo$b
 *  e.a.a.a.a
 *  java.io.BufferedInputStream
 *  java.io.BufferedOutputStream
 *  java.io.Closeable
 *  java.io.FileInputStream
 *  java.io.FileOutputStream
 *  java.io.InputStream
 *  java.io.OutputStream
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.List
 */
package com.xiaomi.push.service;

import android.content.SharedPreferences;
import com.xiaomi.push.al;
import com.xiaomi.push.b;
import com.xiaomi.push.c;
import com.xiaomi.push.en;
import com.xiaomi.push.eo;
import com.xiaomi.push.gz;
import com.xiaomi.push.i;
import com.xiaomi.push.service.bg;
import com.xiaomi.push.t;
import com.xiaomi.push.y;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.Closeable;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class bf {
    private static bf a = new bf();
    private static String a;
    private al.b a;
    private en.a a;
    private List<a> a = new ArrayList();

    private bf() {
    }

    public static bf a() {
        return a;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static String a() {
        Class<bf> class_ = bf.class;
        synchronized (bf.class) {
            String string2;
            String string3;
            if (a != null) return a;
            SharedPreferences sharedPreferences = t.a().getSharedPreferences("XMPushServiceConfig", 0);
            a = string3 = sharedPreferences.getString("DeviceUUID", null);
            if (string3 != null) return a;
            a = string2 = i.a(t.a(), false);
            if (string2 == null) return a;
            sharedPreferences.edit().putString("DeviceUUID", a).commit();
            return a;
        }
    }

    private void b() {
        if (this.a == null) {
            this.d();
        }
    }

    private void c() {
        if (this.a != null) {
            return;
        }
        bg bg2 = new bg(this);
        this.a = bg2;
        gz.a(bg2);
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private void d() {
        BufferedInputStream bufferedInputStream;
        Throwable throwable;
        block9 : {
            block7 : {
                Exception exception;
                block8 : {
                    bufferedInputStream = new BufferedInputStream((InputStream)t.a().openFileInput("XMCloudCfg"));
                    try {
                        this.a = en.a.b((b)b.a((InputStream)bufferedInputStream));
                        bufferedInputStream.close();
                        break block7;
                    }
                    catch (Exception exception2) {
                        break block8;
                    }
                    catch (Throwable throwable2) {
                        throwable = throwable2;
                        bufferedInputStream = null;
                        break block9;
                    }
                    catch (Exception exception3) {
                        bufferedInputStream = null;
                        exception = exception3;
                    }
                }
                try {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("load config failure: ");
                    stringBuilder.append(exception.getMessage());
                    com.xiaomi.channel.commonutils.logger.b.a((String)stringBuilder.toString());
                }
                catch (Throwable throwable3) {
                    // empty catch block
                }
            }
            y.a((Closeable)bufferedInputStream);
            if (this.a != null) return;
            this.a = new en.a();
            return;
        }
        y.a((Closeable)bufferedInputStream);
        throw throwable;
    }

    private void e() {
        try {
            if (this.a != null) {
                BufferedOutputStream bufferedOutputStream = new BufferedOutputStream((OutputStream)t.a().openFileOutput("XMCloudCfg", 0));
                c c5 = c.a((OutputStream)bufferedOutputStream);
                this.a.a(c5);
                c5.a();
                bufferedOutputStream.close();
                return;
            }
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = e.a.a.a.a.F1((String)"save config failure: ");
            stringBuilder.append(exception.getMessage());
            com.xiaomi.channel.commonutils.logger.b.a((String)stringBuilder.toString());
        }
    }

    public static /* synthetic */ al.b g(bf bf2, al.b b7) {
        bf2.a = null;
        return null;
    }

    public static /* synthetic */ en.a h(bf bf2) {
        return bf2.a;
    }

    public static /* synthetic */ en.a i(bf bf2, en.a a2) {
        bf2.a = a2;
        return a2;
    }

    public static /* synthetic */ List j(bf bf2) {
        return bf2.a;
    }

    public static /* synthetic */ void m(bf bf2) {
        bf2.e();
    }

    public en.a a() {
        this.b();
        return this.a;
    }

    public void a(a a2) {
        bf bf2 = this;
        synchronized (bf2) {
            this.a.add((Object)a2);
            return;
        }
    }

    public int f() {
        this.b();
        en.a a2 = this.a;
        if (a2 != null) {
            return a2.c();
        }
        return 0;
    }

    public void k() {
        bf bf2 = this;
        synchronized (bf2) {
            this.a.clear();
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void l(eo.b b7) {
        a[] arra;
        boolean bl2 = b7.d();
        int n4 = 0;
        if (bl2) {
            int n5 = b7.d();
            this.b();
            en.a a2 = this.a;
            int n6 = a2 != null ? a2.c() : 0;
            if (n5 > n6) {
                this.c();
            }
        }
        bf bf2 = this;
        synchronized (bf2) {
            bf bf3 = this.a;
            arra = (a[])bf3.toArray((Object[])new a[bf3.size()]);
        }
        int n7 = arra.length;
        while (n4 < n7) {
            arra[n4].a(b7);
            ++n4;
        }
        return;
    }

    public static abstract class a {
        public void a(en.a a2) {
        }

        public void a(eo.b b7) {
        }
    }

}

