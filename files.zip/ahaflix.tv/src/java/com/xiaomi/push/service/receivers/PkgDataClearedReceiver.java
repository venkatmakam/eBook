/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 *  android.net.Uri
 *  android.text.TextUtils
 *  com.xiaomi.channel.commonutils.logger.b
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.xiaomi.push.service.receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;
import com.xiaomi.channel.commonutils.logger.b;
import com.xiaomi.push.service.XMPushService;
import com.xiaomi.push.service.ay;
import com.xiaomi.push.service.bc;

public class PkgDataClearedReceiver
extends BroadcastReceiver {
    public void onReceive(Context context, Intent intent) {
        String string2;
        if (intent != null && "android.intent.action.PACKAGE_DATA_CLEARED".equals((Object)intent.getAction()) && intent.getData() != null && !TextUtils.isEmpty((CharSequence)(string2 = intent.getData().getEncodedSchemeSpecificPart()))) {
            try {
                Intent intent2 = new Intent(context, XMPushService.class);
                intent2.setAction(ay.b);
                intent2.putExtra("data_cleared_pkg_name", string2);
                bc.a(context).a(intent2);
                return;
            }
            catch (Exception exception) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("data cleared broadcast error: ");
                stringBuilder.append((Object)exception);
                b.d((String)stringBuilder.toString());
            }
        }
    }
}

