/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.xiaomi.push.service.aq
 *  com.xiaomi.push.service.aq$b
 *  com.xiaomi.push.service.aq$b$a
 *  com.xiaomi.push.service.aq$c
 *  java.lang.Object
 */
package com.xiaomi.push.service;

import com.xiaomi.push.service.XMPushService;
import com.xiaomi.push.service.aq;

public class ar
implements aq.b.a {
    public final /* synthetic */ aq.b a;

    public ar(aq.b b5) {
        this.a = b5;
    }

    public void a(aq.c c3, aq.c c5, int n5) {
        if (c5 == aq.c.b) {
            aq.b.c((aq.b)this.a).a((XMPushService.i)aq.b.b((aq.b)this.a), 60000L);
            return;
        }
        aq.b.c((aq.b)this.a).b((XMPushService.i)aq.b.b((aq.b)this.a));
    }
}

