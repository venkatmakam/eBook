/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.app.Notification
 *  android.app.Notification$Builder
 *  android.content.Context
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.service.notification.StatusBarNotification
 *  android.text.TextUtils
 *  com.xiaomi.channel.commonutils.logger.b
 *  com.xiaomi.push.bd
 *  e.a.a.a.a
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.util.ArrayList
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 */
package com.xiaomi.push.service;

import android.annotation.TargetApi;
import android.app.Notification;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.service.notification.StatusBarNotification;
import android.text.TextUtils;
import com.xiaomi.push.bd;
import com.xiaomi.push.hv;
import com.xiaomi.push.service.ah;
import com.xiaomi.push.service.aj;
import com.xiaomi.push.service.ak;
import com.xiaomi.push.service.al;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
@TargetApi(value=24)
public class ag {
    private static ag a = new ag();

    private ag() {
    }

    private int a(String string2, String string3) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("GroupSummary");
        stringBuilder.append(string2);
        stringBuilder.append(string3);
        return stringBuilder.toString().hashCode();
    }

    public static ag a() {
        return a;
    }

    private String a(Notification notification) {
        Bundle bundle;
        if (notification != null && (bundle = notification.extras) != null) {
            return bundle.getString("push_src_group_name");
        }
        return null;
    }

    private List<StatusBarNotification> a(aj aj2) {
        List<StatusBarNotification> list = aj2 != null ? aj2.h() : null;
        if (list != null) {
            if (list.size() == 0) {
                return null;
            }
            return list;
        }
        return null;
    }

    /*
     * Enabled aggressive block sorting
     */
    private void a(Context context, int n4, Notification notification, boolean bl2) {
        List<StatusBarNotification> list;
        aj aj2;
        String string2;
        block11 : {
            String string3;
            block10 : {
                block9 : {
                    string2 = ak.a(notification);
                    if (!TextUtils.isEmpty((CharSequence)string2)) break block9;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("group auto not extract pkg from notification:");
                    stringBuilder.append(n4);
                    string3 = stringBuilder.toString();
                    break block10;
                }
                aj2 = aj.a(context, string2);
                list = this.a(aj2);
                if (list != null) break block11;
                string3 = "group auto not get notifications";
            }
            com.xiaomi.channel.commonutils.logger.b.a((String)string3);
            return;
        }
        String string4 = this.b(notification);
        HashMap hashMap = new HashMap();
        for (StatusBarNotification statusBarNotification : list) {
            if (statusBarNotification.getNotification() == null || statusBarNotification.getId() == n4) continue;
            this.a((Map<String, a>)hashMap, statusBarNotification);
        }
        Iterator iterator = hashMap.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry entry = (Map.Entry)iterator.next();
            String string5 = (String)entry.getKey();
            if (TextUtils.isEmpty((CharSequence)string5)) continue;
            a a2 = (a)entry.getValue();
            if (bl2 && string5.equals((Object)string4) && !this.b(notification)) {
                b b7 = new b(this, n4, notification);
                List<b> list2 = this.a(notification) ? a2.b : a2.a;
                list2.add((Object)b7);
            }
            int n5 = a2.a.size();
            if (a2.b.size() <= 0) {
                if (n5 < 2) continue;
                this.a(context, string2, string5, ((b)a2.a.get((int)0)).b);
                continue;
            }
            if (n5 <= 0) {
                this.a(context, string2, string5);
                continue;
            }
            if (n5 < 2 || this.a(context)) continue;
            b b8 = (b)a2.b.get(0);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("group refresh:");
            stringBuilder.append((Object)b8);
            com.xiaomi.channel.commonutils.logger.b.b((String)stringBuilder.toString());
            b8.b.when = System.currentTimeMillis();
            aj2.a(b8.a, b8.b);
        }
        return;
    }

    private void a(Context context, String string2, String string3) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("group cancel summary:");
        stringBuilder.append(string3);
        com.xiaomi.channel.commonutils.logger.b.b((String)stringBuilder.toString());
        int n4 = this.a(string2, string3);
        aj.a(context, string2).e(n4);
    }

    /*
     * Exception decompiling
     */
    private void a(Context var1, String var2, String var3, Notification var4) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Underrun type stack
        // org.benf.cfr.reader.b.a.c.e.a(StackSim.java:35)
        // org.benf.cfr.reader.b.b.af.a(OperationFactoryPop.java:20)
        // org.benf.cfr.reader.b.b.e.a(JVMInstr.java:315)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:195)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    private void a(Map<String, a> map, StatusBarNotification statusBarNotification) {
        String string2 = this.b(statusBarNotification.getNotification());
        a a2 = (a)map.get((Object)string2);
        if (a2 == null) {
            a2 = new a(this, null);
            map.put((Object)string2, (Object)a2);
        }
        b b7 = new b(this, statusBarNotification.getId(), statusBarNotification.getNotification());
        List<b> list = this.a(statusBarNotification.getNotification()) ? a2.b : a2.a;
        list.add((Object)b7);
    }

    private boolean a() {
        return Build.VERSION.SDK_INT >= 24;
    }

    private boolean a(Notification notification) {
        Object object;
        if (notification != null && (object = bd.a((Object)notification, (String)"isGroupSummary", null)) instanceof Boolean) {
            return (Boolean)object;
        }
        return false;
    }

    private boolean a(Context context) {
        if (!this.b(context)) {
            return false;
        }
        if (!aj.a(context)) {
            return false;
        }
        return al.a(context).a(hv.aX.a(), true);
    }

    private String b(Notification notification) {
        if (notification == null) {
            return null;
        }
        String string2 = notification.getGroup();
        if (this.b(notification)) {
            string2 = this.a(notification);
        }
        return string2;
    }

    /*
     * Enabled aggressive block sorting
     */
    private void b(Context context, int n4, Notification notification) {
        aj aj2;
        List<StatusBarNotification> list;
        block7 : {
            String string2;
            block6 : {
                String string3;
                block5 : {
                    string3 = ak.a(notification);
                    if (!TextUtils.isEmpty((CharSequence)string3)) break block5;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("group restore not extract pkg from notification:");
                    stringBuilder.append(n4);
                    string2 = stringBuilder.toString();
                    break block6;
                }
                aj2 = aj.a(context, string3);
                list = this.a(aj2);
                if (list != null) break block7;
                string2 = "group restore not get notifications";
            }
            com.xiaomi.channel.commonutils.logger.b.a((String)string2);
            return;
        }
        Iterator iterator = list.iterator();
        while (iterator.hasNext()) {
            StatusBarNotification statusBarNotification = (StatusBarNotification)iterator.next();
            Notification notification2 = statusBarNotification.getNotification();
            if (notification2 == null || !this.b(notification2) || statusBarNotification.getId() == n4) continue;
            Notification.Builder builder = Notification.Builder.recoverBuilder((Context)context, (Notification)statusBarNotification.getNotification());
            builder.setGroup(this.a(notification2));
            aj2.a(statusBarNotification.getId(), builder.build());
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("group restore notification:");
            stringBuilder.append(statusBarNotification.getId());
            com.xiaomi.channel.commonutils.logger.b.b((String)stringBuilder.toString());
        }
        return;
    }

    private boolean b(Notification notification) {
        if (notification != null && notification.getGroup() != null) {
            Bundle bundle = notification.extras;
            if (bundle == null) {
                return false;
            }
            long l3 = bundle.getLong("push_src_group_time");
            String string2 = this.a(notification);
            String string3 = notification.getGroup();
            Object[] arrobject = new Object[]{l3, string2};
            return string3.equals((Object)String.format((String)"pushmask_%s_%s", (Object[])arrobject));
        }
        return false;
    }

    private boolean b(Context context) {
        return al.a(context).a(hv.aW.a(), true);
    }

    public String a(Context context, Notification.Builder builder, String string2) {
        if (this.a() && this.a(context)) {
            long l3 = System.currentTimeMillis();
            Bundle bundle = builder.getExtras();
            bundle.putString("push_src_group_name", string2);
            bundle.putLong("push_src_group_time", l3);
            Object[] arrobject = new Object[]{l3, string2};
            return String.format((String)"pushmask_%s_%s", (Object[])arrobject);
        }
        return string2;
    }

    public void a(Context context, int n4, Notification notification) {
        if (!this.a()) {
            return;
        }
        if (this.a(context)) {
            try {
                this.b(context, n4, notification);
            }
            catch (Exception exception) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("group notify handle restore error ");
                stringBuilder.append((Object)exception);
                com.xiaomi.channel.commonutils.logger.b.a((String)stringBuilder.toString());
            }
        }
        if (this.b(context)) {
            try {
                this.a(context, n4, notification, true);
                return;
            }
            catch (Exception exception) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("group notify handle auto error ");
                stringBuilder.append((Object)exception);
                com.xiaomi.channel.commonutils.logger.b.a((String)stringBuilder.toString());
            }
        }
    }

    public class a {
        public List<b> a = new ArrayList();
        public List<b> b = new ArrayList();

        private a(ag ag2) {
        }

        public /* synthetic */ a(ag ag2, ah ah2) {
            this(ag2);
        }
    }

    public class b {
        public int a;
        public Notification b;

        public b(ag ag2, int n4, Notification notification) {
            this.a = n4;
            this.b = notification;
        }

        public String toString() {
            StringBuilder stringBuilder = e.a.a.a.a.F1((String)"id:");
            stringBuilder.append(this.a);
            return stringBuilder.toString();
        }
    }

}

