/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.xiaomi.channel.commonutils.logger.b
 *  com.xiaomi.push.service.XMPushService$d
 *  java.lang.Class
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 */
package com.xiaomi.push.service;

import com.xiaomi.channel.commonutils.logger.b;
import com.xiaomi.push.hi;
import com.xiaomi.push.service.XMPushService;
import com.xiaomi.push.service.ad;

/*
 * Duplicate member names - consider using --renamedupmembers true
 * Exception performing whole class analysis.
 */
public class ba {
    private static int d = 300000;
    private int a;
    private long a;
    private XMPushService a;
    private int b;
    private int c;

    public ba(XMPushService xMPushService) {
        this.b = 0;
        this.c = 0;
        this.a = xMPushService;
        this.a = 500;
        this.a = 0L;
    }

    private int a() {
        if (this.b > 8) {
            return 300000;
        }
        double d7 = 1.0 + 2.0 * Math.random();
        int n4 = this.b;
        if (n4 > 4) {
            return (int)(d7 * 60000.0);
        }
        if (n4 > 1) {
            return (int)(d7 * 10000.0);
        }
        if (this.a == 0L) {
            return 0;
        }
        if (System.currentTimeMillis() - this.a < 310000L) {
            int n5;
            int n6 = this.a;
            int n7 = d;
            if (n6 >= n7) {
                return n6;
            }
            this.c = n5 = 1 + this.c;
            if (n5 >= 4) {
                return n7;
            }
            this.a = (int)(1.5 * (double)n6);
            return n6;
        }
        this.a = 1000;
        this.c = 0;
        return 0;
    }

    public void a() {
        this.a = System.currentTimeMillis();
        this.a.a(1);
        this.b = 0;
    }

    public void a(boolean bl2) {
        if (this.a.a()) {
            if (bl2) {
                if (!this.a.a(1)) {
                    this.b = 1 + this.b;
                }
                this.a.a(1);
                XMPushService xMPushService = this.a;
                xMPushService.getClass();
                xMPushService.a((XMPushService.i)new /* Unavailable Anonymous Inner Class!! */);
                return;
            }
            if (this.a.a(1)) {
                return;
            }
            int n4 = this.a();
            this.b = 1 + this.b;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("schedule reconnect in ");
            stringBuilder.append(n4);
            stringBuilder.append("ms");
            b.a((String)stringBuilder.toString());
            XMPushService xMPushService = this.a;
            xMPushService.getClass();
            xMPushService.a((XMPushService.i)new /* Unavailable Anonymous Inner Class!! */, (long)n4);
            if (this.b == 2 && hi.a().a()) {
                ad.b();
            }
            if (this.b == 3) {
                ad.a();
                return;
            }
        } else {
            b.c((String)"should not reconnect as no client or network.");
        }
    }
}

