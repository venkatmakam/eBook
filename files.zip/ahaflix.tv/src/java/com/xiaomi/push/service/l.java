/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.content.pm.PackageInfo
 *  android.content.pm.PackageManager
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.text.TextUtils
 *  com.xiaomi.channel.commonutils.logger.b
 *  com.xiaomi.push.ab
 *  com.xiaomi.push.ax
 *  com.xiaomi.push.ba
 *  com.xiaomi.push.bc
 *  com.xiaomi.push.bi
 *  com.xiaomi.push.fx
 *  e.a.a.a.a
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.Map
 *  java.util.TreeMap
 *  org.json.JSONObject
 */
package com.xiaomi.push.service;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.text.TextUtils;
import com.xiaomi.channel.commonutils.logger.b;
import com.xiaomi.push.ab;
import com.xiaomi.push.ax;
import com.xiaomi.push.ba;
import com.xiaomi.push.bc;
import com.xiaomi.push.bi;
import com.xiaomi.push.fx;
import com.xiaomi.push.i;
import com.xiaomi.push.o;
import com.xiaomi.push.service.k;
import java.util.Map;
import java.util.TreeMap;
import org.json.JSONObject;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class l {
    private static k a;
    private static a a;

    public static k a(Context context) {
        Class<l> class_ = l.class;
        synchronized (l.class) {
            block8 : {
                k k3 = a;
                if (k3 == null) break block8;
                return k3;
            }
            SharedPreferences sharedPreferences = context.getSharedPreferences("mipush_account", 0);
            String string2 = sharedPreferences.getString("uuid", null);
            String string3 = sharedPreferences.getString("token", null);
            String string4 = sharedPreferences.getString("security", null);
            String string5 = sharedPreferences.getString("app_id", null);
            String string6 = sharedPreferences.getString("app_token", null);
            String string7 = sharedPreferences.getString("package_name", null);
            String string8 = sharedPreferences.getString("device_id", null);
            int n4 = sharedPreferences.getInt("env_type", 1);
            if (!TextUtils.isEmpty((CharSequence)string8) && i.a(string8)) {
                string8 = i.k(context);
                sharedPreferences.edit().putString("device_id", string8).commit();
            }
            if (!(TextUtils.isEmpty((CharSequence)string2) || TextUtils.isEmpty((CharSequence)string3) || TextUtils.isEmpty((CharSequence)string4))) {
                k k4;
                String string9 = i.k(context);
                if (!("com.xiaomi.xmsf".equals((Object)context.getPackageName()) || TextUtils.isEmpty((CharSequence)string9) || TextUtils.isEmpty((CharSequence)string8) || string8.equals((Object)string9))) {
                    b.a((String)"read_phone_state permission changes.");
                }
                a = k4 = new k(string2, string3, string4, string5, string6, string7, n4);
                // ** MonitorExit[var15_1] (shouldn't be in output)
                return k4;
            }
            return null;
            finally {
                // ** MonitorExit[var15_1] (shouldn't be in output)
            }
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public static k a(Context var0, String var1_1, String var2_2, String var3_3) {
        var77_4 = l.class;
        // MONITORENTER : com.xiaomi.push.service.l.class
        var4_5 = new TreeMap();
        var6_6 = i.a(var0, false);
        var7_7 = new StringBuilder();
        var7_7.append("account register:");
        var7_7.append(var6_6);
        var7_7.append(" mim:");
        var7_7.append(ax.a((Context)var0).e());
        b.a((String)var7_7.toString());
        var4_5.put((Object)"devid", (Object)var6_6);
        var4_5.put((Object)"devid1", (Object)i.a(var0));
        var14_8 = l.a;
        if (var14_8 == null || TextUtils.isEmpty((CharSequence)var14_8.a)) ** GOTO lbl-1000
        var4_5.put((Object)"uuid", (Object)l.a.a);
        var76_9 = l.a.a.lastIndexOf("/");
        if (var76_9 != -1) {
            var15_10 = l.a.a.substring(var76_9 + 1);
        } else lbl-1000: // 2 sources:
        {
            var15_10 = null;
        }
        ax.a((Context)var0).a((Map)var4_5);
        var16_11 = i.c(var0);
        if (var16_11 != null) {
            var4_5.put((Object)"vdevid", (Object)var16_11);
        }
        if (!TextUtils.isEmpty((CharSequence)(var18_12 = i.b(var0)))) {
            var4_5.put((Object)"gaid", (Object)var18_12);
        }
        if (l.a(var0)) {
            var2_2 = "1000271";
        }
        var19_13 = var2_2;
        if (l.a(var0)) {
            var3_3 = "420100086271";
        }
        var20_14 = var3_3;
        if (l.a(var0)) {
            var1_1 = "com.xiaomi.xmsf";
        }
        var21_15 = var1_1;
        var4_5.put((Object)"appid", (Object)var19_13);
        var4_5.put((Object)"apptoken", (Object)var20_14);
        try {
            var25_16 = var0.getPackageManager().getPackageInfo(var21_15, 16384);
        }
        catch (Exception var24_17) {
            b.a((Throwable)var24_17);
            var25_16 = null;
        }
        var26_18 = var25_16 != null ? String.valueOf((int)var25_16.versionCode) : "0";
        var4_5.put((Object)"appversion", (Object)var26_18);
        var4_5.put((Object)"sdkversion", (Object)Integer.toString((int)30706));
        var4_5.put((Object)"packagename", (Object)var21_15);
        var4_5.put((Object)"model", (Object)Build.MODEL);
        var4_5.put((Object)"board", (Object)Build.BOARD);
        if (!com.xiaomi.push.l.d()) {
            var32_19 = "";
            var33_20 = i.f(var0);
            if (!TextUtils.isEmpty((CharSequence)var33_20)) {
                var34_21 = new StringBuilder();
                var34_21.append(var32_19);
                var34_21.append(bi.a((String)var33_20));
                var32_19 = var34_21.toString();
            }
            var37_22 = i.h(var0);
            if (!TextUtils.isEmpty((CharSequence)var32_19) && !TextUtils.isEmpty((CharSequence)var37_22)) {
                var70_23 = new StringBuilder();
                var70_23.append(var32_19);
                var70_23.append(",");
                var70_23.append(var37_22);
                var32_19 = var70_23.toString();
            }
            if (!TextUtils.isEmpty((CharSequence)var32_19)) {
                var4_5.put((Object)"imei_md5", (Object)var32_19);
            }
        }
        var38_24 = new StringBuilder();
        var38_24.append(Build.VERSION.RELEASE);
        var38_24.append("-");
        var38_24.append(Build.VERSION.INCREMENTAL);
        var4_5.put((Object)"os", (Object)var38_24.toString());
        var43_25 = i.a();
        if (var43_25 >= 0) {
            var4_5.put((Object)"space_id", (Object)Integer.toString((int)var43_25));
        }
        if (!TextUtils.isEmpty((CharSequence)(var45_26 = i.n(var0)))) {
            var4_5.put((Object)"mac_address", (Object)bi.a((String)var45_26));
        }
        var4_5.put((Object)"android_id", (Object)i.e(var0));
        var47_27 = new StringBuilder();
        var47_27.append(Build.BRAND);
        var47_27.append("");
        var4_5.put((Object)"brand", (Object)var47_27.toString());
        var4_5.put((Object)"ram", (Object)i.b());
        var4_5.put((Object)"rom", (Object)i.c());
        var53_28 = bc.a((Context)var0, (String)l.a(var0), (Map)var4_5);
        var54_29 = "";
        if (var53_28 != null) {
            var54_29 = var53_28.a();
        }
        if (!TextUtils.isEmpty((CharSequence)var54_29)) {
            var55_30 = new JSONObject(var54_29);
            if (var55_30.getInt("code") == 0) {
                var56_31 = var55_30.getJSONObject("data");
                var57_32 = var56_31.getString("ssecurity");
                var58_33 = var56_31.getString("token");
                var59_34 = var56_31.getString("userId");
                if (TextUtils.isEmpty((CharSequence)var15_10)) {
                    var60_35 = new StringBuilder();
                    var60_35.append("an");
                    var60_35.append(bi.a((int)6));
                    var15_10 = var60_35.toString();
                }
                var63_36 = new StringBuilder();
                var63_36.append(var59_34);
                var63_36.append("@xiaomi.com/");
                var63_36.append(var15_10);
                var67_37 = new k(var63_36.toString(), var58_33, var57_32, var19_13, var20_14, var21_15, ab.a());
                l.a(var0, var67_37);
                i.a(var0, var56_31.optString("vdevid"));
                l.a = var67_37;
                // MONITOREXIT : var77_4
                return var67_37;
            }
            com.xiaomi.push.service.o.a(var0, var55_30.getInt("code"), var55_30.optString("description"));
            b.a((String)var54_29);
        }
        // MONITOREXIT : var77_4
        return null;
    }

    public static String a(Context context) {
        String string2;
        StringBuilder stringBuilder;
        String string3 = com.xiaomi.push.service.a.a(context).a();
        if (ab.b()) {
            stringBuilder = e.a.a.a.a.F1((String)"http://");
            stringBuilder.append(fx.b);
            string2 = ":9085";
        } else if (o.a.name().equals((Object)string3)) {
            stringBuilder = new StringBuilder();
            string2 = "https://cn.register.xmpush.xiaomi.com";
        } else if (o.b.name().equals((Object)string3)) {
            stringBuilder = new StringBuilder();
            string2 = "https://register.xmpush.global.xiaomi.com";
        } else if (o.c.name().equals((Object)string3)) {
            stringBuilder = new StringBuilder();
            string2 = "https://fr.register.xmpush.global.xiaomi.com";
        } else if (o.d.name().equals((Object)string3)) {
            stringBuilder = new StringBuilder();
            string2 = "https://ru.register.xmpush.global.xiaomi.com";
        } else if (o.e.name().equals((Object)string3)) {
            stringBuilder = new StringBuilder();
            string2 = "https://idmb.register.xmpush.global.xiaomi.com";
        } else {
            stringBuilder = e.a.a.a.a.F1((String)"https://");
            string2 = ab.a() ? "sandbox.xmpush.xiaomi.com" : "register.xmpush.xiaomi.com";
        }
        return e.a.a.a.a.r1((StringBuilder)stringBuilder, (String)string2, (String)"/pass/v2/register");
    }

    public static void a() {
        a a2 = a;
        if (a2 != null) {
            a2.a();
        }
    }

    public static void a(Context context) {
        context.getSharedPreferences("mipush_account", 0).edit().clear().commit();
        a = null;
        l.a();
    }

    public static void a(Context context, k k3) {
        SharedPreferences.Editor editor = context.getSharedPreferences("mipush_account", 0).edit();
        editor.putString("uuid", k3.a);
        editor.putString("security", k3.c);
        editor.putString("token", k3.b);
        editor.putString("app_id", k3.d);
        editor.putString("package_name", k3.f);
        editor.putString("app_token", k3.e);
        editor.putString("device_id", i.k(context));
        editor.putInt("env_type", k3.a);
        editor.commit();
        l.a();
    }

    public static void a(a a2) {
        a = a2;
    }

    private static boolean a(Context context) {
        return context.getPackageName().equals((Object)"com.xiaomi.xmsf");
    }

    public static interface a {
        public void a();
    }

}

