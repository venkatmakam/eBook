/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.xiaomi.push.gk
 *  com.xiaomi.push.gt
 *  com.xiaomi.push.gu
 *  com.xiaomi.push.gy
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 *  org.xmlpull.v1.XmlPullParser
 */
package com.xiaomi.push.service;

import com.xiaomi.push.gk;
import com.xiaomi.push.gt;
import com.xiaomi.push.gu;
import com.xiaomi.push.gy;
import java.util.ArrayList;
import java.util.List;
import org.xmlpull.v1.XmlPullParser;

public class e
implements gt {
    public static gk a(XmlPullParser xmlPullParser) {
        int n5;
        String[] arrstring;
        String[] arrstring2;
        String string;
        ArrayList arrayList;
        if (xmlPullParser.getEventType() != 2) {
            return null;
        }
        String string2 = xmlPullParser.getName();
        String string3 = xmlPullParser.getNamespace();
        if (xmlPullParser.getAttributeCount() > 0) {
            String[] arrstring3 = new String[xmlPullParser.getAttributeCount()];
            String[] arrstring4 = new String[xmlPullParser.getAttributeCount()];
            for (int i5 = 0; i5 < xmlPullParser.getAttributeCount(); ++i5) {
                arrstring3[i5] = xmlPullParser.getAttributeName(i5);
                arrstring4[i5] = gy.b((String)xmlPullParser.getAttributeValue(i5));
            }
            arrstring2 = arrstring3;
            arrstring = arrstring4;
            string = null;
            arrayList = null;
        } else {
            arrstring2 = null;
            arrstring = null;
            string = null;
            arrayList = null;
        }
        while ((n5 = xmlPullParser.next()) != 3) {
            gk gk2;
            if (n5 == 4) {
                string = xmlPullParser.getText().trim();
                continue;
            }
            if (n5 != 2) continue;
            if (arrayList == null) {
                arrayList = new ArrayList();
            }
            if ((gk2 = e.a(xmlPullParser)) == null) continue;
            arrayList.add((Object)gk2);
        }
        gk gk3 = new gk(string2, string3, arrstring2, arrstring, string, arrayList);
        return gk3;
    }

    public void a() {
        gu.a().a("all", "xm:chat", (Object)this);
    }

    public gk b(XmlPullParser xmlPullParser) {
        int n5 = xmlPullParser.getEventType();
        while (n5 != 1 && n5 != 2) {
            n5 = xmlPullParser.next();
        }
        if (n5 == 2) {
            return e.a(xmlPullParser);
        }
        return null;
    }
}

