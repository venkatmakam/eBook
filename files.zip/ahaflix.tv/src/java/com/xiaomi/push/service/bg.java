/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.util.Base64
 *  com.xiaomi.channel.commonutils.logger.b
 *  com.xiaomi.push.al
 *  com.xiaomi.push.al$b
 *  com.xiaomi.push.dg
 *  com.xiaomi.push.en
 *  com.xiaomi.push.en$a
 *  com.xiaomi.push.service.bf
 *  com.xiaomi.push.service.bf$a
 *  com.xiaomi.push.t
 *  e.a.a.a.a
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.xiaomi.push.service;

import android.content.Context;
import android.util.Base64;
import com.xiaomi.channel.commonutils.logger.b;
import com.xiaomi.push.al;
import com.xiaomi.push.dg;
import com.xiaomi.push.en;
import com.xiaomi.push.service.bf;
import com.xiaomi.push.t;
import e.a.a.a.a;

public class bg
extends al.b {
    public boolean a = false;
    public final /* synthetic */ bf b;

    public bg(bf bf2) {
        this.b = bf2;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public void b() {
        en.a a3 = en.a.a((byte[])Base64.decode((String)dg.a((Context)t.a(), (String)"http://resolver.msg.xiaomi.net/psc/?t=a", null), (int)10));
        if (a3 == null) return;
        try {
            bf.i((bf)this.b, (en.a)a3);
            this.a = true;
            bf.m((bf)this.b);
            return;
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = a.F1((String)"fetch config failure: ");
            stringBuilder.append(exception.getMessage());
            b.a((String)stringBuilder.toString());
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void c() {
        bf.g((bf)this.b, null);
        if (this.a) {
            bf.a[] arra;
            bf bf2;
            bf bf3 = bf2 = this.b;
            synchronized (bf3) {
                arra = (bf.a[])bf.j((bf)this.b).toArray((Object[])new bf.a[bf.j((bf)this.b).size()]);
            }
            int n5 = arra.length;
            for (int i5 = 0; i5 < n5; ++i5) {
                arra[i5].a(bf.h((bf)this.b));
            }
        }
    }
}

