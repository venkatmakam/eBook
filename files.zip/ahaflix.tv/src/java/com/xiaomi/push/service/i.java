/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.SharedPreferences
 *  com.xiaomi.push.hp
 *  com.xiaomi.push.hu
 *  com.xiaomi.push.service.j
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 */
package com.xiaomi.push.service;

import android.content.SharedPreferences;
import com.xiaomi.push.hp;
import com.xiaomi.push.hu;
import com.xiaomi.push.service.XMPushService;
import com.xiaomi.push.service.j;
import java.util.List;

public class i
implements hp {
    private final XMPushService a;

    public i(XMPushService xMPushService) {
        this.a = xMPushService;
    }

    public static /* synthetic */ XMPushService a(i i5) {
        return i5.a;
    }

    private String a(String string) {
        if ("com.xiaomi.xmsf".equals((Object)string)) {
            return "1000271";
        }
        return this.a.getSharedPreferences("pref_registered_pkg_names", 0).getString(string, null);
    }

    public static /* synthetic */ String b(i i5, String string) {
        return i5.a(string);
    }

    public void a(List<hu> list, String string, String string2) {
        XMPushService xMPushService = this.a;
        j j6 = new j(this, 4, string, list, string2);
        xMPushService.a((XMPushService.i)j6);
    }
}

