/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.xiaomi.channel.commonutils.logger.b
 *  e.a.a.a.a
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.Collection
 *  java.util.Iterator
 */
package com.xiaomi.push.service;

import com.xiaomi.channel.commonutils.logger.b;
import com.xiaomi.push.service.bh;
import e.a.a.a.a;
import java.util.Collection;
import java.util.Iterator;

public class bi
implements Runnable {
    public final /* synthetic */ bh a;

    public bi(bh bh2) {
        this.a = bh2;
    }

    public void run() {
        try {
            Iterator iterator = bh.c(this.a).values().iterator();
            while (iterator.hasNext()) {
                (iterator.next()).run();
            }
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = a.F1((String)"Sync job exception :");
            stringBuilder.append(exception.getMessage());
            b.a((String)stringBuilder.toString());
        }
        bh.d(this.a, false);
    }
}

