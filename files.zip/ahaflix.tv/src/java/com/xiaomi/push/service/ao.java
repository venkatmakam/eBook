/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.text.TextUtils
 *  com.xiaomi.push.bi
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.xiaomi.push.service;

import android.text.TextUtils;
import com.xiaomi.push.bi;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class ao {
    private static long a = 0L;
    private static String a = "";

    public static String a() {
        if (TextUtils.isEmpty((CharSequence)a)) {
            a = bi.a((int)4);
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(a);
        long l3 = a;
        a = 1L + l3;
        stringBuilder.append(l3);
        return stringBuilder.toString();
    }
}

