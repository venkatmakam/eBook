/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  java.lang.Object
 *  java.lang.Runnable
 */
package com.xiaomi.push.service.receivers;

import android.content.Context;
import com.xiaomi.push.service.receivers.NetworkStatusReceiver;

public class a
implements Runnable {
    public final /* synthetic */ Context a;
    public final /* synthetic */ NetworkStatusReceiver b;

    public a(NetworkStatusReceiver networkStatusReceiver, Context context) {
        this.b = networkStatusReceiver;
        this.a = context;
    }

    public void run() {
        NetworkStatusReceiver.b(this.b, this.a);
    }
}

