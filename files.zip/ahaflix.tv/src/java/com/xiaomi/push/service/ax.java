/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.annotation.SuppressLint
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.net.Uri
 *  android.provider.Settings
 *  android.provider.Settings$Global
 *  com.xiaomi.push.ab
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 */
package com.xiaomi.push.service;

import android.annotation.SuppressLint;
import android.content.ContentResolver;
import android.content.Context;
import android.net.Uri;
import android.provider.Settings;
import com.xiaomi.push.ab;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class ax {
    private static ax a;
    private int a;
    private Context a = 0;

    private ax(Context context) {
        this.a = context.getApplicationContext();
    }

    public static ax a(Context context) {
        if (a == null) {
            a = new ax(context);
        }
        return a;
    }

    @SuppressLint(value={"NewApi"})
    public int a() {
        int n4 = this.a;
        if (n4 != 0) {
            return n4;
        }
        try {
            this.a = Settings.Global.getInt((ContentResolver)this.a.getContentResolver(), (String)"device_provisioned", (int)0);
        }
        catch (Exception exception) {}
        return this.a;
    }

    @SuppressLint(value={"NewApi"})
    public Uri a() {
        return Settings.Global.getUriFor((String)"device_provisioned");
    }

    public boolean a() {
        String string2 = ab.a;
        return string2.contains((CharSequence)"xmsf") || string2.contains((CharSequence)"xiaomi") || string2.contains((CharSequence)"miui");
        {
        }
    }
}

