/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Process
 *  android.text.TextUtils
 *  com.xiaomi.channel.commonutils.logger.b
 *  com.xiaomi.push.da
 *  com.xiaomi.push.en
 *  com.xiaomi.push.en$a
 *  e.a.a.a.a
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Throwable
 *  java.net.Socket
 *  java.net.SocketAddress
 *  java.util.List
 *  java.util.concurrent.BlockingQueue
 *  java.util.concurrent.LinkedBlockingQueue
 *  java.util.concurrent.ThreadPoolExecutor
 *  java.util.concurrent.TimeUnit
 *  java.util.regex.Pattern
 */
package com.xiaomi.push.service;

import android.os.Process;
import android.text.TextUtils;
import com.xiaomi.channel.commonutils.logger.b;
import com.xiaomi.push.da;
import com.xiaomi.push.en;
import com.xiaomi.push.hi;
import com.xiaomi.push.service.ae;
import com.xiaomi.push.service.bf;
import e.a.a.a.a;
import java.net.Socket;
import java.net.SocketAddress;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class ad {
    private static long a;
    private static ThreadPoolExecutor a;
    private static final Pattern a;

    public static {
        ThreadPoolExecutor threadPoolExecutor;
        a = Pattern.compile((String)"([0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3})");
        a = 0L;
        a = threadPoolExecutor = new ThreadPoolExecutor(1, 1, 20L, TimeUnit.SECONDS, (BlockingQueue)new LinkedBlockingQueue());
    }

    /*
     * Exception decompiling
     */
    private static String a(String var0) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl54 : ALOAD_2 : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    public static void a() {
        en.a a2;
        long l3 = System.currentTimeMillis();
        if (a.getActiveCount() > 0 && l3 - a < 1800000L) {
            return;
        }
        if (hi.a().a() && (a2 = bf.a().a()) != null && a2.e() > 0) {
            a = l3;
            ad.a((List<String>)a2.a(), true);
        }
    }

    public static void a(List<String> list, boolean bl2) {
        a.execute((Runnable)new ae(list, bl2));
    }

    public static void b() {
        String string2;
        String string3 = ad.a("/proc/self/net/tcp");
        if (!TextUtils.isEmpty((CharSequence)string3)) {
            StringBuilder stringBuilder = a.F1((String)"dump tcp for uid = ");
            stringBuilder.append(Process.myUid());
            b.a((String)stringBuilder.toString());
            b.a((String)string3);
        }
        if (!TextUtils.isEmpty((CharSequence)(string2 = ad.a("/proc/self/net/tcp6")))) {
            StringBuilder stringBuilder = a.F1((String)"dump tcp6 for uid = ");
            stringBuilder.append(Process.myUid());
            b.a((String)stringBuilder.toString());
            b.a((String)string2);
        }
    }

    private static boolean b(String string2) {
        long l3 = System.currentTimeMillis();
        try {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("ConnectivityTest: begin to connect to ");
            stringBuilder.append(string2);
            b.a((String)stringBuilder.toString());
            Socket socket = new Socket();
            socket.connect((SocketAddress)da.a((String)string2, (int)5222), 5000);
            socket.setTcpNoDelay(true);
            long l4 = System.currentTimeMillis() - l3;
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append("ConnectivityTest: connect to ");
            stringBuilder2.append(string2);
            stringBuilder2.append(" in ");
            stringBuilder2.append(l4);
            b.a((String)stringBuilder2.toString());
            socket.close();
            return true;
        }
        catch (Throwable throwable) {
            StringBuilder stringBuilder = a.f((String)"ConnectivityTest: could not connect to:", (String)string2, (String)" exception: ");
            stringBuilder.append(throwable.getClass().getSimpleName());
            stringBuilder.append(" description: ");
            stringBuilder.append(throwable.getMessage());
            b.d((String)stringBuilder.toString());
            return false;
        }
    }

    public static /* synthetic */ boolean c(String string2) {
        return ad.b(string2);
    }
}

