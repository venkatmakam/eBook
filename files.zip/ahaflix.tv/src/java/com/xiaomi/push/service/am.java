/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.util.Pair
 *  com.xiaomi.push.ad
 *  com.xiaomi.push.hz
 *  com.xiaomi.push.ib
 *  com.xiaomi.push.in
 *  e.a.a.a.a
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.List
 */
package com.xiaomi.push.service;

import android.content.SharedPreferences;
import android.util.Pair;
import com.xiaomi.push.ad;
import com.xiaomi.push.hw;
import com.xiaomi.push.hx;
import com.xiaomi.push.hz;
import com.xiaomi.push.ib;
import com.xiaomi.push.in;
import com.xiaomi.push.io;
import com.xiaomi.push.service.al;
import com.xiaomi.push.service.an;
import e.a.a.a.a;
import java.util.ArrayList;
import java.util.List;

public class am {
    public static int a(al al2, hw hw2) {
        int n4;
        String string2 = am.a(hw2);
        int n5 = an.a[hw2.ordinal()];
        if (n5 != (n4 = 1)) {
            n4 = 0;
        }
        return al2.b.getInt(string2, n4);
    }

    private static String a(hw hw2) {
        StringBuilder stringBuilder = a.F1((String)"oc_version_");
        stringBuilder.append(hw2.a());
        return stringBuilder.toString();
    }

    private static List<Pair<Integer, Object>> a(List<ib> list, boolean bl2) {
        if (ad.a(list)) {
            return null;
        }
        ArrayList arrayList = new ArrayList();
        for (ib ib2 : list) {
            int n4 = ib2.a();
            hx hx2 = hx.a(ib2.b());
            if (hx2 == null) continue;
            if (bl2 && ib2.a) {
                arrayList.add((Object)new Pair((Object)n4, null));
                continue;
            }
            int n5 = an.b[hx2.ordinal()];
            Object object = n5 != 1 ? (n5 != 2 ? (n5 != 3 ? (n5 != 4 ? null : new Pair((Object)n4, (Object)ib2.g())) : new Pair((Object)n4, (Object)ib2.a())) : new Pair((Object)n4, (Object)ib2.a())) : new Pair((Object)n4, (Object)ib2.c());
            arrayList.add(object);
        }
        return arrayList;
    }

    public static void a(al al2, hw hw2, int n4) {
        String string2 = am.a(hw2);
        al2.b.edit().putInt(string2, n4).commit();
    }

    public static void a(al al2, in in2) {
        al2.b(am.a((List<ib>)in2.a(), true));
        al2.c();
    }

    public static void a(al al2, io io2) {
        for (hz hz2 : io2.a()) {
            if (hz2.a() <= am.a(al2, hz2.a())) continue;
            am.a(al2, hz2.a(), hz2.a());
            al2.a(am.a((List<ib>)hz2.a, false));
        }
        al2.c();
    }
}

