/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.xiaomi.channel.commonutils.logger.b
 *  com.xiaomi.push.ai
 *  com.xiaomi.push.ai$a
 *  com.xiaomi.push.hq
 *  com.xiaomi.push.ja
 *  com.xiaomi.push.jb
 *  com.xiaomi.push.service.ao
 *  com.xiaomi.push.service.w
 *  e.a.a.a.a
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.ref.WeakReference
 */
package com.xiaomi.push.service;

import com.xiaomi.push.ai;
import com.xiaomi.push.hq;
import com.xiaomi.push.ip;
import com.xiaomi.push.ja;
import com.xiaomi.push.jb;
import com.xiaomi.push.service.XMPushService;
import com.xiaomi.push.service.ao;
import com.xiaomi.push.service.w;
import e.a.a.a.a;
import java.lang.ref.WeakReference;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class b
extends ai.a {
    private ip a;
    private WeakReference<XMPushService> a;
    private boolean a = false;

    public b(ip ip2, WeakReference<XMPushService> weakReference, boolean bl) {
        this.a = ip2;
        this.a = weakReference;
        this.a = bl;
    }

    public int a() {
        return 22;
    }

    public void run() {
        ip ip2 = this.a;
        if (ip2 != null) {
            if (this.a == null) {
                return;
            }
            XMPushService xMPushService = (XMPushService)((Object)ip2.get());
            if (xMPushService == null) {
                return;
            }
            this.a.a(ao.a());
            this.a.a(false);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("MoleInfo aw_ping : send aw_Ping msg ");
            stringBuilder.append(this.a.a());
            com.xiaomi.channel.commonutils.logger.b.c((String)stringBuilder.toString());
            try {
                String string = this.a.c();
                xMPushService.o(string, ja.a((jb)w.c((String)string, (String)this.a.b(), (jb)this.a, (hq)hq.i)), this.a);
                return;
            }
            catch (Exception exception) {
                StringBuilder stringBuilder2 = a.F1((String)"MoleInfo aw_ping : send help app ping error");
                stringBuilder2.append(exception.toString());
                com.xiaomi.channel.commonutils.logger.b.d((String)stringBuilder2.toString());
            }
        }
    }
}

