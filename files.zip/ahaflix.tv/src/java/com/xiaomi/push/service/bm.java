/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.xiaomi.push.fp
 *  com.xiaomi.push.gb
 *  com.xiaomi.push.gn
 *  com.xiaomi.push.service.XMPushService$c
 *  com.xiaomi.push.service.XMPushService$k
 *  java.lang.Object
 */
package com.xiaomi.push.service;

import com.xiaomi.push.fp;
import com.xiaomi.push.gb;
import com.xiaomi.push.gn;
import com.xiaomi.push.service.XMPushService;

/*
 * Exception performing whole class analysis.
 */
public class bm
implements gb {
    public final /* synthetic */ XMPushService a;

    public bm(XMPushService xMPushService) {
        this.a = xMPushService;
    }

    public void a(fp fp2) {
        XMPushService xMPushService = this.a;
        xMPushService.a((XMPushService.i)new /* Unavailable Anonymous Inner Class!! */);
    }

    public void a(gn gn2) {
        XMPushService xMPushService = this.a;
        xMPushService.a((XMPushService.i)new /* Unavailable Anonymous Inner Class!! */);
    }
}

