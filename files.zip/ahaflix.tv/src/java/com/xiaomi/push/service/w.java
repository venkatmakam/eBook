/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Messenger
 *  android.text.TextUtils
 *  com.xiaomi.channel.commonutils.logger.b
 *  com.xiaomi.push.di
 *  com.xiaomi.push.fp
 *  com.xiaomi.push.fw
 *  com.xiaomi.push.gh
 *  com.xiaomi.push.gn
 *  com.xiaomi.push.id
 *  com.xiaomi.push.if
 *  com.xiaomi.push.im
 *  e.a.a.a.a
 *  java.lang.CharSequence
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.nio.ByteBuffer
 *  java.util.Map
 */
package com.xiaomi.push.service;

import android.content.Context;
import android.os.Messenger;
import android.text.TextUtils;
import com.xiaomi.channel.commonutils.logger.b;
import com.xiaomi.push.di;
import com.xiaomi.push.fp;
import com.xiaomi.push.fw;
import com.xiaomi.push.gh;
import com.xiaomi.push.gn;
import com.xiaomi.push.hq;
import com.xiaomi.push.id;
import com.xiaomi.push.if;
import com.xiaomi.push.im;
import com.xiaomi.push.ip;
import com.xiaomi.push.ja;
import com.xiaomi.push.jb;
import com.xiaomi.push.jg;
import com.xiaomi.push.service.XMPushService;
import com.xiaomi.push.service.aq;
import com.xiaomi.push.service.bh;
import com.xiaomi.push.service.k;
import com.xiaomi.push.service.l;
import com.xiaomi.push.service.o;
import com.xiaomi.push.service.x;
import com.xiaomi.push.service.y;
import com.xiaomi.push.service.z;
import e.a.a.a.a;
import java.nio.ByteBuffer;
import java.util.Map;

public final class w {
    public static fp a(k k3, im im2) {
        try {
            fp fp2 = new fp();
            fp2.a(5);
            fp2.c(k3.a);
            fp2.b(w.a(im2));
            fp2.a("SECMSG", "message");
            String string2 = k3.a;
            im2.a.a = string2.substring(0, string2.indexOf("@"));
            im2.a.c = string2.substring(1 + string2.indexOf("/"));
            fp2.a(ja.a(im2), k3.c);
            fp2.a((short)1);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("try send mi push message. packagename:");
            stringBuilder.append(im2.b);
            stringBuilder.append(" action:");
            stringBuilder.append((Object)im2.a);
            b.a((String)stringBuilder.toString());
            return fp2;
        }
        catch (NullPointerException nullPointerException) {
            b.a((Throwable)nullPointerException);
            return null;
        }
    }

    private static String a(im im2) {
        String string2;
        Map map;
        id id2 = im2.a;
        if (id2 != null && (map = id2.b) != null && !TextUtils.isEmpty((CharSequence)(string2 = (String)map.get((Object)"ext_traffic_source_pkg")))) {
            return string2;
        }
        return im2.b;
    }

    private static void a(XMPushService xMPushService, k k3, int n4) {
        bh bh2 = bh.a((Context)xMPushService);
        y y3 = new y("MSAID", n4, xMPushService, k3);
        bh2.a(y3);
    }

    public static im b(String string2, String string3) {
        ip ip2 = new ip();
        ip2.b(string3);
        ip2.c("package uninstalled");
        ip2.a(gn.i());
        ip2.a(false);
        return w.c(string2, string3, ip2, hq.i);
    }

    public static <T extends jb<T, ?>> im c(String string2, String string3, T t2, hq hq2) {
        byte[] arrby = ja.a(t2);
        im im2 = new im();
        if if_ = new if();
        if_.a = 5L;
        if_.a = "fakeid";
        im2.a(if_);
        im2.a(ByteBuffer.wrap((byte[])arrby));
        im2.a(hq2);
        im2.b(true);
        im2.b(string2);
        im2.a(false);
        im2.a(string3);
        return im2;
    }

    public static String d(String string2) {
        return a.h1((String)string2, (String)".permission.MIPUSH_RECEIVE");
    }

    public static void e(XMPushService xMPushService) {
        k k3 = l.a(xMPushService.getApplicationContext());
        if (k3 != null) {
            aq.b b7 = l.a(xMPushService.getApplicationContext()).a(xMPushService);
            b7.e(null);
            b7.a(new z(xMPushService));
            aq.a().a(b7);
            bh bh2 = bh.a((Context)xMPushService);
            x x2 = new x("GAID", 172800L, xMPushService, k3);
            bh2.a(x2);
            w.a(xMPushService, k3, 172800);
        }
    }

    public static void f(XMPushService xMPushService, im im2) {
        di.a((String)im2.b(), (Context)xMPushService.getApplicationContext(), (im)im2, (int)-1);
        fw fw2 = xMPushService.a();
        if (fw2 != null) {
            if (fw2.a()) {
                fp fp2 = w.a(l.a((Context)xMPushService), im2);
                if (fp2 != null) {
                    fw2.b(fp2);
                }
                return;
            }
            throw new gh("Don't support XMPP connection.");
        }
        throw new gh("try send msg while connection is null.");
    }

    public static void g(XMPushService xMPushService, String string2, byte[] arrby) {
        di.a((String)string2, (Context)xMPushService.getApplicationContext(), (byte[])arrby);
        fw fw2 = xMPushService.a();
        if (fw2 != null) {
            if (fw2.a()) {
                fp fp2;
                im im2 = new im();
                try {
                    ja.a(im2, arrby);
                    fp2 = w.a(l.a((Context)xMPushService), im2);
                }
                catch (jg jg2) {
                    b.a((Throwable)jg2);
                    fp2 = null;
                }
                if (fp2 != null) {
                    fw2.b(fp2);
                    return;
                }
                o.a((Context)xMPushService, string2, arrby, 70000003, "not a valid message");
                return;
            }
            throw new gh("Don't support XMPP connection.");
        }
        throw new gh("try send msg while connection is null.");
    }
}

