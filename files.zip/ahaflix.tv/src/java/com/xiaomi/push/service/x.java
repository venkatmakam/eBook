/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.text.TextUtils
 *  com.xiaomi.channel.commonutils.logger.b
 *  com.xiaomi.push.hq
 *  com.xiaomi.push.i
 *  com.xiaomi.push.ia
 *  com.xiaomi.push.ja
 *  com.xiaomi.push.jb
 *  com.xiaomi.push.service.ao
 *  com.xiaomi.push.service.bh$a
 *  com.xiaomi.push.service.k
 *  com.xiaomi.push.service.w
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.HashMap
 *  java.util.Map
 */
package com.xiaomi.push.service;

import android.content.Context;
import android.text.TextUtils;
import com.xiaomi.channel.commonutils.logger.b;
import com.xiaomi.push.hq;
import com.xiaomi.push.i;
import com.xiaomi.push.ia;
import com.xiaomi.push.ip;
import com.xiaomi.push.ja;
import com.xiaomi.push.jb;
import com.xiaomi.push.service.XMPushService;
import com.xiaomi.push.service.ao;
import com.xiaomi.push.service.bh;
import com.xiaomi.push.service.k;
import com.xiaomi.push.service.w;
import java.util.HashMap;
import java.util.Map;

public final class x
extends bh.a {
    public final /* synthetic */ XMPushService c;
    public final /* synthetic */ k d;

    public x(String string, long l2, XMPushService xMPushService, k k5) {
        this.c = xMPushService;
        this.d = k5;
        super(string, l2);
    }

    public void a(bh bh2) {
        String string = bh2.a("GAID", "gaid");
        String string2 = i.b((Context)this.c);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("gaid :");
        stringBuilder.append(string2);
        b.c((String)stringBuilder.toString());
        if (!TextUtils.isEmpty((CharSequence)string2) && !TextUtils.equals((CharSequence)string, (CharSequence)string2)) {
            bh2.a("GAID", "gaid", string2);
            ip ip2 = new ip();
            ip2.b(this.d.d);
            ip2.c(ia.g.a);
            ip2.a(ao.a());
            ip2.a((Map<String, String>)new HashMap());
            ip2.a().put((Object)"gaid", (Object)string2);
            byte[] arrby = ja.a((jb)w.c((String)this.c.getPackageName(), (String)this.d.d, (jb)ip2, (hq)hq.i));
            XMPushService xMPushService = this.c;
            xMPushService.o(xMPushService.getPackageName(), arrby, true);
        }
    }
}

