/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Deprecated
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.xiaomi.push.service.module;

@Deprecated
public final class PushChannelRegion
extends Enum<PushChannelRegion> {
    private static final /* synthetic */ PushChannelRegion[] $VALUES;
    public static final /* enum */ PushChannelRegion China;
    public static final /* enum */ PushChannelRegion Europe;
    public static final /* enum */ PushChannelRegion Global;
    public static final /* enum */ PushChannelRegion India;
    public static final /* enum */ PushChannelRegion Russia;

    public static {
        PushChannelRegion pushChannelRegion;
        PushChannelRegion pushChannelRegion2;
        PushChannelRegion pushChannelRegion3;
        PushChannelRegion pushChannelRegion4;
        PushChannelRegion pushChannelRegion5;
        China = pushChannelRegion2 = new PushChannelRegion();
        Global = pushChannelRegion3 = new PushChannelRegion();
        Europe = pushChannelRegion5 = new PushChannelRegion();
        Russia = pushChannelRegion = new PushChannelRegion();
        India = pushChannelRegion4 = new PushChannelRegion();
        $VALUES = new PushChannelRegion[]{pushChannelRegion2, pushChannelRegion3, pushChannelRegion5, pushChannelRegion, pushChannelRegion4};
    }

    public static PushChannelRegion valueOf(String string2) {
        return (PushChannelRegion)Enum.valueOf(PushChannelRegion.class, (String)string2);
    }

    public static PushChannelRegion[] values() {
        return (PushChannelRegion[])$VALUES.clone();
    }
}

