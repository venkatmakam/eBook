/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.text.TextUtils
 *  com.xiaomi.channel.commonutils.logger.b
 *  com.xiaomi.push.ac
 *  com.xiaomi.push.ai
 *  com.xiaomi.push.bf
 *  com.xiaomi.push.bi
 *  com.xiaomi.push.hu
 *  java.io.BufferedOutputStream
 *  java.io.Closeable
 *  java.io.File
 *  java.io.FileOutputStream
 *  java.io.IOException
 *  java.io.OutputStream
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Throwable
 *  java.util.Arrays
 */
package com.xiaomi.push.service;

import android.content.Context;
import android.text.TextUtils;
import com.xiaomi.channel.commonutils.logger.b;
import com.xiaomi.push.ac;
import com.xiaomi.push.ai;
import com.xiaomi.push.bf;
import com.xiaomi.push.bi;
import com.xiaomi.push.h;
import com.xiaomi.push.hu;
import com.xiaomi.push.ja;
import com.xiaomi.push.p;
import com.xiaomi.push.service.bj;
import com.xiaomi.push.service.bl;
import com.xiaomi.push.y;
import java.io.BufferedOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Arrays;

public class bk {
    public static final Object a = new Object();

    public static void a(Context context, hu hu2) {
        if (!bj.a(hu2.e())) {
            return;
        }
        ai.a((Context)context).a((Runnable)new bl(context, hu2));
    }

    public static byte[] a(Context context) {
        String string2 = p.a(context).a("mipush", "td_key", "");
        if (TextUtils.isEmpty((CharSequence)string2)) {
            string2 = bi.a((int)20);
            p.a(context).a("mipush", "td_key", string2);
        }
        return bk.a(string2);
    }

    private static byte[] a(String string2) {
        byte[] arrby = Arrays.copyOf((byte[])bf.a((String)string2), (int)16);
        arrby[0] = 68;
        arrby[15] = 84;
        return arrby;
    }

    public static /* synthetic */ void b(Context context, hu hu2) {
        bk.c(context, hu2);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static void c(Context var0, hu var1_1) {
        block13 : {
            block14 : {
                var2_2 = bk.a(var0);
                try {
                    block17 : {
                        block15 : {
                            block16 : {
                                var13_3 = h.b(var2_2, ja.a(var1_1));
                                if (var13_3 == null || var13_3.length < 1) break block15;
                                if (var13_3.length <= 10240) break block16;
                                var20_4 = new StringBuilder();
                                var20_4.append("TinyData write to cache file failed case too much data content item:");
                                var20_4.append(var1_1.d());
                                var20_4.append("  ts:");
                                var20_4.append(System.currentTimeMillis());
                                var19_5 = var20_4.toString();
                                break block17;
                            }
                            var25_6 = new BufferedOutputStream((OutputStream)new FileOutputStream(new File(var0.getFilesDir(), "tiny_data.data"), true));
                            try {
                                var25_6.write(ac.a((int)var13_3.length));
                                var25_6.write(var13_3);
                                var25_6.flush();
                            }
                            catch (Throwable var28_7) {
                                var4_8 = var25_6;
                                var6_9 = var28_7;
                                break block13;
                            }
                            catch (Exception var27_12) {
                                var4_8 = var25_6;
                                var3_13 = var27_12;
                                break block14;
                            }
                            catch (IOException var26_16) {
                                var4_8 = var25_6;
                                var3_13 = var26_16;
                                ** GOTO lbl65
                            }
                            y.a(null);
                            y.a((Closeable)var25_6);
                            return;
                        }
                        var14_17 = new StringBuilder();
                        var14_17.append("TinyData write to cache file failed case encryption fail item:");
                        var14_17.append(var1_1.d());
                        var14_17.append("  ts:");
                        var14_17.append(System.currentTimeMillis());
                        var19_5 = var14_17.toString();
                    }
                    b.a((String)var19_5);
                }
                catch (Throwable var6_10) {
                    var4_8 = null;
                    break block13;
                }
                catch (Exception var3_14) {
                    var4_8 = null;
                }
                y.a(null);
                y.a(null);
                return;
            }
            try {
                var10_18 = new StringBuilder();
                var10_18.append("TinyData write to cache file  failed item:");
                var10_18.append(var1_1.d());
                var9_19 = var10_18.toString();
lbl58: // 2 sources:
                do {
                    b.a((String)var9_19, (Throwable)var3_13);
                    y.a(null);
                    y.a(var4_8);
                    return;
                    break;
                } while (true);
                catch (IOException var3_15) {
                    var4_8 = null;
                }
lbl65: // 2 sources:
                var5_20 = new StringBuilder();
                var5_20.append("TinyData write to cache file failed cause io exception item:");
                var5_20.append(var1_1.d());
                var9_19 = var5_20.toString();
                ** continue;
            }
            catch (Throwable var6_11) {
                // empty catch block
            }
        }
        y.a(null);
        y.a(var4_8);
        throw var6_9;
    }
}

