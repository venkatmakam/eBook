/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.annotation.SuppressLint
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Bundle
 *  android.os.Message
 *  android.os.Messenger
 *  android.os.RemoteException
 *  android.text.TextUtils
 *  com.xiaomi.channel.commonutils.logger.b
 *  com.xiaomi.push.fp
 *  com.xiaomi.push.gl
 *  com.xiaomi.push.gm
 *  com.xiaomi.push.gn
 *  com.xiaomi.push.gp
 *  e.a.a.a.a
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.Collection
 *  java.util.Iterator
 */
package com.xiaomi.push.service;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.text.TextUtils;
import com.xiaomi.channel.commonutils.logger.b;
import com.xiaomi.push.fp;
import com.xiaomi.push.gl;
import com.xiaomi.push.gm;
import com.xiaomi.push.gn;
import com.xiaomi.push.gp;
import com.xiaomi.push.l;
import com.xiaomi.push.service.XMPushService;
import com.xiaomi.push.service.aq;
import com.xiaomi.push.service.au;
import com.xiaomi.push.service.p;
import e.a.a.a.a;
import java.util.Collection;
import java.util.Iterator;

public class d {
    private p a = new p();

    public static String a(aq.b b7) {
        StringBuilder stringBuilder;
        String string2;
        if (!"9".equals((Object)b7.g)) {
            stringBuilder = new StringBuilder();
            stringBuilder.append(b7.a);
            string2 = ".permission.MIPUSH_RECEIVE";
        } else {
            stringBuilder = new StringBuilder();
            stringBuilder.append(b7.a);
            string2 = ".permission.MIMC_RECEIVE";
        }
        stringBuilder.append(string2);
        return stringBuilder.toString();
    }

    private static void a(Context context, Intent intent, aq.b b7) {
        if ("com.xiaomi.xmsf".equals((Object)context.getPackageName())) {
            context.sendBroadcast(intent);
            return;
        }
        context.sendBroadcast(intent, d.a(b7));
    }

    @SuppressLint(value={"WrongConstant"})
    public void a(Context context) {
        Intent intent = new Intent();
        intent.setAction("com.xiaomi.push.service_started");
        if (l.c()) {
            intent.addFlags(16777216);
        }
        context.sendBroadcast(intent);
    }

    public void a(Context context, aq.b b7, int n4) {
        if ("5".equalsIgnoreCase(b7.g)) {
            return;
        }
        Intent intent = new Intent();
        intent.setAction("com.xiaomi.push.channel_closed");
        intent.setPackage(b7.a);
        intent.putExtra(au.r, b7.g);
        intent.putExtra("ext_reason", n4);
        intent.putExtra(au.p, b7.b);
        intent.putExtra(au.C, b7.i);
        if (b7.l != null && "9".equals((Object)b7.g)) {
            Message message = Message.obtain(null, (int)17, (Object)intent);
            try {
                b7.l.send(message);
                return;
            }
            catch (RemoteException remoteException) {
                b7.l = null;
                StringBuilder stringBuilder = a.F1((String)"peer may died: ");
                String string2 = b7.b;
                stringBuilder.append(string2.substring(string2.lastIndexOf(64)));
                b.a((String)stringBuilder.toString());
                return;
            }
        }
        d.a(context, intent, b7);
    }

    public void a(Context context, aq.b b7, String string2, String string3) {
        if ("5".equalsIgnoreCase(b7.g)) {
            b.d((String)"mipush kicked by server");
            return;
        }
        Intent intent = new Intent();
        intent.setAction("com.xiaomi.push.kicked");
        intent.setPackage(b7.a);
        intent.putExtra("ext_kick_type", string2);
        intent.putExtra("ext_kick_reason", string3);
        intent.putExtra("ext_chid", b7.g);
        intent.putExtra(au.p, b7.b);
        intent.putExtra(au.C, b7.i);
        d.a(context, intent, b7);
    }

    public void a(Context context, aq.b b7, boolean bl2, int n4, String string2) {
        if ("5".equalsIgnoreCase(b7.g)) {
            this.a.a(context, b7, bl2, n4, string2);
            return;
        }
        Intent intent = new Intent();
        intent.setAction("com.xiaomi.push.channel_opened");
        intent.setPackage(b7.a);
        intent.putExtra("ext_succeeded", bl2);
        if (!bl2) {
            intent.putExtra("ext_reason", n4);
        }
        if (!TextUtils.isEmpty((CharSequence)string2)) {
            intent.putExtra("ext_reason_msg", string2);
        }
        intent.putExtra("ext_chid", b7.g);
        intent.putExtra(au.p, b7.b);
        intent.putExtra(au.C, b7.i);
        d.a(context, intent, b7);
    }

    /*
     * Exception decompiling
     */
    public void a(XMPushService var1, String var2, fp var3) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl149 : LDC : trying to set 0 previously set to 1
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Enabled aggressive block sorting
     */
    public void a(XMPushService xMPushService, String string2, gn gn2) {
        String string3;
        block12 : {
            block16 : {
                aq.b b7;
                String string4;
                String string5;
                block14 : {
                    block15 : {
                        block13 : {
                            block11 : {
                                block10 : {
                                    Collection<aq.b> collection = aq.a().a(gn2.k());
                                    if (collection.isEmpty()) {
                                        b7 = null;
                                    } else {
                                        Iterator iterator = collection.iterator();
                                        if (collection.size() == 1) {
                                            b7 = (aq.b)iterator.next();
                                        } else {
                                            aq.b b8;
                                            String string6 = gn2.m();
                                            String string7 = gn2.l();
                                            do {
                                                boolean bl2 = iterator.hasNext();
                                                b7 = null;
                                                if (!bl2) break block10;
                                                b8 = (aq.b)iterator.next();
                                            } while (!TextUtils.equals((CharSequence)string6, (CharSequence)b8.b) && !TextUtils.equals((CharSequence)string7, (CharSequence)b8.b));
                                            b7 = b8;
                                        }
                                    }
                                }
                                if (b7 != null) break block11;
                                StringBuilder stringBuilder = new StringBuilder();
                                stringBuilder.append("error while notify channel closed! channel ");
                                stringBuilder.append(string2);
                                stringBuilder.append(" not registered");
                                string3 = stringBuilder.toString();
                                break block12;
                            }
                            if ("5".equalsIgnoreCase(string2)) {
                                this.a.a(xMPushService, gn2, b7);
                                return;
                            }
                            string5 = b7.a;
                            if (!(gn2 instanceof gm)) break block13;
                            string4 = "com.xiaomi.push.new_msg";
                            break block14;
                        }
                        if (!(gn2 instanceof gl)) break block15;
                        string4 = "com.xiaomi.push.new_iq";
                        break block14;
                    }
                    if (!(gn2 instanceof gp)) break block16;
                    string4 = "com.xiaomi.push.new_pres";
                }
                Intent intent = new Intent();
                intent.setAction(string4);
                intent.setPackage(string5);
                intent.putExtra("ext_chid", string2);
                intent.putExtra("ext_packet", gn2.a());
                intent.putExtra(au.C, b7.i);
                intent.putExtra(au.v, b7.h);
                d.a((Context)xMPushService, intent, b7);
                return;
            }
            string3 = "unknown packet type, drop it";
        }
        b.d((String)string3);
    }
}

