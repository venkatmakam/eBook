/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.NoSuchFieldError
 *  java.lang.Object
 */
package com.xiaomi.push.service;

import com.xiaomi.push.hw;
import com.xiaomi.push.hx;

public class an {
    public static final /* synthetic */ int[] a;
    public static final /* synthetic */ int[] b;

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static {
        hx.values();
        var1 = new int[4];
        an.b = var1;
        try {
            var1[0] = 1;
        }
        catch (NoSuchFieldError v0) {}
        try {
            var17_1 = an.b;
            var17_1[1] = 2;
        }
        catch (NoSuchFieldError v1) {}
        try {
            var15_2 = an.b;
            var15_2[2] = 3;
            ** GOTO lbl-1000
        }
        catch (NoSuchFieldError v2) {
            try lbl-1000: // 2 sources:
            {
                var13_3 = an.b;
                var13_3[3] = 4;
            }
            catch (NoSuchFieldError v3) {}
        }
        hw.values();
        var7_4 = new int[2];
        an.a = var7_4;
        try {
            var7_4[0] = 1;
            ** GOTO lbl-1000
        }
        catch (NoSuchFieldError v4) {
            try lbl-1000: // 2 sources:
            {
                var10_5 = an.a;
                var10_5[1] = 2;
                return;
            }
            catch (NoSuchFieldError v5) {}
        }
    }
}

