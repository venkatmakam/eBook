/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.text.TextUtils
 *  com.xiaomi.channel.commonutils.logger.b
 *  com.xiaomi.push.bi
 *  com.xiaomi.push.ht
 *  com.xiaomi.push.hu
 *  e.a.a.a.a
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.text.SimpleDateFormat
 *  java.util.ArrayList
 *  java.util.List
 *  java.util.concurrent.atomic.AtomicLong
 */
package com.xiaomi.push.service;

import android.content.Context;
import android.text.TextUtils;
import com.xiaomi.channel.commonutils.logger.b;
import com.xiaomi.push.bi;
import com.xiaomi.push.ht;
import com.xiaomi.push.hu;
import com.xiaomi.push.ia;
import com.xiaomi.push.ip;
import com.xiaomi.push.ja;
import com.xiaomi.push.service.bk;
import com.xiaomi.push.t;
import com.xiaomi.push.y;
import e.a.a.a.a;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class bj {
    private static String a;
    private static SimpleDateFormat a;
    private static AtomicLong a;

    public static {
        SimpleDateFormat simpleDateFormat;
        a = new AtomicLong(0L);
        a = simpleDateFormat = new SimpleDateFormat("yyyy/MM/dd");
        a = simpleDateFormat.format((Object)System.currentTimeMillis());
    }

    public static String a() {
        Class<bj> class_ = bj.class;
        synchronized (bj.class) {
            String string2 = a.format((Object)System.currentTimeMillis());
            if (!TextUtils.equals((CharSequence)a, (CharSequence)string2)) {
                a.set(0L);
                a = string2;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(string2);
            stringBuilder.append("-");
            stringBuilder.append(a.incrementAndGet());
            String string3 = stringBuilder.toString();
            // ** MonitorExit[var7] (shouldn't be in output)
            return string3;
        }
    }

    public static ArrayList<ip> a(List<hu> list, String string2, String string3, int n4) {
        block9 : {
            String string4;
            block8 : {
                block7 : {
                    if (list != null) break block7;
                    string4 = "requests can not be null in TinyDataHelper.transToThriftObj().";
                    break block8;
                }
                if (list.size() != 0) break block9;
                string4 = "requests.length is 0 in TinyDataHelper.transToThriftObj().";
            }
            b.d((String)string4);
            return null;
        }
        ArrayList arrayList = new ArrayList();
        ht ht2 = new ht();
        int n5 = 0;
        for (int i6 = 0; i6 < list.size(); ++i6) {
            hu hu2 = (hu)list.get(i6);
            if (hu2 == null) continue;
            int n6 = ja.a(hu2).length;
            if (n6 > n4) {
                StringBuilder stringBuilder = a.F1((String)"TinyData is too big, ignore upload request item:");
                stringBuilder.append(hu2.d());
                b.d((String)stringBuilder.toString());
                continue;
            }
            if (n5 + n6 > n4) {
                ip ip2 = new ip("-1", false);
                ip2.d(string2);
                ip2.b(string3);
                ip2.c(ia.B.a);
                ip2.a(y.a(ja.a(ht2)));
                arrayList.add((Object)ip2);
                ht2 = new ht();
                n5 = 0;
            }
            ht2.a(hu2);
            n5 += n6;
        }
        if (ht2.a() != 0) {
            ip ip3 = new ip("-1", false);
            ip3.d(string2);
            ip3.b(string3);
            ip3.c(ia.B.a);
            ip3.a(y.a(ja.a(ht2)));
            arrayList.add((Object)ip3);
        }
        return arrayList;
    }

    public static void a(Context context, String string2, String string3, long l3, String string4) {
        hu hu2 = new hu();
        hu2.d(string2);
        hu2.c(string3);
        hu2.a(l3);
        hu2.b(string4);
        hu2.a("push_sdk_channel");
        hu2.g(context.getPackageName());
        hu2.e(context.getPackageName());
        hu2.a(true);
        hu2.b(System.currentTimeMillis());
        hu2.f(bj.a());
        bk.a(context, hu2);
    }

    public static boolean a(hu hu2, boolean bl2) {
        block9 : {
            String string2;
            block3 : {
                block8 : {
                    block7 : {
                        block6 : {
                            block5 : {
                                block4 : {
                                    block2 : {
                                        if (hu2 != null) break block2;
                                        string2 = "item is null, verfiy ClientUploadDataItem failed.";
                                        break block3;
                                    }
                                    if (bl2 || !TextUtils.isEmpty((CharSequence)hu2.a)) break block4;
                                    string2 = "item.channel is null or empty, verfiy ClientUploadDataItem failed.";
                                    break block3;
                                }
                                if (!TextUtils.isEmpty((CharSequence)hu2.d)) break block5;
                                string2 = "item.category is null or empty, verfiy ClientUploadDataItem failed.";
                                break block3;
                            }
                            if (!TextUtils.isEmpty((CharSequence)hu2.c)) break block6;
                            string2 = "item.name is null or empty, verfiy ClientUploadDataItem failed.";
                            break block3;
                        }
                        if (bi.a((String)hu2.d)) break block7;
                        string2 = "item.category can only contain ascii char, verfiy ClientUploadDataItem failed.";
                        break block3;
                    }
                    if (bi.a((String)hu2.c)) break block8;
                    string2 = "item.name can only contain ascii char, verfiy ClientUploadDataItem failed.";
                    break block3;
                }
                String string3 = hu2.b;
                if (string3 == null || string3.length() <= 10240) break block9;
                StringBuilder stringBuilder = a.F1((String)"item.data is too large(");
                stringBuilder.append(hu2.b.length());
                stringBuilder.append("), max size for data is ");
                stringBuilder.append(10240);
                stringBuilder.append(" , verfiy ClientUploadDataItem failed.");
                string2 = stringBuilder.toString();
            }
            b.a((String)string2);
            return true;
        }
        return false;
    }

    public static boolean a(String string2) {
        return !t.b() || "com.miui.hybrid".equals((Object)string2);
    }
}

