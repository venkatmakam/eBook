/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Service
 *  android.content.BroadcastReceiver
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.IntentFilter
 *  android.database.ContentObserver
 *  android.net.ConnectivityManager
 *  android.net.NetworkInfo
 *  android.net.NetworkInfo$DetailedState
 *  android.net.NetworkInfo$State
 *  android.net.Uri
 *  android.os.Bundle
 *  android.os.Handler
 *  android.os.IBinder
 *  android.os.Looper
 *  android.os.Messenger
 *  android.os.Parcelable
 *  android.os.Process
 *  android.provider.Settings
 *  android.provider.Settings$Secure
 *  android.provider.Settings$System
 *  android.text.TextUtils
 *  com.xiaomi.channel.commonutils.logger.b
 *  com.xiaomi.push.ab
 *  com.xiaomi.push.ai
 *  com.xiaomi.push.ai$a
 *  com.xiaomi.push.bc
 *  com.xiaomi.push.bh
 *  com.xiaomi.push.dc
 *  com.xiaomi.push.dl
 *  com.xiaomi.push.ff
 *  com.xiaomi.push.fg
 *  com.xiaomi.push.fp
 *  com.xiaomi.push.fu
 *  com.xiaomi.push.fw
 *  com.xiaomi.push.fx
 *  com.xiaomi.push.fz
 *  com.xiaomi.push.ga
 *  com.xiaomi.push.gb
 *  com.xiaomi.push.gc
 *  com.xiaomi.push.gh
 *  com.xiaomi.push.gj
 *  com.xiaomi.push.gm
 *  com.xiaomi.push.gn
 *  com.xiaomi.push.hb
 *  com.xiaomi.push.hi
 *  com.xiaomi.push.hl
 *  com.xiaomi.push.ho
 *  com.xiaomi.push.hp
 *  com.xiaomi.push.hq
 *  com.xiaomi.push.hv
 *  com.xiaomi.push.i
 *  com.xiaomi.push.im
 *  com.xiaomi.push.ja
 *  com.xiaomi.push.jb
 *  com.xiaomi.push.jg
 *  com.xiaomi.push.o
 *  com.xiaomi.push.service.XMPushService$a
 *  com.xiaomi.push.service.XMPushService$d
 *  com.xiaomi.push.service.XMPushService$e
 *  com.xiaomi.push.service.XMPushService$f
 *  com.xiaomi.push.service.XMPushService$g
 *  com.xiaomi.push.service.XMPushService$h
 *  com.xiaomi.push.service.XMPushService$j
 *  com.xiaomi.push.service.XMPushService$l
 *  com.xiaomi.push.service.XMPushService$m
 *  com.xiaomi.push.service.XMPushService$p
 *  com.xiaomi.push.service.XMPushService$q
 *  com.xiaomi.push.service.a
 *  com.xiaomi.push.service.af
 *  com.xiaomi.push.service.al
 *  com.xiaomi.push.service.ap
 *  com.xiaomi.push.service.aq
 *  com.xiaomi.push.service.aq$a
 *  com.xiaomi.push.service.aq$b
 *  com.xiaomi.push.service.aq$c
 *  com.xiaomi.push.service.au
 *  com.xiaomi.push.service.ba
 *  com.xiaomi.push.service.bb
 *  com.xiaomi.push.service.bf
 *  com.xiaomi.push.service.bn
 *  com.xiaomi.push.service.bo
 *  com.xiaomi.push.service.bq
 *  com.xiaomi.push.service.bt
 *  com.xiaomi.push.service.bu
 *  com.xiaomi.push.service.bv
 *  com.xiaomi.push.service.c
 *  com.xiaomi.push.service.d
 *  com.xiaomi.push.service.g
 *  com.xiaomi.push.service.g$b
 *  com.xiaomi.push.service.k
 *  com.xiaomi.push.service.l
 *  com.xiaomi.push.service.l$a
 *  com.xiaomi.push.service.m
 *  com.xiaomi.push.service.n
 *  com.xiaomi.push.service.o
 *  com.xiaomi.push.t
 *  e.a.a.a.a
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.IllegalArgumentException
 *  java.lang.IllegalStateException
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.NumberFormatException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Throwable
 *  java.lang.ref.WeakReference
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.Date
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 */
package com.xiaomi.push.service;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.ContentObserver;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Messenger;
import android.os.Parcelable;
import android.os.Process;
import android.provider.Settings;
import android.text.TextUtils;
import com.xiaomi.push.ab;
import com.xiaomi.push.ai;
import com.xiaomi.push.bc;
import com.xiaomi.push.dc;
import com.xiaomi.push.dl;
import com.xiaomi.push.ff;
import com.xiaomi.push.fg;
import com.xiaomi.push.fp;
import com.xiaomi.push.fu;
import com.xiaomi.push.fw;
import com.xiaomi.push.fx;
import com.xiaomi.push.fz;
import com.xiaomi.push.ga;
import com.xiaomi.push.gb;
import com.xiaomi.push.gc;
import com.xiaomi.push.gh;
import com.xiaomi.push.gj;
import com.xiaomi.push.gm;
import com.xiaomi.push.gn;
import com.xiaomi.push.hb;
import com.xiaomi.push.hi;
import com.xiaomi.push.hl;
import com.xiaomi.push.ho;
import com.xiaomi.push.hp;
import com.xiaomi.push.hq;
import com.xiaomi.push.hv;
import com.xiaomi.push.im;
import com.xiaomi.push.ip;
import com.xiaomi.push.iq;
import com.xiaomi.push.ja;
import com.xiaomi.push.jb;
import com.xiaomi.push.jg;
import com.xiaomi.push.o;
import com.xiaomi.push.service.XMPushService;
import com.xiaomi.push.service.af;
import com.xiaomi.push.service.al;
import com.xiaomi.push.service.ap;
import com.xiaomi.push.service.aq;
import com.xiaomi.push.service.au;
import com.xiaomi.push.service.av;
import com.xiaomi.push.service.b;
import com.xiaomi.push.service.ba;
import com.xiaomi.push.service.bb;
import com.xiaomi.push.service.bf;
import com.xiaomi.push.service.bh;
import com.xiaomi.push.service.bm;
import com.xiaomi.push.service.bn;
import com.xiaomi.push.service.bo;
import com.xiaomi.push.service.bp;
import com.xiaomi.push.service.bq;
import com.xiaomi.push.service.br;
import com.xiaomi.push.service.bs;
import com.xiaomi.push.service.bt;
import com.xiaomi.push.service.bu;
import com.xiaomi.push.service.bv;
import com.xiaomi.push.service.bw;
import com.xiaomi.push.service.c;
import com.xiaomi.push.service.g;
import com.xiaomi.push.service.k;
import com.xiaomi.push.service.l;
import com.xiaomi.push.service.n;
import com.xiaomi.push.t;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/*
 * Duplicate member names - consider using --renamedupmembers true
 * Exception performing whole class analysis.
 */
public class XMPushService
extends Service
implements fz {
    public static int a;
    private static final int d;
    private long a;
    private ContentObserver a;
    private fu a;
    private fw a;
    private fx a;
    private gb a;
    private e a;
    private p a;
    private ap a;
    private ba a;
    private com.xiaomi.push.service.d a;
    private com.xiaomi.push.service.g a;
    private String a;
    private ArrayList<l> a;
    private Collection<af> a;
    private int b;
    private ContentObserver b;
    private int c;
    public Messenger e;

    public static {
        d = Process.myPid();
        dc.a((String)"cn.app.chat.xiaomi.net", (String)"cn.app.chat.xiaomi.net");
        a = 1;
    }

    public XMPushService() {
        this.b = 0;
        this.c = 0;
        this.a = 0L;
        this.a = null;
        this.a = null;
        this.e = null;
        this.a = (int)Collections.synchronizedCollection((Collection)new ArrayList());
        this.a = (int)new ArrayList();
        this.a = new bm(this);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private gn a(gn var1_1, String var2_2, String var3_3) {
        block4 : {
            block3 : {
                var4_4 = aq.a();
                var5_5 = var4_4.a(var2_2);
                if (!var5_5.isEmpty()) break block3;
                var6_6 = new StringBuilder();
                var7_7 = "open channel should be called first before sending a packet, pkg=";
                ** GOTO lbl27
            }
            var1_1.o(var2_2);
            var2_2 = var1_1.k();
            if (TextUtils.isEmpty((CharSequence)var2_2)) {
                var2_2 = (String)var5_5.get(0);
                var1_1.l(var2_2);
            }
            var10_8 = var4_4.a(var2_2, var1_1.m());
            if (this.c()) break block4;
            var6_6 = new StringBuilder();
            var7_7 = "drop a packet as the channel is not connected, chid=";
            ** GOTO lbl27
        }
        if (var10_8 != null && var10_8.j == aq.c.c) {
            if (TextUtils.equals((CharSequence)var3_3, (CharSequence)var10_8.i) != false) return var1_1;
            var6_6 = new StringBuilder();
            var6_6.append("invalid session. ");
            var6_6.append(var3_3);
        } else {
            var6_6 = new StringBuilder();
            var7_7 = "drop a packet as the channel is not opened, chid=";
lbl27: // 3 sources:
            var6_6.append(var7_7);
            var6_6.append(var2_2);
        }
        com.xiaomi.channel.commonutils.logger.b.a((String)var6_6.toString());
        return null;
    }

    private aq.b a(String string, Intent intent) {
        String string2 = intent.getStringExtra(au.p);
        aq.b b5 = aq.a().a(string, string2);
        if (b5 == null) {
            b5 = new aq.b(this);
        }
        b5.g = intent.getStringExtra(au.r);
        b5.b = intent.getStringExtra(au.p);
        b5.c = intent.getStringExtra(au.t);
        b5.a = intent.getStringExtra(au.z);
        b5.e = intent.getStringExtra(au.x);
        b5.f = intent.getStringExtra(au.y);
        b5.a = intent.getBooleanExtra(au.w, false);
        b5.h = intent.getStringExtra(au.v);
        b5.i = intent.getStringExtra(au.C);
        b5.d = intent.getStringExtra(au.u);
        b5.a = this.a;
        b5.e((Messenger)intent.getParcelableExtra(au.G));
        b5.a = this.getApplicationContext();
        aq.a().a(b5);
        return b5;
    }

    /*
     * Exception decompiling
     */
    private String a() {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl18 : ALOAD : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    private void a(BroadcastReceiver broadcastReceiver) {
        if (broadcastReceiver != null) {
            try {
                this.unregisterReceiver(broadcastReceiver);
                return;
            }
            catch (IllegalArgumentException illegalArgumentException) {
                com.xiaomi.channel.commonutils.logger.b.a((Throwable)illegalArgumentException);
            }
        }
    }

    private void a(Intent intent) {
        fp fp2;
        String string = intent.getStringExtra(au.z);
        String string2 = intent.getStringExtra(au.C);
        Bundle bundle = intent.getBundleExtra("ext_packet");
        aq aq2 = aq.a();
        if (bundle != null) {
            gm gm2 = (gm)this.a((gn)new gm(bundle), string, string2);
            if (gm2 == null) {
                return;
            }
            fp2 = fp.a((gn)gm2, (String)aq2.a((String)gm2.k(), (String)gm2.m()).h);
        } else {
            byte[] arrby = intent.getByteArrayExtra("ext_raw_packet");
            fp2 = null;
            if (arrby != null) {
                long l2 = intent.getLongExtra(au.p, 0L);
                String string3 = intent.getStringExtra(au.q);
                String string4 = intent.getStringExtra("ext_chid");
                aq.b b5 = aq2.a(string4, Long.toString((long)l2));
                fp2 = null;
                if (b5 != null) {
                    fp fp3;
                    fp3 = new fp();
                    try {
                        fp3.a(Integer.parseInt((String)string4));
                    }
                    catch (NumberFormatException numberFormatException) {}
                    fp3.a("SECMSG", null);
                    fp3.a(l2, "xiaomi.com", string3);
                    fp3.a(intent.getStringExtra("ext_pkt_id"));
                    fp3.a(arrby, b5.h);
                    fp2 = fp3;
                }
            }
        }
        if (fp2 != null) {
            this.c((i)new bb(this, fp2));
        }
    }

    private void a(Intent intent, int n5) {
        byte[] arrby = intent.getByteArrayExtra("mipush_payload");
        boolean bl = intent.getBooleanExtra("com.xiaomi.mipush.MESSAGE_CACHE", true);
        ip ip2 = new ip();
        try {
            ja.a((jb)ip2, (byte[])arrby);
            ai.a((Context)this.getApplicationContext()).a((ai.a)new b(ip2, (WeakReference<XMPushService>)new WeakReference((Object)this), bl), n5);
            return;
        }
        catch (jg jg2) {
            com.xiaomi.channel.commonutils.logger.b.d((String)"aw_ping : send help app ping  error");
            return;
        }
    }

    private void a(String string, int n5) {
        Collection collection = aq.a().a(string);
        if (collection != null) {
            for (aq.b b5 : collection) {
                if (b5 == null) continue;
                q q4 = new /* Unavailable Anonymous Inner Class!! */;
                this.a((i)q4);
            }
        }
        aq.a().a(string);
    }

    private boolean a(String string, Intent intent) {
        String string2 = intent.getStringExtra(au.p);
        aq.b b5 = aq.a().a(string, string2);
        if (b5 != null && string != null) {
            String string3 = intent.getStringExtra(au.C);
            String string4 = intent.getStringExtra(au.v);
            boolean bl = TextUtils.isEmpty((CharSequence)b5.i);
            boolean bl2 = false;
            if (!bl) {
                boolean bl3 = TextUtils.equals((CharSequence)string3, (CharSequence)b5.i);
                bl2 = false;
                if (!bl3) {
                    StringBuilder stringBuilder = e.a.a.a.a.F1((String)"session changed. old session=");
                    e.a.a.a.a.K((StringBuilder)stringBuilder, (String)b5.i, (String)", new session=", (String)string3, (String)" chid = ");
                    stringBuilder.append(string);
                    com.xiaomi.channel.commonutils.logger.b.a((String)stringBuilder.toString());
                    bl2 = true;
                }
            }
            if (!string4.equals((Object)b5.h)) {
                StringBuilder stringBuilder = e.a.a.a.a.f((String)"security changed. chid = ", (String)string, (String)" sechash = ");
                stringBuilder.append(com.xiaomi.push.bh.a((String)string4));
                com.xiaomi.channel.commonutils.logger.b.a((String)stringBuilder.toString());
                return true;
            }
            return bl2;
        }
        return false;
    }

    private int[] a() {
        String[] arrstring;
        String string = al.a((Context)this.getApplicationContext()).a(hv.aN.a(), "");
        if (!TextUtils.isEmpty((CharSequence)string) && (arrstring = string.split(",")) != null && arrstring.length >= 2) {
            int[] arrn = new int[2];
            try {
                int n5;
                int n6;
                arrn[0] = Integer.valueOf((String)arrstring[0]);
                arrn[1] = Integer.valueOf((String)arrstring[1]);
                if (arrn[0] >= 0 && arrn[0] <= 23 && arrn[1] >= 0 && arrn[1] <= 23 && (n6 = arrn[0]) != (n5 = arrn[1])) {
                    return arrn;
                }
            }
            catch (NumberFormatException numberFormatException) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("parse falldown time range failure: ");
                stringBuilder.append((Object)numberFormatException);
                com.xiaomi.channel.commonutils.logger.b.d((String)stringBuilder.toString());
            }
        }
        return null;
    }

    public static /* synthetic */ fw b(XMPushService xMPushService) {
        return xMPushService.a;
    }

    private void b(Intent intent) {
        String string = intent.getStringExtra(au.z);
        String string2 = intent.getStringExtra(au.C);
        Parcelable[] arrparcelable = intent.getParcelableArrayExtra("ext_packets");
        int n5 = arrparcelable.length;
        gm[] arrgm = new gm[n5];
        intent.getBooleanExtra("ext_encrypt", true);
        int n6 = 0;
        for (int i5 = 0; i5 < arrparcelable.length; ++i5) {
            arrgm[i5] = new gm((Bundle)arrparcelable[i5]);
            arrgm[i5] = (gm)this.a((gn)arrgm[i5], string, string2);
            if (arrgm[i5] != null) continue;
            return;
        }
        aq aq2 = aq.a();
        fp[] arrfp = new fp[n5];
        while (n6 < n5) {
            gm gm2 = arrgm[n6];
            arrfp[n6] = fp.a((gn)gm2, (String)aq2.a((String)gm2.k(), (String)gm2.m()).h);
            ++n6;
        }
        this.c((i)new c(this, arrfp));
    }

    /*
     * Enabled aggressive block sorting
     */
    private void b(boolean bl) {
        block3 : {
            block2 : {
                this.a = System.currentTimeMillis();
                if (!this.c()) break block2;
                if (this.a.d() || this.a.e() || bc.d((Context)this)) break block3;
                this.c((i)new /* Unavailable Anonymous Inner Class!! */);
            }
            this.a(true);
            return;
        }
        this.c((i)new /* Unavailable Anonymous Inner Class!! */);
    }

    public static /* synthetic */ fw c(XMPushService xMPushService, fw fw2) {
        xMPushService.a = null;
        return null;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void c() {
        block12 : {
            block7 : {
                String string;
                block9 : {
                    block11 : {
                        block10 : {
                            block8 : {
                                com.xiaomi.push.service.a a3 = com.xiaomi.push.service.a.a((Context)this.getApplicationContext());
                                String string2 = a3.a();
                                StringBuilder stringBuilder = new StringBuilder();
                                stringBuilder.append("region of cache is ");
                                stringBuilder.append(string2);
                                com.xiaomi.channel.commonutils.logger.b.a((String)stringBuilder.toString());
                                if (TextUtils.isEmpty((CharSequence)string2)) {
                                    string2 = this.a();
                                }
                                if (TextUtils.isEmpty((CharSequence)string2)) break block7;
                                this.a = string2;
                                a3.a(string2);
                                if (!o.b.name().equals((Object)this.a)) break block8;
                                string = "app.chat.global.xiaomi.net";
                                break block9;
                            }
                            if (!o.c.name().equals((Object)this.a)) break block10;
                            string = "fr.app.chat.global.xiaomi.net";
                            break block9;
                        }
                        if (!o.d.name().equals((Object)this.a)) break block11;
                        string = "ru.app.chat.global.xiaomi.net";
                        break block9;
                    }
                    if (!o.e.name().equals((Object)this.a)) break block12;
                    string = "idmb.app.chat.global.xiaomi.net";
                }
                fx.a((String)string);
                break block12;
            }
            this.a = o.a.name();
        }
        if (o.a.name().equals((Object)this.a)) {
            fx.a((String)"cn.app.chat.xiaomi.net");
        }
        if (this.h()) {
            bv bv2 = new bv(this, 11);
            this.a((i)bv2);
            com.xiaomi.push.service.l.a((l.a)new bw(this, (i)bv2));
        }
        try {
            if (!t.a()) return;
            this.a.a((Context)this);
            return;
        }
        catch (Exception exception) {
            com.xiaomi.channel.commonutils.logger.b.a((Throwable)exception);
        }
    }

    /*
     * Exception decompiling
     */
    private void c(Intent var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl456.1 : LDC_W : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    private void c(i i5) {
        this.a.a((g.b)i5);
    }

    private void c(boolean bl) {
        block7 : {
            block8 : {
                if (!t.a()) break block7;
                if (!bl) break block8;
                this.sendBroadcast(new Intent("miui.intent.action.NETWORK_CONNECTED"));
                int n5 = this.a;
                af[] arraf = (af[])n5.toArray((Object[])new af[0]);
                int n6 = arraf.length;
                for (int i5 = 0; i5 < n6; ++i5) {
                    arraf[i5].a();
                }
                break block7;
            }
            try {
                this.sendBroadcast(new Intent("miui.intent.action.NETWORK_BLOCKED"));
                return;
            }
            catch (Exception exception) {
                com.xiaomi.channel.commonutils.logger.b.a((Throwable)exception);
            }
        }
    }

    public static /* synthetic */ fx d(XMPushService xMPushService) {
        return xMPushService.a;
    }

    private void d() {
        NetworkInfo networkInfo;
        try {
            networkInfo = ((ConnectivityManager)this.getSystemService("connectivity")).getActiveNetworkInfo();
        }
        catch (Exception exception) {
            com.xiaomi.channel.commonutils.logger.b.a((Throwable)exception);
            networkInfo = null;
        }
        if (networkInfo != null) {
            StringBuilder stringBuilder = e.a.a.a.a.d((String)"[", (String)"type: ");
            stringBuilder.append(networkInfo.getTypeName());
            stringBuilder.append("[");
            stringBuilder.append(networkInfo.getSubtypeName());
            stringBuilder.append("], state: ");
            stringBuilder.append((Object)networkInfo.getState());
            stringBuilder.append("/");
            stringBuilder.append((Object)networkInfo.getDetailedState());
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append("network changed,");
            stringBuilder2.append(stringBuilder.toString());
            com.xiaomi.channel.commonutils.logger.b.a((String)stringBuilder2.toString());
            NetworkInfo.State state = networkInfo.getState();
            if (state == NetworkInfo.State.SUSPENDED || state == NetworkInfo.State.UNKNOWN) {
                return;
            }
        } else {
            com.xiaomi.channel.commonutils.logger.b.a((String)"network changed, no active network");
        }
        if (hi.a() != null) {
            hi.a().a();
        }
        hb.a((Context)this);
        this.a.d();
        if (bc.b((Context)this)) {
            if (this.c() && this.e()) {
                this.b(false);
            }
            if (!this.c() && !this.d()) {
                this.a.a(1);
                this.a((i)new /* Unavailable Anonymous Inner Class!! */);
            }
            dl.a((Context)this).a();
        } else {
            this.a((i)new /* Unavailable Anonymous Inner Class!! */);
        }
        this.e();
    }

    /*
     * Exception decompiling
     */
    private void d(Intent var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl57 : ALOAD : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    public static /* synthetic */ ap e(XMPushService xMPushService) {
        return xMPushService.a;
    }

    private void e() {
        if (this.a()) {
            if (!fg.a()) {
                fg.a((boolean)true);
                return;
            }
        } else {
            fg.a();
        }
    }

    private boolean e() {
        if (System.currentTimeMillis() - this.a < 30000L) {
            return false;
        }
        return bc.c((Context)this);
    }

    public static /* synthetic */ com.xiaomi.push.service.g f(XMPushService xMPushService) {
        return xMPushService.a;
    }

    /*
     * Enabled aggressive block sorting
     */
    private void f() {
        block6 : {
            String string;
            block5 : {
                block4 : {
                    fw fw2 = this.a;
                    if (fw2 == null || !fw2.b()) break block4;
                    string = "try to connect while connecting.";
                    break block5;
                }
                fw fw3 = this.a;
                if (fw3 == null || !fw3.c()) break block6;
                string = "try to connect while is connected.";
            }
            com.xiaomi.channel.commonutils.logger.b.d((String)string);
            return;
        }
        this.a.b(bc.a((Context)this));
        this.g();
        if (this.a == null) {
            aq.a().a((Context)this);
            this.c(false);
        }
    }

    private boolean f() {
        boolean bl = "com.xiaomi.xmsf".equals((Object)this.getPackageName());
        boolean bl2 = false;
        if (bl) {
            int n5 = Settings.Secure.getInt((ContentResolver)this.getContentResolver(), (String)"EXTREME_POWER_MODE_ENABLE", (int)0);
            bl2 = false;
            if (n5 == 1) {
                bl2 = true;
            }
        }
        return bl2;
    }

    public static /* synthetic */ String g(XMPushService xMPushService) {
        return xMPushService.a;
    }

    private void g() {
        try {
            this.a.a(this.a, (gj)new bp(this));
            this.a.e();
            this.a = this.a;
            return;
        }
        catch (gh gh2) {
            com.xiaomi.channel.commonutils.logger.b.a((String)"fail to create Slim connection", (Throwable)gh2);
            this.a.b(3, (Exception)((Object)gh2));
            return;
        }
    }

    private boolean g() {
        boolean bl = "com.xiaomi.xmsf".equals((Object)this.getPackageName());
        boolean bl2 = false;
        if (bl) {
            int n5 = Settings.System.getInt((ContentResolver)this.getContentResolver(), (String)"power_supersave_mode_open", (int)0);
            bl2 = false;
            if (n5 == 1) {
                bl2 = true;
            }
        }
        return bl2;
    }

    private void h() {
    }

    private boolean h() {
        return "com.xiaomi.xmsf".equals((Object)this.getPackageName()) || !com.xiaomi.push.service.m.a((Context)this).b(this.getPackageName());
        {
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void i() {
        int n5;
        int n6 = n5 = this.a;
        synchronized (n6) {
            this.a.clear();
            return;
        }
    }

    private boolean i() {
        return this.getApplicationContext().getPackageName().equals((Object)"com.xiaomi.xmsf") && this.j() && !com.xiaomi.push.i.b((Context)this) && !com.xiaomi.push.i.a((Context)this.getApplicationContext());
    }

    private boolean j() {
        boolean bl;
        block3 : {
            block4 : {
                int n5;
                int n6;
                int n7;
                block2 : {
                    Date date = new Date();
                    bl = true;
                    Object[] arrobject = new Object[bl];
                    arrobject[0] = date;
                    n6 = Integer.valueOf((String)String.format((String)"%tH", (Object[])arrobject));
                    n5 = this.b;
                    n7 = this.c;
                    if (n5 <= n7) break block2;
                    if (n6 >= n5) break block3;
                    if (n6 < n7) {
                        return bl;
                    }
                    break block4;
                }
                if (n5 < n7 && n6 >= n5 && n6 < n7) {
                    return bl;
                }
            }
            bl = false;
        }
        return bl;
    }

    private boolean k() {
        if (TextUtils.equals((CharSequence)this.getPackageName(), (CharSequence)"com.xiaomi.xmsf")) {
            return false;
        }
        return al.a((Context)this).a(hv.H.a(), false);
    }

    public static /* synthetic */ void m(XMPushService xMPushService) {
        xMPushService.e();
    }

    public static /* synthetic */ void n(XMPushService xMPushService, Intent intent) {
        xMPushService.c(intent);
    }

    public static /* synthetic */ boolean p(XMPushService xMPushService) {
        return xMPushService.f();
    }

    public static /* synthetic */ void r(XMPushService xMPushService) {
        xMPushService.c();
    }

    public static /* synthetic */ boolean s(XMPushService xMPushService) {
        return xMPushService.g();
    }

    public static /* synthetic */ void t(XMPushService xMPushService) {
        xMPushService.f();
    }

    public fw a() {
        return this.a;
    }

    public com.xiaomi.push.service.d a() {
        return new com.xiaomi.push.service.d();
    }

    public void a(int n5) {
        this.a.a(n5);
    }

    public void a(int n5, Exception exception) {
        StringBuilder stringBuilder = e.a.a.a.a.F1((String)"disconnect ");
        stringBuilder.append(this.hashCode());
        stringBuilder.append(", ");
        fw fw2 = this.a;
        Integer n6 = fw2 == null ? null : Integer.valueOf((int)fw2.hashCode());
        stringBuilder.append((Object)n6);
        com.xiaomi.channel.commonutils.logger.b.a((String)stringBuilder.toString());
        fw fw3 = this.a;
        if (fw3 != null) {
            fw3.b(n5, exception);
            this.a = null;
        }
        this.a(7);
        this.a(4);
        aq.a().a((Context)this, n5);
    }

    public void a(fp fp2) {
        fw fw2 = this.a;
        if (fw2 != null) {
            fw2.b(fp2);
            return;
        }
        throw new gh("try send msg while connection is null.");
    }

    public void a(fw fw2) {
        hi.a().a(fw2);
        this.c(true);
        this.a.a();
        if (!fg.a() && !this.i()) {
            com.xiaomi.channel.commonutils.logger.b.a((String)"reconnection successful, reactivate alarm.");
            fg.a((boolean)true);
        }
        Iterator iterator = aq.a().a().iterator();
        while (iterator.hasNext()) {
            this.a((i)new /* Unavailable Anonymous Inner Class!! */);
        }
    }

    public void a(fw fw2, int n5, Exception exception) {
        hi.a().a(fw2, n5, exception);
        if (!this.i()) {
            this.a(false);
        }
    }

    public void a(fw fw2, Exception exception) {
        hi.a().a(fw2, exception);
        this.c(false);
        if (!this.i()) {
            this.a(false);
        }
    }

    public void a(i i5) {
        this.a(i5, 0L);
    }

    public void a(i i5, long l2) {
        try {
            this.a.a((g.b)i5, l2);
            return;
        }
        catch (IllegalStateException illegalStateException) {
            StringBuilder stringBuilder = e.a.a.a.a.F1((String)"can't execute job err = ");
            stringBuilder.append(illegalStateException.getMessage());
            com.xiaomi.channel.commonutils.logger.b.a((String)stringBuilder.toString());
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void a(l l2) {
        int n5;
        int n6 = n5 = this.a;
        synchronized (n6) {
            this.a.add((Object)l2);
            return;
        }
    }

    public void a(aq.b b5) {
        if (b5 != null) {
            long l2 = b5.a();
            StringBuilder stringBuilder = e.a.a.a.a.F1((String)"schedule rebind job in ");
            stringBuilder.append(l2 / 1000L);
            com.xiaomi.channel.commonutils.logger.b.a((String)stringBuilder.toString());
            this.a((i)new /* Unavailable Anonymous Inner Class!! */, l2);
        }
    }

    public void a(String string, String string2, int n5, String string3, String string4) {
        aq.b b5 = aq.a().a(string, string2);
        if (b5 != null) {
            q q4 = new /* Unavailable Anonymous Inner Class!! */;
            this.a((i)q4);
        }
        aq.a().a(string, string2);
    }

    public void a(boolean bl) {
        this.a.a(bl);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public void a(byte[] var1_1, String var2_2) {
        if (var1_1 == null) {
            com.xiaomi.push.service.o.a((Context)this, (String)var2_2, (byte[])var1_1, (int)70000003, (String)"null payload");
            com.xiaomi.channel.commonutils.logger.b.a((String)"register request without payload");
            return;
        }
        var3_3 = new im();
        ja.a((jb)var3_3, (byte[])var1_1);
        if (var3_3.a != hq.a) ** GOTO lbl26
        var5_4 = new iq();
        {
            catch (jg var4_7) {
                com.xiaomi.channel.commonutils.logger.b.a((Throwable)var4_7);
                com.xiaomi.push.service.o.a((Context)this, (String)var2_2, (byte[])var1_1, (int)70000003, (String)" data container error.");
                return;
            }
        }
        try {
            ja.a((jb)var5_4, (byte[])var3_3.a());
            com.xiaomi.push.service.o.a((String)var3_3.b(), (byte[])var1_1);
            var7_5 = new n(this, var3_3.b(), var5_4.b(), var5_4.c(), var1_1);
            this.a((i)var7_5);
            ff.a((Context)this.getApplicationContext()).a(var3_3.b(), "E100003", var5_4.a(), 6002, null);
            return;
        }
        catch (jg var6_6) {
            com.xiaomi.channel.commonutils.logger.b.a((Throwable)var6_6);
            com.xiaomi.push.service.o.a((Context)this, (String)var2_2, (byte[])var1_1, (int)70000003, (String)" data action error.");
            return;
lbl26: // 1 sources:
            com.xiaomi.push.service.o.a((Context)this, (String)var2_2, (byte[])var1_1, (int)70000003, (String)" registration action required.");
            com.xiaomi.channel.commonutils.logger.b.a((String)"register request with invalid payload");
            return;
        }
    }

    public void a(fp[] arrfp) {
        fw fw2 = this.a;
        if (fw2 != null) {
            fw2.a(arrfp);
            return;
        }
        throw new gh("try send msg while connection is null.");
    }

    public boolean a() {
        return bc.b((Context)this) && aq.a().a() > 0 && !this.b() && this.h() && !this.g() && !this.f();
    }

    public boolean a(int n5) {
        return this.a.a(n5);
    }

    public com.xiaomi.push.service.d b() {
        return this.a;
    }

    public void b(fw fw2) {
        com.xiaomi.channel.commonutils.logger.b.c((String)"begin to connect...");
        hi.a().b(fw2);
    }

    public void b(i i5) {
        this.a.a(i5.d, (g.b)i5);
    }

    /*
     * Exception decompiling
     */
    public boolean b() {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Underrun type stack
        // org.benf.cfr.reader.b.a.c.e.a(StackSim.java:35)
        // org.benf.cfr.reader.b.b.af.a(OperationFactoryPop.java:20)
        // org.benf.cfr.reader.b.b.e.a(JVMInstr.java:315)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:195)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    public boolean c() {
        fw fw2 = this.a;
        return fw2 != null && fw2.c();
    }

    public boolean d() {
        fw fw2 = this.a;
        return fw2 != null && fw2.b();
    }

    public void l() {
        if (System.currentTimeMillis() - this.a < (long)gc.a()) {
            return;
        }
        if (bc.c((Context)this)) {
            this.b(true);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public void o(String string, byte[] arrby, boolean bl) {
        block4 : {
            block3 : {
                Collection collection;
                block2 : {
                    collection = aq.a().a("5");
                    if (!collection.isEmpty()) break block2;
                    if (!bl) return;
                    break block3;
                }
                if (((aq.b)collection.iterator().next()).j == aq.c.c) break block4;
                if (!bl) return;
            }
            com.xiaomi.push.service.o.b((String)string, (byte[])arrby);
            return;
        }
        this.a((i)new bn(this, 4, string, arrby));
    }

    public IBinder onBind(Intent intent) {
        return this.e.getBinder();
    }

    public void onCreate() {
        super.onCreate();
        t.a((Context)this);
        k k5 = com.xiaomi.push.service.l.a((Context)this);
        if (k5 != null) {
            ab.a((int)k5.a);
        }
        this.e = new Messenger((Handler)new bq(this));
        av.a(this);
        br br2 = new br(this, null, 5222, "xiaomi.com", null);
        this.a = br2;
        br2.a(true);
        this.a = new fu(this, this.a);
        this.a = this.a();
        fg.a((Context)this);
        this.a.a((fz)this);
        this.a = new ap(this);
        this.a = new ba(this);
        new com.xiaomi.push.service.e().a();
        hi.a().a(this);
        this.a = new com.xiaomi.push.service.g("Connection Controller Thread");
        aq aq2 = aq.a();
        aq2.b();
        aq2.a((aq.a)new bs(this));
        if (this.k()) {
            this.h();
        }
        ho.a((Context)this).a((hp)new com.xiaomi.push.service.i(this), "UPLOADER_PUSH_CHANNEL");
        this.a(new hl((Context)this));
        this.a((i)new /* Unavailable Anonymous Inner Class!! */);
        this.a.add((Object)bh.a((Context)this));
        if (this.h()) {
            this.a = new /* Unavailable Anonymous Inner Class!! */;
            IntentFilter intentFilter = new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE");
            this.registerReceiver((BroadcastReceiver)this.a, intentFilter);
        }
        if ("com.xiaomi.xmsf".equals((Object)this.getPackageName())) {
            int[] arrn;
            Uri uri;
            Uri uri2 = Settings.Secure.getUriFor((String)"EXTREME_POWER_MODE_ENABLE");
            if (uri2 != null) {
                this.a = new bt(this, new Handler(Looper.getMainLooper()));
                try {
                    this.getContentResolver().registerContentObserver(uri2, false, this.a);
                }
                catch (Throwable throwable) {
                    StringBuilder stringBuilder = e.a.a.a.a.F1((String)"register observer err:");
                    stringBuilder.append(throwable.getMessage());
                    com.xiaomi.channel.commonutils.logger.b.a((String)stringBuilder.toString());
                }
            }
            if ((uri = Settings.System.getUriFor((String)"power_supersave_mode_open")) != null) {
                this.b = new bu(this, new Handler(Looper.getMainLooper()));
                try {
                    this.getContentResolver().registerContentObserver(uri, false, this.b);
                }
                catch (Throwable throwable) {
                    StringBuilder stringBuilder = e.a.a.a.a.F1((String)"register super-power-mode observer err:");
                    stringBuilder.append(throwable.getMessage());
                    com.xiaomi.channel.commonutils.logger.b.d((String)stringBuilder.toString());
                }
            }
            if ((arrn = this.a()) != null) {
                this.a = new /* Unavailable Anonymous Inner Class!! */;
                IntentFilter intentFilter = new IntentFilter();
                intentFilter.addAction("android.intent.action.SCREEN_ON");
                intentFilter.addAction("android.intent.action.SCREEN_OFF");
                this.registerReceiver((BroadcastReceiver)this.a, intentFilter);
                this.b = arrn[0];
                this.c = arrn[1];
                StringBuilder stringBuilder = e.a.a.a.a.F1((String)"falldown initialized: ");
                stringBuilder.append(this.b);
                stringBuilder.append(",");
                stringBuilder.append(this.c);
                com.xiaomi.channel.commonutils.logger.b.a((String)stringBuilder.toString());
            }
        }
        StringBuilder stringBuilder = e.a.a.a.a.F1((String)"XMPushService created pid = ");
        stringBuilder.append(d);
        com.xiaomi.channel.commonutils.logger.b.a((String)stringBuilder.toString());
    }

    public void onDestroy() {
        p p2;
        e e2 = this.a;
        if (e2 != null) {
            this.a((BroadcastReceiver)e2);
            this.a = null;
        }
        if ((p2 = this.a) != null) {
            this.a((BroadcastReceiver)p2);
            this.a = null;
        }
        if ("com.xiaomi.xmsf".equals((Object)this.getPackageName()) && this.a != null) {
            try {
                this.getContentResolver().unregisterContentObserver(this.a);
            }
            catch (Throwable throwable) {
                StringBuilder stringBuilder = e.a.a.a.a.F1((String)"unregister observer err:");
                stringBuilder.append(throwable.getMessage());
                com.xiaomi.channel.commonutils.logger.b.a((String)stringBuilder.toString());
            }
        }
        if ("com.xiaomi.xmsf".equals((Object)this.getPackageName()) && this.b != null) {
            try {
                this.getContentResolver().unregisterContentObserver(this.b);
            }
            catch (Throwable throwable) {
                StringBuilder stringBuilder = e.a.a.a.a.F1((String)"unregister super-power-mode err:");
                stringBuilder.append(throwable.getMessage());
                com.xiaomi.channel.commonutils.logger.b.d((String)stringBuilder.toString());
            }
        }
        this.a.clear();
        this.a.b();
        this.a((i)new bo(this, 2));
        this.a((i)new /* Unavailable Anonymous Inner Class!! */);
        aq.a().b();
        aq.a().a((Context)this, 15);
        aq.a().a();
        this.a.b((fz)this);
        bf.a().k();
        fg.a();
        this.i();
        super.onDestroy();
        com.xiaomi.channel.commonutils.logger.b.a((String)"Service destroyed");
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public void onStart(Intent var1_1, int var2_2) {
        block4 : {
            block5 : {
                var3_3 = System.currentTimeMillis();
                if (var1_1 == null) {
                    com.xiaomi.channel.commonutils.logger.b.d((String)"onStart() with intent NULL");
                } else {
                    var5_4 = new Object[]{var1_1.getAction(), var1_1.getStringExtra(au.r), var1_1.getStringExtra(au.z), var1_1.getStringExtra("mipush_app_package"), var1_1.getStringExtra("ext_is_xmpushservice_bridge")};
                    com.xiaomi.channel.commonutils.logger.b.c((String)String.format((String)"onStart() with intent.Action = %s, chid = %s, pkg = %s|%s, from-bridge = %s", (Object[])var5_4));
                }
                if (var1_1 == null || var1_1.getAction() == null) break block4;
                if ("com.xiaomi.push.timer".equalsIgnoreCase(var1_1.getAction()) || "com.xiaomi.push.check_alive".equalsIgnoreCase(var1_1.getAction())) break block5;
                if ("com.xiaomi.push.network_status_changed".equalsIgnoreCase(var1_1.getAction())) break block4;
                var12_5 = new /* Unavailable Anonymous Inner Class!! */;
                ** GOTO lbl19
            }
            if (this.a.a()) {
                com.xiaomi.channel.commonutils.logger.b.d((String)"ERROR, the job controller is blocked.");
                aq.a().a((Context)this, 14);
                this.stopSelf();
            } else {
                var12_5 = new /* Unavailable Anonymous Inner Class!! */;
lbl19: // 2 sources:
                this.a((i)var12_5);
            }
        }
        if ((var6_6 = System.currentTimeMillis() - var3_3) <= 50L) return;
        var8_7 = new StringBuilder();
        var8_7.append("[Prefs] spend ");
        var8_7.append(var6_6);
        var8_7.append(" ms, too more times.");
        com.xiaomi.channel.commonutils.logger.b.c((String)var8_7.toString());
    }

    public int onStartCommand(Intent intent, int n5, int n6) {
        this.onStart(intent, n6);
        return a;
    }

    public void q() {
        Iterator iterator = new ArrayList((Collection)this.a).iterator();
        while (iterator.hasNext()) {
            (iterator.next()).a();
        }
    }

    /*
     * Duplicate member names - consider using --renamedupmembers true
     */
    public static abstract class i
    extends g.b {
        public i(int n5) {
            super(n5);
        }

        public abstract String a();

        public abstract void a();

        public void run() {
            int n5 = this.d;
            if (n5 != 4 && n5 != 8) {
                StringBuilder stringBuilder = e.a.a.a.a.F1((String)"JOB: ");
                stringBuilder.append(this.a());
                com.xiaomi.channel.commonutils.logger.b.a((String)stringBuilder.toString());
            }
            this.a();
        }
    }

}

