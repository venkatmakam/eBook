/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 *  android.net.Uri
 *  android.os.Bundle
 *  com.xiaomi.channel.commonutils.logger.b
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 */
package com.xiaomi.push.service.receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import com.xiaomi.channel.commonutils.logger.b;
import com.xiaomi.push.service.XMPushService;
import com.xiaomi.push.service.ay;
import com.xiaomi.push.service.bc;

public class PkgUninstallReceiver
extends BroadcastReceiver {
    public void onReceive(Context context, Intent intent) {
        if (intent != null && "android.intent.action.PACKAGE_REMOVED".equals((Object)intent.getAction())) {
            boolean bl2 = intent.getExtras().getBoolean("android.intent.extra.REPLACING");
            Uri uri = intent.getData();
            if (uri != null && !bl2) {
                try {
                    Intent intent2 = new Intent(context, XMPushService.class);
                    intent2.setAction(ay.a);
                    intent2.putExtra("uninstall_pkg_name", uri.getEncodedSchemeSpecificPart());
                    bc.a(context).a(intent2);
                    return;
                }
                catch (Exception exception) {
                    b.a((Throwable)exception);
                }
            }
        }
    }
}

