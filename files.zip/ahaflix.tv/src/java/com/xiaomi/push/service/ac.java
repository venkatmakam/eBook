/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  com.xiaomi.push.bi
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Collection
 *  java.util.HashMap
 *  java.util.LinkedList
 *  java.util.Map
 *  java.util.Queue
 */
package com.xiaomi.push.service;

import android.content.SharedPreferences;
import com.xiaomi.push.bi;
import com.xiaomi.push.service.XMPushService;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class ac {
    private static Object a = new Object();
    private static Map<String, Queue<String>> a;

    public static {
        a = new HashMap();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static boolean a(XMPushService xMPushService, String string2, String string3) {
        Object object;
        Object object2 = object = a;
        synchronized (object2) {
            SharedPreferences sharedPreferences = xMPushService.getSharedPreferences("push_message_ids", 0);
            Queue queue = (Queue)a.get((Object)string2);
            if (queue == null) {
                String[] arrstring = sharedPreferences.getString(string2, "").split(",");
                LinkedList linkedList = new LinkedList();
                int n4 = arrstring.length;
                for (int i6 = 0; i6 < n4; ++i6) {
                    linkedList.add((Object)arrstring[i6]);
                }
                a.put((Object)string2, (Object)linkedList);
                queue = linkedList;
            }
            if (queue.contains((Object)string3)) {
                return true;
            }
            queue.add((Object)string3);
            if (queue.size() > 25) {
                queue.poll();
            }
            String string4 = bi.a((Collection)queue, (String)",");
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString(string2, string4);
            editor.commit();
            return false;
        }
    }
}

