/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.xiaomi.channel.commonutils.logger.b
 *  com.xiaomi.push.bf
 *  e.a.a.a.a
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.xiaomi.push.service;

import com.xiaomi.channel.commonutils.logger.b;
import com.xiaomi.push.bf;
import e.a.a.a.a;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class az {
    private static int a = 8;
    private byte[] a = new byte[256];
    private int b = 0;
    private int c = 0;
    private int d = -666;

    public static int a(byte by) {
        if (by >= 0) {
            return by;
        }
        return by + 256;
    }

    private void a() {
        this.c = 0;
        this.b = 0;
    }

    private void a(int n4, byte[] arrby, boolean bl2) {
        int n5;
        int n6 = arrby.length;
        int n7 = 0;
        for (int i6 = 0; i6 < 256; ++i6) {
            this.a[i6] = (byte)i6;
        }
        this.c = 0;
        this.b = 0;
        while ((n5 = this.b) < n4) {
            int n8;
            this.c = n8 = (this.c + az.a(this.a[n5]) + az.a(arrby[this.b % n6])) % 256;
            az.a(this.a, this.b, n8);
            this.b = 1 + this.b;
        }
        if (n4 != 256) {
            this.d = (this.c + az.a(this.a[n4]) + az.a(arrby[n4 % n6])) % 256;
        }
        if (bl2) {
            StringBuilder stringBuilder = a.F1((String)"S_");
            int n9 = n4 - 1;
            stringBuilder.append(n9);
            stringBuilder.append(":");
            while (n7 <= n4) {
                stringBuilder.append(" ");
                stringBuilder.append(az.a(this.a[n7]));
                ++n7;
            }
            stringBuilder.append("   j_");
            stringBuilder.append(n9);
            stringBuilder.append("=");
            stringBuilder.append(this.c);
            stringBuilder.append("   j_");
            stringBuilder.append(n4);
            stringBuilder.append("=");
            stringBuilder.append(this.d);
            stringBuilder.append("   S_");
            stringBuilder.append(n9);
            stringBuilder.append("[j_");
            stringBuilder.append(n9);
            stringBuilder.append("]=");
            stringBuilder.append(az.a(this.a[this.c]));
            stringBuilder.append("   S_");
            stringBuilder.append(n9);
            stringBuilder.append("[j_");
            stringBuilder.append(n4);
            stringBuilder.append("]=");
            stringBuilder.append(az.a(this.a[this.d]));
            if (this.a[1] != 0) {
                stringBuilder.append("   S[1]!=0");
            }
            b.a((String)stringBuilder.toString());
        }
    }

    private void a(byte[] arrby) {
        this.a(256, arrby, false);
    }

    private static void a(byte[] arrby, int n4, int n5) {
        byte by = arrby[n4];
        arrby[n4] = arrby[n5];
        arrby[n5] = by;
    }

    public static byte[] a(String string2, String string3) {
        byte[] arrby = bf.a((String)string2);
        byte[] arrby2 = string3.getBytes();
        byte[] arrby3 = new byte[1 + arrby.length + arrby2.length];
        int n4 = 0;
        for (int i6 = 0; i6 < arrby.length; ++i6) {
            arrby3[i6] = arrby[i6];
        }
        arrby3[arrby.length] = 95;
        while (n4 < arrby2.length) {
            arrby3[n4 + (1 + arrby.length)] = arrby2[n4];
            ++n4;
        }
        return arrby3;
    }

    public static byte[] a(byte[] arrby, String string2) {
        return az.a(arrby, bf.a((String)string2));
    }

    public static byte[] a(byte[] arrby, byte[] arrby2) {
        byte[] arrby3 = new byte[arrby2.length];
        az az2 = new az();
        az2.a(arrby);
        az2.a();
        for (int i6 = 0; i6 < arrby2.length; ++i6) {
            arrby3[i6] = (byte)(arrby2[i6] ^ az2.b());
        }
        return arrby3;
    }

    public static byte[] a(byte[] arrby, byte[] arrby2, boolean bl2, int n4, int n5) {
        if (n4 >= 0 && n4 <= arrby2.length && n4 + n5 <= arrby2.length) {
            int n6;
            byte[] arrby3;
            int n7 = 0;
            if (!bl2) {
                arrby3 = new byte[n5];
                n6 = 0;
            } else {
                arrby3 = arrby2;
                n6 = n4;
            }
            az az2 = new az();
            az2.a(arrby);
            az2.a();
            while (n7 < n5) {
                arrby3[n6 + n7] = (byte)(arrby2[n4 + n7] ^ az2.b());
                ++n7;
            }
            return arrby3;
        }
        throw new IllegalArgumentException(a.Y0((String)"start = ", (int)n4, (String)" len = ", (int)n5));
    }

    public byte b() {
        int n4;
        int n5;
        this.b = n5 = (1 + this.b) % 256;
        this.c = n4 = (this.c + az.a(this.a[n5])) % 256;
        az.a(this.a, this.b, n4);
        byte[] arrby = this.a;
        return arrby[(az.a(arrby[this.b]) + az.a(this.a[this.c])) % 256];
    }
}

