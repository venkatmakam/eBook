/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.BroadcastReceiver
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  com.xiaomi.channel.commonutils.logger.b
 *  com.xiaomi.mipush.sdk.COSPushHelper
 *  com.xiaomi.mipush.sdk.FTOSPushHelper
 *  com.xiaomi.mipush.sdk.HWPushHelper
 *  com.xiaomi.mipush.sdk.MiPushClient
 *  com.xiaomi.mipush.sdk.ag
 *  com.xiaomi.mipush.sdk.aq
 *  com.xiaomi.mipush.sdk.av
 *  com.xiaomi.mipush.sdk.b
 *  com.xiaomi.push.bc
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.concurrent.BlockingQueue
 *  java.util.concurrent.LinkedBlockingQueue
 *  java.util.concurrent.ThreadPoolExecutor
 *  java.util.concurrent.TimeUnit
 */
package com.xiaomi.push.service.receivers;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import com.xiaomi.channel.commonutils.logger.b;
import com.xiaomi.mipush.sdk.COSPushHelper;
import com.xiaomi.mipush.sdk.FTOSPushHelper;
import com.xiaomi.mipush.sdk.HWPushHelper;
import com.xiaomi.mipush.sdk.MiPushClient;
import com.xiaomi.mipush.sdk.ag;
import com.xiaomi.mipush.sdk.aq;
import com.xiaomi.mipush.sdk.av;
import com.xiaomi.push.bc;
import com.xiaomi.push.hb;
import com.xiaomi.push.service.receivers.a;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class NetworkStatusReceiver
extends BroadcastReceiver {
    private static int a = 1;
    private static BlockingQueue<Runnable> a;
    private static ThreadPoolExecutor a;
    private static boolean a = false;
    private static int b = 1;
    private static int c = 2;
    private boolean b = false;

    public static {
        ThreadPoolExecutor threadPoolExecutor;
        a = (int)new LinkedBlockingQueue();
        a = threadPoolExecutor = new ThreadPoolExecutor(a, b, (long)c, TimeUnit.SECONDS, (BlockingQueue)a);
        a = false;
    }

    public NetworkStatusReceiver() {
        this.b = true;
    }

    public NetworkStatusReceiver(Object object) {
        a = true;
    }

    private void a(Context context) {
        if (!aq.a((Context)context).a() && com.xiaomi.mipush.sdk.b.a((Context)context).c() && !com.xiaomi.mipush.sdk.b.a((Context)context).e()) {
            try {
                Intent intent = new Intent();
                intent.setComponent(new ComponentName(context, "com.xiaomi.push.service.XMPushService"));
                intent.setAction("com.xiaomi.push.network_status_changed");
                com.xiaomi.push.service.bc.a(context).a(intent);
            }
            catch (Exception exception) {
                b.a((Throwable)exception);
            }
        }
        hb.a(context);
        if (bc.b((Context)context) && aq.a((Context)context).b()) {
            aq.a((Context)context).c();
        }
        if (bc.b((Context)context)) {
            if ("syncing".equals((Object)ag.a((Context)context).a(av.a))) {
                MiPushClient.disablePush((Context)context);
            }
            if ("syncing".equals((Object)ag.a((Context)context).a(av.b))) {
                MiPushClient.enablePush((Context)context);
            }
            if ("syncing".equals((Object)ag.a((Context)context).a(av.c))) {
                MiPushClient.syncAssemblePushToken((Context)context);
            }
            if ("syncing".equals((Object)ag.a((Context)context).a(av.d))) {
                MiPushClient.syncAssembleFCMPushToken((Context)context);
            }
            if ("syncing".equals((Object)ag.a((Context)context).a(av.e))) {
                MiPushClient.syncAssembleCOSPushToken((Context)context);
            }
            if ("syncing".equals((Object)ag.a((Context)context).a(av.f))) {
                MiPushClient.syncAssembleFTOSPushToken((Context)context);
            }
            if (HWPushHelper.needConnect() && HWPushHelper.shouldTryConnect((Context)context)) {
                HWPushHelper.setConnectTime((Context)context);
                HWPushHelper.registerHuaWeiAssemblePush((Context)context);
            }
            COSPushHelper.doInNetworkChange((Context)context);
            FTOSPushHelper.doInNetworkChange((Context)context);
        }
    }

    public static boolean a() {
        return a;
    }

    public static /* synthetic */ void b(NetworkStatusReceiver networkStatusReceiver, Context context) {
        networkStatusReceiver.a(context);
    }

    public void onReceive(Context context, Intent intent) {
        if (this.b) {
            return;
        }
        a.execute((Runnable)new a(this, context));
    }
}

