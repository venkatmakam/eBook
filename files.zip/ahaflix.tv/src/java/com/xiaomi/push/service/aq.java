/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.IBinder
 *  android.os.IBinder$DeathRecipient
 *  android.os.Messenger
 *  android.text.TextUtils
 *  com.xiaomi.channel.commonutils.logger.b
 *  com.xiaomi.push.service.XMPushService$b
 *  com.xiaomi.push.service.aq$b$b
 *  com.xiaomi.push.service.as
 *  com.xiaomi.push.service.at
 *  e.a.a.a.a
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Enum
 *  java.lang.Exception
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.List
 *  java.util.concurrent.ConcurrentHashMap
 */
package com.xiaomi.push.service;

import android.content.Context;
import android.os.IBinder;
import android.os.Messenger;
import android.text.TextUtils;
import com.xiaomi.push.service.XMPushService;
import com.xiaomi.push.service.aq;
import com.xiaomi.push.service.ar;
import com.xiaomi.push.service.as;
import com.xiaomi.push.service.at;
import com.xiaomi.push.service.au;
import com.xiaomi.push.service.d;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class aq {
    private static aq a;
    private List<a> a;
    private ConcurrentHashMap<String, HashMap<String, b>> a = new ArrayList();

    private aq() {
    }

    public static aq a() {
        Class<aq> class_ = aq.class;
        synchronized (aq.class) {
            if (a == null) {
                a = new aq();
            }
            aq aq2 = a;
            // ** MonitorExit[var2] (shouldn't be in output)
            return aq2;
        }
    }

    private String a(String string2) {
        if (TextUtils.isEmpty((CharSequence)string2)) {
            return null;
        }
        int n4 = string2.indexOf("@");
        if (n4 > 0) {
            string2 = string2.substring(0, n4);
        }
        return string2;
    }

    public int a() {
        aq aq2 = this;
        synchronized (aq2) {
            int n4 = this.a.size();
            return n4;
        }
    }

    public b a(String string2, String string3) {
        aq aq2 = this;
        synchronized (aq2) {
            HashMap hashMap;
            block4 : {
                hashMap = (HashMap)this.a.get((Object)string2);
                if (hashMap != null) break block4;
                return null;
            }
            b b7 = (b)hashMap.get((Object)this.a(string3));
            return b7;
        }
    }

    public ArrayList<b> a() {
        aq aq2 = this;
        synchronized (aq2) {
            ArrayList arrayList = new ArrayList();
            Iterator iterator = this.a.values().iterator();
            while (iterator.hasNext()) {
                arrayList.addAll(((HashMap)iterator.next()).values());
            }
            return arrayList;
        }
    }

    public Collection<b> a(String string2) {
        aq aq2 = this;
        synchronized (aq2) {
            block4 : {
                if (this.a.containsKey((Object)string2)) break block4;
                ArrayList arrayList = new ArrayList();
                return arrayList;
            }
            Collection collection = ((HashMap)((HashMap)this.a.get((Object)string2)).clone()).values();
            return collection;
        }
    }

    public List<String> a(String string2) {
        aq aq2 = this;
        synchronized (aq2) {
            ArrayList arrayList = new ArrayList();
            Iterator iterator = this.a.values().iterator();
            while (iterator.hasNext()) {
                for (b b7 : ((HashMap)iterator.next()).values()) {
                    if (!string2.equals((Object)b7.a)) continue;
                    arrayList.add((Object)b7.g);
                }
            }
            return arrayList;
        }
    }

    public void a() {
        aq aq2 = this;
        synchronized (aq2) {
            Iterator iterator = this.a().iterator();
            while (iterator.hasNext()) {
                ((b)iterator.next()).d();
            }
            this.a.clear();
            return;
        }
    }

    public void a(Context context) {
        aq aq2 = this;
        synchronized (aq2) {
            Iterator iterator = this.a.values().iterator();
            while (iterator.hasNext()) {
                Iterator iterator2 = ((HashMap)iterator.next()).values().iterator();
                while (iterator2.hasNext()) {
                    ((b)iterator2.next()).a(c.a, 1, 3, null, null);
                }
            }
            return;
        }
    }

    public void a(Context context, int n4) {
        aq aq2 = this;
        synchronized (aq2) {
            Iterator iterator = this.a.values().iterator();
            while (iterator.hasNext()) {
                Iterator iterator2 = ((HashMap)iterator.next()).values().iterator();
                while (iterator2.hasNext()) {
                    ((b)iterator2.next()).a(c.a, 2, n4, null, null);
                }
            }
            return;
        }
    }

    public void a(a a2) {
        aq aq2 = this;
        synchronized (aq2) {
            this.a.add((Object)a2);
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void a(b b7) {
        aq aq2 = this;
        synchronized (aq2) {
            HashMap hashMap = (HashMap)this.a.get((Object)b7.g);
            if (hashMap == null) {
                hashMap = new HashMap();
                this.a.put((Object)b7.g, (Object)hashMap);
            }
            hashMap.put((Object)this.a(b7.b), (Object)b7);
            Iterator iterator = this.a.iterator();
            while (iterator.hasNext()) {
                ((a)iterator.next()).a();
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void a(String string2) {
        aq aq2 = this;
        synchronized (aq2) {
            HashMap hashMap = (HashMap)this.a.get((Object)string2);
            if (hashMap != null) {
                Iterator iterator = hashMap.values().iterator();
                while (iterator.hasNext()) {
                    ((b)iterator.next()).d();
                }
                hashMap.clear();
                this.a.remove((Object)string2);
            }
            Iterator iterator = this.a.iterator();
            while (iterator.hasNext()) {
                ((a)iterator.next()).a();
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void a(String string2, String string3) {
        aq aq2 = this;
        synchronized (aq2) {
            HashMap hashMap = (HashMap)this.a.get((Object)string2);
            if (hashMap != null) {
                b b7 = (b)hashMap.get((Object)this.a(string3));
                if (b7 != null) {
                    b7.d();
                }
                hashMap.remove((Object)this.a(string3));
                if (hashMap.isEmpty()) {
                    this.a.remove((Object)string2);
                }
            }
            Iterator iterator = this.a.iterator();
            while (iterator.hasNext()) {
                ((a)iterator.next()).a();
            }
            return;
        }
    }

    public void b() {
        aq aq2 = this;
        synchronized (aq2) {
            this.a.clear();
            return;
        }
    }

    public static interface a {
        public void a();
    }

    /*
     * Duplicate member names - consider using --renamedupmembers true
     * Exception performing whole class analysis.
     */
    public static class com.xiaomi.push.service.aq$b {
        private int a;
        public Context a;
        private XMPushService.b a;
        private XMPushService a;
        public d a;
        public String a;
        private List<a> a;
        public boolean a;
        public String b;
        private boolean b;
        public String c;
        public String d;
        public String e;
        public String f;
        public String g;
        public String h;
        public String i;
        public com.xiaomi.push.service.aq$c j;
        public com.xiaomi.push.service.aq$c k;
        public Messenger l;
        public IBinder.DeathRecipient m;
        public final b n;

        public com.xiaomi.push.service.aq$b() {
            this.j = com.xiaomi.push.service.aq$c.a;
            this.a = 0;
            this.a = (int)new ArrayList();
            this.k = null;
            this.b = false;
            this.a = new /* Unavailable Anonymous Inner Class!! */;
            this.m = null;
            this.n = new /* Unavailable Anonymous Inner Class!! */;
        }

        public com.xiaomi.push.service.aq$b(XMPushService xMPushService) {
            this.j = com.xiaomi.push.service.aq$c.a;
            this.a = 0;
            this.a = (int)new ArrayList();
            this.k = null;
            this.b = false;
            this.a = new /* Unavailable Anonymous Inner Class!! */;
            this.m = null;
            this.n = new /* Unavailable Anonymous Inner Class!! */;
            this.a = xMPushService;
            this.a(new ar(this));
        }

        public static String a(String string2) {
            boolean bl2 = TextUtils.isEmpty((CharSequence)string2);
            String string3 = "";
            if (bl2) {
                return string3;
            }
            int n4 = string2.lastIndexOf("/");
            if (n4 != -1) {
                string3 = string2.substring(n4 + 1);
            }
            return string3;
        }

        /*
         * Exception decompiling
         */
        private void a(int var1, int var2, String var3, String var4) {
            // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
            // org.benf.cfr.reader.util.ConfusedCFRException: Underrun type stack
            // org.benf.cfr.reader.b.a.c.e.a(StackSim.java:35)
            // org.benf.cfr.reader.b.b.af.a(OperationFactoryPop.java:20)
            // org.benf.cfr.reader.b.b.e.a(JVMInstr.java:315)
            // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:195)
            // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
            // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
            // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
            // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
            // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
            // org.benf.cfr.reader.entities.g.p(Method.java:396)
            // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
            // org.benf.cfr.reader.entities.d.c(ClassFile.java:773)
            // org.benf.cfr.reader.entities.d.e(ClassFile.java:870)
            // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
            // org.benf.cfr.reader.b.a(Driver.java:128)
            // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
            // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
            // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
            // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
            // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
            // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
            // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
            // java.lang.Thread.run(Thread.java:923)
            throw new IllegalStateException("Decompilation failed");
        }

        private boolean a(int n4, int n5, String string2) {
            com.xiaomi.push.service.aq$c c5 = this.k;
            if (c5 != null) {
                StringBuilder stringBuilder;
                String string3;
                boolean bl2 = this.b;
                if (!bl2) {
                    return true;
                }
                if (c5 == this.j) {
                    stringBuilder = new StringBuilder();
                    string3 = " status recovered, don't notify client:";
                } else {
                    if (this.l != null && bl2) {
                        StringBuilder stringBuilder2 = e.a.a.a.a.F1((String)"Peer alive notify status to client:");
                        stringBuilder2.append(this.g);
                        com.xiaomi.channel.commonutils.logger.b.b((String)stringBuilder2.toString());
                        return true;
                    }
                    stringBuilder = new StringBuilder();
                    string3 = "peer died, ignore notify ";
                }
                stringBuilder.append(string3);
                stringBuilder.append(this.g);
                com.xiaomi.channel.commonutils.logger.b.b((String)stringBuilder.toString());
                return false;
            }
            return true;
        }

        public static /* synthetic */ XMPushService.b b(com.xiaomi.push.service.aq$b b7) {
            return b7.a;
        }

        private boolean b(int n4, int n5, String string2) {
            if (n4 != 1) {
                if (n4 != 2) {
                    if (n4 != 3) {
                        return false;
                    }
                    return true ^ "wait".equals((Object)string2);
                }
                return this.a.c();
            }
            if (this.j == com.xiaomi.push.service.aq$c.c) {
                return false;
            }
            if (!this.a.c()) {
                return false;
            }
            if (n5 != 21) {
                return n5 != 7 || !"wait".equals((Object)string2);
            }
            return false;
        }

        public static /* synthetic */ void f(com.xiaomi.push.service.aq$b b7, int n4, int n5, String string2, String string3) {
            b7.a(n4, n5, string2, string3);
        }

        public static /* synthetic */ boolean g(com.xiaomi.push.service.aq$b b7, int n4, int n5, String string2) {
            return b7.a(n4, n5, string2);
        }

        public long a() {
            return 1000L * ((long)(20.0 * Math.random() - 10.0) + (long)(15 * (1 + this.a)));
        }

        public String a(int n4) {
            if (n4 != 1) {
                if (n4 != 2) {
                    if (n4 != 3) {
                        return "unknown";
                    }
                    return "KICK";
                }
                return "CLOSE";
            }
            return "OPEN";
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        public void a(a a2) {
            int n4;
            int n5 = n4 = this.a;
            synchronized (n5) {
                this.a.add((Object)a2);
                return;
            }
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        public void a(com.xiaomi.push.service.aq$c c5, int n4, int n5, String string2, String string3) {
            int n6;
            int n7 = n6 = this.a;
            synchronized (n7) {
                Iterator iterator = this.a.iterator();
                while (iterator.hasNext()) {
                    ((a)iterator.next()).a(this.j, c5, n5);
                }
            }
            com.xiaomi.push.service.aq$c c7 = this.j;
            if (c7 != c5) {
                Object[] arrobject = new Object[]{c7, c5, this.a(n4), au.a(n5), string2, string3, this.g};
                com.xiaomi.channel.commonutils.logger.b.a((String)String.format((String)"update the client %7$s status. %1$s->%2$s %3$s %4$s %5$s %6$s", (Object[])arrobject));
                this.j = c5;
            }
            if (this.a == null) {
                com.xiaomi.channel.commonutils.logger.b.d((String)"status changed while the client dispatcher is missing");
                return;
            }
            if (c5 == com.xiaomi.push.service.aq$c.b) {
                return;
            }
            com.xiaomi.push.service.aq$c c8 = this.k;
            int n8 = 0;
            if (c8 != null) {
                boolean bl2 = this.b;
                n8 = !bl2 ? 0 : (this.l != null && bl2 ? 1000 : 10100);
            }
            this.a.b((XMPushService.i)this.n);
            if (this.b(n4, n5, string3)) {
                this.a(n4, n5, string2, string3);
                return;
            }
            this.a.a(this.n.a(n4, n5, string2, string3), (long)n8);
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        public void b(a a2) {
            int n4;
            int n5 = n4 = this.a;
            synchronized (n5) {
                this.a.remove((Object)a2);
                return;
            }
        }

        /*
         * Exception decompiling
         */
        public void d() {
            // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
            // org.benf.cfr.reader.util.ConfusedCFRException: Underrun type stack
            // org.benf.cfr.reader.b.a.c.e.a(StackSim.java:35)
            // org.benf.cfr.reader.b.b.af.a(OperationFactoryPop.java:20)
            // org.benf.cfr.reader.b.b.e.a(JVMInstr.java:315)
            // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:195)
            // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
            // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
            // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
            // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
            // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
            // org.benf.cfr.reader.entities.g.p(Method.java:396)
            // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
            // org.benf.cfr.reader.entities.d.c(ClassFile.java:773)
            // org.benf.cfr.reader.entities.d.e(ClassFile.java:870)
            // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
            // org.benf.cfr.reader.b.a(Driver.java:128)
            // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
            // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
            // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
            // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
            // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
            // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
            // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
            // java.lang.Thread.run(Thread.java:923)
            throw new IllegalStateException("Decompilation failed");
        }

        /*
         * Unable to fully structure code
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         * Lifted jumps to return sites
         */
        public void e(Messenger var1_1) {
            this.d();
            if (var1_1 == null) ** GOTO lbl9
            try {
                this.l = var1_1;
                this.b = true;
                this.m = new c(this, var1_1);
                var1_1.getBinder().linkToDeath(this.m, 0);
                return;
lbl9: // 1 sources:
                var2_2 = new StringBuilder();
                var2_2.append("peer linked with old sdk chid = ");
                var2_2.append(this.g);
                com.xiaomi.channel.commonutils.logger.b.b((String)var2_2.toString());
                return;
            }
            catch (Exception var3_3) {
                var4_4 = e.a.a.a.a.F1((String)"peer linkToDeath err: ");
                var4_4.append(var3_3.getMessage());
                com.xiaomi.channel.commonutils.logger.b.b((String)var4_4.toString());
                this.l = null;
                this.b = false;
                return;
            }
        }

        public static interface a {
            public void a(com.xiaomi.push.service.aq$c var1, com.xiaomi.push.service.aq$c var2, int var3);
        }

        public class c
        implements IBinder.DeathRecipient {
            public final com.xiaomi.push.service.aq$b a;
            public final Messenger b;

            public c(com.xiaomi.push.service.aq$b b8, Messenger messenger) {
                this.a = b8;
                this.b = messenger;
            }

            public void binderDied() {
                StringBuilder stringBuilder = e.a.a.a.a.F1((String)"peer died, chid = ");
                stringBuilder.append(this.a.g);
                com.xiaomi.channel.commonutils.logger.b.b((String)stringBuilder.toString());
                b.this.a.a((XMPushService.i)new as(this, 0), 0L);
                if ("9".equals((Object)this.a.g) && "com.xiaomi.xmsf".equals((Object)b.this.a.getPackageName())) {
                    b.this.a.a((XMPushService.i)new at(this, 0), 60000L);
                }
            }
        }

    }

    /*
     * Duplicate member names - consider using --renamedupmembers true
     */
    public static final class c
    extends Enum<c> {
        public static final /* enum */ c a;
        private static final /* synthetic */ c[] a;
        public static final /* enum */ c b;
        public static final /* enum */ c c;

        public static {
            c c5;
            c c7;
            c c8;
            a = c5 = new c();
            b = c7 = new c();
            c = c8 = new c();
            a = new c[]{c5, c7, c8};
        }

        public static c valueOf(String string2) {
            return (c)Enum.valueOf(c.class, (String)string2);
        }

        public static c[] values() {
            return (c[])a.clone();
        }
    }

}

