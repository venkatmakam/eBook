/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  com.xiaomi.push.service.aq
 *  com.xiaomi.push.service.aq$b
 *  com.xiaomi.push.service.aq$b$a
 *  com.xiaomi.push.service.aq$c
 *  com.xiaomi.push.service.o
 *  java.lang.Object
 *  java.lang.String
 */
package com.xiaomi.push.service;

import android.content.Context;
import com.xiaomi.push.service.XMPushService;
import com.xiaomi.push.service.aq;
import com.xiaomi.push.service.o;

public final class z
implements aq.b.a {
    public final /* synthetic */ XMPushService a;

    public z(XMPushService xMPushService) {
        this.a = xMPushService;
    }

    public void a(aq.c c3, aq.c c5, int n5) {
        if (c5 == aq.c.c) {
            o.a((XMPushService)this.a);
            o.b((XMPushService)this.a);
            return;
        }
        if (c5 == aq.c.a) {
            o.a((Context)this.a, (int)70000001, (String)" the push is not connected.");
        }
    }
}

