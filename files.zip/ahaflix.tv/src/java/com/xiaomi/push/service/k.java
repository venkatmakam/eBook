/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  com.xiaomi.push.g
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.reflect.Field
 *  java.util.Locale
 */
package com.xiaomi.push.service;

import android.content.Context;
import com.xiaomi.push.g;
import com.xiaomi.push.service.XMPushService;
import com.xiaomi.push.service.a;
import com.xiaomi.push.service.aq;
import com.xiaomi.push.service.d;
import com.xiaomi.push.t;
import java.lang.reflect.Field;
import java.util.Locale;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class k {
    public final int a;
    public final String a;
    public final String b;
    public final String c;
    public final String d;
    public final String e;
    public final String f;

    public k(String string2, String string3, String string4, String string5, String string6, String string7, int n4) {
        this.a = string2;
        this.b = string3;
        this.c = string4;
        this.d = string5;
        this.e = string6;
        this.f = string7;
        this.a = n4;
    }

    public static boolean a() {
        try {
            boolean bl2 = t.a(null, "miui.os.Build").getField("IS_ALPHA_BUILD").getBoolean(null);
            return bl2;
        }
        catch (Exception exception) {
            return false;
        }
    }

    public static boolean a(Context context) {
        return "com.xiaomi.xmsf".equals((Object)context.getPackageName()) && k.a();
    }

    private static boolean b(Context context) {
        return context.getPackageName().equals((Object)"com.xiaomi.xmsf");
    }

    public aq.b a(XMPushService xMPushService) {
        aq.b b7 = new aq.b(xMPushService);
        this.a(b7, (Context)xMPushService, xMPushService.b(), "c");
        return b7;
    }

    public aq.b a(aq.b b7, Context context, d d7, String string2) {
        b7.a = context.getPackageName();
        b7.b = this.a;
        b7.h = this.c;
        b7.c = this.b;
        b7.g = "5";
        b7.d = "XMPUSH-PASS";
        b7.a = false;
        String string3 = k.b(context) ? g.b((Context)context) : "";
        Object[] arrobject = new Object[]{"sdk_ver", 39, "cpvn", "3_7_6", "cpvc", 30706, "aapn", string3, "country_code", a.a(context).b(), "region", a.a(context).a()};
        b7.e = String.format((String)"%1$s:%2$s,%3$s:%4$s,%5$s:%6$s:%7$s:%8$s,%9$s:%10$s,%11$s:%12$s", (Object[])arrobject);
        String string4 = k.b(context) ? "1000271" : this.d;
        Object[] arrobject2 = new Object[]{"appid", string4, "locale", Locale.getDefault().toString(), "miid", t.a(context)};
        b7.f = String.format((String)"%1$s:%2$s,%3$s:%4$s,%5$s:%6$s,sync:1", (Object[])arrobject2);
        if (k.a(context)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(b7.f);
            stringBuilder.append(String.format((String)",%1$s:%2$s", (Object[])new Object[]{"ab", string2}));
            b7.f = stringBuilder.toString();
        }
        b7.a = d7;
        return b7;
    }
}

