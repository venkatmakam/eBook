/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.app.Service
 *  android.app.job.JobParameters
 *  android.app.job.JobService
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Binder
 *  android.os.Handler
 *  android.os.IBinder
 *  android.os.Looper
 *  android.os.Message
 *  com.xiaomi.channel.commonutils.logger.b
 *  com.xiaomi.push.bd
 *  com.xiaomi.push.fg
 *  e.a.a.a.a
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.xiaomi.push.service;

import android.annotation.TargetApi;
import android.app.Service;
import android.app.job.JobParameters;
import android.app.job.JobService;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import com.xiaomi.channel.commonutils.logger.b;
import com.xiaomi.push.bd;
import com.xiaomi.push.fg;
import com.xiaomi.push.service.XMPushService;

public class XMJobService
extends Service {
    private IBinder a = null;

    public IBinder onBind(Intent intent) {
        IBinder iBinder = this.a;
        if (iBinder != null) {
            return iBinder;
        }
        return new Binder();
    }

    public void onCreate() {
        super.onCreate();
        this.a = new a((Service)this).b;
    }

    public void onDestroy() {
        super.onDestroy();
    }

    @TargetApi(value=21)
    public static class com.xiaomi.push.service.XMJobService$a
    extends JobService {
        private Handler a;
        public Binder b = null;

        public com.xiaomi.push.service.XMJobService$a(Service service) {
            Object[] arrobject = new Object[]{new Intent()};
            this.b = (Binder)bd.a((Object)((Object)this), (String)"onBind", (Object[])arrobject);
            bd.a((Object)((Object)this), (String)"attachBaseContext", (Object[])new Object[]{service});
        }

        public boolean onStartJob(JobParameters jobParameters) {
            StringBuilder stringBuilder = e.a.a.a.a.F1((String)"Job started ");
            stringBuilder.append(jobParameters.getJobId());
            b.a((String)stringBuilder.toString());
            Intent intent = new Intent((Context)this, XMPushService.class);
            intent.setAction("com.xiaomi.push.timer");
            intent.setPackage(this.getPackageName());
            this.startService(intent);
            if (this.a == null) {
                this.a = new a(this);
            }
            Handler handler = this.a;
            handler.sendMessage(Message.obtain((Handler)handler, (int)1, (Object)jobParameters));
            return true;
        }

        public boolean onStopJob(JobParameters jobParameters) {
            StringBuilder stringBuilder = e.a.a.a.a.F1((String)"Job stop ");
            stringBuilder.append(jobParameters.getJobId());
            b.a((String)stringBuilder.toString());
            return false;
        }

        public static class a
        extends Handler {
            public JobService a;

            public a(JobService jobService) {
                super(jobService.getMainLooper());
                this.a = jobService;
            }

            public void handleMessage(Message message) {
                if (message.what != 1) {
                    return;
                }
                JobParameters jobParameters = (JobParameters)message.obj;
                StringBuilder stringBuilder = e.a.a.a.a.F1((String)"Job finished ");
                stringBuilder.append(jobParameters.getJobId());
                b.a((String)stringBuilder.toString());
                this.a.jobFinished(jobParameters, false);
                if (jobParameters.getJobId() == 1) {
                    fg.a((boolean)false);
                }
            }
        }

    }

}

