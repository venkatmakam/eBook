/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.text.TextUtils
 *  com.xiaomi.channel.commonutils.logger.b
 *  com.xiaomi.push.a
 *  com.xiaomi.push.cy
 *  com.xiaomi.push.dc
 *  com.xiaomi.push.dl
 *  com.xiaomi.push.eo
 *  com.xiaomi.push.eo$b
 *  com.xiaomi.push.eo$d
 *  com.xiaomi.push.eo$g
 *  com.xiaomi.push.eo$h
 *  com.xiaomi.push.eo$i
 *  com.xiaomi.push.eo$j
 *  com.xiaomi.push.eo$k
 *  com.xiaomi.push.fl
 *  com.xiaomi.push.fp
 *  com.xiaomi.push.fx
 *  com.xiaomi.push.gk
 *  com.xiaomi.push.gl
 *  com.xiaomi.push.gm
 *  com.xiaomi.push.gn
 *  com.xiaomi.push.service.bb
 *  e.a.a.a.a
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Throwable
 *  java.util.Date
 */
package com.xiaomi.push.service;

import android.content.Context;
import android.text.TextUtils;
import com.xiaomi.channel.commonutils.logger.b;
import com.xiaomi.push.a;
import com.xiaomi.push.cy;
import com.xiaomi.push.dc;
import com.xiaomi.push.dl;
import com.xiaomi.push.eo;
import com.xiaomi.push.fl;
import com.xiaomi.push.fp;
import com.xiaomi.push.fx;
import com.xiaomi.push.gk;
import com.xiaomi.push.gl;
import com.xiaomi.push.gm;
import com.xiaomi.push.gn;
import com.xiaomi.push.hb;
import com.xiaomi.push.hk;
import com.xiaomi.push.service.XMPushService;
import com.xiaomi.push.service.aq;
import com.xiaomi.push.service.bb;
import com.xiaomi.push.service.bf;
import com.xiaomi.push.service.d;
import java.util.Date;

public class ap {
    private XMPushService a;

    public ap(XMPushService xMPushService) {
        this.a = xMPushService;
    }

    private void a(gk gk2) {
        String string2 = gk2.c();
        if (!TextUtils.isEmpty((CharSequence)string2)) {
            String[] arrstring = string2.split(";");
            cy cy2 = dc.a().a(fx.a(), false);
            if (cy2 != null && arrstring.length > 0) {
                cy2.a(arrstring);
                this.a.a(20, null);
                this.a.a(true);
            }
        }
    }

    private void b(gn gn2) {
        aq.b b7;
        String string2 = gn2.l();
        String string3 = gn2.k();
        if (!TextUtils.isEmpty((CharSequence)string2) && !TextUtils.isEmpty((CharSequence)string3) && (b7 = aq.a().a(string3, string2)) != null) {
            hb.a((Context)this.a, b7.a, hb.a(gn2.a()), true, true, System.currentTimeMillis());
        }
    }

    private void c(fp fp2) {
        aq.b b7;
        String string2 = fp2.g();
        String string3 = Integer.toString((int)fp2.a());
        if (!TextUtils.isEmpty((CharSequence)string2) && !TextUtils.isEmpty((CharSequence)string3) && (b7 = aq.a().a(string3, string2)) != null) {
            hb.a((Context)this.a, b7.a, fp2.c(), true, true, System.currentTimeMillis());
        }
    }

    public void a(fp fp2) {
        if (5 != fp2.a()) {
            this.c(fp2);
        }
        try {
            this.b(fp2);
            return;
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = e.a.a.a.a.F1((String)"handle Blob chid = ");
            stringBuilder.append(fp2.a());
            stringBuilder.append(" cmd = ");
            stringBuilder.append(fp2.a());
            stringBuilder.append(" packetid = ");
            stringBuilder.append(fp2.e());
            stringBuilder.append(" failure ");
            b.a((String)stringBuilder.toString(), (Throwable)exception);
            return;
        }
    }

    public void a(gn gn2) {
        String string2;
        gm gm2;
        if (!"5".equals((Object)gn2.k())) {
            this.b(gn2);
        }
        if (TextUtils.isEmpty((CharSequence)(string2 = gn2.k()))) {
            string2 = "1";
            gn2.l(string2);
        }
        if (string2.equals((Object)"0")) {
            StringBuilder stringBuilder = e.a.a.a.a.F1((String)"Received wrong packet with chid = 0 : ");
            stringBuilder.append(gn2.a());
            b.a((String)stringBuilder.toString());
        }
        if (gn2 instanceof gl) {
            gk gk2 = gn2.a("kick");
            if (gk2 != null) {
                String string3 = gn2.l();
                String string4 = gk2.a("type");
                String string5 = gk2.a("reason");
                StringBuilder stringBuilder = e.a.a.a.a.f((String)"kicked by server, chid=", (String)string2, (String)" res=");
                stringBuilder.append(aq.b.a(string3));
                stringBuilder.append(" type=");
                stringBuilder.append(string4);
                stringBuilder.append(" reason=");
                stringBuilder.append(string5);
                b.a((String)stringBuilder.toString());
                if ("wait".equals((Object)string4)) {
                    aq.b b7 = aq.a().a(string2, string3);
                    if (b7 != null) {
                        this.a.a(b7);
                        b7.a(aq.c.a, 3, 0, string5, string4);
                        return;
                    }
                } else {
                    this.a.a(string2, string3, 3, string5, string4);
                    aq.a().a(string2, string3);
                }
                return;
            }
        } else if (gn2 instanceof gm && "redir".equals((Object)(gm2 = (gm)gn2).b())) {
            gk gk3 = gm2.a("hosts");
            if (gk3 != null) {
                this.a(gk3);
            }
            return;
        }
        this.a.b().a(this.a, string2, gn2);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public void b(fp var1_1) {
        block23 : {
            block20 : {
                block18 : {
                    block21 : {
                        block22 : {
                            block19 : {
                                var2_2 = var1_1.a();
                                if (var1_1.a() == 0) break block18;
                                var22_3 = Integer.toString((int)var1_1.a());
                                if (!"SECMSG".equals((Object)var1_1.a())) break block19;
                                if (!var1_1.a()) {
                                    this.a.b().a(this.a, var22_3, var1_1);
                                    return;
                                }
                                var4_4 = e.a.a.a.a.F1((String)"Recv SECMSG errCode = ");
                                var4_4.append(var1_1.b());
                                var4_4.append(" errStr = ");
                                var7_5 = var1_1.c();
                                break block20;
                            }
                            if (!"BIND".equals((Object)var2_2)) break block21;
                            var34_6 = eo.d.a((byte[])var1_1.a());
                            var35_7 = var1_1.g();
                            var36_8 = aq.a().a(var22_3, var35_7);
                            if (var36_8 == null) {
                                return;
                            }
                            if (var34_6.a()) {
                                var47_9 = e.a.a.a.a.F1((String)"SMACK: channel bind succeeded, chid=");
                                var47_9.append(var1_1.a());
                                b.a((String)var47_9.toString());
                                var36_8.a(aq.c.c, 1, 0, null, null);
                                return;
                            }
                            var37_10 = var34_6.a();
                            if (!"auth".equals((Object)var37_10)) break block22;
                            if ("invalid-sig".equals((Object)var34_6.b())) {
                                var43_11 = e.a.a.a.a.F1((String)"SMACK: bind error invalid-sig token = ");
                                var43_11.append(var36_8.c);
                                var43_11.append(" sec = ");
                                var43_11.append(var36_8.h);
                                b.a((String)var43_11.toString());
                                hk.a(0, fl.Q.a(), 1, null, 0);
                            }
                            var40_12 = aq.c.a;
                            var41_13 = 1;
                            var42_14 = 5;
                            ** GOTO lbl44
                        }
                        if ("cancel".equals((Object)var37_10)) {
                            var40_12 = aq.c.a;
                            var41_13 = 1;
                            var42_14 = 7;
lbl44: // 2 sources:
                            var36_8.a(var40_12, var41_13, var42_14, var34_6.b(), var37_10);
                            aq.a().a(var22_3, var35_7);
                        } else if ("wait".equals((Object)var37_10)) {
                            this.a.a(var36_8);
                            var36_8.a(aq.c.a, 1, 7, var34_6.b(), var37_10);
                        }
                        var38_15 = e.a.a.a.a.f((String)"SMACK: channel bind failed, chid=", (String)var22_3, (String)" reason=");
                        var38_15.append(var34_6.b());
                        var9_16 = var38_15.toString();
                        break block23;
                    }
                    if ("KICK".equals((Object)var2_2) == false) return;
                    var23_17 = eo.g.a((byte[])var1_1.a());
                    var24_18 = var1_1.g();
                    var25_19 = var23_17.a();
                    var26_20 = var23_17.b();
                    var27_21 = e.a.a.a.a.f((String)"kicked by server, chid=", (String)var22_3, (String)" res= ");
                    var27_21.append(aq.b.a(var24_18));
                    var27_21.append(" type=");
                    var27_21.append(var25_19);
                    var27_21.append(" reason=");
                    var27_21.append(var26_20);
                    b.a((String)var27_21.toString());
                    if ("wait".equals((Object)var25_19)) {
                        var33_22 = aq.a().a(var22_3, var24_18);
                        if (var33_22 == null) return;
                        this.a.a(var33_22);
                        var33_22.a(aq.c.a, 3, 0, var26_20, var25_19);
                        return;
                    }
                    this.a.a(var22_3, var24_18, 3, var26_20, var25_19);
                    aq.a().a(var22_3, var24_18);
                    return;
                }
                if ("PING".equals((Object)var2_2)) {
                    var20_23 = var1_1.a();
                    if (var20_23 != null && var20_23.length > 0 && (var21_24 = eo.j.a((byte[])var20_23)).b()) {
                        bf.a().l(var21_24.a());
                    }
                    if (!"com.xiaomi.xmsf".equals((Object)this.a.getPackageName())) {
                        this.a.l();
                    }
                    if ("1".equals((Object)var1_1.e())) {
                        b.a((String)"received a server ping");
                    } else {
                        hk.b();
                    }
                    this.a.q();
                    return;
                }
                if ("SYNC".equals((Object)var2_2)) {
                    if ("CONF".equals((Object)var1_1.b())) {
                        var19_25 = eo.b.a((byte[])var1_1.a());
                        bf.a().l(var19_25);
                        return;
                    }
                    if (TextUtils.equals((CharSequence)"U", (CharSequence)var1_1.b())) {
                        var16_26 = eo.k.a((byte[])var1_1.a());
                        dl.a((Context)this.a).a(var16_26.a(), var16_26.b(), new Date(var16_26.a()), new Date(var16_26.b()), 1024 * var16_26.c(), var16_26.e());
                        var17_27 = new fp();
                        var17_27.a(0);
                        var17_27.a(var1_1.a(), "UCA");
                        var17_27.a(var1_1.e());
                        var18_28 = this.a;
                        var18_28.a((XMPushService.i)new bb(var18_28, var17_27));
                        return;
                    }
                    if (TextUtils.equals((CharSequence)"P", (CharSequence)var1_1.b()) == false) return;
                    var10_29 = eo.i.a((byte[])var1_1.a());
                    var11_30 = new fp();
                    var11_30.a(0);
                    var11_30.a(var1_1.a(), "PCA");
                    var11_30.a(var1_1.e());
                    var12_31 = new eo.i();
                    if (var10_29.a()) {
                        var12_31.a(var10_29.a());
                    }
                    var11_30.a(var12_31.a(), null);
                    var13_32 = this.a;
                    var13_32.a((XMPushService.i)new bb(var13_32, var11_30));
                    var4_4 = new StringBuilder();
                    var4_4.append("ACK msgP: id = ");
                    var7_5 = var1_1.e();
                } else {
                    if ("NOTIFY".equals((Object)var1_1.a()) == false) return;
                    var3_33 = eo.h.a((byte[])var1_1.a());
                    var4_4 = e.a.a.a.a.F1((String)"notify by server err = ");
                    var4_4.append(var3_33.c());
                    var4_4.append(" desc = ");
                    var7_5 = var3_33.a();
                }
            }
            var4_4.append(var7_5);
            var9_16 = var4_4.toString();
        }
        b.a((String)var9_16);
    }
}

