/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.content.ServiceConnection
 *  android.os.IBinder
 *  android.os.Message
 *  android.os.Messenger
 *  android.os.RemoteException
 *  com.xiaomi.channel.commonutils.logger.b
 *  java.lang.Object
 *  java.lang.Throwable
 *  java.util.Iterator
 */
package com.xiaomi.push.service;

import android.content.ComponentName;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import com.xiaomi.channel.commonutils.logger.b;
import com.xiaomi.push.service.bc;
import java.util.Iterator;

public class be
implements ServiceConnection {
    public final /* synthetic */ bc a;

    public be(bc bc2) {
        this.a = bc2;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
        bc bc2;
        bc bc3 = bc2 = this.a;
        synchronized (bc3) {
            bc.c(this.a, new Messenger(iBinder));
            bc.e(this.a, false);
            Iterator iterator = bc.d(this.a).iterator();
            do {
                if (!iterator.hasNext()) {
                    bc.d(this.a).clear();
                    return;
                }
                Message message = (Message)iterator.next();
                try {
                    bc.b(this.a).send(message);
                }
                catch (RemoteException remoteException) {
                    b.a((Throwable)remoteException);
                    continue;
                }
                break;
            } while (true);
        }
    }

    public void onServiceDisconnected(ComponentName componentName) {
        bc.c(this.a, null);
        bc.e(this.a, false);
    }
}

