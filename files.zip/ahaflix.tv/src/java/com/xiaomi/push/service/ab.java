/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.xiaomi.push.ai
 *  com.xiaomi.push.ai$a
 *  com.xiaomi.push.service.aj
 */
package com.xiaomi.push.service;

import com.xiaomi.push.ai;
import com.xiaomi.push.service.aj;

public final class ab
extends ai.a {
    public final /* synthetic */ int a;
    public final /* synthetic */ aj b;

    public ab(int n5, aj aj2) {
        this.a = n5;
        this.b = aj2;
    }

    public int a() {
        return this.a;
    }

    public void run() {
        this.b.e(this.a);
    }
}

