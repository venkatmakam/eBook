/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.content.pm.PackageInfo
 *  android.content.pm.PackageManager
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Handler
 *  android.os.Looper
 *  android.os.Message
 *  android.os.Messenger
 *  com.xiaomi.channel.commonutils.logger.b
 *  com.xiaomi.push.ab
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.List
 */
package com.xiaomi.push.service;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.Messenger;
import com.xiaomi.channel.commonutils.logger.b;
import com.xiaomi.push.ab;
import com.xiaomi.push.l;
import com.xiaomi.push.service.bd;
import java.util.ArrayList;
import java.util.List;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class bc {
    private static bc a;
    private static String a;
    private Context a;
    private Messenger a;
    private List<Message> a;
    private boolean a = new ArrayList();
    private Messenger b;
    private boolean b = false;

    private bc(Context context) {
        this.a = context.getApplicationContext();
        this.a = new Messenger((Handler)new bd(this, Looper.getMainLooper()));
        if (this.a()) {
            b.c((String)"use miui push service");
            this.a = true;
        }
    }

    private Message a(Intent intent) {
        Message message = Message.obtain();
        message.what = 17;
        message.obj = intent;
        return message;
    }

    public static bc a(Context context) {
        if (a == null) {
            a = new bc(context);
        }
        return a;
    }

    /*
     * Exception decompiling
     */
    private void a(Intent var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl74 : ALOAD : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    private boolean a() {
        PackageInfo packageInfo;
        block4 : {
            if (ab.e) {
                return false;
            }
            PackageManager packageManager = this.a.getPackageManager();
            try {
                packageInfo = packageManager.getPackageInfo("com.xiaomi.xmsf", 4);
                if (packageInfo != null) break block4;
                return false;
            }
            catch (Exception exception) {
                return false;
            }
        }
        int n4 = packageInfo.versionCode;
        return n4 >= 104;
    }

    public static /* synthetic */ Messenger b(bc bc2) {
        return bc2.b;
    }

    public static /* synthetic */ Messenger c(bc bc2, Messenger messenger) {
        bc2.b = messenger;
        return messenger;
    }

    public static /* synthetic */ List d(bc bc2) {
        return bc2.a;
    }

    public static /* synthetic */ boolean e(bc bc2, boolean bl2) {
        bc2.b = bl2;
        return bl2;
    }

    public boolean a(Intent intent) {
        try {
            if (!l.a() && Build.VERSION.SDK_INT >= 26) {
                this.a(intent);
            } else {
                this.a.startService(intent);
            }
            return true;
        }
        catch (Exception exception) {
            b.a((Throwable)exception);
            return false;
        }
    }
}

