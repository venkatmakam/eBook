/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.net.Uri
 *  android.net.Uri$Builder
 *  android.os.Build
 *  android.os.Build$VERSION
 *  com.xiaomi.channel.commonutils.logger.b
 *  com.xiaomi.push.bc
 *  com.xiaomi.push.cy
 *  com.xiaomi.push.db
 *  com.xiaomi.push.dc
 *  com.xiaomi.push.dc$a
 *  com.xiaomi.push.dc$b
 *  com.xiaomi.push.en
 *  com.xiaomi.push.en$a
 *  com.xiaomi.push.eo
 *  com.xiaomi.push.eo$b
 *  com.xiaomi.push.fl
 *  com.xiaomi.push.fw
 *  com.xiaomi.push.fx
 *  com.xiaomi.push.gy
 *  com.xiaomi.push.hi
 *  com.xiaomi.push.hk
 *  com.xiaomi.push.service.bf
 *  com.xiaomi.push.service.bf$a
 *  com.xiaomi.push.t
 *  e.a.a.a.a
 *  java.io.IOException
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.net.URL
 *  java.util.ArrayList
 *  java.util.Iterator
 */
package com.xiaomi.push.service;

import android.content.Context;
import android.net.Uri;
import android.os.Build;
import com.xiaomi.push.bc;
import com.xiaomi.push.cy;
import com.xiaomi.push.db;
import com.xiaomi.push.dc;
import com.xiaomi.push.en;
import com.xiaomi.push.eo;
import com.xiaomi.push.fl;
import com.xiaomi.push.fw;
import com.xiaomi.push.fx;
import com.xiaomi.push.gy;
import com.xiaomi.push.hi;
import com.xiaomi.push.hk;
import com.xiaomi.push.service.XMPushService;
import com.xiaomi.push.service.bf;
import com.xiaomi.push.t;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class av
extends bf.a
implements dc.a {
    private long a;
    private XMPushService a;

    public av(XMPushService xMPushService) {
        this.a = xMPushService;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static void a(XMPushService xMPushService) {
        av av2 = new av(xMPushService);
        bf.a().a((bf.a)av2);
        Class<dc> class_ = dc.class;
        synchronized (dc.class) {
            dc.a((dc.a)av2);
            dc.a((Context)xMPushService, null, (dc.b)new a(), (String)"0", (String)"push", (String)"2.2");
            // ** MonitorExit[var3_2] (shouldn't be in output)
            return;
        }
    }

    public dc a(Context context, db db2, dc.b b5, String string) {
        return new b(context, db2, b5, string);
    }

    public void a(en.a a3) {
    }

    public void a(eo.b b5) {
        if (b5.b() && b5.a() && System.currentTimeMillis() - this.a > 3600000L) {
            cy cy2;
            StringBuilder stringBuilder = e.a.a.a.a.F1((String)"fetch bucket :");
            stringBuilder.append(b5.a());
            com.xiaomi.channel.commonutils.logger.b.a((String)stringBuilder.toString());
            this.a = System.currentTimeMillis();
            dc dc2 = dc.a();
            dc2.a();
            dc2.b();
            fw fw2 = this.a.a();
            if (fw2 != null && (cy2 = dc2.b(fw2.a().c())) != null) {
                ArrayList arrayList = cy2.a();
                boolean bl = true;
                Iterator iterator = arrayList.iterator();
                while (iterator.hasNext()) {
                    if (!((String)iterator.next()).equals((Object)fw2.a())) continue;
                    bl = false;
                    break;
                }
                if (bl && !arrayList.isEmpty()) {
                    com.xiaomi.channel.commonutils.logger.b.a((String)"bucket changed, force reconnect");
                    this.a.a(0, null);
                    this.a.a(false);
                }
            }
        }
    }

    public static class a
    implements dc.b {
        public String a(String string) {
            Uri.Builder builder = Uri.parse((String)string).buildUpon();
            builder.appendQueryParameter("sdkver", String.valueOf((int)39));
            builder.appendQueryParameter("osver", String.valueOf((int)Build.VERSION.SDK_INT));
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(Build.MODEL);
            stringBuilder.append(":");
            stringBuilder.append(Build.VERSION.INCREMENTAL);
            builder.appendQueryParameter("os", gy.a((String)stringBuilder.toString()));
            builder.appendQueryParameter("mi", String.valueOf((int)t.a()));
            String string2 = builder.toString();
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append("fetch bucket from : ");
            stringBuilder2.append(string2);
            com.xiaomi.channel.commonutils.logger.b.c((String)stringBuilder2.toString());
            URL uRL = new URL(string2);
            int n5 = uRL.getPort() == -1 ? 80 : uRL.getPort();
            try {
                long l2 = System.currentTimeMillis();
                String string3 = bc.a((Context)t.a(), (URL)uRL);
                long l3 = System.currentTimeMillis() - l2;
                StringBuilder stringBuilder3 = new StringBuilder();
                stringBuilder3.append(uRL.getHost());
                stringBuilder3.append(":");
                stringBuilder3.append(n5);
                hk.a((String)stringBuilder3.toString(), (int)((int)l3), null);
                return string3;
            }
            catch (IOException iOException) {
                StringBuilder stringBuilder4 = new StringBuilder();
                stringBuilder4.append(uRL.getHost());
                stringBuilder4.append(":");
                stringBuilder4.append(n5);
                hk.a((String)stringBuilder4.toString(), (int)-1, (Exception)((Object)iOException));
                throw iOException;
            }
        }
    }

    public static class b
    extends dc {
        public b(Context context, db db2, dc.b b5, String string) {
            super(context, db2, b5, string, null, null);
        }

        public String a(ArrayList<String> arrayList, String string, String string2, boolean bl) {
            try {
                if (hi.a().a()) {
                    string2 = bf.a();
                }
                String string3 = super.a(arrayList, string, string2, bl);
                return string3;
            }
            catch (IOException iOException) {
                int n5 = bc.b((Context)dc.h);
                hk.a((int)0, (int)fl.r.a(), (int)1, null, (int)n5);
                throw iOException;
            }
        }
    }

}

