/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.content.pm.PackageManager
 *  android.text.TextUtils
 *  com.xiaomi.channel.commonutils.logger.b
 *  com.xiaomi.push.ff
 *  com.xiaomi.push.fp
 *  com.xiaomi.push.g
 *  com.xiaomi.push.gh
 *  com.xiaomi.push.gk
 *  com.xiaomi.push.gm
 *  com.xiaomi.push.gn
 *  com.xiaomi.push.id
 *  com.xiaomi.push.ig
 *  com.xiaomi.push.im
 *  com.xiaomi.push.service.q
 *  com.xiaomi.push.service.r
 *  com.xiaomi.push.service.s
 *  com.xiaomi.push.service.t
 *  com.xiaomi.push.service.u
 *  com.xiaomi.push.service.v
 *  e.a.a.a.a
 *  java.io.IOException
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.IllegalArgumentException
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Throwable
 *  java.util.HashMap
 *  java.util.List
 *  java.util.Map
 *  org.json.JSONException
 */
package com.xiaomi.push.service;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.text.TextUtils;
import com.xiaomi.channel.commonutils.logger.b;
import com.xiaomi.push.ff;
import com.xiaomi.push.fp;
import com.xiaomi.push.g;
import com.xiaomi.push.gh;
import com.xiaomi.push.gk;
import com.xiaomi.push.gm;
import com.xiaomi.push.gn;
import com.xiaomi.push.hb;
import com.xiaomi.push.hq;
import com.xiaomi.push.ia;
import com.xiaomi.push.id;
import com.xiaomi.push.ig;
import com.xiaomi.push.im;
import com.xiaomi.push.ip;
import com.xiaomi.push.ja;
import com.xiaomi.push.jj;
import com.xiaomi.push.service.XMPushService;
import com.xiaomi.push.service.aa;
import com.xiaomi.push.service.aq;
import com.xiaomi.push.service.az;
import com.xiaomi.push.service.k;
import com.xiaomi.push.service.l;
import com.xiaomi.push.service.m;
import com.xiaomi.push.service.q;
import com.xiaomi.push.service.r;
import com.xiaomi.push.service.s;
import com.xiaomi.push.service.u;
import com.xiaomi.push.service.v;
import com.xiaomi.push.service.w;
import com.xiaomi.push.t;
import e.a.a.a.a;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.json.JSONException;

public class p {
    public static Intent a(byte[] arrby, long l3) {
        im im2 = p.a(arrby);
        if (im2 == null) {
            return null;
        }
        Intent intent = new Intent("com.xiaomi.mipush.RECEIVE_MESSAGE");
        intent.putExtra("mipush_payload", arrby);
        intent.putExtra("mrt", Long.toString((long)l3));
        intent.setPackage(im2.b);
        return intent;
    }

    public static im a(Context context, im im2) {
        ig ig2 = new ig();
        ig2.b(im2.a());
        id id2 = im2.a();
        if (id2 != null) {
            ig2.a(id2.a());
            ig2.a(id2.a());
            if (!TextUtils.isEmpty((CharSequence)id2.b())) {
                ig2.c(id2.b());
            }
        }
        ig2.a(ja.a(context, im2));
        im im3 = w.c(im2.b(), im2.a(), ig2, hq.f);
        id id3 = im2.a().a();
        id3.a("mat", Long.toString((long)System.currentTimeMillis()));
        im3.a(id3);
        return im3;
    }

    public static im a(byte[] arrby) {
        im im2 = new im();
        try {
            ja.a(im2, arrby);
            return im2;
        }
        catch (Throwable throwable) {
            b.a((Throwable)throwable);
            return null;
        }
    }

    private static void a(XMPushService xMPushService, im im2) {
        xMPushService.a((XMPushService.i)new q(4, xMPushService, im2));
    }

    private static void a(XMPushService xMPushService, im im2, String string2) {
        xMPushService.a((XMPushService.i)new u(4, xMPushService, im2, string2));
    }

    private static void a(XMPushService xMPushService, im im2, String string2, String string3) {
        v v2 = new v(4, xMPushService, im2, string2, string3);
        xMPushService.a((XMPushService.i)v2);
    }

    /*
     * Exception decompiling
     */
    public static void a(XMPushService var0, String var1, byte[] var2, Intent var3) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl377 : ALOAD_0 : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    private static void a(XMPushService xMPushService, byte[] arrby, long l3) {
        Map map;
        im im2 = p.a(arrby);
        if (im2 == null) {
            return;
        }
        if (TextUtils.isEmpty((CharSequence)im2.b)) {
            b.a((String)"receive a mipush message without package name");
            return;
        }
        Long l4 = System.currentTimeMillis();
        Intent intent = p.a(arrby, l4);
        String string2 = aa.f(im2);
        hb.a((Context)xMPushService, string2, l3, true, true, System.currentTimeMillis());
        id id2 = im2.a();
        if (id2 != null) {
            id2.a("mrt", Long.toString((long)l4));
        }
        hq hq2 = hq.e;
        hq hq3 = im2.a();
        String string3 = "";
        if (hq2 == hq3 && m.a((Context)xMPushService).a(im2.b) && !aa.a(im2)) {
            if (id2 != null) {
                string3 = id2.a();
                if (aa.e(im2)) {
                    ff.a((Context)xMPushService.getApplicationContext()).a(im2.b(), aa.b(im2), string3, "1");
                }
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Drop a message for unregistered, msgid=");
            stringBuilder.append(string3);
            b.a((String)stringBuilder.toString());
            p.a(xMPushService, im2, im2.b);
            return;
        }
        if (hq2 == im2.a() && m.a((Context)xMPushService).c(im2.b) && !aa.a(im2)) {
            if (id2 != null) {
                string3 = id2.a();
                if (aa.e(im2)) {
                    ff.a((Context)xMPushService.getApplicationContext()).a(im2.b(), aa.b(im2), string3, "2");
                }
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Drop a message for push closed, msgid=");
            stringBuilder.append(string3);
            b.a((String)stringBuilder.toString());
            p.a(xMPushService, im2, im2.b);
            return;
        }
        if (hq2 == im2.a() && !TextUtils.equals((CharSequence)xMPushService.getPackageName(), (CharSequence)"com.xiaomi.xmsf") && !TextUtils.equals((CharSequence)xMPushService.getPackageName(), (CharSequence)im2.b)) {
            StringBuilder stringBuilder = a.F1((String)"Receive a message with wrong package name, expect ");
            stringBuilder.append(xMPushService.getPackageName());
            stringBuilder.append(", received ");
            stringBuilder.append(im2.b);
            b.a((String)stringBuilder.toString());
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append("package should be ");
            stringBuilder2.append(xMPushService.getPackageName());
            stringBuilder2.append(", but got ");
            stringBuilder2.append(im2.b);
            p.a(xMPushService, im2, "unmatched_package", stringBuilder2.toString());
            if (id2 != null && aa.e(im2)) {
                ff.a((Context)xMPushService.getApplicationContext()).a(im2.b(), aa.b(im2), id2.a(), "3");
            }
            return;
        }
        if (id2 != null && id2.a() != null) {
            Object[] arrobject = new Object[]{im2.a(), id2.a()};
            b.a((String)String.format((String)"receive a message, appid=%1$s, msgid= %2$s", (Object[])arrobject));
        }
        if (id2 != null && (map = id2.a()) != null && map.containsKey((Object)"hide") && "true".equalsIgnoreCase((String)map.get((Object)"hide"))) {
            p.b(xMPushService, im2);
            return;
        }
        if (id2 != null && id2.a() != null && id2.a().containsKey((Object)"__miid")) {
            String string4 = (String)id2.a().get((Object)"__miid");
            String string5 = t.a(xMPushService.getApplicationContext());
            if (TextUtils.isEmpty((CharSequence)string5) || !TextUtils.equals((CharSequence)string4, (CharSequence)string5)) {
                if (aa.e(im2)) {
                    ff.a((Context)xMPushService.getApplicationContext()).a(im2.b(), aa.b(im2), id2.a(), "4");
                }
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(string4);
                stringBuilder.append(" should be login, but got ");
                stringBuilder.append(string5);
                b.a((String)stringBuilder.toString());
                StringBuilder stringBuilder3 = new StringBuilder();
                stringBuilder3.append(string4);
                stringBuilder3.append(" should be login, but got ");
                stringBuilder3.append(string5);
                p.a(xMPushService, im2, "miid already logout or anther already login", stringBuilder3.toString());
                return;
            }
        }
        p.a(xMPushService, string2, arrby, intent);
    }

    private static boolean a(Context context, Intent intent) {
        boolean bl2;
        block3 : {
            List list;
            PackageManager packageManager = context.getPackageManager();
            bl2 = true;
            try {
                list = packageManager.queryBroadcastReceivers(intent, 32);
                if (list == null) break block3;
            }
            catch (Exception exception) {}
            boolean bl3 = list.isEmpty();
            if (bl3) break block3;
            return bl2;
        }
        bl2 = false;
        return bl2;
    }

    private static boolean a(Context context, String string2) {
        Intent intent = new Intent("com.xiaomi.mipush.miui.CLICK_MESSAGE");
        intent.setPackage(string2);
        Intent intent2 = new Intent("com.xiaomi.mipush.miui.RECEIVE_MESSAGE");
        intent2.setPackage(string2);
        PackageManager packageManager = context.getPackageManager();
        try {
            boolean bl2;
            block5 : {
                block4 : {
                    List list = packageManager.queryBroadcastReceivers(intent2, 32);
                    List list2 = packageManager.queryIntentServices(intent, 32);
                    if (!list.isEmpty()) break block4;
                    boolean bl3 = list2.isEmpty();
                    bl2 = false;
                    if (bl3) break block5;
                }
                bl2 = true;
            }
            return bl2;
        }
        catch (Exception exception) {
            b.a((Throwable)exception);
            return false;
        }
    }

    private static boolean a(im im2) {
        return "com.xiaomi.xmsf".equals((Object)im2.b) && im2.a() != null && im2.a().a() != null && im2.a().a().containsKey((Object)"miui_package_name");
    }

    private static boolean a(XMPushService xMPushService, String string2, im im2, id id2) {
        boolean bl2 = true;
        if (id2 != null && id2.a() != null && id2.a().containsKey((Object)"__check_alive") && id2.a().containsKey((Object)"__awake")) {
            ip ip2 = new ip();
            ip2.b(im2.a());
            ip2.d(string2);
            ip2.c(ia.G.a);
            ip2.a(id2.a());
            ip2.a = new HashMap();
            boolean bl3 = g.a((Context)xMPushService.getApplicationContext(), (String)string2);
            ip2.a.put((Object)"app_running", (Object)Boolean.toString((boolean)bl3));
            if (!bl3) {
                boolean bl4 = Boolean.parseBoolean((String)((String)id2.a().get((Object)"__awake")));
                ip2.a.put((Object)"awaked", (Object)Boolean.toString((boolean)bl4));
                if (!bl4) {
                    bl2 = false;
                }
            }
            im im3 = w.c(im2.b(), im2.a(), ip2, hq.i);
            try {
                w.f(xMPushService, im3);
                return bl2;
            }
            catch (gh gh2) {
                b.a((Throwable)gh2);
            }
        }
        return bl2;
    }

    private static void b(XMPushService xMPushService, im im2) {
        xMPushService.a((XMPushService.i)new r(4, xMPushService, im2));
    }

    private static boolean b(im im2) {
        Map map = im2.a().a();
        return map != null && map.containsKey((Object)"notify_effect");
    }

    private static void c(XMPushService xMPushService, im im2) {
        xMPushService.a((XMPushService.i)new s(4, xMPushService, im2));
    }

    private static boolean c(im im2) {
        if (im2.a() != null && im2.a().a() != null) {
            return "1".equals(im2.a().a().get((Object)"obslete_ads_message"));
        }
        return false;
    }

    private static void d(XMPushService xMPushService, im im2) {
        xMPushService.a((XMPushService.i)new com.xiaomi.push.service.t(4, xMPushService, im2));
    }

    public void a(Context context, aq.b b7, boolean bl2, int n4, String string2) {
        k k3;
        if (!bl2 && (k3 = l.a(context)) != null && "token-expired".equals((Object)string2)) {
            void var7_9;
            try {
                l.a(context, k3.f, k3.d, k3.e);
                return;
            }
            catch (JSONException jSONException) {
            }
            catch (IOException iOException) {
                // empty catch block
            }
            b.a((Throwable)var7_9);
        }
    }

    public void a(XMPushService xMPushService, fp fp2, aq.b b7) {
        try {
            p.a(xMPushService, fp2.a(b7.h), fp2.c());
            return;
        }
        catch (IllegalArgumentException illegalArgumentException) {
            b.a((Throwable)illegalArgumentException);
            return;
        }
    }

    public void a(XMPushService xMPushService, gn gn2, aq.b b7) {
        if (gn2 instanceof gm) {
            gm gm2 = (gm)gn2;
            gk gk2 = gm2.a("s");
            if (gk2 != null) {
                try {
                    p.a(xMPushService, az.a(az.a(b7.h, gm2.j()), gk2.c()), hb.a(gn2.a()));
                    return;
                }
                catch (IllegalArgumentException illegalArgumentException) {
                    b.a((Throwable)illegalArgumentException);
                    return;
                }
            }
        } else {
            b.a((String)"not a mipush message");
        }
    }
}

