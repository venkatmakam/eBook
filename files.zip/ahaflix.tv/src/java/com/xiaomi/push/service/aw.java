/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  com.xiaomi.channel.commonutils.logger.b
 *  com.xiaomi.push.ep
 *  com.xiaomi.push.eu
 *  com.xiaomi.push.ey
 *  com.xiaomi.push.ho
 *  com.xiaomi.push.hq
 *  com.xiaomi.push.ia
 *  com.xiaomi.push.ja
 *  com.xiaomi.push.jb
 *  com.xiaomi.push.jj
 *  com.xiaomi.push.service.ao
 *  com.xiaomi.push.service.w
 *  e.a.a.a.a
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.HashMap
 */
package com.xiaomi.push.service;

import android.content.Context;
import com.xiaomi.channel.commonutils.logger.b;
import com.xiaomi.push.ep;
import com.xiaomi.push.eu;
import com.xiaomi.push.ey;
import com.xiaomi.push.ho;
import com.xiaomi.push.hq;
import com.xiaomi.push.ia;
import com.xiaomi.push.ip;
import com.xiaomi.push.ja;
import com.xiaomi.push.jb;
import com.xiaomi.push.jj;
import com.xiaomi.push.service.XMPushService;
import com.xiaomi.push.service.ao;
import com.xiaomi.push.service.w;
import e.a.a.a.a;
import java.util.HashMap;

public class aw
implements ey {
    public void a(Context context, HashMap<String, String> hashMap) {
        ip ip2 = new ip();
        ip2.b(eu.a((Context)context).a());
        ip2.d(eu.a((Context)context).b());
        ip2.c(ia.H.a);
        ip2.a(ao.a());
        ip2.a = hashMap;
        byte[] arrby = ja.a((jb)w.c((String)ip2.c(), (String)ip2.b(), (jb)ip2, (hq)hq.i));
        if (context instanceof XMPushService) {
            StringBuilder stringBuilder = a.F1((String)"MoleInfo : send data directly in pushLayer ");
            stringBuilder.append(ip2.a());
            b.a((String)stringBuilder.toString());
            ((XMPushService)context).o(context.getPackageName(), arrby, true);
            return;
        }
        StringBuilder stringBuilder = a.F1((String)"MoleInfo : context is not correct in pushLayer ");
        stringBuilder.append(ip2.a());
        b.a((String)stringBuilder.toString());
    }

    public void b(Context context, HashMap<String, String> hashMap) {
        ho ho2 = ho.a((Context)context);
        if (ho2 != null) {
            ho2.a("category_awake_app", "wake_up_app", 1L, ep.a(hashMap));
        }
    }

    public void c(Context context, HashMap<String, String> hashMap) {
        StringBuilder stringBuilder = a.F1((String)"MoleInfo\uff1a\u3000");
        stringBuilder.append(ep.b(hashMap));
        b.a((String)stringBuilder.toString());
    }
}

