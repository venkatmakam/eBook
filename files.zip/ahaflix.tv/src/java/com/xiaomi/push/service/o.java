/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.util.Pair
 *  com.xiaomi.channel.commonutils.logger.b
 *  com.xiaomi.push.gh
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.Map
 *  java.util.Set
 */
package com.xiaomi.push.service;

import android.content.Context;
import android.content.Intent;
import android.util.Pair;
import com.xiaomi.channel.commonutils.logger.b;
import com.xiaomi.push.gh;
import com.xiaomi.push.service.XMPushService;
import com.xiaomi.push.service.w;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class o {
    private static ArrayList<Pair<String, byte[]>> a = new HashMap();
    private static final Map<String, byte[]> a;

    public static {
        a = new ArrayList();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static void a(Context context, int n4, String string2) {
        ArrayList<Pair<String, byte[]>> arrayList;
        ArrayList<Pair<String, byte[]>> arrayList2 = arrayList = a;
        synchronized (arrayList2) {
            Iterator iterator = arrayList.keySet().iterator();
            do {
                if (!iterator.hasNext()) {
                    a.clear();
                    return;
                }
                String string3 = (String)iterator.next();
                o.a(context, string3, (byte[])a.get((Object)string3), n4, string2);
            } while (true);
        }
    }

    public static void a(Context context, String string2, byte[] arrby, int n4, String string3) {
        Intent intent = new Intent("com.xiaomi.mipush.ERROR");
        intent.setPackage(string2);
        intent.putExtra("mipush_payload", arrby);
        intent.putExtra("mipush_error_code", n4);
        intent.putExtra("mipush_error_msg", string3);
        context.sendBroadcast(intent, w.d(string2));
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public static void a(XMPushService xMPushService) {
        ArrayList<Pair<String, byte[]>> arrayList;
        try {
            ArrayList<Pair<String, byte[]>> arrayList2 = arrayList = a;
            // MONITORENTER : arrayList2
        }
        catch (gh gh2) {
            b.a((Throwable)gh2);
            xMPushService.a(10, (Exception)((Object)gh2));
            return;
        }
        Iterator iterator = arrayList.keySet().iterator();
        do {
            if (!iterator.hasNext()) {
                a.clear();
                // MONITOREXIT : arrayList2
                return;
            }
            String string2 = (String)iterator.next();
            w.g(xMPushService, string2, (byte[])a.get((Object)string2));
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static void a(String string2, byte[] arrby) {
        ArrayList<Pair<String, byte[]>> arrayList;
        ArrayList<Pair<String, byte[]>> arrayList2 = arrayList = a;
        synchronized (arrayList2) {
            arrayList.put((Object)string2, (Object)arrby);
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public static void b(XMPushService xMPushService) {
        ArrayList<Pair<String, byte[]>> arrayList;
        ArrayList<Pair<String, byte[]>> arrayList2 = arrayList = a;
        // MONITORENTER : arrayList2
        ArrayList<Pair<String, byte[]>> arrayList3 = a;
        a = new ArrayList();
        // MONITOREXIT : arrayList2
        try {
            Iterator iterator = arrayList3.iterator();
            while (iterator.hasNext()) {
                Pair pair = (Pair)iterator.next();
                w.g(xMPushService, (String)pair.first, (byte[])pair.second);
            }
            return;
        }
        catch (gh gh2) {
            b.a((Throwable)gh2);
            xMPushService.a(10, (Exception)((Object)gh2));
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static void b(String string2, byte[] arrby) {
        ArrayList<Pair<String, byte[]>> arrayList;
        ArrayList<Pair<String, byte[]>> arrayList2 = arrayList = a;
        synchronized (arrayList2) {
            a.add((Object)new Pair((Object)string2, (Object)arrby));
            if (a.size() > 50) {
                a.remove(0);
            }
            return;
        }
    }
}

