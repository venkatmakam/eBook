/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.text.TextUtils
 *  com.xiaomi.channel.commonutils.logger.b
 *  java.io.Closeable
 *  java.io.File
 *  java.io.IOException
 *  java.io.RandomAccessFile
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.nio.channels.FileChannel
 *  java.nio.channels.FileLock
 */
package com.xiaomi.push.service;

import android.content.Context;
import android.text.TextUtils;
import com.xiaomi.channel.commonutils.logger.b;
import com.xiaomi.push.y;
import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class a {
    private static volatile a a;
    private Context a;
    private final Object a;
    private final String a = "mipush_region";
    private final Object b;
    private final String b = "mipush_country_code";
    private final String c = "mipush_region.lock";
    private final String d = "mipush_country_code.lock";
    private volatile String e;
    private volatile String f;

    public a(Context context) {
        this.a = context;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static a a(Context context) {
        if (a != null) return a;
        Class<a> class_ = a.class;
        synchronized (a.class) {
            if (a != null) return a;
            a = new a(context);
            // ** MonitorExit[var2_1] (shouldn't be in output)
            return a;
        }
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    private String a(Context context, String string2, String string3, Object object) {
        RandomAccessFile randomAccessFile;
        FileLock fileLock;
        void var13_20;
        boolean bl2;
        block24 : {
            FileLock fileLock2;
            boolean bl3;
            block23 : {
                boolean bl4;
                String string4;
                File file = new File(context.getFilesDir(), string2);
                if (!file.exists()) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("No ready file to get data from ");
                    stringBuilder.append(string2);
                    b.a((String)stringBuilder.toString());
                    return null;
                }
                Object object2 = object;
                // MONITORENTER : object2
                File file2 = new File(context.getFilesDir(), string3);
                y.a(file2);
                randomAccessFile = new RandomAccessFile(file2, "rw");
                fileLock2 = randomAccessFile.getChannel().lock();
                try {
                    string4 = y.a(file);
                }
                catch (Exception exception) {
                    break block23;
                }
                if (fileLock2 != null && (bl4 = fileLock2.isValid())) {
                    try {
                        fileLock2.release();
                    }
                    catch (IOException iOException) {
                        b.a((Throwable)iOException);
                    }
                }
                y.a((Closeable)randomAccessFile);
                // MONITOREXIT : object2
                return string4;
                catch (Throwable throwable) {
                    fileLock = null;
                    break block24;
                }
                catch (Exception exception) {
                    fileLock2 = null;
                    break block23;
                }
                catch (Throwable throwable) {
                    fileLock = null;
                    randomAccessFile = null;
                    break block24;
                }
                catch (Exception exception) {
                    randomAccessFile = null;
                    fileLock2 = null;
                }
            }
            try {
                void var10_17;
                b.a((Throwable)var10_17);
            }
            catch (Throwable throwable) {
                fileLock = fileLock2;
            }
            if (fileLock2 != null && (bl3 = fileLock2.isValid())) {
                try {
                    fileLock2.release();
                }
                catch (IOException iOException) {
                    b.a((Throwable)iOException);
                }
            }
            y.a(randomAccessFile);
            // MONITOREXIT : object2
            return null;
        }
        if (fileLock != null && (bl2 = fileLock.isValid())) {
            try {
                fileLock.release();
            }
            catch (IOException iOException) {
                b.a((Throwable)iOException);
            }
        }
        y.a(randomAccessFile);
        throw var13_20;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    private void a(Context var1_1, String var2_2, String var3_3, String var4_4, Object var5_5) {
        block21 : {
            var19_6 = var5_5;
            // MONITORENTER : var19_6
            var6_7 = null;
            var7_8 = new File(var1_1.getFilesDir(), var4_4);
            y.a(var7_8);
            var9_9 = new RandomAccessFile(var7_8, "rw");
            try {
                var6_7 = var9_9.getChannel().lock();
                y.a(new File(var1_1.getFilesDir(), var3_3), var2_2);
                ** if (var6_7 == null) goto lbl20
            }
            catch (Throwable var10_17) {}
lbl-1000: // 1 sources:
            {
                var17_10 = var6_7.isValid();
                if (var17_10) {
                    try {
                        var6_7.release();
                    }
                    catch (IOException var18_11) {
                        b.a((Throwable)var18_11);
                    }
                }
            }
lbl20: // 4 sources:
            ** GOTO lbl-1000
            {
                block20 : {
                    catch (Exception var8_12) {
                        break block20;
                    }
                    catch (Throwable var10_15) {
                        var6_7 = null;
                        var9_9 = null;
                        break block21;
                    }
                    catch (Exception var8_13) {
                        var9_9 = null;
                    }
                }
                b.a((Throwable)var8_14);
                if (var6_7 == null) ** break block22
                var14_18 = var6_7.isValid();
                if (!var14_18) ** break block22
                try {
                    var6_7.release();
                }
                catch (IOException var15_19) {
                    b.a((Throwable)var15_19);
                }
            }
            catch (Throwable var12_22) {
                throw var12_22;
            }
lbl-1000: // 6 sources:
            {
                
                y.a(var9_9);
                return;
            }
        }
        if (var6_7 != null && (var11_20 = var6_7.isValid())) {
            try {
                var6_7.release();
            }
            catch (IOException var13_21) {
                b.a((Throwable)var13_21);
            }
        }
        y.a(var9_9);
        throw var10_16;
    }

    public String a() {
        if (TextUtils.isEmpty((CharSequence)this.e)) {
            this.e = this.a(this.a, "mipush_region", "mipush_region.lock", this.a);
        }
        return this.e;
    }

    public void a(String string2) {
        if (!TextUtils.equals((CharSequence)string2, (CharSequence)this.e)) {
            this.e = string2;
            this.a(this.a, this.e, "mipush_region", "mipush_region.lock", this.a);
        }
    }

    public String b() {
        if (TextUtils.isEmpty((CharSequence)this.f)) {
            this.f = this.a(this.a, "mipush_country_code", "mipush_country_code.lock", this.b);
        }
        return this.f;
    }

    public void b(String string2) {
        if (!TextUtils.equals((CharSequence)string2, (CharSequence)this.f)) {
            this.f = string2;
            this.a(this.a, this.f, "mipush_country_code", "mipush_country_code.lock", this.b);
        }
    }
}

