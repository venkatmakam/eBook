/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.xiaomi.push.gj
 *  com.xiaomi.push.gn
 *  java.lang.Object
 */
package com.xiaomi.push.service;

import com.xiaomi.push.gj;
import com.xiaomi.push.gn;
import com.xiaomi.push.service.XMPushService;

public class bp
implements gj {
    public bp(XMPushService xMPushService) {
    }

    public boolean a(gn gn2) {
        return true;
    }
}

