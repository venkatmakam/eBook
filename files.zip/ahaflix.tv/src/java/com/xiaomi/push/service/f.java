/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.content.pm.PackageInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.content.pm.ProviderInfo
 *  android.content.pm.ServiceInfo
 *  com.xiaomi.channel.commonutils.logger.b
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.List
 */
package com.xiaomi.push.service;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ProviderInfo;
import android.content.pm.ServiceInfo;
import com.xiaomi.channel.commonutils.logger.b;
import java.util.List;

public class f {
    public static boolean a(Context context, String string2) {
        block5 : {
            ServiceInfo[] arrserviceInfo = context.getPackageManager().getPackageInfo((String)string2, (int)4).services;
            if (arrserviceInfo == null) break block5;
            int n4 = arrserviceInfo.length;
            for (int i6 = 0; i6 < n4; ++i6) {
                try {
                    boolean bl2;
                    ServiceInfo serviceInfo = arrserviceInfo[i6];
                    if (!serviceInfo.exported || !serviceInfo.enabled || !"com.xiaomi.mipush.sdk.PushMessageHandler".equals((Object)serviceInfo.name) || (bl2 = context.getPackageName().equals((Object)serviceInfo.packageName))) continue;
                    return true;
                }
                catch (PackageManager.NameNotFoundException nameNotFoundException) {
                    b.a((Throwable)nameNotFoundException);
                    break;
                }
            }
        }
        return false;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static boolean a(Context context, String string2, String string3) {
        PackageManager packageManager = context.getPackageManager();
        Intent intent = new Intent(string3);
        intent.setPackage(string2);
        List list = packageManager.queryIntentServices(intent, 32);
        if (list == null) return false;
        try {
            boolean bl2 = list.isEmpty();
            if (bl2) return false;
            return true;
        }
        catch (Exception exception) {
            b.a((Throwable)exception);
        }
        return false;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static boolean b(Context context, String string2) {
        boolean bl2 = false;
        List list = context.getPackageManager().queryContentProviders(null, 0, 8);
        bl2 = false;
        if (list == null) return bl2;
        boolean bl3 = list.isEmpty();
        bl2 = false;
        if (bl3) return bl2;
        try {
            for (ProviderInfo providerInfo : list) {
                boolean bl4;
                if (!providerInfo.enabled || !providerInfo.exported || !(bl4 = providerInfo.authority.equals((Object)string2))) continue;
                bl2 = true;
            }
            return bl2;
        }
        catch (Exception exception) {
            b.a((Throwable)exception);
        }
        return bl2;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static boolean b(Context context, String string2, String string3) {
        PackageManager packageManager = context.getPackageManager();
        Intent intent = new Intent(string3);
        intent.setPackage(string2);
        List list = packageManager.queryIntentActivities(intent, 32);
        if (list == null) return false;
        try {
            boolean bl2 = list.isEmpty();
            if (bl2) return false;
            return true;
        }
        catch (Exception exception) {
            b.a((Throwable)exception);
        }
        return false;
    }
}

