/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.app.Notification
 *  android.app.NotificationChannel
 *  android.app.NotificationManager
 *  android.content.Context
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.service.notification.StatusBarNotification
 *  android.util.Log
 *  com.xiaomi.channel.commonutils.logger.b
 *  com.xiaomi.push.bd
 *  e.a.a.a.a
 *  java.lang.Boolean
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.reflect.Constructor
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.Iterator
 *  java.util.List
 *  java.util.WeakHashMap
 */
package com.xiaomi.push.service;

import android.annotation.TargetApi;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.service.notification.StatusBarNotification;
import android.util.Log;
import com.xiaomi.channel.commonutils.logger.b;
import com.xiaomi.push.bd;
import com.xiaomi.push.hv;
import com.xiaomi.push.i;
import com.xiaomi.push.l;
import com.xiaomi.push.service.ak;
import com.xiaomi.push.service.al;
import e.a.a.a.a;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.WeakHashMap;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class aj {
    private static Context a;
    private static Object a;
    private static WeakHashMap<Integer, aj> a;
    private static final boolean a;
    private static boolean b;
    private String a;

    public static {
        a = Log.isLoggable((String)"NMHelper", (int)3);
        a = new WeakHashMap();
    }

    private aj(String string2) {
        this.a = string2;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("create ");
        stringBuilder.append((Object)this);
        this.i(stringBuilder.toString());
    }

    /*
     * Exception decompiling
     */
    private static int a(String var0) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl12.1 : ICONST_M1 : trying to set 0 previously set to 1
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    private static NotificationManager a() {
        return (NotificationManager)a.getSystemService("notification");
    }

    public static aj a(Context context, String string2) {
        aj.a(context);
        int n4 = string2.hashCode();
        aj aj2 = (aj)a.get((Object)n4);
        if (aj2 == null) {
            aj2 = new aj(string2);
            a.put((Object)n4, (Object)aj2);
        }
        return aj2;
    }

    /*
     * Exception decompiling
     */
    private static <T> T a(Object var0) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl16.1 : ACONST_NULL : trying to set 0 previously set to 1
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    private static Object a(List list) {
        return Class.forName((String)"android.content.pm.ParceledListSlice").getConstructor(new Class[]{List.class}).newInstance(new Object[]{list});
    }

    private static void a(Context context) {
        if (a == null) {
            a = context.getApplicationContext();
            NotificationManager notificationManager = aj.a();
            Boolean bl2 = (Boolean)bd.a((Object)notificationManager, (String)"isSystemConditionProviderEnabled", (Object[])new Object[]{"xmsf_fake_condition_provider_path"});
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("fwk is support.init:");
            stringBuilder.append((Object)bl2);
            aj.j(stringBuilder.toString());
            boolean bl3 = bl2 != null ? bl2 : false;
            b = bl3;
            if (bl3) {
                a = bd.a((Object)notificationManager, (String)"getService", (Object[])new Object[0]);
            }
        }
    }

    @TargetApi(value=26)
    private static boolean a() {
        if (!l.a()) {
            return false;
        }
        if (!al.a(a).a(hv.aZ.a(), true)) {
            return false;
        }
        return b;
    }

    public static boolean a(Context context) {
        aj.a(context);
        return aj.a();
    }

    public static void j(String string2) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("NMHelper:");
        stringBuilder.append(string2);
        b.a((String)stringBuilder.toString());
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @TargetApi(value=26)
    public NotificationChannel a(String string2) {
        NotificationChannel notificationChannel;
        void var3_11;
        block7 : {
            block6 : {
                boolean bl2;
                NotificationChannel notificationChannel2;
                notificationChannel = null;
                if (!aj.a()) break block6;
                List<NotificationChannel> list = this.d();
                notificationChannel = null;
                if (list == null) return notificationChannel;
                Iterator iterator = list.iterator();
                do {
                    boolean bl3 = iterator.hasNext();
                    notificationChannel = null;
                    if (!bl3) return notificationChannel;
                } while (!(bl2 = string2.equals((Object)(notificationChannel2 = (NotificationChannel)iterator.next()).getId())));
                try {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("getNotificationChannel succ:");
                    stringBuilder.append(string2);
                    this.i(stringBuilder.toString());
                    return notificationChannel2;
                }
                catch (Exception exception) {
                    notificationChannel = notificationChannel2;
                }
                break block7;
            }
            try {
                return aj.a().getNotificationChannel(string2);
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("getNotificationChannel error");
        stringBuilder.append((Object)var3_11);
        aj.j(stringBuilder.toString());
        return notificationChannel;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void a(int n4, Notification notification) {
        String string2 = this.a;
        NotificationManager notificationManager = aj.a();
        try {
            int n5 = Build.VERSION.SDK_INT;
            if (aj.a()) {
                notification.extras.putString("xmsf_target_package", string2);
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("notify succ:");
                stringBuilder.append(n4);
                this.i(stringBuilder.toString());
                if (n5 >= 29) {
                    notificationManager.notifyAsPackage(string2, null, n4, notification);
                    return;
                }
            }
            notificationManager.notify(n4, notification);
            return;
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("notify error");
            stringBuilder.append((Object)exception);
            this.i(stringBuilder.toString());
            return;
        }
    }

    public String b(String string2) {
        String string3;
        if (aj.a()) {
            this.i("get cid new format");
            string3 = "mipush|%s|%s";
        } else {
            this.i("get cid old format");
            string3 = "mipush_%s_%s";
        }
        Object[] arrobject = new Object[]{this.a, string2};
        return String.format((String)string3, (Object[])arrobject);
    }

    public String c(String string2, String string3) {
        if (!aj.a()) {
            string2 = string3;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("group summary cid is ");
        stringBuilder.append(string2);
        this.i(stringBuilder.toString());
        return string2;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @TargetApi(value=26)
    public List<NotificationChannel> d() {
        block9 : {
            block10 : {
                block8 : {
                    block6 : {
                        block7 : {
                            var1_1 = this.a;
                            var2_2 = null;
                            var7_3 = aj.a();
                            var2_2 = null;
                            if (!var7_3) break block6;
                            var8_4 = aj.a(var1_1);
                            var2_2 = null;
                            if (var8_4 == -1) break block7;
                            var9_5 = aj.a;
                            var10_6 = new Object[]{var1_1, var8_4, Boolean.FALSE};
                            var11_7 = (List)aj.a(bd.a((Object)var9_5, (String)"getNotificationChannelsForPackage", (Object[])var10_6));
                            try {
                                var12_8 = new StringBuilder();
                                var12_8.append("getNotificationChannels succ:");
                                var12_8.append((Object)var11_7);
                                this.i(var12_8.toString());
                                var15_9 = "mipush|%s|%s";
                                var2_2 = var11_7;
                                ** GOTO lbl32
                            }
                            catch (Exception var3_10) {
                                var2_2 = var11_7;
                                break block8;
                            }
                        }
                        var2_2 = null;
                        var15_9 = null;
                        ** GOTO lbl32
                    }
                    try {
                        var2_2 = aj.a().getNotificationChannels();
                        var15_9 = "mipush_%s_%s";
lbl32: // 3 sources:
                        var16_13 = new StringBuilder();
                        var16_13.append("getNotificationChannels filter before:");
                        var16_13.append((Object)var2_2);
                        this.i(var16_13.toString());
                        if (!l.a() || var2_2 == null) break block9;
                        var19_14 = new ArrayList();
                        var20_15 = String.format((String)var15_9, (Object[])new Object[]{var1_1, ""});
                        for (NotificationChannel var25_17 : var2_2) {
                            if (!var25_17.getId().startsWith(var20_15)) continue;
                            var19_14.add((Object)var25_17);
                        }
                        break block10;
                    }
                    catch (Exception var3_11) {
                        // empty catch block
                    }
                }
                var4_19 = new StringBuilder();
                var4_19.append("getNotificationChannels error ");
                var4_19.append((Object)var3_12);
                aj.j(var4_19.toString());
                return var2_2;
            }
            var2_2 = var19_14;
        }
        var22_18 = new StringBuilder();
        var22_18.append("getNotificationChannels filter after:");
        var22_18.append((Object)var2_2);
        this.i(var22_18.toString());
        return var2_2;
    }

    public void e(int n4) {
        String string2 = this.a;
        try {
            if (aj.a()) {
                Object object = a;
                Object[] arrobject = new Object[]{string2, null, n4};
                bd.b((Object)object, (String)"cancelNotificationWithTag", (Object[])arrobject);
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("cancel succ:");
                stringBuilder.append(n4);
                this.i(stringBuilder.toString());
                return;
            }
            aj.a().cancel(n4);
            return;
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("cancel error");
            stringBuilder.append((Object)exception);
            this.i(stringBuilder.toString());
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @TargetApi(value=26)
    public void f(NotificationChannel notificationChannel) {
        String string2 = this.a;
        try {
            if (aj.a()) {
                int n4 = aj.a(string2);
                if (n4 == -1) return;
                Object object = aj.a(Arrays.asList((Object[])new NotificationChannel[]{notificationChannel}));
                Object object2 = a;
                Object[] arrobject = new Object[]{string2, n4, object};
                bd.b((Object)object2, (String)"createNotificationChannelsForPackage", (Object[])arrobject);
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("createNotificationChannel succ:");
                stringBuilder.append((Object)notificationChannel);
                this.i(stringBuilder.toString());
                return;
            }
            aj.a().createNotificationChannel(notificationChannel);
            return;
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("createNotificationChannel error");
            stringBuilder.append((Object)exception);
            aj.j(stringBuilder.toString());
        }
    }

    @TargetApi(value=26)
    public void g(String string2) {
        aj.a().deleteNotificationChannel(string2);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("deleteNotificationChannel succ ");
        stringBuilder.append(string2);
        this.i(stringBuilder.toString());
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @TargetApi(value=23)
    public List<StatusBarNotification> h() {
        block12 : {
            block10 : {
                block11 : {
                    var1_1 = this.a;
                    var2_2 = aj.a();
                    var3_3 = null;
                    var8_4 = aj.a();
                    var3_3 = null;
                    if (var8_4) {
                        var10_6 = i.a();
                        var3_3 = null;
                        if (var10_6 != -1) {
                            var11_7 = aj.a;
                            var12_8 = new Object[]{var1_1, var10_6};
                            var3_3 = (List)aj.a(bd.a((Object)var11_7, (String)"getAppActiveNotifications", (Object[])var12_8));
                        }
                        var13_9 = new StringBuilder();
                        var13_9.append("getActiveNotifications succ:");
                        var13_9.append(var10_6);
                        var13_9.append(":");
                        var13_9.append(var3_3);
                        var18_10 = var13_9.toString();
                    } else {
                        var19_11 = var2_2.getActiveNotifications();
                        var20_12 = new StringBuilder();
                        var20_12.append("getActiveNotifications filter before:");
                        var20_12.append(Arrays.toString((Object[])var19_11));
                        this.i(var20_12.toString());
                        var23_13 = l.a();
                        var3_3 = null;
                        if (var19_11 == null) break block10;
                        var24_14 = var19_11.length;
                        var3_3 = null;
                        if (var24_14 <= 0) break block10;
                        var25_15 = new ArrayList();
                        try {
                            var26_16 = var19_11.length;
                            break block11;
                        }
                        catch (Exception var4_18) {
                            var3_3 = var25_15;
                            break block12;
                        }
                    }
lbl39: // 2 sources:
                    do {
                        this.i(var18_10);
                        return var3_3;
                        break;
                    } while (true);
                }
                for (var9_5 = 0; var9_5 < var26_16; ++var9_5) {
                    var27_17 = var19_11[var9_5];
                    if (var23_13 && !var1_1.equals((Object)ak.a(var27_17.getNotification()))) continue;
                    var25_15.add(var27_17);
                }
                var3_3 = var25_15;
            }
            try {
                var29_21 = new StringBuilder();
                var29_21.append("getActiveNotifications filter after:");
                var29_21.append((Object)var3_3);
                var18_10 = var29_21.toString();
                ** continue;
            }
            catch (Exception var4_19) {
                // empty catch block
            }
        }
        var5_22 = new StringBuilder();
        var5_22.append("getActiveNotifications error ");
        var5_22.append((Object)var4_20);
        aj.j(var5_22.toString());
        return var3_3;
    }

    public void i(String string2) {
        if (a) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(this.a);
            stringBuilder.append("-->");
            stringBuilder.append(string2);
            aj.j(stringBuilder.toString());
        }
    }

    public String toString() {
        return a.r1((StringBuilder)a.F1((String)"NotificationManagerHelper{"), (String)this.a, (String)"}");
    }
}

