/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  com.xiaomi.push.ai
 *  com.xiaomi.push.r
 *  com.xiaomi.push.service.af
 *  com.xiaomi.push.service.bh$a
 *  com.xiaomi.push.service.bi
 *  java.lang.Class
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.util.concurrent.ConcurrentHashMap
 */
package com.xiaomi.push.service;

import android.content.Context;
import android.content.SharedPreferences;
import com.xiaomi.push.ai;
import com.xiaomi.push.r;
import com.xiaomi.push.service.af;
import com.xiaomi.push.service.bh;
import com.xiaomi.push.service.bi;
import java.util.concurrent.ConcurrentHashMap;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class bh
implements af {
    private static volatile bh a;
    private long a;
    private SharedPreferences a;
    private ConcurrentHashMap<String, a> a;
    private volatile boolean a = new ConcurrentHashMap();
    public Context b;

    private bh(Context context) {
        this.b = context.getApplicationContext();
        this.a = context.getSharedPreferences("sync", 0);
    }

    public static /* synthetic */ SharedPreferences a(bh bh2) {
        return bh2.a;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static bh a(Context context) {
        if (a != null) return a;
        Class<bh> class_ = bh.class;
        synchronized (bh.class) {
            if (a != null) return a;
            a = new bh(context);
            // ** MonitorExit[var2_1] (shouldn't be in output)
            return a;
        }
    }

    public static /* synthetic */ bh b() {
        return a;
    }

    public static /* synthetic */ ConcurrentHashMap c(bh bh2) {
        return bh2.a;
    }

    public static /* synthetic */ boolean d(bh bh2, boolean bl) {
        bh2.a = bl;
        return bl;
    }

    public String a(String string, String string2) {
        SharedPreferences sharedPreferences = this.a;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(string);
        stringBuilder.append(":");
        stringBuilder.append(string2);
        return sharedPreferences.getString(stringBuilder.toString(), "");
    }

    public void a() {
        if (this.a) {
            return;
        }
        long l2 = System.currentTimeMillis();
        if (l2 - this.a < 3600000L) {
            return;
        }
        this.a = l2;
        this.a = true;
        int n5 = (int)(10.0 * Math.random());
        ai.a((Context)this.b).a((Runnable)new bi(this), n5);
    }

    public void a(a a3) {
        if (this.a.putIfAbsent((Object)a3.a, (Object)a3) == null) {
            int n5 = 10 + (int)(30.0 * Math.random());
            ai.a((Context)this.b).a((Runnable)a3, n5);
        }
    }

    public void a(String string, String string2, String string3) {
        SharedPreferences.Editor editor = bh.a.a.edit();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(string);
        stringBuilder.append(":");
        stringBuilder.append(string2);
        r.a((SharedPreferences.Editor)editor.putString(stringBuilder.toString(), string3));
    }
}

