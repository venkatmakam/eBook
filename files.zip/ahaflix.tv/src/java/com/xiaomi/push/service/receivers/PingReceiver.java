/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 *  android.text.TextUtils
 *  com.xiaomi.channel.commonutils.logger.b
 *  com.xiaomi.push.fg
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Throwable
 */
package com.xiaomi.push.service.receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;
import com.xiaomi.channel.commonutils.logger.b;
import com.xiaomi.push.fg;
import com.xiaomi.push.service.XMPushService;
import com.xiaomi.push.service.au;
import com.xiaomi.push.service.bc;

public class PingReceiver
extends BroadcastReceiver {
    public void onReceive(Context context, Intent intent) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(intent.getPackage());
        stringBuilder.append(" is the package name");
        b.c((String)stringBuilder.toString());
        if (au.o.equals((Object)intent.getAction())) {
            if (TextUtils.equals((CharSequence)context.getPackageName(), (CharSequence)intent.getPackage())) {
                b.c((String)"Ping XMChannelService on timer");
                try {
                    Intent intent2 = new Intent(context, XMPushService.class);
                    intent2.putExtra("time_stamp", System.currentTimeMillis());
                    intent2.setAction("com.xiaomi.push.timer");
                    bc.a(context).a(intent2);
                    return;
                }
                catch (Exception exception) {
                    b.a((Throwable)exception);
                    return;
                }
            }
        } else {
            b.a((String)"cancel the old ping timer");
            fg.a();
        }
    }
}

