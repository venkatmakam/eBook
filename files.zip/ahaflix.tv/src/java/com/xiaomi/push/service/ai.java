/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.content.res.Resources
 *  android.graphics.Bitmap
 *  android.graphics.BitmapFactory
 *  android.graphics.BitmapFactory$Options
 *  android.net.Uri
 *  android.util.DisplayMetrics
 *  com.xiaomi.channel.commonutils.logger.b
 *  com.xiaomi.push.bi
 *  e.a.a.a.a
 *  java.io.BufferedOutputStream
 *  java.io.ByteArrayInputStream
 *  java.io.Closeable
 *  java.io.File
 *  java.io.FileInputStream
 *  java.io.FileOutputStream
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.OutputStream
 *  java.lang.Exception
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Throwable
 */
package com.xiaomi.push.service;

import android.content.ContentResolver;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.util.DisplayMetrics;
import com.xiaomi.push.bi;
import com.xiaomi.push.x;
import com.xiaomi.push.y;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class ai {
    private static long a;

    private static int a(Context context, InputStream inputStream) {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeStream((InputStream)inputStream, null, (BitmapFactory.Options)options);
        if (options.outWidth != -1 && options.outHeight != -1) {
            int n4;
            int n5 = options.outWidth;
            int n6 = Math.round((float)(48.0f * ((float)context.getResources().getDisplayMetrics().densityDpi / 160.0f)));
            if (n5 > n6 && (n4 = options.outHeight) > n6) {
                return Math.min((int)(n5 / n6), (int)(n4 / n6));
            }
            return 1;
        }
        com.xiaomi.channel.commonutils.logger.b.a((String)"decode dimension failed for bitmap.");
        return 1;
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static Bitmap a(Context context, String string2) {
        InputStream inputStream;
        void var6_15;
        InputStream inputStream2;
        block11 : {
            InputStream inputStream3;
            block10 : {
                Bitmap bitmap;
                Uri uri = Uri.parse((String)string2);
                inputStream = context.getContentResolver().openInputStream(uri);
                int n4 = ai.a(context, inputStream);
                inputStream3 = context.getContentResolver().openInputStream(uri);
                try {
                    BitmapFactory.Options options = new BitmapFactory.Options();
                    options.inSampleSize = n4;
                    bitmap = BitmapFactory.decodeStream((InputStream)inputStream3, null, (BitmapFactory.Options)options);
                }
                catch (IOException iOException) {
                    break block10;
                }
                y.a((Closeable)inputStream3);
                y.a((Closeable)inputStream);
                return bitmap;
                catch (Throwable throwable) {
                    inputStream2 = null;
                    break block11;
                }
                catch (IOException iOException) {
                    inputStream3 = null;
                    break block10;
                }
                catch (Throwable throwable) {
                    inputStream2 = null;
                    inputStream = null;
                    break block11;
                }
                catch (IOException iOException) {
                    inputStream3 = null;
                    inputStream = null;
                }
            }
            try {
                void var3_11;
                com.xiaomi.channel.commonutils.logger.b.a((Throwable)var3_11);
            }
            catch (Throwable throwable) {
                inputStream2 = inputStream3;
            }
            y.a(inputStream3);
            y.a((Closeable)inputStream);
            return null;
        }
        y.a(inputStream2);
        y.a((Closeable)inputStream);
        throw var6_15;
    }

    /*
     * Exception decompiling
     */
    private static a a(String var0, boolean var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl199 : NEW : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static b a(Context var0, String var1_1, boolean var2_2) {
        block14 : {
            block13 : {
                block12 : {
                    block11 : {
                        var3_3 = null;
                        var4_4 = new b(null, 0L);
                        var5_5 = ai.b(var0, var1_1);
                        if (var5_5 != null) {
                            var4_4.a = var5_5;
                            return var4_4;
                        }
                        var8_6 = ai.a(var1_1, var2_2);
                        if (var8_6 != null) break block11;
                        y.a(null);
                        return var4_4;
                    }
                    var4_4.a = var8_6.b;
                    var9_7 = var8_6.a;
                    var3_3 = null;
                    if (var9_7 == null) ** GOTO lbl35
                    var3_3 = null;
                    if (!var2_2) break block12;
                    var10_8 = new ByteArrayInputStream(var9_7);
                    try {
                        var11_9 = ai.a(var0, (InputStream)var10_8);
                        var12_10 = new BitmapFactory.Options();
                        var12_10.inSampleSize = var11_9;
                        var4_4.a = BitmapFactory.decodeByteArray((byte[])var9_7, (int)0, (int)var9_7.length, (BitmapFactory.Options)var12_10);
                        return var4_4.a;
                    }
                    catch (Exception var6_14) {}
                    finally {
                        var3_3 = var10_8;
                        ** GOTO lbl35
                    }
                }
                try {
                    var4_4.a = BitmapFactory.decodeByteArray((byte[])var9_7, (int)0, (int)var9_7.length);
lbl35: // 3 sources:
                    ai.a(var0, var8_6.a, var1_1);
                    break block13;
                }
                catch (Throwable var7_12) {
                    break block14;
                }
                catch (Exception var6_15) {
                    // empty catch block
                }
                com.xiaomi.channel.commonutils.logger.b.a((Throwable)var6_16);
            }
            y.a(var3_3);
            return var4_4;
        }
        y.a(var3_3);
        throw var7_13;
    }

    private static void a(Context context) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(context.getCacheDir().getPath());
        File file = new File(e.a.a.a.a.r1((StringBuilder)stringBuilder, (String)File.separator, (String)"mipush_icon"));
        if (!file.exists()) {
            return;
        }
        if (a == 0L) {
            a = x.a(file);
        }
        if (a > 0xF00000L) {
            block7 : {
                int n4;
                File[] arrfile;
                try {
                    arrfile = file.listFiles();
                    n4 = 0;
                }
                catch (Exception exception) {
                    com.xiaomi.channel.commonutils.logger.b.a((Throwable)exception);
                }
                do {
                    block8 : {
                        if (n4 >= arrfile.length) break block7;
                        if (arrfile[n4].isDirectory() || Math.abs((long)(System.currentTimeMillis() - arrfile[n4].lastModified())) <= 1209600L) break block8;
                        arrfile[n4].delete();
                    }
                    ++n4;
                } while (true);
            }
            a = 0L;
        }
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private static void a(Context context, byte[] arrby, String string2) {
        void var10_12;
        FileOutputStream fileOutputStream;
        BufferedOutputStream bufferedOutputStream;
        block13 : {
            File file;
            block15 : {
                BufferedOutputStream bufferedOutputStream2;
                block14 : {
                    if (arrby == null) {
                        com.xiaomi.channel.commonutils.logger.b.a((String)"cannot save small icon cause bitmap is null");
                        return;
                    }
                    ai.a(context);
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(context.getCacheDir().getPath());
                    File file2 = new File(e.a.a.a.a.r1((StringBuilder)stringBuilder, (String)File.separator, (String)"mipush_icon"));
                    if (!file2.exists()) {
                        file2.mkdirs();
                    }
                    file = new File(file2, bi.a((String)string2));
                    bufferedOutputStream2 = null;
                    if (!file.exists()) {
                        file.createNewFile();
                    }
                    fileOutputStream = new FileOutputStream(file);
                    BufferedOutputStream bufferedOutputStream3 = new BufferedOutputStream((OutputStream)fileOutputStream);
                    try {
                        bufferedOutputStream3.write(arrby);
                        bufferedOutputStream3.flush();
                    }
                    catch (Throwable throwable) {
                        bufferedOutputStream = bufferedOutputStream3;
                        break block13;
                    }
                    catch (Exception exception) {
                        bufferedOutputStream2 = bufferedOutputStream3;
                        break block14;
                    }
                    y.a((Closeable)bufferedOutputStream3);
                    break block15;
                    catch (Exception exception) {
                        bufferedOutputStream2 = null;
                        break block14;
                    }
                    catch (Throwable throwable) {
                        fileOutputStream = null;
                        bufferedOutputStream = null;
                        break block13;
                    }
                    catch (Exception exception) {
                        fileOutputStream = null;
                    }
                }
                try {
                    void var8_17;
                    com.xiaomi.channel.commonutils.logger.b.a((Throwable)var8_17);
                }
                catch (Throwable throwable) {
                    BufferedOutputStream bufferedOutputStream4;
                    bufferedOutputStream = bufferedOutputStream4 = bufferedOutputStream2;
                }
                y.a(bufferedOutputStream2);
            }
            y.a((Closeable)fileOutputStream);
            if (a != 0L) return;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(context.getCacheDir().getPath());
            a = x.a(new File(e.a.a.a.a.r1((StringBuilder)stringBuilder, (String)File.separator, (String)"mipush_icon"))) + file.length();
            return;
        }
        y.a(bufferedOutputStream);
        y.a((Closeable)fileOutputStream);
        throw var10_12;
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private static Bitmap b(Context var0, String var1_1) {
        block8 : {
            var2_2 = new StringBuilder();
            var2_2.append(var0.getCacheDir().getPath());
            var4_3 = new File(e.a.a.a.a.r1((StringBuilder)var2_2, (String)File.separator, (String)"mipush_icon"), bi.a((String)var1_1));
            var5_4 = var4_3.exists();
            var6_5 = null;
            if (!var5_4) {
                return null;
            }
            var7_6 = new FileInputStream(var4_3);
            try {
                var6_5 = BitmapFactory.decodeStream((InputStream)var7_6);
                var4_3.setLastModified(System.currentTimeMillis());
            }
            catch (Throwable var13_7) {
                break block8;
            }
            catch (Exception var8_9) {
                var9_11 = var6_5;
                var6_5 = var7_6;
                var10_12 = var9_11;
                ** GOTO lbl-1000
            }
            y.a((Closeable)var7_6);
            return var6_5;
            catch (Throwable var11_13) {
                var12_14 = var6_5;
                var13_8 = var11_13;
                var7_6 = var12_14;
                break block8;
            }
            catch (Exception var15_15) {
                var8_10 = var15_15;
                var10_12 = null;
            }
lbl-1000: // 2 sources:
            {
                com.xiaomi.channel.commonutils.logger.b.a((Throwable)var8_10);
            }
            y.a((Closeable)var6_5);
            return var10_12;
        }
        y.a((Closeable)var7_6);
        throw var13_8;
    }

    public static class a {
        public byte[] a;
        public int b;

        public a(byte[] arrby, int n4) {
            this.a = arrby;
            this.b = n4;
        }
    }

    /*
     * Duplicate member names - consider using --renamedupmembers true
     */
    public static class b {
        public long a;
        public Bitmap a;

        public b(Bitmap bitmap, long l3) {
            this.a = bitmap;
            this.a = l3;
        }
    }

}

