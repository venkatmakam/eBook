/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  java.lang.Object
 */
package com.xiaomi.push;

import android.content.SharedPreferences;

public final class r {
    public static void a(SharedPreferences.Editor editor) {
        editor.apply();
    }
}

