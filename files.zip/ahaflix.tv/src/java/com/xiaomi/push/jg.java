/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.String
 *  java.lang.Throwable
 */
package com.xiaomi.push;

public class jg
extends Exception {
    public jg() {
    }

    public jg(String string2) {
        super(string2);
    }

    public jg(Throwable throwable) {
        super(throwable);
    }
}

