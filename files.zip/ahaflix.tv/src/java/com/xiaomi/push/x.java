/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.xiaomi.channel.commonutils.logger.b
 *  java.io.File
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.HashMap
 */
package com.xiaomi.push;

import com.xiaomi.channel.commonutils.logger.b;
import java.io.File;
import java.util.HashMap;

public class x {
    private static final HashMap<String, String> a;

    public static {
        HashMap hashMap;
        a = hashMap = new HashMap();
        hashMap.put((Object)"FFD8FF", (Object)"jpg");
        hashMap.put((Object)"89504E47", (Object)"png");
        hashMap.put((Object)"47494638", (Object)"gif");
        hashMap.put((Object)"474946", (Object)"gif");
        hashMap.put((Object)"424D", (Object)"bmp");
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static long a(File file) {
        File[] arrfile;
        int n4;
        long l3 = 0L;
        try {
            arrfile = file.listFiles();
            n4 = 0;
        }
        catch (Exception exception) {
            b.a((Throwable)exception);
        }
        do {
            if (n4 >= arrfile.length) return l3;
            long l4 = arrfile[n4].isDirectory() ? x.a(arrfile[n4]) : arrfile[n4].length();
            l3 += l4;
            ++n4;
        } while (true);
        return l3;
    }
}

