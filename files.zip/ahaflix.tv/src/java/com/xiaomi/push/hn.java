/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.text.TextUtils
 *  com.xiaomi.channel.commonutils.logger.b
 *  com.xiaomi.push.hu
 *  e.a.a.a.a
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.util.ArrayList
 *  java.util.HashMap
 *  java.util.List
 */
package com.xiaomi.push;

import android.content.Context;
import android.text.TextUtils;
import com.xiaomi.channel.commonutils.logger.b;
import com.xiaomi.push.hp;
import com.xiaomi.push.hu;
import com.xiaomi.push.service.bj;
import e.a.a.a.a;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class hn {
    private static HashMap<String, ArrayList<hu>> a(Context context, List<hu> list) {
        if (list != null && list.size() != 0) {
            HashMap hashMap = new HashMap();
            for (hu hu2 : list) {
                hn.a(context, hu2);
                ArrayList arrayList = (ArrayList)hashMap.get((Object)hu2.c());
                if (arrayList == null) {
                    arrayList = new ArrayList();
                    hashMap.put((Object)hu2.c(), (Object)arrayList);
                }
                arrayList.add((Object)hu2);
            }
            return hashMap;
        }
        return null;
    }

    /*
     * Exception decompiling
     */
    private static void a(Context var0, hp var1, HashMap<String, ArrayList<hu>> var2) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl5 : ALOAD_3 : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    public static void a(Context context, hp hp2, List<hu> list) {
        HashMap<String, ArrayList<hu>> hashMap = hn.a(context, list);
        if (hashMap != null && hashMap.size() != 0) {
            hn.a(context, hp2, hashMap);
            return;
        }
        StringBuilder stringBuilder = a.F1((String)"TinyData TinyDataCacheUploader.uploadTinyData itemsUploading == null || itemsUploading.size() == 0  ts:");
        stringBuilder.append(System.currentTimeMillis());
        b.a((String)stringBuilder.toString());
    }

    private static void a(Context context, hu hu2) {
        if (hu2.a) {
            hu2.a("push_sdk_channel");
        }
        if (TextUtils.isEmpty((CharSequence)hu2.d())) {
            hu2.f(bj.a());
        }
        hu2.b(System.currentTimeMillis());
        if (TextUtils.isEmpty((CharSequence)hu2.e())) {
            hu2.e(context.getPackageName());
        }
        if (TextUtils.isEmpty((CharSequence)hu2.c())) {
            hu2.e(hu2.e());
        }
    }
}

