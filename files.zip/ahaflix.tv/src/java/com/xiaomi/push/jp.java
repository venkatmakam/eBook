/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.nio.ByteBuffer
 */
package com.xiaomi.push;

import com.xiaomi.push.jg;
import com.xiaomi.push.jj;
import com.xiaomi.push.jk;
import com.xiaomi.push.jl;
import com.xiaomi.push.jm;
import com.xiaomi.push.jq;
import com.xiaomi.push.jr;
import java.nio.ByteBuffer;

public class jp {
    private static int a = Integer.MAX_VALUE;

    public static void a(jm jm2, byte by) {
        jp.a(jm2, by, a);
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static void a(jm jm2, byte by, int n4) {
        if (n4 <= 0) throw new jg("Maximum skip depth exceeded");
        int n5 = 0;
        switch (by) {
            default: {
                return;
            }
            case 15: {
                jk jk2 = jm2.a();
                do {
                    if (n5 >= jk2.a) {
                        jm2.i();
                        return;
                    }
                    jp.a(jm2, jk2.a, n4 - 1);
                    ++n5;
                } while (true);
            }
            case 14: {
                jq jq2 = jm2.a();
                do {
                    if (n5 >= jq2.a) {
                        jm2.j();
                        return;
                    }
                    jp.a(jm2, jq2.a, n4 - 1);
                    ++n5;
                } while (true);
            }
            case 13: {
                jl jl2 = jm2.a();
                do {
                    if (n5 >= jl2.a) {
                        jm2.h();
                        return;
                    }
                    byte by2 = jl2.a;
                    int n6 = n4 - 1;
                    jp.a(jm2, by2, n6);
                    jp.a(jm2, jl2.b, n6);
                    ++n5;
                } while (true);
            }
            case 12: {
                jm2.a();
                do {
                    byte by3;
                    if ((by3 = jm2.a().a) == 0) {
                        jm2.f();
                        return;
                    }
                    int n7 = n4 - 1;
                    jp.a(jm2, by3, n7);
                    jm2.g();
                } while (true);
            }
            case 11: {
                jm2.a();
                return;
            }
            case 10: {
                jm2.a();
                return;
            }
            case 8: {
                jm2.a();
                return;
            }
            case 6: {
                jm2.a();
                return;
            }
            case 4: {
                jm2.a();
                return;
            }
            case 3: {
                jm2.a();
                return;
            }
            case 2: 
        }
        jm2.a();
        return;
        catch (Throwable throwable) {
            throw throwable;
        }
    }
}

