/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.xiaomi.push.jg
 *  java.lang.String
 *  java.lang.Throwable
 */
package com.xiaomi.push;

import com.xiaomi.push.jg;

public class jx
extends jg {
    public jx() {
    }

    public jx(int n5) {
    }

    public jx(int n5, String string) {
        super(string);
    }

    public jx(int n5, Throwable throwable) {
        super(throwable);
    }

    public jx(String string) {
        super(string);
    }
}

