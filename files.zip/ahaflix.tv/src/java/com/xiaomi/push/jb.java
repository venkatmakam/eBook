/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.Serializable
 *  java.lang.Comparable
 *  java.lang.Object
 */
package com.xiaomi.push;

import com.xiaomi.push.jm;
import java.io.Serializable;

public interface jb<T extends jb, F>
extends Serializable,
Comparable<T> {
    public void a(jm var1);

    public void b(jm var1);
}

