/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  com.xiaomi.channel.commonutils.logger.b
 *  e.a.a.a.a
 *  java.io.Closeable
 *  java.io.File
 *  java.io.IOException
 *  java.io.RandomAccessFile
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.nio.channels.FileChannel
 *  java.nio.channels.FileLock
 *  java.util.Collections
 *  java.util.HashSet
 *  java.util.Set
 */
package com.xiaomi.push;

import android.content.Context;
import com.xiaomi.channel.commonutils.logger.b;
import com.xiaomi.push.y;
import e.a.a.a.a;
import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class u {
    private static final Set<String> a = Collections.synchronizedSet((Set)new HashSet());
    private Context a;
    private RandomAccessFile a;
    private String a;
    private FileLock a;

    private u(Context context) {
        this.a = context;
    }

    public static u a(Context context, File file) {
        Set<String> set;
        StringBuilder stringBuilder = a.F1((String)"Locking: ");
        stringBuilder.append(file.getAbsolutePath());
        b.c((String)stringBuilder.toString());
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append(file.getAbsolutePath());
        stringBuilder2.append(".LOCK");
        String string2 = stringBuilder2.toString();
        File file2 = new File(string2);
        if (!file2.exists()) {
            file2.getParentFile().mkdirs();
            file2.createNewFile();
        }
        if ((set = a).add((Object)string2)) {
            u u3;
            block6 : {
                block7 : {
                    RandomAccessFile randomAccessFile;
                    u3 = new u(context);
                    u3.a = string2;
                    try {
                        RandomAccessFile randomAccessFile2;
                        u3.a = randomAccessFile2 = new RandomAccessFile(file2, "rw");
                        u3.a = randomAccessFile2.getChannel().lock();
                        StringBuilder stringBuilder3 = new StringBuilder();
                        stringBuilder3.append("Locked: ");
                        stringBuilder3.append(string2);
                        stringBuilder3.append(" :");
                        stringBuilder3.append((Object)u3.a);
                        b.c((String)stringBuilder3.toString());
                        if (u3.a != null) break block6;
                        randomAccessFile = u3.a;
                        if (randomAccessFile == null) break block7;
                    }
                    catch (Throwable throwable) {
                        if (u3.a == null) {
                            RandomAccessFile randomAccessFile3 = u3.a;
                            if (randomAccessFile3 != null) {
                                y.a((Closeable)randomAccessFile3);
                            }
                            a.remove((Object)u3.a);
                        }
                        throw throwable;
                    }
                    y.a((Closeable)randomAccessFile);
                }
                set.remove((Object)u3.a);
            }
            return u3;
        }
        throw new IOException("abtain lock failure");
    }

    public void a() {
        RandomAccessFile randomAccessFile;
        StringBuilder stringBuilder = a.F1((String)"unLock: ");
        stringBuilder.append((Object)this.a);
        b.c((String)stringBuilder.toString());
        FileLock fileLock = this.a;
        if (fileLock != null && fileLock.isValid()) {
            try {
                this.a.release();
            }
            catch (IOException iOException) {}
            this.a = null;
        }
        if ((randomAccessFile = this.a) != null) {
            y.a((Closeable)randomAccessFile);
        }
        a.remove((Object)this.a);
    }
}

