/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 */
package com.xiaomi.push;

import android.content.SharedPreferences;
import com.xiaomi.push.p;

public class q
implements Runnable {
    public final /* synthetic */ String a;
    public final /* synthetic */ String b;
    public final /* synthetic */ String c;
    public final /* synthetic */ p d;

    public q(p p2, String string2, String string3, String string4) {
        this.d = p2;
        this.a = string2;
        this.b = string3;
        this.c = string4;
    }

    public void run() {
        SharedPreferences.Editor editor = p.a(this.d).getSharedPreferences(this.a, 4).edit();
        editor.putString(this.b, this.c);
        editor.commit();
    }
}

