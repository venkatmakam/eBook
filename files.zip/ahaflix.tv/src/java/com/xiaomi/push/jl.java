/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.xiaomi.push;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class jl {
    public final byte a;
    public final int a;
    public final byte b;

    public jl() {
        this(0, 0, 0);
    }

    public jl(byte by, byte by2, int n4) {
        this.a = by;
        this.b = by2;
        this.a = n4;
    }
}

