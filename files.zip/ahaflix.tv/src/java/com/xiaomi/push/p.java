/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.SharedPreferences
 *  android.os.Handler
 *  android.os.Looper
 *  android.text.TextUtils
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.util.HashMap
 *  java.util.Map
 */
package com.xiaomi.push;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import com.xiaomi.push.q;
import java.util.HashMap;
import java.util.Map;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class p {
    private static volatile p a;
    private Context a;
    private Handler a;
    private Map<String, Map<String, String>> a;

    private p(Context context) {
        this.a = context;
        this.a = new Handler(Looper.getMainLooper());
        this.a = new HashMap();
    }

    public static /* synthetic */ Context a(p p2) {
        return p2.a;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static p a(Context context) {
        if (a != null) return a;
        Class<p> class_ = p.class;
        synchronized (p.class) {
            if (a != null) return a;
            a = new p(context);
            // ** MonitorExit[var2_1] (shouldn't be in output)
            return a;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private String a(String string2, String string3) {
        p p2 = this;
        synchronized (p2) {
            boolean bl2;
            if (this.a != null && !TextUtils.isEmpty((CharSequence)string2) && !(bl2 = TextUtils.isEmpty((CharSequence)string3))) {
                try {
                    Map map = (Map)this.a.get((Object)string2);
                    if (map != null) {
                        String string4 = (String)map.get((Object)string3);
                        return string4;
                    }
                }
                finally {
                    return "";
                }
            }
            return "";
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void b(String string2, String string3, String string4) {
        p p2 = this;
        synchronized (p2) {
            Map map;
            if (this.a == null) {
                this.a = new HashMap();
            }
            if ((map = (Map)this.a.get((Object)string2)) == null) {
                map = new HashMap();
            }
            map.put((Object)string3, (Object)string4);
            this.a.put((Object)string2, (Object)map);
            return;
        }
    }

    public String a(String string2, String string3, String string4) {
        p p2 = this;
        synchronized (p2) {
            block4 : {
                String string5 = this.a(string2, string3);
                boolean bl2 = TextUtils.isEmpty((CharSequence)string5);
                if (bl2) break block4;
                return string5;
            }
            String string6 = this.a.getSharedPreferences(string2, 4).getString(string3, string4);
            return string6;
        }
    }

    public void a(String string2, String string3, String string4) {
        p p2 = this;
        synchronized (p2) {
            this.b(string2, string3, string4);
            this.a.post((Runnable)new q(this, string2, string3, string4));
            return;
        }
    }
}

