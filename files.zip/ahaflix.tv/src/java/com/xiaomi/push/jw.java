/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  e.a.a.a.a
 *  java.lang.Object
 *  java.lang.String
 */
package com.xiaomi.push;

import com.xiaomi.push.jx;
import e.a.a.a.a;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public abstract class jw {
    public int a() {
        return 0;
    }

    public abstract int a(byte[] var1, int var2, int var3);

    public void a(int n4) {
    }

    public abstract void a(byte[] var1, int var2, int var3);

    public byte[] a() {
        return null;
    }

    public int b() {
        return -1;
    }

    public int b(byte[] arrby, int n4, int n5) {
        int n6;
        int n7;
        for (n7 = 0; n7 < n5; n7 += n6) {
            n6 = this.a(arrby, n4 + n7, n5 - n7);
            if (n6 > 0) {
                continue;
            }
            throw new jx(a.Z0((String)"Cannot read. Remote side has closed. Tried to read ", (int)n5, (String)" bytes, but only got ", (int)n7, (String)" bytes."));
        }
        return n7;
    }
}

