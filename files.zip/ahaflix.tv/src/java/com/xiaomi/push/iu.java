/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.xiaomi.push.if
 *  com.xiaomi.push.jb
 *  com.xiaomi.push.jc
 *  com.xiaomi.push.jj
 *  com.xiaomi.push.jk
 *  com.xiaomi.push.jm
 *  com.xiaomi.push.jp
 *  com.xiaomi.push.jr
 *  e.a.a.a.a
 *  java.io.Serializable
 *  java.lang.Boolean
 *  java.lang.Class
 *  java.lang.Cloneable
 *  java.lang.Comparable
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.List
 */
package com.xiaomi.push;

import com.xiaomi.push.if;
import com.xiaomi.push.jb;
import com.xiaomi.push.jc;
import com.xiaomi.push.jj;
import com.xiaomi.push.jk;
import com.xiaomi.push.jm;
import com.xiaomi.push.jn;
import com.xiaomi.push.jp;
import com.xiaomi.push.jr;
import e.a.a.a.a;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class iu
implements jb<iu, Object>,
Serializable,
Cloneable {
    private static final jj a;
    private static final jr a;
    private static final jj b;
    private static final jj c;
    private static final jj d;
    private static final jj e;
    private static final jj f;
    private static final jj g;
    private static final jj h;
    public if a;
    public String a;
    public List<String> a;
    public String b;
    public String c;
    public String d;
    public String e;
    public String f;

    public static {
        a = new jr("XmPushActionSubscription");
        a = new jj("", 11, 1);
        b = new jj("", 12, 2);
        c = new jj("", 11, 3);
        d = new jj("", 11, 4);
        e = new jj("", 11, 5);
        f = new jj("", 11, 6);
        g = new jj("", 11, 7);
        h = new jj("", 15, 8);
    }

    public int a(iu iu2) {
        int n5;
        int n6;
        int n7;
        int n8;
        int n9;
        int n10;
        int n11;
        int n12;
        if (!this.getClass().equals((Object)iu2.getClass())) {
            return this.getClass().getName().compareTo(iu2.getClass().getName());
        }
        int n13 = Boolean.valueOf((boolean)this.a()).compareTo(Boolean.valueOf((boolean)iu2.a()));
        if (n13 != 0) {
            return n13;
        }
        if (this.a() && (n12 = jc.a((String)this.a, (String)iu2.a)) != 0) {
            return n12;
        }
        int n14 = Boolean.valueOf((boolean)this.b()).compareTo(Boolean.valueOf((boolean)iu2.b()));
        if (n14 != 0) {
            return n14;
        }
        if (this.b() && (n8 = jc.a((Comparable)this.a, (Comparable)iu2.a)) != 0) {
            return n8;
        }
        int n15 = Boolean.valueOf((boolean)this.c()).compareTo(Boolean.valueOf((boolean)iu2.c()));
        if (n15 != 0) {
            return n15;
        }
        if (this.c() && (n11 = jc.a((String)this.b, (String)iu2.b)) != 0) {
            return n11;
        }
        int n16 = Boolean.valueOf((boolean)this.d()).compareTo(Boolean.valueOf((boolean)iu2.d()));
        if (n16 != 0) {
            return n16;
        }
        if (this.d() && (n5 = jc.a((String)this.c, (String)iu2.c)) != 0) {
            return n5;
        }
        int n17 = Boolean.valueOf((boolean)this.e()).compareTo(Boolean.valueOf((boolean)iu2.e()));
        if (n17 != 0) {
            return n17;
        }
        if (this.e() && (n10 = jc.a((String)this.d, (String)iu2.d)) != 0) {
            return n10;
        }
        int n18 = Boolean.valueOf((boolean)this.f()).compareTo(Boolean.valueOf((boolean)iu2.f()));
        if (n18 != 0) {
            return n18;
        }
        if (this.f() && (n7 = jc.a((String)this.e, (String)iu2.e)) != 0) {
            return n7;
        }
        int n19 = Boolean.valueOf((boolean)this.g()).compareTo(Boolean.valueOf((boolean)iu2.g()));
        if (n19 != 0) {
            return n19;
        }
        if (this.g() && (n9 = jc.a((String)this.f, (String)iu2.f)) != 0) {
            return n9;
        }
        int n20 = Boolean.valueOf((boolean)this.h()).compareTo(Boolean.valueOf((boolean)iu2.h()));
        if (n20 != 0) {
            return n20;
        }
        if (this.h() && (n6 = jc.a((List)this.a, (List)iu2.a)) != 0) {
            return n6;
        }
        return 0;
    }

    public iu a(String string) {
        this.b = string;
        return this;
    }

    public void a() {
        if (this.b != null) {
            if (this.c != null) {
                if (this.d != null) {
                    return;
                }
                StringBuilder stringBuilder = a.F1((String)"Required field 'topic' was not present! Struct: ");
                stringBuilder.append(this.toString());
                throw new jn(stringBuilder.toString());
            }
            StringBuilder stringBuilder = a.F1((String)"Required field 'appId' was not present! Struct: ");
            stringBuilder.append(this.toString());
            throw new jn(stringBuilder.toString());
        }
        StringBuilder stringBuilder = a.F1((String)"Required field 'id' was not present! Struct: ");
        stringBuilder.append(this.toString());
        throw new jn(stringBuilder.toString());
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public void a(jm var1_1) {
        var1_1.a();
        do {
            block13 : {
                var3_2 = var1_1.a();
                var4_3 = var3_2.a;
                if (var4_3 == 0) {
                    var1_1.f();
                    this.a();
                    return;
                }
                switch (var3_2.a) {
                    case 8: {
                        if (var4_3 != 15) break;
                        var6_5 = var1_1.a();
                        this.a = new ArrayList(var6_5.a);
                        for (var7_6 = 0; var7_6 < var6_5.a; ++var7_6) {
                            var8_7 = var1_1.a();
                            this.a.add((Object)var8_7);
                        }
                        var1_1.i();
                        ** break;
                    }
                    case 7: {
                        if (var4_3 != 11) break;
                        this.f = var1_1.a();
                        ** break;
                    }
                    case 6: {
                        if (var4_3 != 11) break;
                        this.e = var1_1.a();
                        ** break;
                    }
                    case 5: {
                        if (var4_3 != 11) break;
                        this.d = var1_1.a();
                        ** break;
                    }
                    case 4: {
                        if (var4_3 != 11) break;
                        this.c = var1_1.a();
                        ** break;
                    }
                    case 3: {
                        if (var4_3 != 11) break;
                        this.b = var1_1.a();
                        ** break;
                    }
                    case 2: {
                        if (var4_3 != 12) break;
                        this.a = var5_4 = new if();
                        var5_4.a(var1_1);
                        ** break;
                    }
                    case 1: {
                        if (var4_3 != 11) break;
                        this.a = var1_1.a();
                        break block13;
                    }
                }
                jp.a((jm)var1_1, (byte)var4_3);
                ** break;
            }
            var1_1.g();
        } while (true);
    }

    public boolean a() {
        return this.a != null;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public boolean a(iu iu2) {
        if (iu2 == null) {
            return false;
        }
        boolean bl = this.a();
        boolean bl2 = iu2.a();
        if (bl || bl2) {
            if (!bl) return false;
            if (!bl2) {
                return false;
            }
            if (!this.a.equals((Object)iu2.a)) {
                return false;
            }
        }
        boolean bl3 = this.b();
        boolean bl4 = iu2.b();
        if (bl3 || bl4) {
            if (!bl3) return false;
            if (!bl4) {
                return false;
            }
            if (!this.a.a(iu2.a)) {
                return false;
            }
        }
        boolean bl5 = this.c();
        boolean bl6 = iu2.c();
        if (bl5 || bl6) {
            if (!bl5) return false;
            if (!bl6) {
                return false;
            }
            if (!this.b.equals((Object)iu2.b)) {
                return false;
            }
        }
        boolean bl7 = this.d();
        boolean bl8 = iu2.d();
        if (bl7 || bl8) {
            if (!bl7) return false;
            if (!bl8) {
                return false;
            }
            if (!this.c.equals((Object)iu2.c)) {
                return false;
            }
        }
        boolean bl9 = this.e();
        boolean bl10 = iu2.e();
        if (bl9 || bl10) {
            if (!bl9) return false;
            if (!bl10) {
                return false;
            }
            if (!this.d.equals((Object)iu2.d)) {
                return false;
            }
        }
        boolean bl11 = this.f();
        boolean bl12 = iu2.f();
        if (bl11 || bl12) {
            if (!bl11) return false;
            if (!bl12) {
                return false;
            }
            if (!this.e.equals((Object)iu2.e)) {
                return false;
            }
        }
        boolean bl13 = this.g();
        boolean bl14 = iu2.g();
        if (bl13 || bl14) {
            if (!bl13) return false;
            if (!bl14) {
                return false;
            }
            if (!this.f.equals((Object)iu2.f)) {
                return false;
            }
        }
        boolean bl15 = this.h();
        boolean bl16 = iu2.h();
        if (!bl15 && !bl16) return true;
        if (!bl15) return false;
        if (!bl16) {
            return false;
        }
        if (this.a.equals((Object)iu2.a)) return true;
        return false;
    }

    public iu b(String string) {
        this.c = string;
        return this;
    }

    public void b(jm jm2) {
        this.a();
        jm2.a(a);
        if (this.a != null && this.a()) {
            jm2.a(a);
            jm2.a(this.a);
            jm2.b();
        }
        if (this.a != null && this.b()) {
            jm2.a(b);
            this.a.b(jm2);
            jm2.b();
        }
        if (this.b != null) {
            jm2.a(c);
            jm2.a(this.b);
            jm2.b();
        }
        if (this.c != null) {
            jm2.a(d);
            jm2.a(this.c);
            jm2.b();
        }
        if (this.d != null) {
            jm2.a(e);
            jm2.a(this.d);
            jm2.b();
        }
        if (this.e != null && this.f()) {
            jm2.a(f);
            jm2.a(this.e);
            jm2.b();
        }
        if (this.f != null && this.g()) {
            jm2.a(g);
            jm2.a(this.f);
            jm2.b();
        }
        if (this.a != null && this.h()) {
            jm2.a(h);
            jm2.a(new jk(11, this.a.size()));
            Iterator iterator = this.a.iterator();
            while (iterator.hasNext()) {
                jm2.a((String)iterator.next());
            }
            jm2.e();
            jm2.b();
        }
        jm2.c();
        jm2.a();
    }

    public boolean b() {
        return this.a != null;
    }

    public iu c(String string) {
        this.d = string;
        return this;
    }

    public boolean c() {
        return this.b != null;
    }

    public /* synthetic */ int compareTo(Object object) {
        return this.a((iu)object);
    }

    public iu d(String string) {
        this.e = string;
        return this;
    }

    public boolean d() {
        return this.c != null;
    }

    public iu e(String string) {
        this.f = string;
        return this;
    }

    public boolean e() {
        return this.d != null;
    }

    public boolean equals(Object object) {
        if (object == null) {
            return false;
        }
        if (object instanceof iu) {
            return this.a((iu)object);
        }
        return false;
    }

    public boolean f() {
        return this.e != null;
    }

    public boolean g() {
        return this.f != null;
    }

    public boolean h() {
        return this.a != null;
    }

    public int hashCode() {
        return 0;
    }

    public String toString() {
        boolean bl;
        boolean bl2;
        StringBuilder stringBuilder = new StringBuilder("XmPushActionSubscription(");
        if (this.a()) {
            stringBuilder.append("debug:");
            String string = this.a;
            if (string == null) {
                stringBuilder.append("null");
            } else {
                stringBuilder.append(string);
            }
            bl = false;
        } else {
            bl = true;
        }
        if (this.b()) {
            if (!bl) {
                stringBuilder.append(", ");
            }
            stringBuilder.append("target:");
            if if_ = this.a;
            if (if_ == null) {
                stringBuilder.append("null");
                bl2 = false;
            } else {
                stringBuilder.append((Object)if_);
                bl2 = false;
            }
        } else {
            bl2 = bl;
        }
        if (!bl2) {
            stringBuilder.append(", ");
        }
        stringBuilder.append("id:");
        String string = this.b;
        if (string == null) {
            stringBuilder.append("null");
        } else {
            stringBuilder.append(string);
        }
        stringBuilder.append(", ");
        stringBuilder.append("appId:");
        String string2 = this.c;
        if (string2 == null) {
            stringBuilder.append("null");
        } else {
            stringBuilder.append(string2);
        }
        stringBuilder.append(", ");
        stringBuilder.append("topic:");
        String string3 = this.d;
        if (string3 == null) {
            stringBuilder.append("null");
        } else {
            stringBuilder.append(string3);
        }
        if (this.f()) {
            stringBuilder.append(", ");
            stringBuilder.append("packageName:");
            String string4 = this.e;
            if (string4 == null) {
                stringBuilder.append("null");
            } else {
                stringBuilder.append(string4);
            }
        }
        if (this.g()) {
            stringBuilder.append(", ");
            stringBuilder.append("category:");
            String string5 = this.f;
            if (string5 == null) {
                stringBuilder.append("null");
            } else {
                stringBuilder.append(string5);
            }
        }
        if (this.h()) {
            stringBuilder.append(", ");
            stringBuilder.append("aliases:");
            jj jj2 = this.a;
            if (jj2 == null) {
                stringBuilder.append("null");
            } else {
                stringBuilder.append((Object)jj2);
            }
        }
        stringBuilder.append(")");
        return stringBuilder.toString();
    }
}

