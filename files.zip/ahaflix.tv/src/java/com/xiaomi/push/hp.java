/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.xiaomi.push.hu
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 */
package com.xiaomi.push;

import com.xiaomi.push.hu;
import java.util.List;

public interface hp {
    public void a(List<hu> var1, String var2, String var3);
}

