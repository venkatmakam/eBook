/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.xiaomi.push.jw
 *  java.io.IOException
 *  java.io.OutputStream
 *  java.lang.String
 *  java.lang.Throwable
 */
package com.xiaomi.push;

import com.xiaomi.push.jw;
import com.xiaomi.push.jx;
import java.io.IOException;
import java.io.OutputStream;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class jt
extends jw {
    public OutputStream a = null;

    public jt() {
    }

    public jt(OutputStream outputStream) {
        this.a = outputStream;
    }

    public int a(byte[] arrby, int n5, int n6) {
        throw new jx(1, "Cannot read from null inputStream");
    }

    public void a(byte[] arrby, int n5, int n6) {
        OutputStream outputStream = this.a;
        if (outputStream != null) {
            try {
                outputStream.write(arrby, n5, n6);
                return;
            }
            catch (IOException iOException) {
                throw new jx(0, iOException);
            }
        }
        throw new jx(1, "Cannot write to null outputStream");
    }
}

