/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.xiaomi.push;

public final class jr {
    public final String a;

    public jr() {
        this("");
    }

    public jr(String string2) {
        this.a = string2;
    }
}

