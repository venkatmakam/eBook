/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.xiaomi.push;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class hs
extends Enum<hs> {
    public static final /* enum */ hs a;
    private static final /* synthetic */ hs[] a;
    public static final /* enum */ hs b;
    public static final /* enum */ hs c;
    public static final /* enum */ hs d;
    public static final /* enum */ hs e;
    public static final /* enum */ hs f;
    public static final /* enum */ hs g;
    public static final /* enum */ hs h;
    public static final /* enum */ hs i;
    public static final /* enum */ hs j;
    public static final /* enum */ hs k;
    public static final /* enum */ hs l;
    public static final /* enum */ hs m;
    public static final /* enum */ hs n;
    public static final /* enum */ hs o;
    public static final /* enum */ hs p;
    public static final /* enum */ hs q;
    public static final /* enum */ hs r;
    public static final /* enum */ hs s;
    public static final /* enum */ hs t;
    public static final /* enum */ hs u;
    public static final /* enum */ hs v;
    public static final /* enum */ hs w;
    public static final /* enum */ hs x;
    private final int a;

    public static {
        hs hs2;
        hs hs3;
        hs hs4;
        hs hs5;
        hs hs6;
        hs hs7;
        hs hs8;
        hs hs9;
        hs hs10;
        hs hs11;
        hs hs12;
        hs hs13;
        hs hs14;
        hs hs15;
        hs hs16;
        hs hs17;
        hs hs18;
        hs hs19;
        hs hs20;
        hs hs21;
        hs hs22;
        hs hs23;
        hs hs24;
        hs hs25;
        a = hs10 = new hs(1);
        b = hs9 = new hs(2);
        c = hs3 = new hs(3);
        d = hs17 = new hs(4);
        e = hs14 = new hs(5);
        f = hs7 = new hs(6);
        g = hs16 = new hs(7);
        h = hs4 = new hs(8);
        i = hs8 = new hs(9);
        j = hs23 = new hs(10);
        k = hs13 = new hs(11);
        l = hs18 = new hs(12);
        m = hs22 = new hs(13);
        n = hs25 = new hs(14);
        o = hs6 = new hs(15);
        p = hs12 = new hs(16);
        q = hs11 = new hs(17);
        r = hs5 = new hs(18);
        s = hs24 = new hs(19);
        t = hs21 = new hs(20);
        u = hs2 = new hs(21);
        v = hs20 = new hs(22);
        w = hs15 = new hs(23);
        x = hs19 = new hs(24);
        a = new hs[]{hs10, hs9, hs3, hs17, hs14, hs7, hs16, hs4, hs8, hs23, hs13, hs18, hs22, hs25, hs6, hs12, hs11, hs5, hs24, hs21, hs2, hs20, hs15, hs19};
    }

    private hs(int n5) {
        this.a = n5;
    }

    public static hs a(int n4) {
        switch (n4) {
            default: {
                return null;
            }
            case 24: {
                return x;
            }
            case 23: {
                return w;
            }
            case 22: {
                return v;
            }
            case 21: {
                return u;
            }
            case 20: {
                return t;
            }
            case 19: {
                return s;
            }
            case 18: {
                return r;
            }
            case 17: {
                return q;
            }
            case 16: {
                return p;
            }
            case 15: {
                return o;
            }
            case 14: {
                return n;
            }
            case 13: {
                return m;
            }
            case 12: {
                return l;
            }
            case 11: {
                return k;
            }
            case 10: {
                return j;
            }
            case 9: {
                return i;
            }
            case 8: {
                return h;
            }
            case 7: {
                return g;
            }
            case 6: {
                return f;
            }
            case 5: {
                return e;
            }
            case 4: {
                return d;
            }
            case 3: {
                return c;
            }
            case 2: {
                return b;
            }
            case 1: 
        }
        return a;
    }

    public static hs valueOf(String string2) {
        return (hs)Enum.valueOf(hs.class, (String)string2);
    }

    public static hs[] values() {
        return (hs[])a.clone();
    }

    public int a() {
        return this.a;
    }
}

