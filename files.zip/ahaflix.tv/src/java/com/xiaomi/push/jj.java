/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  e.a.a.a.a
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.xiaomi.push;

import e.a.a.a.a;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class jj {
    public final byte a;
    public final String a;
    public final short a;

    public jj() {
        this("", 0, 0);
    }

    public jj(String string2, byte by, short s2) {
        this.a = string2;
        this.a = by;
        this.a = s2;
    }

    public String toString() {
        StringBuilder stringBuilder = a.F1((String)"<TField name:'");
        stringBuilder.append(this.a);
        stringBuilder.append("' type:");
        stringBuilder.append((int)this.a);
        stringBuilder.append(" field-id:");
        return a.o1((StringBuilder)stringBuilder, (int)this.a, (String)">");
    }
}

