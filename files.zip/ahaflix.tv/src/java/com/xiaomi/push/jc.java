/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Comparable
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.nio.ByteBuffer
 *  java.util.Collection
 *  java.util.Comparator
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 *  java.util.TreeMap
 *  java.util.TreeSet
 */
package com.xiaomi.push;

import com.xiaomi.push.jd;
import java.nio.ByteBuffer;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class jc {
    private static final Comparator a = new a(null);

    public static int a(byte by, byte by2) {
        if (by < by2) {
            return -1;
        }
        return by2 < by;
    }

    public static int a(int n4, int n5) {
        if (n4 < n5) {
            return -1;
        }
        return n5 < n4;
    }

    public static int a(long l3, long l4) {
        if (l3 < l4) {
            return -1;
        }
        return l4 < l3;
    }

    public static int a(Comparable comparable, Comparable comparable2) {
        return comparable.compareTo((Object)comparable2);
    }

    public static int a(String string2, String string3) {
        return string2.compareTo(string3);
    }

    public static int a(ByteBuffer byteBuffer, byte[] arrby, int n4) {
        int n5 = byteBuffer.remaining();
        System.arraycopy((Object)byteBuffer.array(), (int)(byteBuffer.arrayOffset() + byteBuffer.position()), (Object)arrby, (int)n4, (int)n5);
        return n5;
    }

    public static int a(List list, List list2) {
        int n4 = jc.a(list.size(), list2.size());
        if (n4 != 0) {
            return n4;
        }
        for (int i6 = 0; i6 < list.size(); ++i6) {
            int n5 = a.compare(list.get(i6), list2.get(i6));
            if (n5 == 0) continue;
            return n5;
        }
        return 0;
    }

    public static int a(Map map, Map map2) {
        int n4 = jc.a(map.size(), map2.size());
        if (n4 != 0) {
            return n4;
        }
        Comparator comparator = a;
        TreeMap treeMap = new TreeMap(comparator);
        treeMap.putAll(map);
        Iterator iterator = treeMap.entrySet().iterator();
        TreeMap treeMap2 = new TreeMap(comparator);
        treeMap2.putAll(map2);
        Iterator iterator2 = treeMap2.entrySet().iterator();
        while (iterator.hasNext() && iterator2.hasNext()) {
            Map.Entry entry = (Map.Entry)iterator.next();
            Map.Entry entry2 = (Map.Entry)iterator2.next();
            Comparator comparator2 = a;
            int n5 = comparator2.compare(entry.getKey(), entry2.getKey());
            if (n5 != 0) {
                return n5;
            }
            int n6 = comparator2.compare(entry.getValue(), entry2.getValue());
            if (n6 == 0) continue;
            return n6;
        }
        return 0;
    }

    public static int a(Set set, Set set2) {
        int n4 = jc.a(set.size(), set2.size());
        if (n4 != 0) {
            return n4;
        }
        Comparator comparator = a;
        TreeSet treeSet = new TreeSet(comparator);
        treeSet.addAll((Collection)set);
        TreeSet treeSet2 = new TreeSet(comparator);
        treeSet2.addAll((Collection)set2);
        Iterator iterator = treeSet.iterator();
        Iterator iterator2 = treeSet2.iterator();
        while (iterator.hasNext() && iterator2.hasNext()) {
            int n5 = a.compare(iterator.next(), iterator2.next());
            if (n5 == 0) continue;
            return n5;
        }
        return 0;
    }

    public static int a(short s2, short s3) {
        if (s2 < s3) {
            return -1;
        }
        return s3 < s2;
    }

    public static int a(boolean bl2, boolean bl3) {
        return Boolean.valueOf((boolean)bl2).compareTo(Boolean.valueOf((boolean)bl3));
    }

    public static int a(byte[] arrby, byte[] arrby2) {
        int n4 = jc.a(arrby.length, arrby2.length);
        if (n4 != 0) {
            return n4;
        }
        for (int i6 = 0; i6 < arrby.length; ++i6) {
            int n5 = jc.a(arrby[i6], arrby2[i6]);
            if (n5 == 0) continue;
            return n5;
        }
        return 0;
    }

    public static String a(byte by) {
        return Integer.toHexString((int)(511 & (by | 256))).toUpperCase().substring(1);
    }

    public static ByteBuffer a(ByteBuffer byteBuffer) {
        if (jc.a(byteBuffer)) {
            return byteBuffer;
        }
        return ByteBuffer.wrap((byte[])jc.a(byteBuffer));
    }

    public static void a(ByteBuffer byteBuffer, StringBuilder stringBuilder) {
        byte[] arrby = byteBuffer.array();
        int n4 = byteBuffer.arrayOffset();
        int n5 = byteBuffer.limit();
        int n6 = n5 - n4 > 128 ? n4 + 128 : n5;
        for (int i6 = n4; i6 < n6; ++i6) {
            if (i6 > n4) {
                stringBuilder.append(" ");
            }
            stringBuilder.append(jc.a(arrby[i6]));
        }
        if (n5 != n6) {
            stringBuilder.append("...");
        }
    }

    public static boolean a(ByteBuffer byteBuffer) {
        return byteBuffer.hasArray() && byteBuffer.position() == 0 && byteBuffer.arrayOffset() == 0 && byteBuffer.remaining() == byteBuffer.capacity();
    }

    public static byte[] a(ByteBuffer byteBuffer) {
        if (jc.a(byteBuffer)) {
            return byteBuffer.array();
        }
        byte[] arrby = new byte[byteBuffer.remaining()];
        jc.a(byteBuffer, arrby, 0);
        return arrby;
    }

    public static class a
    implements Comparator {
        private a() {
        }

        public /* synthetic */ a(jd jd2) {
            this();
        }

        public int compare(Object object, Object object2) {
            if (object == null && object2 == null) {
                return 0;
            }
            if (object == null) {
                return -1;
            }
            if (object2 == null) {
                return 1;
            }
            if (object instanceof List) {
                return jc.a((List)object, (List)object2);
            }
            if (object instanceof Set) {
                return jc.a((Set)object, (Set)object2);
            }
            if (object instanceof Map) {
                return jc.a((Map)object, (Map)object2);
            }
            if (object instanceof byte[]) {
                return jc.a((byte[])object, (byte[])object2);
            }
            return jc.a((Comparable)object, (Comparable)object2);
        }
    }

}

