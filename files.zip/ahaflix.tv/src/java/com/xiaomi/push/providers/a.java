/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.database.SQLException
 *  android.database.sqlite.SQLiteDatabase
 *  android.database.sqlite.SQLiteDatabase$CursorFactory
 *  android.database.sqlite.SQLiteOpenHelper
 *  com.xiaomi.channel.commonutils.logger.b
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 */
package com.xiaomi.push.providers;

import android.content.Context;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import com.xiaomi.channel.commonutils.logger.b;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class a
extends SQLiteOpenHelper {
    private static int a = 1;
    public static final Object a = new Object();
    private static final String[] a = new String[]{"package_name", "TEXT", "message_ts", " LONG DEFAULT 0 ", "bytes", " LONG DEFAULT 0 ", "network_type", " INT DEFAULT -1 ", "rcv", " INT DEFAULT -1 ", "imsi", "TEXT"};

    public a(Context context) {
        super(context, "traffic.db", null, a);
    }

    private void a(SQLiteDatabase sQLiteDatabase) {
        String[] arrstring;
        StringBuilder stringBuilder = new StringBuilder("CREATE TABLE traffic(_id INTEGER  PRIMARY KEY ,");
        for (int i6 = 0; i6 < -1 + (arrstring = a).length; i6 += 2) {
            if (i6 != 0) {
                stringBuilder.append(",");
            }
            stringBuilder.append(arrstring[i6]);
            stringBuilder.append(" ");
            stringBuilder.append(arrstring[i6 + 1]);
        }
        stringBuilder.append(");");
        sQLiteDatabase.execSQL(stringBuilder.toString());
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void onCreate(SQLiteDatabase sQLiteDatabase) {
        Object object;
        Object object2 = object = a;
        synchronized (object2) {
            try {
                try {
                    this.a(sQLiteDatabase);
                }
                catch (SQLException sQLException) {
                    b.a((Throwable)sQLException);
                }
                return;
            }
            catch (Throwable throwable2) {}
            throw throwable2;
        }
    }

    public void onUpgrade(SQLiteDatabase sQLiteDatabase, int n4, int n5) {
    }
}

