/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ContentProvider
 *  android.content.ContentValues
 *  android.content.Context
 *  android.content.UriMatcher
 *  android.database.Cursor
 *  android.database.sqlite.SQLiteDatabase
 *  android.database.sqlite.SQLiteOpenHelper
 *  android.net.Uri
 *  e.a.a.a.a
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.xiaomi.push.providers;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.net.Uri;
import com.xiaomi.push.hb;
import com.xiaomi.push.providers.a;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class TrafficProvider
extends ContentProvider {
    private static final UriMatcher a;
    public static final Uri a;
    private SQLiteOpenHelper a;

    public static {
        UriMatcher uriMatcher;
        a = Uri.parse((String)"content://com.xiaomi.push.providers.TrafficProvider/traffic");
        a = uriMatcher = new UriMatcher(-1);
        uriMatcher.addURI("com.xiaomi.push.providers.TrafficProvider", "traffic", 1);
        uriMatcher.addURI("com.xiaomi.push.providers.TrafficProvider", "update_imsi", 2);
    }

    public int bulkInsert(Uri uri, ContentValues[] arrcontentValues) {
        return 0;
    }

    public int delete(Uri uri, String string2, String[] arrstring) {
        return 0;
    }

    public String getType(Uri uri) {
        if (a.match(uri) == 1) {
            return "vnd.android.cursor.dir/vnd.xiaomi.push.traffic";
        }
        throw new IllegalArgumentException(e.a.a.a.a.d1((String)"Unknown URI ", (Uri)uri));
    }

    public Uri insert(Uri uri, ContentValues contentValues) {
        return null;
    }

    public boolean onCreate() {
        this.a = new a(this.getContext());
        return true;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public Cursor query(Uri uri, String[] arrstring, String string2, String[] arrstring2, String string3) {
        Object object;
        Object object2 = object = a.a;
        synchronized (object2) {
            if (a.match(uri) == 1) {
                return this.a.getReadableDatabase().query("traffic", arrstring, string2, arrstring2, null, null, string3);
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Unknown URI ");
            stringBuilder.append((Object)uri);
            throw new IllegalArgumentException(stringBuilder.toString());
        }
    }

    public int update(Uri uri, ContentValues contentValues, String string2, String[] arrstring) {
        if (a.match(uri) == 2 && contentValues != null && contentValues.containsKey("imsi")) {
            hb.a(contentValues.getAsString("imsi"));
        }
        return 0;
    }
}

