/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.text.TextUtils
 *  com.xiaomi.channel.commonutils.logger.b
 *  e.a.a.a.a
 *  java.io.BufferedInputStream
 *  java.io.BufferedWriter
 *  java.io.ByteArrayOutputStream
 *  java.io.Closeable
 *  java.io.File
 *  java.io.FileFilter
 *  java.io.FileInputStream
 *  java.io.FileOutputStream
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.InputStreamReader
 *  java.io.OutputStream
 *  java.io.OutputStreamWriter
 *  java.io.StringWriter
 *  java.io.Writer
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.Date
 *  java.util.zip.GZIPOutputStream
 *  java.util.zip.ZipEntry
 *  java.util.zip.ZipOutputStream
 */
package com.xiaomi.push;

import android.text.TextUtils;
import com.xiaomi.channel.commonutils.logger.b;
import com.xiaomi.push.z;
import e.a.a.a.a;
import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.util.Date;
import java.util.zip.GZIPOutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class y {
    public static final String[] a = new String[]{"jpg", "png", "bmp", "gif", "webp"};

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static String a(File file) {
        InputStreamReader inputStreamReader;
        StringWriter stringWriter;
        void var3_11;
        block9 : {
            InputStreamReader inputStreamReader2;
            block8 : {
                String string2;
                stringWriter = new StringWriter();
                inputStreamReader2 = new InputStreamReader((InputStream)new BufferedInputStream((InputStream)new FileInputStream(file)));
                try {
                    int n4;
                    char[] arrc = new char[2048];
                    while ((n4 = inputStreamReader2.read(arrc)) != -1) {
                        stringWriter.write(arrc, 0, n4);
                    }
                    string2 = stringWriter.toString();
                }
                catch (IOException iOException) {
                    break block8;
                }
                y.a((Closeable)inputStreamReader2);
                y.a((Closeable)stringWriter);
                return string2;
                catch (Throwable throwable) {
                    inputStreamReader = null;
                    break block9;
                }
                catch (IOException iOException) {
                    inputStreamReader2 = null;
                }
            }
            try {
                void var5_8;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("read file :");
                stringBuilder.append(file.getAbsolutePath());
                stringBuilder.append(" failure :");
                stringBuilder.append(var5_8.getMessage());
                b.c((String)stringBuilder.toString());
            }
            catch (Throwable throwable) {
                inputStreamReader = inputStreamReader2;
            }
            y.a((Closeable)inputStreamReader2);
            y.a((Closeable)stringWriter);
            return null;
        }
        y.a(inputStreamReader);
        y.a((Closeable)stringWriter);
        throw var3_11;
    }

    /*
     * Exception decompiling
     */
    public static void a(Closeable var0) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Underrun type stack
        // org.benf.cfr.reader.b.a.c.e.a(StackSim.java:35)
        // org.benf.cfr.reader.b.b.af.a(OperationFactoryPop.java:20)
        // org.benf.cfr.reader.b.b.e.a(JVMInstr.java:315)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:195)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    public static void a(File file) {
        block5 : {
            block4 : {
                block3 : {
                    if (!file.isDirectory()) break block3;
                    File[] arrfile = file.listFiles();
                    for (int i6 = 0; i6 < arrfile.length; ++i6) {
                        y.a(arrfile[i6]);
                    }
                    break block4;
                }
                if (!file.exists()) break block5;
            }
            file.delete();
        }
    }

    /*
     * Exception decompiling
     */
    public static void a(File var0, File var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl55.1 : ALOAD_2 : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static void a(File var0, String var1_1) {
        block8 : {
            block9 : {
                if (!var0.exists()) {
                    var11_2 = a.F1((String)"mkdir ");
                    var11_2.append(var0.getAbsolutePath());
                    b.c((String)var11_2.toString());
                    var0.getParentFile().mkdirs();
                }
                var2_3 = null;
                var3_4 = new BufferedWriter((Writer)new OutputStreamWriter((OutputStream)new FileOutputStream(var0)));
                try {
                    var3_4.write(var1_1);
                }
                catch (Throwable var10_5) {
                    break block8;
                }
                catch (IOException var4_8) {
                    var2_3 = var3_4;
                    ** GOTO lbl-1000
                }
                y.a((Closeable)var3_4);
                return;
                catch (Throwable var10_6) {
                    break block9;
                }
                catch (IOException var4_9) {
                    // empty catch block
                }
lbl-1000: // 2 sources:
                {
                    var5_11 = new StringBuilder();
                    var5_11.append("write file :");
                    var5_11.append(var0.getAbsolutePath());
                    var5_11.append(" failure :");
                    var5_11.append(var4_10.getMessage());
                    b.c((String)var5_11.toString());
                }
                y.a((Closeable)var2_3);
                return;
            }
            var3_4 = var2_3;
        }
        y.a(var3_4);
        throw var10_7;
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static void a(ZipOutputStream var0, File var1_1, String var2_2, FileFilter var3_3) {
        block22 : {
            block21 : {
                var4_4 = "";
                if (var2_2 == null) {
                    var2_2 = var4_4;
                }
                var5_5 = null;
                try {
                    var11_6 = var1_1.isDirectory();
                    var12_7 = 0;
                    if (!var11_6) {
                        var34_20 = TextUtils.isEmpty((CharSequence)var2_2);
                        var5_5 = null;
                        if (!var34_20) {
                            var35_21 = new ZipEntry(var2_2);
                        } else {
                            var39_22 = new Date();
                            var40_23 = new StringBuilder();
                            var40_23.append(String.valueOf((long)var39_22.getTime()));
                            var40_23.append(".txt");
                            var35_21 = new ZipEntry(var40_23.toString());
                        }
                        var0.putNextEntry(var35_21);
                        var36_24 = new FileInputStream(var1_1);
                        try {
                            var37_25 = new byte[1024];
                            while ((var38_26 = var36_24.read(var37_25)) != -1) {
                                var0.write(var37_25, 0, var38_26);
                            }
                        }
                        catch (IOException var6_30) {}
                        finally {
                            var5_5 = var36_24;
                            ** GOTO lbl80
                        }
                    } else {
                        var5_5 = null;
                        var13_8 = var3_3 != null ? var1_1.listFiles(var3_3) : var1_1.listFiles();
                        var14_9 = new StringBuilder();
                        var14_9.append(var2_2);
                        var16_10 = File.separator;
                        var14_9.append(var16_10);
                        var0.putNextEntry(new ZipEntry(var14_9.toString()));
                        if (!TextUtils.isEmpty((CharSequence)var2_2)) {
                            var31_11 = new StringBuilder();
                            var31_11.append(var2_2);
                            var31_11.append(var16_10);
                            var4_4 = var31_11.toString();
                        }
                        var18_12 = 0;
                        do {
                            var19_13 = var13_8.length;
                            var5_5 = null;
                            if (var18_12 >= var19_13) break;
                            var20_14 = var13_8[var18_12];
                            var21_15 = new StringBuilder();
                            var21_15.append(var4_4);
                            var21_15.append(var13_8[var18_12].getName());
                            y.a(var0, var20_14, var21_15.toString(), null);
                            ++var18_12;
                        } while (true);
                        var24_16 = var1_1.listFiles((FileFilter)new z());
                        var5_5 = null;
                        if (var24_16 != null) {
                            var25_17 = var24_16.length;
                            do {
                                var5_5 = null;
                                if (var12_7 < var25_17) {
                                    var26_18 = var24_16[var12_7];
                                    var27_19 = new StringBuilder();
                                    var27_19.append(var4_4);
                                    var27_19.append(File.separator);
                                    var27_19.append(var26_18.getName());
                                    y.a(var0, var26_18, var27_19.toString(), var3_3);
                                    ++var12_7;
                                    continue;
                                }
                                ** GOTO lbl80
                                break;
                            } while (true);
                        }
                    }
                    break block21;
                }
                catch (Throwable var10_28) {
                    break block22;
                }
                catch (IOException var6_31) {
                    // empty catch block
                }
                {
                    var7_33 = new StringBuilder();
                    var7_33.append("zipFiction failed with exception:");
                    var7_33.append(var6_32.toString());
                    b.d((String)var7_33.toString());
                }
            }
            y.a(var5_5);
            return;
        }
        y.a(var5_5);
        throw var10_29;
    }

    public static boolean a(File file) {
        block7 : {
            block6 : {
                block5 : {
                    try {
                        if (!file.isDirectory()) break block5;
                        return false;
                    }
                    catch (Throwable throwable) {
                        throwable.printStackTrace();
                        return false;
                    }
                }
                if (!file.exists()) break block6;
                return true;
            }
            File file2 = file.getParentFile();
            if (file2.exists() || file2.mkdirs()) break block7;
            return false;
        }
        boolean bl2 = file.createNewFile();
        return bl2;
    }

    public static byte[] a(byte[] arrby) {
        try {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            GZIPOutputStream gZIPOutputStream = new GZIPOutputStream((OutputStream)byteArrayOutputStream);
            gZIPOutputStream.write(arrby);
            gZIPOutputStream.finish();
            gZIPOutputStream.close();
            byte[] arrby2 = byteArrayOutputStream.toByteArray();
            byteArrayOutputStream.close();
            arrby = arrby2;
        }
        catch (Exception exception) {}
        return arrby;
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static void b(File file, File file2) {
        void var5_9;
        FileOutputStream fileOutputStream;
        FileInputStream fileInputStream;
        block10 : {
            FileInputStream fileInputStream2;
            block9 : {
                if (file.getAbsolutePath().equals((Object)file2.getAbsolutePath())) {
                    return;
                }
                fileInputStream = null;
                fileInputStream2 = new FileInputStream(file);
                fileOutputStream = new FileOutputStream(file2);
                try {
                    int n4;
                    byte[] arrby = new byte[1024];
                    while ((n4 = fileInputStream2.read(arrby)) >= 0) {
                        fileOutputStream.write(arrby, 0, n4);
                    }
                }
                catch (Throwable throwable) {
                    break block9;
                }
                fileInputStream2.close();
                fileOutputStream.close();
                return;
                catch (Throwable throwable) {
                    fileOutputStream = null;
                }
            }
            fileInputStream = fileInputStream2;
            break block10;
            catch (Throwable throwable) {
                fileOutputStream = null;
            }
        }
        if (fileInputStream != null) {
            fileInputStream.close();
        }
        if (fileOutputStream == null) throw var5_9;
        fileOutputStream.close();
        throw var5_9;
    }
}

