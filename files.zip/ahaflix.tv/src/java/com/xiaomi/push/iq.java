/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.xiaomi.push.ie
 *  com.xiaomi.push.if
 *  com.xiaomi.push.jb
 *  com.xiaomi.push.jc
 *  com.xiaomi.push.jj
 *  com.xiaomi.push.jl
 *  com.xiaomi.push.jm
 *  com.xiaomi.push.jp
 *  com.xiaomi.push.jr
 *  e.a.a.a.a
 *  java.io.Serializable
 *  java.lang.Boolean
 *  java.lang.Class
 *  java.lang.Cloneable
 *  java.lang.Comparable
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.BitSet
 *  java.util.HashMap
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 */
package com.xiaomi.push;

import com.xiaomi.push.ie;
import com.xiaomi.push.if;
import com.xiaomi.push.jb;
import com.xiaomi.push.jc;
import com.xiaomi.push.jj;
import com.xiaomi.push.jl;
import com.xiaomi.push.jm;
import com.xiaomi.push.jn;
import com.xiaomi.push.jp;
import com.xiaomi.push.jr;
import e.a.a.a.a;
import java.io.Serializable;
import java.util.BitSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class iq
implements jb<iq, Object>,
Serializable,
Cloneable {
    private static final jj A;
    private static final jj B;
    private static final jj a;
    private static final jr a;
    private static final jj b;
    private static final jj c;
    private static final jj d;
    private static final jj e;
    private static final jj f;
    private static final jj g;
    private static final jj h;
    private static final jj i;
    private static final jj j;
    private static final jj k;
    private static final jj l;
    private static final jj m;
    private static final jj n;
    private static final jj o;
    private static final jj p;
    private static final jj q;
    private static final jj r;
    private static final jj s;
    private static final jj t;
    private static final jj u;
    private static final jj v;
    private static final jj w;
    private static final jj x;
    private static final jj y;
    private static final jj z;
    public int a;
    public long a;
    public ie a;
    public if a;
    public String a;
    private BitSet a;
    public Map<String, String> a;
    public boolean a = true;
    public int b;
    public long b;
    public String b;
    public boolean b = false;
    public int c;
    public String c;
    public String d;
    public String e;
    public String f;
    public String g;
    public String h;
    public String i;
    public String j;
    public String k;
    public String l;
    public String m;
    public String n;
    public String o;
    public String p;
    public String q;
    public String r;

    public static {
        a = new jr("XmPushActionRegistration");
        a = new jj("", 11, 1);
        b = new jj("", 12, 2);
        c = new jj("", 11, 3);
        d = new jj("", 11, 4);
        e = new jj("", 11, 5);
        f = new jj("", 11, 6);
        g = new jj("", 11, 7);
        h = new jj("", 11, 8);
        i = new jj("", 11, 9);
        j = new jj("", 11, 10);
        k = new jj("", 11, 11);
        l = new jj("", 11, 12);
        m = new jj("", 8, 13);
        n = new jj("", 8, 14);
        o = new jj("", 11, 15);
        p = new jj("", 11, 16);
        q = new jj("", 11, 17);
        r = new jj("", 11, 18);
        s = new jj("", 8, 19);
        t = new jj("", 8, 20);
        u = new jj("", 2, 21);
        v = new jj("", 10, 22);
        w = new jj("", 10, 23);
        x = new jj("", 11, 24);
        y = new jj("", 11, 25);
        z = new jj("", 13, 100);
        A = new jj("", 2, 101);
        B = new jj("", 11, 102);
    }

    public boolean A() {
        return this.a.get(6);
    }

    public boolean B() {
        return this.r != null;
    }

    public int a(iq iq2) {
        int n5;
        int n6;
        int n7;
        int n8;
        int n9;
        int n10;
        int n11;
        int n12;
        int n13;
        int n14;
        int n15;
        int n16;
        int n17;
        int n18;
        int n19;
        int n20;
        int n21;
        int n22;
        int n23;
        int n24;
        int n25;
        int n26;
        int n27;
        int n28;
        int n29;
        int n30;
        int n31;
        int n32;
        if (!this.getClass().equals((Object)iq2.getClass())) {
            return this.getClass().getName().compareTo(iq2.getClass().getName());
        }
        int n33 = Boolean.valueOf((boolean)this.a()).compareTo(Boolean.valueOf((boolean)iq2.a()));
        if (n33 != 0) {
            return n33;
        }
        if (this.a() && (n17 = jc.a((String)this.a, (String)iq2.a)) != 0) {
            return n17;
        }
        int n34 = Boolean.valueOf((boolean)this.b()).compareTo(Boolean.valueOf((boolean)iq2.b()));
        if (n34 != 0) {
            return n34;
        }
        if (this.b() && (n20 = jc.a((Comparable)this.a, (Comparable)iq2.a)) != 0) {
            return n20;
        }
        int n35 = Boolean.valueOf((boolean)this.c()).compareTo(Boolean.valueOf((boolean)iq2.c()));
        if (n35 != 0) {
            return n35;
        }
        if (this.c() && (n14 = jc.a((String)this.b, (String)iq2.b)) != 0) {
            return n14;
        }
        int n36 = Boolean.valueOf((boolean)this.d()).compareTo(Boolean.valueOf((boolean)iq2.d()));
        if (n36 != 0) {
            return n36;
        }
        if (this.d() && (n8 = jc.a((String)this.c, (String)iq2.c)) != 0) {
            return n8;
        }
        int n37 = Boolean.valueOf((boolean)this.e()).compareTo(Boolean.valueOf((boolean)iq2.e()));
        if (n37 != 0) {
            return n37;
        }
        if (this.e() && (n5 = jc.a((String)this.d, (String)iq2.d)) != 0) {
            return n5;
        }
        int n38 = Boolean.valueOf((boolean)this.f()).compareTo(Boolean.valueOf((boolean)iq2.f()));
        if (n38 != 0) {
            return n38;
        }
        if (this.f() && (n24 = jc.a((String)this.e, (String)iq2.e)) != 0) {
            return n24;
        }
        int n39 = Boolean.valueOf((boolean)this.g()).compareTo(Boolean.valueOf((boolean)iq2.g()));
        if (n39 != 0) {
            return n39;
        }
        if (this.g() && (n26 = jc.a((String)this.f, (String)iq2.f)) != 0) {
            return n26;
        }
        int n40 = Boolean.valueOf((boolean)this.h()).compareTo(Boolean.valueOf((boolean)iq2.h()));
        if (n40 != 0) {
            return n40;
        }
        if (this.h() && (n6 = jc.a((String)this.g, (String)iq2.g)) != 0) {
            return n6;
        }
        int n41 = Boolean.valueOf((boolean)this.i()).compareTo(Boolean.valueOf((boolean)iq2.i()));
        if (n41 != 0) {
            return n41;
        }
        if (this.i() && (n19 = jc.a((String)this.h, (String)iq2.h)) != 0) {
            return n19;
        }
        int n42 = Boolean.valueOf((boolean)this.j()).compareTo(Boolean.valueOf((boolean)iq2.j()));
        if (n42 != 0) {
            return n42;
        }
        if (this.j() && (n25 = jc.a((String)this.i, (String)iq2.i)) != 0) {
            return n25;
        }
        int n43 = Boolean.valueOf((boolean)this.k()).compareTo(Boolean.valueOf((boolean)iq2.k()));
        if (n43 != 0) {
            return n43;
        }
        if (this.k() && (n18 = jc.a((String)this.j, (String)iq2.j)) != 0) {
            return n18;
        }
        int n44 = Boolean.valueOf((boolean)this.l()).compareTo(Boolean.valueOf((boolean)iq2.l()));
        if (n44 != 0) {
            return n44;
        }
        if (this.l() && (n10 = jc.a((String)this.k, (String)iq2.k)) != 0) {
            return n10;
        }
        int n45 = Boolean.valueOf((boolean)this.m()).compareTo(Boolean.valueOf((boolean)iq2.m()));
        if (n45 != 0) {
            return n45;
        }
        if (this.m() && (n31 = jc.a((int)this.a, (int)iq2.a)) != 0) {
            return n31;
        }
        int n46 = Boolean.valueOf((boolean)this.n()).compareTo(Boolean.valueOf((boolean)iq2.n()));
        if (n46 != 0) {
            return n46;
        }
        if (this.n() && (n7 = jc.a((int)this.b, (int)iq2.b)) != 0) {
            return n7;
        }
        int n47 = Boolean.valueOf((boolean)this.o()).compareTo(Boolean.valueOf((boolean)iq2.o()));
        if (n47 != 0) {
            return n47;
        }
        if (this.o() && (n29 = jc.a((String)this.l, (String)iq2.l)) != 0) {
            return n29;
        }
        int n48 = Boolean.valueOf((boolean)this.p()).compareTo(Boolean.valueOf((boolean)iq2.p()));
        if (n48 != 0) {
            return n48;
        }
        if (this.p() && (n9 = jc.a((String)this.m, (String)iq2.m)) != 0) {
            return n9;
        }
        int n49 = Boolean.valueOf((boolean)this.q()).compareTo(Boolean.valueOf((boolean)iq2.q()));
        if (n49 != 0) {
            return n49;
        }
        if (this.q() && (n13 = jc.a((String)this.n, (String)iq2.n)) != 0) {
            return n13;
        }
        int n50 = Boolean.valueOf((boolean)this.r()).compareTo(Boolean.valueOf((boolean)iq2.r()));
        if (n50 != 0) {
            return n50;
        }
        if (this.r() && (n23 = jc.a((String)this.o, (String)iq2.o)) != 0) {
            return n23;
        }
        int n51 = Boolean.valueOf((boolean)this.s()).compareTo(Boolean.valueOf((boolean)iq2.s()));
        if (n51 != 0) {
            return n51;
        }
        if (this.s() && (n32 = jc.a((int)this.c, (int)iq2.c)) != 0) {
            return n32;
        }
        int n52 = Boolean.valueOf((boolean)this.t()).compareTo(Boolean.valueOf((boolean)iq2.t()));
        if (n52 != 0) {
            return n52;
        }
        if (this.t() && (n12 = jc.a((Comparable)this.a, (Comparable)iq2.a)) != 0) {
            return n12;
        }
        int n53 = Boolean.valueOf((boolean)this.u()).compareTo(Boolean.valueOf((boolean)iq2.u()));
        if (n53 != 0) {
            return n53;
        }
        if (this.u() && (n30 = jc.a((boolean)this.a, (boolean)iq2.a)) != 0) {
            return n30;
        }
        int n54 = Boolean.valueOf((boolean)this.v()).compareTo(Boolean.valueOf((boolean)iq2.v()));
        if (n54 != 0) {
            return n54;
        }
        if (this.v() && (n11 = jc.a((long)this.a, (long)iq2.a)) != 0) {
            return n11;
        }
        int n55 = Boolean.valueOf((boolean)this.w()).compareTo(Boolean.valueOf((boolean)iq2.w()));
        if (n55 != 0) {
            return n55;
        }
        if (this.w() && (n15 = jc.a((long)this.b, (long)iq2.b)) != 0) {
            return n15;
        }
        int n56 = Boolean.valueOf((boolean)this.x()).compareTo(Boolean.valueOf((boolean)iq2.x()));
        if (n56 != 0) {
            return n56;
        }
        if (this.x() && (n21 = jc.a((String)this.p, (String)iq2.p)) != 0) {
            return n21;
        }
        int n57 = Boolean.valueOf((boolean)this.y()).compareTo(Boolean.valueOf((boolean)iq2.y()));
        if (n57 != 0) {
            return n57;
        }
        if (this.y() && (n16 = jc.a((String)this.q, (String)iq2.q)) != 0) {
            return n16;
        }
        int n58 = Boolean.valueOf((boolean)this.z()).compareTo(Boolean.valueOf((boolean)iq2.z()));
        if (n58 != 0) {
            return n58;
        }
        if (this.z() && (n22 = jc.a((Map)this.a, (Map)iq2.a)) != 0) {
            return n22;
        }
        int n59 = Boolean.valueOf((boolean)this.A()).compareTo(Boolean.valueOf((boolean)iq2.A()));
        if (n59 != 0) {
            return n59;
        }
        if (this.A() && (n28 = jc.a((boolean)this.b, (boolean)iq2.b)) != 0) {
            return n28;
        }
        int n60 = Boolean.valueOf((boolean)this.B()).compareTo(Boolean.valueOf((boolean)iq2.B()));
        if (n60 != 0) {
            return n60;
        }
        if (this.B() && (n27 = jc.a((String)this.r, (String)iq2.r)) != 0) {
            return n27;
        }
        return 0;
    }

    public iq a(int n5) {
        this.a = n5;
        this.a(true);
        return this;
    }

    public iq a(ie ie2) {
        this.a = ie2;
        return this;
    }

    public iq a(String string) {
        this.b = string;
        return this;
    }

    public String a() {
        return this.b;
    }

    public void a() {
        if (this.b != null) {
            if (this.c != null) {
                if (this.f != null) {
                    return;
                }
                StringBuilder stringBuilder = a.F1((String)"Required field 'token' was not present! Struct: ");
                stringBuilder.append(this.toString());
                throw new jn(stringBuilder.toString());
            }
            StringBuilder stringBuilder = a.F1((String)"Required field 'appId' was not present! Struct: ");
            stringBuilder.append(this.toString());
            throw new jn(stringBuilder.toString());
        }
        StringBuilder stringBuilder = a.F1((String)"Required field 'id' was not present! Struct: ");
        stringBuilder.append(this.toString());
        throw new jn(stringBuilder.toString());
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public void a(jm var1_1) {
        var1_1.a();
        do {
            block37 : {
                var3_2 = var1_1.a();
                var4_3 = var3_2.a;
                if (var4_3 == 0) {
                    var1_1.f();
                    this.a();
                    return;
                }
                var5_4 = var3_2.a;
                block0 : switch (var5_4) {
                    default: {
                        switch (var5_4) {
                            case 102: {
                                if (var4_3 == 11) {
                                    this.r = var1_1.a();
                                    ** break;
                                }
                                ** GOTO lbl23
                            }
                            case 101: {
                                if (var4_3 == 2) {
                                    this.b = var1_1.a();
                                    this.g(true);
                                    ** break;
                                }
                            }
lbl23: // 4 sources:
                            default: {
                                break block0;
                            }
                            case 100: 
                        }
                        if (var4_3 != 13) break;
                        var7_6 = var1_1.a();
                        this.a = new HashMap(2 * var7_6.a);
                        for (var8_7 = 0; var8_7 < var7_6.a; ++var8_7) {
                            var9_8 = var1_1.a();
                            var10_9 = var1_1.a();
                            this.a.put((Object)var9_8, (Object)var10_9);
                        }
                        var1_1.h();
                        ** break;
                    }
                    case 25: {
                        if (var4_3 != 11) break;
                        this.q = var1_1.a();
                        ** break;
                    }
                    case 24: {
                        if (var4_3 != 11) break;
                        this.p = var1_1.a();
                        ** break;
                    }
                    case 23: {
                        if (var4_3 != 10) break;
                        this.b = var1_1.a();
                        this.f(true);
                        ** break;
                    }
                    case 22: {
                        if (var4_3 != 10) break;
                        this.a = var1_1.a();
                        this.e(true);
                        ** break;
                    }
                    case 21: {
                        if (var4_3 != 2) break;
                        this.a = var1_1.a();
                        this.d(true);
                        ** break;
                    }
                    case 20: {
                        if (var4_3 != 8) break;
                        this.a = ie.a((int)var1_1.a());
                        ** break;
                    }
                    case 19: {
                        if (var4_3 != 8) break;
                        this.c = var1_1.a();
                        this.c(true);
                        ** break;
                    }
                    case 18: {
                        if (var4_3 != 11) break;
                        this.o = var1_1.a();
                        ** break;
                    }
                    case 17: {
                        if (var4_3 != 11) break;
                        this.n = var1_1.a();
                        ** break;
                    }
                    case 16: {
                        if (var4_3 != 11) break;
                        this.m = var1_1.a();
                        ** break;
                    }
                    case 15: {
                        if (var4_3 != 11) break;
                        this.l = var1_1.a();
                        ** break;
                    }
                    case 14: {
                        if (var4_3 != 8) break;
                        this.b = var1_1.a();
                        this.b(true);
                        ** break;
                    }
                    case 13: {
                        if (var4_3 != 8) break;
                        this.a = var1_1.a();
                        this.a(true);
                        ** break;
                    }
                    case 12: {
                        if (var4_3 != 11) break;
                        this.k = var1_1.a();
                        ** break;
                    }
                    case 11: {
                        if (var4_3 != 11) break;
                        this.j = var1_1.a();
                        ** break;
                    }
                    case 10: {
                        if (var4_3 != 11) break;
                        this.i = var1_1.a();
                        ** break;
                    }
                    case 9: {
                        if (var4_3 != 11) break;
                        this.h = var1_1.a();
                        ** break;
                    }
                    case 8: {
                        if (var4_3 != 11) break;
                        this.g = var1_1.a();
                        ** break;
                    }
                    case 7: {
                        if (var4_3 != 11) break;
                        this.f = var1_1.a();
                        ** break;
                    }
                    case 6: {
                        if (var4_3 != 11) break;
                        this.e = var1_1.a();
                        ** break;
                    }
                    case 5: {
                        if (var4_3 != 11) break;
                        this.d = var1_1.a();
                        ** break;
                    }
                    case 4: {
                        if (var4_3 != 11) break;
                        this.c = var1_1.a();
                        ** break;
                    }
                    case 3: {
                        if (var4_3 != 11) break;
                        this.b = var1_1.a();
                        ** break;
                    }
                    case 2: {
                        if (var4_3 != 12) break;
                        this.a = var6_5 = new if();
                        var6_5.a(var1_1);
                        ** break;
                    }
                    case 1: {
                        if (var4_3 != 11) break;
                        this.a = var1_1.a();
                        break block37;
                    }
                }
                jp.a((jm)var1_1, (byte)var4_3);
                ** break;
            }
            var1_1.g();
        } while (true);
    }

    public void a(boolean bl) {
        this.a.set(0, bl);
    }

    public boolean a() {
        return this.a != null;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public boolean a(iq iq2) {
        if (iq2 == null) {
            return false;
        }
        boolean bl = this.a();
        boolean bl2 = iq2.a();
        if (bl || bl2) {
            if (!bl) return false;
            if (!bl2) {
                return false;
            }
            if (!this.a.equals((Object)iq2.a)) {
                return false;
            }
        }
        boolean bl3 = this.b();
        boolean bl4 = iq2.b();
        if (bl3 || bl4) {
            if (!bl3) return false;
            if (!bl4) {
                return false;
            }
            if (!this.a.a(iq2.a)) {
                return false;
            }
        }
        boolean bl5 = this.c();
        boolean bl6 = iq2.c();
        if (bl5 || bl6) {
            if (!bl5) return false;
            if (!bl6) {
                return false;
            }
            if (!this.b.equals((Object)iq2.b)) {
                return false;
            }
        }
        boolean bl7 = this.d();
        boolean bl8 = iq2.d();
        if (bl7 || bl8) {
            if (!bl7) return false;
            if (!bl8) {
                return false;
            }
            if (!this.c.equals((Object)iq2.c)) {
                return false;
            }
        }
        boolean bl9 = this.e();
        boolean bl10 = iq2.e();
        if (bl9 || bl10) {
            if (!bl9) return false;
            if (!bl10) {
                return false;
            }
            if (!this.d.equals((Object)iq2.d)) {
                return false;
            }
        }
        boolean bl11 = this.f();
        boolean bl12 = iq2.f();
        if (bl11 || bl12) {
            if (!bl11) return false;
            if (!bl12) {
                return false;
            }
            if (!this.e.equals((Object)iq2.e)) {
                return false;
            }
        }
        boolean bl13 = this.g();
        boolean bl14 = iq2.g();
        if (bl13 || bl14) {
            if (!bl13) return false;
            if (!bl14) {
                return false;
            }
            if (!this.f.equals((Object)iq2.f)) {
                return false;
            }
        }
        boolean bl15 = this.h();
        boolean bl16 = iq2.h();
        if (bl15 || bl16) {
            if (!bl15) return false;
            if (!bl16) {
                return false;
            }
            if (!this.g.equals((Object)iq2.g)) {
                return false;
            }
        }
        boolean bl17 = this.i();
        boolean bl18 = iq2.i();
        if (bl17 || bl18) {
            if (!bl17) return false;
            if (!bl18) {
                return false;
            }
            if (!this.h.equals((Object)iq2.h)) {
                return false;
            }
        }
        boolean bl19 = this.j();
        boolean bl20 = iq2.j();
        if (bl19 || bl20) {
            if (!bl19) return false;
            if (!bl20) {
                return false;
            }
            if (!this.i.equals((Object)iq2.i)) {
                return false;
            }
        }
        boolean bl21 = this.k();
        boolean bl22 = iq2.k();
        if (bl21 || bl22) {
            if (!bl21) return false;
            if (!bl22) {
                return false;
            }
            if (!this.j.equals((Object)iq2.j)) {
                return false;
            }
        }
        boolean bl23 = this.l();
        boolean bl24 = iq2.l();
        if (bl23 || bl24) {
            if (!bl23) return false;
            if (!bl24) {
                return false;
            }
            if (!this.k.equals((Object)iq2.k)) {
                return false;
            }
        }
        boolean bl25 = this.m();
        boolean bl26 = iq2.m();
        if (bl25 || bl26) {
            if (!bl25) return false;
            if (!bl26) {
                return false;
            }
            if (this.a != iq2.a) {
                return false;
            }
        }
        boolean bl27 = this.n();
        boolean bl28 = iq2.n();
        if (bl27 || bl28) {
            if (!bl27) return false;
            if (!bl28) {
                return false;
            }
            if (this.b != iq2.b) {
                return false;
            }
        }
        boolean bl29 = this.o();
        boolean bl30 = iq2.o();
        if (bl29 || bl30) {
            if (!bl29) return false;
            if (!bl30) {
                return false;
            }
            if (!this.l.equals((Object)iq2.l)) {
                return false;
            }
        }
        boolean bl31 = this.p();
        boolean bl32 = iq2.p();
        if (bl31 || bl32) {
            if (!bl31) return false;
            if (!bl32) {
                return false;
            }
            if (!this.m.equals((Object)iq2.m)) {
                return false;
            }
        }
        boolean bl33 = this.q();
        boolean bl34 = iq2.q();
        if (bl33 || bl34) {
            if (!bl33) return false;
            if (!bl34) {
                return false;
            }
            if (!this.n.equals((Object)iq2.n)) {
                return false;
            }
        }
        boolean bl35 = this.r();
        boolean bl36 = iq2.r();
        if (bl35 || bl36) {
            if (!bl35) return false;
            if (!bl36) {
                return false;
            }
            if (!this.o.equals((Object)iq2.o)) {
                return false;
            }
        }
        boolean bl37 = this.s();
        boolean bl38 = iq2.s();
        if (bl37 || bl38) {
            if (!bl37) return false;
            if (!bl38) {
                return false;
            }
            if (this.c != iq2.c) {
                return false;
            }
        }
        boolean bl39 = this.t();
        boolean bl40 = iq2.t();
        if (bl39 || bl40) {
            if (!bl39) return false;
            if (!bl40) {
                return false;
            }
            if (!this.a.equals((Object)iq2.a)) {
                return false;
            }
        }
        boolean bl41 = this.u();
        boolean bl42 = iq2.u();
        if (bl41 || bl42) {
            if (!bl41) return false;
            if (!bl42) {
                return false;
            }
            if (this.a != iq2.a) {
                return false;
            }
        }
        boolean bl43 = this.v();
        boolean bl44 = iq2.v();
        if (bl43 || bl44) {
            if (!bl43) return false;
            if (!bl44) {
                return false;
            }
            if (this.a != iq2.a) {
                return false;
            }
        }
        boolean bl45 = this.w();
        boolean bl46 = iq2.w();
        if (bl45 || bl46) {
            if (!bl45) return false;
            if (!bl46) {
                return false;
            }
            if (this.b != iq2.b) {
                return false;
            }
        }
        boolean bl47 = this.x();
        boolean bl48 = iq2.x();
        if (bl47 || bl48) {
            if (!bl47) return false;
            if (!bl48) {
                return false;
            }
            if (!this.p.equals((Object)iq2.p)) {
                return false;
            }
        }
        boolean bl49 = this.y();
        boolean bl50 = iq2.y();
        if (bl49 || bl50) {
            if (!bl49) return false;
            if (!bl50) {
                return false;
            }
            if (!this.q.equals((Object)iq2.q)) {
                return false;
            }
        }
        boolean bl51 = this.z();
        boolean bl52 = iq2.z();
        if (bl51 || bl52) {
            if (!bl51) return false;
            if (!bl52) {
                return false;
            }
            if (!this.a.equals((Object)iq2.a)) {
                return false;
            }
        }
        boolean bl53 = this.A();
        boolean bl54 = iq2.A();
        if (bl53 || bl54) {
            if (!bl53) return false;
            if (!bl54) {
                return false;
            }
            if (this.b != iq2.b) {
                return false;
            }
        }
        boolean bl55 = this.B();
        boolean bl56 = iq2.B();
        if (!bl55 && !bl56) return true;
        if (!bl55) return false;
        if (!bl56) {
            return false;
        }
        if (this.r.equals((Object)iq2.r)) return true;
        return false;
    }

    public iq b(int n5) {
        this.b = n5;
        this.b(true);
        return this;
    }

    public iq b(String string) {
        this.c = string;
        return this;
    }

    public String b() {
        return this.c;
    }

    public void b(jm jm2) {
        this.a();
        jm2.a(a);
        if (this.a != null && this.a()) {
            jm2.a(a);
            jm2.a(this.a);
            jm2.b();
        }
        if (this.a != null && this.b()) {
            jm2.a(b);
            this.a.b(jm2);
            jm2.b();
        }
        if (this.b != null) {
            jm2.a(c);
            jm2.a(this.b);
            jm2.b();
        }
        if (this.c != null) {
            jm2.a(d);
            jm2.a(this.c);
            jm2.b();
        }
        if (this.d != null && this.e()) {
            jm2.a(e);
            jm2.a(this.d);
            jm2.b();
        }
        if (this.e != null && this.f()) {
            jm2.a(f);
            jm2.a(this.e);
            jm2.b();
        }
        if (this.f != null) {
            jm2.a(g);
            jm2.a(this.f);
            jm2.b();
        }
        if (this.g != null && this.h()) {
            jm2.a(h);
            jm2.a(this.g);
            jm2.b();
        }
        if (this.h != null && this.i()) {
            jm2.a(i);
            jm2.a(this.h);
            jm2.b();
        }
        if (this.i != null && this.j()) {
            jm2.a(j);
            jm2.a(this.i);
            jm2.b();
        }
        if (this.j != null && this.k()) {
            jm2.a(k);
            jm2.a(this.j);
            jm2.b();
        }
        if (this.k != null && this.l()) {
            jm2.a(l);
            jm2.a(this.k);
            jm2.b();
        }
        if (this.m()) {
            jm2.a(m);
            jm2.a(this.a);
            jm2.b();
        }
        if (this.n()) {
            jm2.a(n);
            jm2.a(this.b);
            jm2.b();
        }
        if (this.l != null && this.o()) {
            jm2.a(o);
            jm2.a(this.l);
            jm2.b();
        }
        if (this.m != null && this.p()) {
            jm2.a(p);
            jm2.a(this.m);
            jm2.b();
        }
        if (this.n != null && this.q()) {
            jm2.a(q);
            jm2.a(this.n);
            jm2.b();
        }
        if (this.o != null && this.r()) {
            jm2.a(r);
            jm2.a(this.o);
            jm2.b();
        }
        if (this.s()) {
            jm2.a(s);
            jm2.a(this.c);
            jm2.b();
        }
        if (this.a != null && this.t()) {
            jm2.a(t);
            jm2.a(this.a.a());
            jm2.b();
        }
        if (this.u()) {
            jm2.a(u);
            jm2.a(this.a);
            jm2.b();
        }
        if (this.v()) {
            jm2.a(v);
            jm2.a(this.a);
            jm2.b();
        }
        if (this.w()) {
            jm2.a(w);
            jm2.a(this.b);
            jm2.b();
        }
        if (this.p != null && this.x()) {
            jm2.a(x);
            jm2.a(this.p);
            jm2.b();
        }
        if (this.q != null && this.y()) {
            jm2.a(y);
            jm2.a(this.q);
            jm2.b();
        }
        if (this.a != null && this.z()) {
            jm2.a(z);
            jm2.a(new jl(11, 11, this.a.size()));
            for (Map.Entry entry : this.a.entrySet()) {
                jm2.a((String)entry.getKey());
                jm2.a((String)entry.getValue());
            }
            jm2.d();
            jm2.b();
        }
        if (this.A()) {
            jm2.a(A);
            jm2.a(this.b);
            jm2.b();
        }
        if (this.r != null && this.B()) {
            jm2.a(B);
            jm2.a(this.r);
            jm2.b();
        }
        jm2.c();
        jm2.a();
    }

    public void b(boolean bl) {
        this.a.set(1, bl);
    }

    public boolean b() {
        return this.a != null;
    }

    public iq c(int n5) {
        this.c = n5;
        this.c(true);
        return this;
    }

    public iq c(String string) {
        this.d = string;
        return this;
    }

    public String c() {
        return this.f;
    }

    public void c(boolean bl) {
        this.a.set(2, bl);
    }

    public boolean c() {
        return this.b != null;
    }

    public /* synthetic */ int compareTo(Object object) {
        return this.a((iq)object);
    }

    public iq d(String string) {
        this.e = string;
        return this;
    }

    public void d(boolean bl) {
        this.a.set(3, bl);
    }

    public boolean d() {
        return this.c != null;
    }

    public iq e(String string) {
        this.f = string;
        return this;
    }

    public void e(boolean bl) {
        this.a.set(4, bl);
    }

    public boolean e() {
        return this.d != null;
    }

    public boolean equals(Object object) {
        if (object == null) {
            return false;
        }
        if (object instanceof iq) {
            return this.a((iq)object);
        }
        return false;
    }

    public iq f(String string) {
        this.g = string;
        return this;
    }

    public void f(boolean bl) {
        this.a.set(5, bl);
    }

    public boolean f() {
        return this.e != null;
    }

    public iq g(String string) {
        this.h = string;
        return this;
    }

    public void g(boolean bl) {
        this.a.set(6, bl);
    }

    public boolean g() {
        return this.f != null;
    }

    public iq h(String string) {
        this.k = string;
        return this;
    }

    public boolean h() {
        return this.g != null;
    }

    public int hashCode() {
        return 0;
    }

    public iq i(String string) {
        this.l = string;
        return this;
    }

    public boolean i() {
        return this.h != null;
    }

    public iq j(String string) {
        this.n = string;
        return this;
    }

    public boolean j() {
        return this.i != null;
    }

    public iq k(String string) {
        this.o = string;
        return this;
    }

    public boolean k() {
        return this.j != null;
    }

    public boolean l() {
        return this.k != null;
    }

    public boolean m() {
        return this.a.get(0);
    }

    public boolean n() {
        return this.a.get(1);
    }

    public boolean o() {
        return this.l != null;
    }

    public boolean p() {
        return this.m != null;
    }

    public boolean q() {
        return this.n != null;
    }

    public boolean r() {
        return this.o != null;
    }

    public boolean s() {
        return this.a.get(2);
    }

    public boolean t() {
        return this.a != null;
    }

    public String toString() {
        boolean bl;
        boolean bl2;
        StringBuilder stringBuilder = new StringBuilder("XmPushActionRegistration(");
        if (this.a()) {
            stringBuilder.append("debug:");
            String string = this.a;
            if (string == null) {
                stringBuilder.append("null");
            } else {
                stringBuilder.append(string);
            }
            bl = false;
        } else {
            bl = true;
        }
        if (this.b()) {
            if (!bl) {
                stringBuilder.append(", ");
            }
            stringBuilder.append("target:");
            if if_ = this.a;
            if (if_ == null) {
                stringBuilder.append("null");
                bl2 = false;
            } else {
                stringBuilder.append((Object)if_);
                bl2 = false;
            }
        } else {
            bl2 = bl;
        }
        if (!bl2) {
            stringBuilder.append(", ");
        }
        stringBuilder.append("id:");
        String string = this.b;
        if (string == null) {
            stringBuilder.append("null");
        } else {
            stringBuilder.append(string);
        }
        stringBuilder.append(", ");
        stringBuilder.append("appId:");
        String string2 = this.c;
        if (string2 == null) {
            stringBuilder.append("null");
        } else {
            stringBuilder.append(string2);
        }
        if (this.e()) {
            stringBuilder.append(", ");
            stringBuilder.append("appVersion:");
            String string3 = this.d;
            if (string3 == null) {
                stringBuilder.append("null");
            } else {
                stringBuilder.append(string3);
            }
        }
        if (this.f()) {
            stringBuilder.append(", ");
            stringBuilder.append("packageName:");
            String string4 = this.e;
            if (string4 == null) {
                stringBuilder.append("null");
            } else {
                stringBuilder.append(string4);
            }
        }
        stringBuilder.append(", ");
        stringBuilder.append("token:");
        String string5 = this.f;
        if (string5 == null) {
            stringBuilder.append("null");
        } else {
            stringBuilder.append(string5);
        }
        if (this.h()) {
            stringBuilder.append(", ");
            stringBuilder.append("deviceId:");
            String string6 = this.g;
            if (string6 == null) {
                stringBuilder.append("null");
            } else {
                stringBuilder.append(string6);
            }
        }
        if (this.i()) {
            stringBuilder.append(", ");
            stringBuilder.append("aliasName:");
            String string7 = this.h;
            if (string7 == null) {
                stringBuilder.append("null");
            } else {
                stringBuilder.append(string7);
            }
        }
        if (this.j()) {
            stringBuilder.append(", ");
            stringBuilder.append("sdkVersion:");
            String string8 = this.i;
            if (string8 == null) {
                stringBuilder.append("null");
            } else {
                stringBuilder.append(string8);
            }
        }
        if (this.k()) {
            stringBuilder.append(", ");
            stringBuilder.append("regId:");
            String string9 = this.j;
            if (string9 == null) {
                stringBuilder.append("null");
            } else {
                stringBuilder.append(string9);
            }
        }
        if (this.l()) {
            stringBuilder.append(", ");
            stringBuilder.append("pushSdkVersionName:");
            String string10 = this.k;
            if (string10 == null) {
                stringBuilder.append("null");
            } else {
                stringBuilder.append(string10);
            }
        }
        if (this.m()) {
            stringBuilder.append(", ");
            stringBuilder.append("pushSdkVersionCode:");
            stringBuilder.append(this.a);
        }
        if (this.n()) {
            stringBuilder.append(", ");
            stringBuilder.append("appVersionCode:");
            stringBuilder.append(this.b);
        }
        if (this.o()) {
            stringBuilder.append(", ");
            stringBuilder.append("androidId:");
            String string11 = this.l;
            if (string11 == null) {
                stringBuilder.append("null");
            } else {
                stringBuilder.append(string11);
            }
        }
        if (this.p()) {
            stringBuilder.append(", ");
            stringBuilder.append("imei:");
            String string12 = this.m;
            if (string12 == null) {
                stringBuilder.append("null");
            } else {
                stringBuilder.append(string12);
            }
        }
        if (this.q()) {
            stringBuilder.append(", ");
            stringBuilder.append("serial:");
            String string13 = this.n;
            if (string13 == null) {
                stringBuilder.append("null");
            } else {
                stringBuilder.append(string13);
            }
        }
        if (this.r()) {
            stringBuilder.append(", ");
            stringBuilder.append("imeiMd5:");
            String string14 = this.o;
            if (string14 == null) {
                stringBuilder.append("null");
            } else {
                stringBuilder.append(string14);
            }
        }
        if (this.s()) {
            stringBuilder.append(", ");
            stringBuilder.append("spaceId:");
            stringBuilder.append(this.c);
        }
        if (this.t()) {
            stringBuilder.append(", ");
            stringBuilder.append("reason:");
            ie ie2 = this.a;
            if (ie2 == null) {
                stringBuilder.append("null");
            } else {
                stringBuilder.append((Object)ie2);
            }
        }
        if (this.u()) {
            stringBuilder.append(", ");
            stringBuilder.append("validateToken:");
            stringBuilder.append(this.a);
        }
        if (this.v()) {
            stringBuilder.append(", ");
            stringBuilder.append("miid:");
            stringBuilder.append(this.a);
        }
        if (this.w()) {
            stringBuilder.append(", ");
            stringBuilder.append("createdTs:");
            stringBuilder.append(this.b);
        }
        if (this.x()) {
            stringBuilder.append(", ");
            stringBuilder.append("subImei:");
            String string15 = this.p;
            if (string15 == null) {
                stringBuilder.append("null");
            } else {
                stringBuilder.append(string15);
            }
        }
        if (this.y()) {
            stringBuilder.append(", ");
            stringBuilder.append("subImeiMd5:");
            String string16 = this.q;
            if (string16 == null) {
                stringBuilder.append("null");
            } else {
                stringBuilder.append(string16);
            }
        }
        if (this.z()) {
            stringBuilder.append(", ");
            stringBuilder.append("connectionAttrs:");
            jj jj2 = this.a;
            if (jj2 == null) {
                stringBuilder.append("null");
            } else {
                stringBuilder.append((Object)jj2);
            }
        }
        if (this.A()) {
            stringBuilder.append(", ");
            stringBuilder.append("cleanOldRegInfo:");
            stringBuilder.append(this.b);
        }
        if (this.B()) {
            stringBuilder.append(", ");
            stringBuilder.append("oldRegId:");
            String string17 = this.r;
            if (string17 == null) {
                stringBuilder.append("null");
            } else {
                stringBuilder.append(string17);
            }
        }
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public boolean u() {
        return this.a.get(3);
    }

    public boolean v() {
        return this.a.get(4);
    }

    public boolean w() {
        return this.a.get(5);
    }

    public boolean x() {
        return this.p != null;
    }

    public boolean y() {
        return this.q != null;
    }

    public boolean z() {
        return this.a != null;
    }
}

