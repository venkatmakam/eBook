/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.NoSuchFieldError
 *  java.lang.Object
 */
package com.xiaomi.push;

import com.xiaomi.push.service.aq;

public class hf {
    public static final /* synthetic */ int[] a;

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static {
        aq.c.values();
        var1 = new int[3];
        hf.a = var1;
        try {
            var1[0] = 1;
        }
        catch (NoSuchFieldError v0) {}
        try {
            var7_1 = hf.a;
            var7_1[1] = 2;
            ** GOTO lbl-1000
        }
        catch (NoSuchFieldError v1) {
            try lbl-1000: // 2 sources:
            {
                var5_2 = hf.a;
                var5_2[2] = 3;
                return;
            }
            catch (NoSuchFieldError v2) {}
        }
    }
}

