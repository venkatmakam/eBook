/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.text.TextUtils
 *  com.xiaomi.channel.commonutils.logger.b
 *  com.xiaomi.push.hu
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.util.HashMap
 *  java.util.Map
 */
package com.xiaomi.push;

import android.content.Context;
import android.text.TextUtils;
import com.xiaomi.channel.commonutils.logger.b;
import com.xiaomi.push.hp;
import com.xiaomi.push.hu;
import com.xiaomi.push.service.bj;
import com.xiaomi.push.service.bk;
import java.util.HashMap;
import java.util.Map;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class ho {
    private static volatile ho a;
    private final Context a;
    private Map<String, hp> a = new HashMap();

    private ho(Context context) {
        this.a = context;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static ho a(Context context) {
        if (context == null) {
            b.d((String)"[TinyDataManager]:mContext is null, TinyDataManager.getInstance(Context) failed.");
            return null;
        }
        if (a != null) return a;
        Class<ho> class_ = ho.class;
        synchronized (ho.class) {
            if (a != null) return a;
            a = new ho(context);
            // ** MonitorExit[var2_1] (shouldn't be in output)
            return a;
        }
    }

    private boolean a(String string2, String string3, String string4, String string5, long l3, String string6) {
        hu hu2 = new hu();
        hu2.d(string4);
        hu2.c(string5);
        hu2.a(l3);
        hu2.b(string6);
        hu2.a(true);
        hu2.a("push_sdk_channel");
        hu2.e(string3);
        return this.a(hu2, string2);
    }

    /*
     * Enabled aggressive block sorting
     */
    public void a(hp hp2, String string2) {
        String string3;
        if (hp2 == null) {
            string3 = "[TinyDataManager]: please do not add null mUploader to TinyDataManager.";
        } else {
            if (!TextUtils.isEmpty((CharSequence)string2)) {
                this.a.put((Object)string2, (Object)hp2);
                return;
            }
            string3 = "[TinyDataManager]: can not add a provider from unkown resource.";
        }
        b.d((String)string3);
    }

    public boolean a(hu hu2, String string2) {
        if (TextUtils.isEmpty((CharSequence)string2)) {
            b.a((String)"pkgName is null or empty, upload ClientUploadDataItem failed.");
            return false;
        }
        if (bj.a(hu2, false)) {
            return false;
        }
        if (TextUtils.isEmpty((CharSequence)hu2.d())) {
            hu2.f(bj.a());
        }
        hu2.g(string2);
        bk.a(this.a, hu2);
        return true;
    }

    public boolean a(String string2, String string3, long l3, String string4) {
        return this.a(this.a.getPackageName(), this.a.getPackageName(), string2, string3, l3, string4);
    }

    public hp b() {
        hp hp2 = (hp)this.a.get((Object)"UPLOADER_PUSH_CHANNEL");
        if (hp2 != null) {
            return hp2;
        }
        hp hp3 = (hp)this.a.get((Object)"UPLOADER_HTTP");
        if (hp3 != null) {
            return hp3;
        }
        return null;
    }
}

