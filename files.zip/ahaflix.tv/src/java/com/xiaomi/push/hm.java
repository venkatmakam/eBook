/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  com.xiaomi.channel.commonutils.logger.b
 *  com.xiaomi.push.ai
 *  com.xiaomi.push.hl
 *  java.io.File
 *  java.io.IOException
 *  java.io.RandomAccessFile
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Throwable
 *  java.nio.channels.FileChannel
 *  java.nio.channels.FileLock
 */
package com.xiaomi.push;

import android.content.Context;
import android.content.SharedPreferences;
import com.xiaomi.channel.commonutils.logger.b;
import com.xiaomi.push.ai;
import com.xiaomi.push.hl;
import com.xiaomi.push.hp;
import com.xiaomi.push.service.bk;
import com.xiaomi.push.y;
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;

public class hm {
    private static boolean a;

    private static void a(Context context) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append((Object)context.getFilesDir());
        stringBuilder.append("/tdReadTemp");
        File file = new File(stringBuilder.toString());
        if (!file.exists()) {
            file.mkdirs();
        }
    }

    public static void a(Context context, hp hp2) {
        ai.a((Context)context).a((Runnable)new a(context, hp2));
    }

    /*
     * Exception decompiling
     */
    private static void a(Context var0, hp var1_1, File var2_2, byte[] var3_3) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [8[UNCONDITIONALDOLOOP]], but top level block is 2[TRYBLOCK]
        // org.benf.cfr.reader.b.a.a.j.a(Op04StructuredStatement.java:432)
        // org.benf.cfr.reader.b.a.a.j.d(Op04StructuredStatement.java:484)
        // org.benf.cfr.reader.b.a.a.i.a(Op03SimpleStatement.java:607)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:692)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    private static void b(Context context) {
        SharedPreferences.Editor editor = context.getSharedPreferences("mipush_extra", 4).edit();
        editor.putLong("last_tiny_data_upload_timestamp", System.currentTimeMillis() / 1000L);
        editor.commit();
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private static void c(Context context, hp hp2) {
        RandomAccessFile randomAccessFile;
        FileLock fileLock;
        void var8_16;
        block26 : {
            byte[] arrby;
            block23 : {
                void var16_10;
                block24 : {
                    void var6_13;
                    block25 : {
                        if (a) {
                            b.a((String)"TinyData extractTinyData is running");
                            return;
                        }
                        a = true;
                        File file = new File(context.getFilesDir(), "tiny_data.data");
                        if (!file.exists()) {
                            b.a((String)"TinyData no ready file to get data.");
                            return;
                        }
                        hm.a(context);
                        arrby = bk.a(context);
                        fileLock = null;
                        File file2 = new File(context.getFilesDir(), "tiny_data.lock");
                        y.a(file2);
                        randomAccessFile = new RandomAccessFile(file2, "rw");
                        try {
                            fileLock = randomAccessFile.getChannel().lock();
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append((Object)context.getFilesDir());
                            stringBuilder.append("/tdReadTemp");
                            stringBuilder.append("/");
                            stringBuilder.append("tiny_data.data");
                            file.renameTo(new File(stringBuilder.toString()));
                        }
                        catch (Exception exception) {
                            break block25;
                        }
                        if (fileLock != null && fileLock.isValid()) {
                            try {
                                fileLock.release();
                                break block23;
                            }
                            catch (IOException iOException) {
                                break block24;
                            }
                        }
                        break block23;
                        catch (Throwable throwable) {
                            fileLock = null;
                            randomAccessFile = null;
                            break block26;
                        }
                        catch (Exception exception) {
                            randomAccessFile = null;
                        }
                    }
                    b.a((Throwable)var6_13);
                    if (fileLock == null || !fileLock.isValid()) break block23;
                    try {
                        fileLock.release();
                        break block23;
                    }
                    catch (IOException iOException) {
                        // empty catch block
                    }
                }
                b.a((Throwable)var16_10);
            }
            y.a(randomAccessFile);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append((Object)context.getFilesDir());
            stringBuilder.append("/tdReadTemp");
            stringBuilder.append("/");
            stringBuilder.append("tiny_data.data");
            File file = new File(stringBuilder.toString());
            if (!file.exists()) {
                b.a((String)"TinyData no ready file to get data.");
                return;
            }
            hm.a(context, hp2, file, arrby);
            hl.a((boolean)false);
            hm.b(context);
            a = false;
            return;
            catch (Throwable throwable) {
                // empty catch block
            }
        }
        if (fileLock != null && fileLock.isValid()) {
            try {
                fileLock.release();
            }
            catch (IOException iOException) {
                b.a((Throwable)iOException);
            }
        }
        y.a(randomAccessFile);
        throw var8_16;
    }

    /*
     * Duplicate member names - consider using --renamedupmembers true
     */
    public static class a
    implements Runnable {
        private Context a;
        private hp a;

        public a(Context context, hp hp2) {
            this.a = hp2;
            this.a = context;
        }

        public void run() {
            hm.c(this.a, this.a);
        }
    }

}

