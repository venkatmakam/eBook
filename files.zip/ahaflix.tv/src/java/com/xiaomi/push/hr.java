/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.xiaomi.push;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class hr
extends Enum<hr> {
    public static final /* enum */ hr a;
    private static final /* synthetic */ hr[] a;
    public static final /* enum */ hr b;
    private final int a;

    public static {
        hr hr2;
        hr hr3;
        a = hr3 = new hr(0);
        b = hr2 = new hr(1);
        a = new hr[]{hr3, hr2};
    }

    private hr(int n5) {
        this.a = n5;
    }

    public static hr valueOf(String string2) {
        return (hr)Enum.valueOf(hr.class, (String)string2);
    }

    public static hr[] values() {
        return (hr[])a.clone();
    }

    public int a() {
        return this.a;
    }
}

