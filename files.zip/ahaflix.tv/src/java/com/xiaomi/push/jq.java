/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.xiaomi.push;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class jq {
    public final byte a;
    public final int a;

    public jq() {
        this(0, 0);
    }

    public jq(byte by, int n4) {
        this.a = by;
        this.a = n4;
    }
}

