/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  com.xiaomi.push.v
 *  java.io.File
 *  java.lang.Runnable
 */
package com.xiaomi.push;

import android.content.Context;
import com.xiaomi.push.v;
import java.io.File;

public final class w
extends v {
    public final /* synthetic */ Runnable b;

    public w(Context context, File file, Runnable runnable) {
        this.b = runnable;
        super(context, file, null);
    }

    public void a(Context context) {
        Runnable runnable = this.b;
        if (runnable != null) {
            runnable.run();
        }
    }
}

