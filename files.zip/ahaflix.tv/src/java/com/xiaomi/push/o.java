/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.xiaomi.push;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class o
extends Enum<o> {
    public static final /* enum */ o a;
    private static final /* synthetic */ o[] a;
    public static final /* enum */ o b;
    public static final /* enum */ o c;
    public static final /* enum */ o d;
    public static final /* enum */ o e;

    public static {
        o o2;
        o o3;
        o o4;
        o o6;
        o o7;
        a = o6 = new o();
        b = o4 = new o();
        c = o3 = new o();
        d = o2 = new o();
        e = o7 = new o();
        a = new o[]{o6, o4, o3, o2, o7};
    }

    public static o valueOf(String string2) {
        return (o)Enum.valueOf(o.class, (String)string2);
    }

    public static o[] values() {
        return (o[])a.clone();
    }
}

