/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.Serializable
 *  java.lang.Object
 */
package com.xiaomi.push;

import com.xiaomi.push.jm;
import com.xiaomi.push.jw;
import java.io.Serializable;

public interface jo
extends Serializable {
    public jm a(jw var1);
}

