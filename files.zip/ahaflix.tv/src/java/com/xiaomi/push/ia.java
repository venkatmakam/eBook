/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.xiaomi.push;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class ia
extends Enum<ia> {
    public static final /* enum */ ia A;
    public static final /* enum */ ia B;
    public static final /* enum */ ia C;
    public static final /* enum */ ia D;
    public static final /* enum */ ia E;
    public static final /* enum */ ia F;
    public static final /* enum */ ia G;
    public static final /* enum */ ia H;
    public static final /* enum */ ia I;
    public static final /* enum */ ia J;
    public static final /* enum */ ia K;
    public static final /* enum */ ia L;
    public static final /* enum */ ia M;
    public static final /* enum */ ia N;
    public static final /* enum */ ia O;
    public static final /* enum */ ia P;
    public static final /* enum */ ia Q;
    public static final /* enum */ ia R;
    public static final /* enum */ ia a;
    private static final /* synthetic */ ia[] a;
    public static final /* enum */ ia b;
    public static final /* enum */ ia c;
    public static final /* enum */ ia d;
    public static final /* enum */ ia e;
    public static final /* enum */ ia f;
    public static final /* enum */ ia g;
    public static final /* enum */ ia h;
    public static final /* enum */ ia i;
    public static final /* enum */ ia j;
    public static final /* enum */ ia k;
    public static final /* enum */ ia l;
    public static final /* enum */ ia m;
    public static final /* enum */ ia n;
    public static final /* enum */ ia o;
    public static final /* enum */ ia p;
    public static final /* enum */ ia q;
    public static final /* enum */ ia r;
    public static final /* enum */ ia s;
    public static final /* enum */ ia t;
    public static final /* enum */ ia u;
    public static final /* enum */ ia v;
    public static final /* enum */ ia w;
    public static final /* enum */ ia x;
    public static final /* enum */ ia y;
    public static final /* enum */ ia z;
    public final String a;

    public static {
        ia ia2;
        ia ia3;
        ia ia4;
        ia ia5;
        ia ia6;
        ia ia7;
        ia ia8;
        ia ia9;
        ia ia10;
        ia ia11;
        ia ia12;
        ia ia13;
        ia ia14;
        ia ia15;
        ia ia16;
        ia ia17;
        ia ia18;
        ia ia19;
        ia ia20;
        ia ia21;
        ia ia22;
        ia ia23;
        ia ia24;
        ia ia25;
        ia ia26;
        ia ia27;
        ia ia28;
        ia ia29;
        ia ia30;
        ia ia31;
        ia ia32;
        ia ia33;
        ia ia34;
        ia ia35;
        ia ia36;
        ia ia37;
        ia ia38;
        ia ia39;
        ia ia40;
        ia ia41;
        ia ia42;
        ia ia43;
        ia ia44;
        ia ia45;
        a = ia19 = new ia("INVALID");
        b = ia23 = new ia("bar:click");
        c = ia40 = new ia("bar:cancel");
        d = ia26 = new ia("app:open");
        e = ia14 = new ia("package uninstalled");
        f = ia41 = new ia("app_uninstalled");
        g = ia35 = new ia("client_info_update");
        h = ia11 = new ia("client_info_update_ok");
        i = ia43 = new ia("client_miid_update");
        j = ia33 = new ia("pull");
        k = ia13 = new ia("ios_sleep");
        l = ia4 = new ia("ios_wakeup");
        m = ia36 = new ia("awake_app");
        n = ia6 = new ia("normal_client_config_update");
        o = ia38 = new ia("custom_client_config_update");
        p = ia25 = new ia("daily_check_client_config");
        q = ia2 = new ia("data_collection");
        r = ia32 = new ia("registration id expired");
        s = ia10 = new ia("!!!MILINK CONNECTION DISABLED!!!");
        t = ia5 = new ia("package_unregistered");
        u = ia16 = new ia("decrypt_msg_fail");
        v = ia34 = new ia("sync_info");
        w = ia3 = new ia("sync_info_result");
        x = ia30 = new ia("force_sync");
        y = ia45 = new ia("upload_client_log");
        z = ia17 = new ia("notification_bar_info");
        A = ia31 = new ia("sync_miid");
        B = ia9 = new ia("upload");
        C = ia18 = new ia("clear_push_message");
        D = ia37 = new ia("disable_push");
        E = ia8 = new ia("enable_push");
        F = ia12 = new ia("client_ab_test");
        G = ia39 = new ia("awake_system_app");
        H = ia24 = new ia("awake_app_response");
        I = ia29 = new ia("hb_register");
        J = ia15 = new ia("hb_register_res");
        K = ia7 = new ia("hb_unregister");
        L = ia28 = new ia("hb_unregister_res");
        M = ia22 = new ia("3rd_party_reg_update");
        N = ia42 = new ia("vr_upload");
        O = ia27 = new ia("log_upload");
        P = ia21 = new ia("app_wakeup");
        Q = ia44 = new ia("app_sleep");
        R = ia20 = new ia("notification_switch");
        a = new ia[]{ia19, ia23, ia40, ia26, ia14, ia41, ia35, ia11, ia43, ia33, ia13, ia4, ia36, ia6, ia38, ia25, ia2, ia32, ia10, ia5, ia16, ia34, ia3, ia30, ia45, ia17, ia31, ia9, ia18, ia37, ia8, ia12, ia39, ia24, ia29, ia15, ia7, ia28, ia22, ia42, ia27, ia21, ia44, ia20};
    }

    private ia(String string3) {
        this.a = string3;
    }

    public static ia valueOf(String string2) {
        return (ia)Enum.valueOf(ia.class, (String)string2);
    }

    public static ia[] values() {
        return (ia[])a.clone();
    }

    public String toString() {
        return this.a;
    }
}

