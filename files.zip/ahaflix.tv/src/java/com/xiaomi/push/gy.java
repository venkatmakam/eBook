/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.xiaomi.push.bf
 *  java.lang.Character
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.Random
 */
package com.xiaomi.push;

import com.xiaomi.push.bf;
import java.util.Random;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class gy {
    private static Random a;
    private static final char[] a;
    private static final char[] b;
    private static final char[] c;
    private static final char[] d;
    private static final char[] e;
    private static char[] f;

    public static {
        a = "&quot;".toCharArray();
        b = "&apos;".toCharArray();
        c = "&amp;".toCharArray();
        d = "&lt;".toCharArray();
        e = "&gt;".toCharArray();
        a = new Random();
        f = "0123456789abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ".toCharArray();
    }

    public static String a(int n4) {
        if (n4 < 1) {
            return null;
        }
        char[] arrc = new char[n4];
        for (int i6 = 0; i6 < n4; ++i6) {
            arrc[i6] = f[a.nextInt(71)];
        }
        return new String(arrc);
    }

    public static String a(String string2) {
        int n4;
        if (string2 == null) {
            return null;
        }
        char[] arrc = string2.toCharArray();
        int n5 = arrc.length;
        StringBuilder stringBuilder = new StringBuilder((int)(1.3 * (double)n5));
        int n6 = 0;
        for (n4 = 0; n4 < n5; ++n4) {
            char c5 = arrc[n4];
            if (c5 > '>') continue;
            if (c5 == '<') {
                if (n4 > n6) {
                    stringBuilder.append(arrc, n6, n4 - n6);
                }
                n6 = n4 + 1;
                stringBuilder.append(d);
                continue;
            }
            if (c5 == '>') {
                if (n4 > n6) {
                    stringBuilder.append(arrc, n6, n4 - n6);
                }
                n6 = n4 + 1;
                stringBuilder.append(e);
                continue;
            }
            if (c5 == '&') {
                int n7;
                if (n4 > n6) {
                    stringBuilder.append(arrc, n6, n4 - n6);
                }
                if (n5 > (n7 = n4 + 5) && arrc[n4 + 1] == '#' && Character.isDigit((char)arrc[n4 + 2]) && Character.isDigit((char)arrc[n4 + 3]) && Character.isDigit((char)arrc[n4 + 4]) && arrc[n7] == ';') continue;
                n6 = n4 + 1;
                stringBuilder.append(c);
                continue;
            }
            if (c5 == '\"') {
                if (n4 > n6) {
                    stringBuilder.append(arrc, n6, n4 - n6);
                }
                n6 = n4 + 1;
                stringBuilder.append(a);
                continue;
            }
            if (c5 != '\'') continue;
            if (n4 > n6) {
                stringBuilder.append(arrc, n6, n4 - n6);
            }
            n6 = n4 + 1;
            stringBuilder.append(b);
        }
        if (n6 == 0) {
            return string2;
        }
        if (n4 > n6) {
            stringBuilder.append(arrc, n6, n4 - n6);
        }
        return stringBuilder.toString();
    }

    public static final String a(String string2, String string3, String string4) {
        if (string2 == null) {
            return null;
        }
        int n4 = string2.indexOf(string3, 0);
        if (n4 >= 0) {
            int n5;
            char[] arrc = string2.toCharArray();
            char[] arrc2 = string4.toCharArray();
            int n6 = string3.length();
            StringBuilder stringBuilder = new StringBuilder(arrc.length);
            stringBuilder.append(arrc, 0, n4);
            stringBuilder.append(arrc2);
            int n7 = n4 + n6;
            while ((n5 = string2.indexOf(string3, n7)) > 0) {
                stringBuilder.append(arrc, n7, n5 - n7);
                stringBuilder.append(arrc2);
                n7 = n5 + n6;
            }
            stringBuilder.append(arrc, n7, arrc.length - n7);
            string2 = stringBuilder.toString();
        }
        return string2;
    }

    public static String a(byte[] arrby) {
        return String.valueOf((char[])bf.a((byte[])arrby));
    }

    public static final String b(String string2) {
        return gy.a(gy.a(gy.a(gy.a(gy.a(string2, "&lt;", "<"), "&gt;", ">"), "&quot;", "\""), "&apos;", "'"), "&amp;", "&");
    }
}

