/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.xiaomi.push;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class hv
extends Enum<hv> {
    public static final /* enum */ hv A;
    public static final /* enum */ hv B;
    public static final /* enum */ hv C;
    public static final /* enum */ hv D;
    public static final /* enum */ hv E;
    public static final /* enum */ hv F;
    public static final /* enum */ hv G;
    public static final /* enum */ hv H;
    public static final /* enum */ hv I;
    public static final /* enum */ hv J;
    public static final /* enum */ hv K;
    public static final /* enum */ hv L;
    public static final /* enum */ hv M;
    public static final /* enum */ hv N;
    public static final /* enum */ hv O;
    public static final /* enum */ hv P;
    public static final /* enum */ hv Q;
    public static final /* enum */ hv R;
    public static final /* enum */ hv S;
    public static final /* enum */ hv T;
    public static final /* enum */ hv U;
    public static final /* enum */ hv V;
    public static final /* enum */ hv W;
    public static final /* enum */ hv X;
    public static final /* enum */ hv Y;
    public static final /* enum */ hv Z;
    public static final /* enum */ hv a;
    private static final /* synthetic */ hv[] a;
    public static final /* enum */ hv aA;
    public static final /* enum */ hv aB;
    public static final /* enum */ hv aC;
    public static final /* enum */ hv aD;
    public static final /* enum */ hv aE;
    public static final /* enum */ hv aF;
    public static final /* enum */ hv aG;
    public static final /* enum */ hv aH;
    public static final /* enum */ hv aI;
    public static final /* enum */ hv aJ;
    public static final /* enum */ hv aK;
    public static final /* enum */ hv aL;
    public static final /* enum */ hv aM;
    public static final /* enum */ hv aN;
    public static final /* enum */ hv aO;
    public static final /* enum */ hv aP;
    public static final /* enum */ hv aQ;
    public static final /* enum */ hv aR;
    public static final /* enum */ hv aS;
    public static final /* enum */ hv aT;
    public static final /* enum */ hv aU;
    public static final /* enum */ hv aV;
    public static final /* enum */ hv aW;
    public static final /* enum */ hv aX;
    public static final /* enum */ hv aY;
    public static final /* enum */ hv aZ;
    public static final /* enum */ hv aa;
    public static final /* enum */ hv ab;
    public static final /* enum */ hv ac;
    public static final /* enum */ hv ad;
    public static final /* enum */ hv ae;
    public static final /* enum */ hv af;
    public static final /* enum */ hv ag;
    public static final /* enum */ hv ah;
    public static final /* enum */ hv ai;
    public static final /* enum */ hv aj;
    public static final /* enum */ hv ak;
    public static final /* enum */ hv al;
    public static final /* enum */ hv am;
    public static final /* enum */ hv an;
    public static final /* enum */ hv ao;
    public static final /* enum */ hv ap;
    public static final /* enum */ hv aq;
    public static final /* enum */ hv ar;
    public static final /* enum */ hv as;
    public static final /* enum */ hv at;
    public static final /* enum */ hv au;
    public static final /* enum */ hv av;
    public static final /* enum */ hv aw;
    public static final /* enum */ hv ax;
    public static final /* enum */ hv ay;
    public static final /* enum */ hv az;
    public static final /* enum */ hv b;
    public static final /* enum */ hv ba;
    public static final /* enum */ hv bb;
    public static final /* enum */ hv bc;
    public static final /* enum */ hv bd;
    public static final /* enum */ hv be;
    public static final /* enum */ hv bf;
    public static final /* enum */ hv bg;
    public static final /* enum */ hv bh;
    public static final /* enum */ hv bi;
    public static final /* enum */ hv bj;
    public static final /* enum */ hv bk;
    public static final /* enum */ hv bl;
    public static final /* enum */ hv bm;
    public static final /* enum */ hv c;
    public static final /* enum */ hv d;
    public static final /* enum */ hv e;
    public static final /* enum */ hv f;
    public static final /* enum */ hv g;
    public static final /* enum */ hv h;
    public static final /* enum */ hv i;
    public static final /* enum */ hv j;
    public static final /* enum */ hv k;
    public static final /* enum */ hv l;
    public static final /* enum */ hv m;
    public static final /* enum */ hv n;
    public static final /* enum */ hv o;
    public static final /* enum */ hv p;
    public static final /* enum */ hv q;
    public static final /* enum */ hv r;
    public static final /* enum */ hv s;
    public static final /* enum */ hv t;
    public static final /* enum */ hv u;
    public static final /* enum */ hv v;
    public static final /* enum */ hv w;
    public static final /* enum */ hv x;
    public static final /* enum */ hv y;
    public static final /* enum */ hv z;
    private final int a;

    public static {
        a = new hv(1);
        b = new hv(2);
        c = new hv(3);
        d = new hv(4);
        e = new hv(5);
        f = new hv(6);
        g = new hv(7);
        h = new hv(8);
        i = new hv(9);
        j = new hv(10);
        k = new hv(11);
        l = new hv(12);
        m = new hv(13);
        n = new hv(14);
        o = new hv(15);
        p = new hv(16);
        q = new hv(17);
        r = new hv(18);
        s = new hv(19);
        t = new hv(20);
        u = new hv(21);
        v = new hv(22);
        w = new hv(23);
        x = new hv(24);
        y = new hv(25);
        z = new hv(26);
        A = new hv(27);
        B = new hv(28);
        C = new hv(29);
        D = new hv(30);
        E = new hv(31);
        F = new hv(32);
        G = new hv(33);
        H = new hv(34);
        I = new hv(35);
        J = new hv(36);
        K = new hv(37);
        L = new hv(38);
        M = new hv(39);
        N = new hv(40);
        O = new hv(41);
        P = new hv(42);
        Q = new hv(43);
        R = new hv(44);
        S = new hv(45);
        T = new hv(46);
        U = new hv(47);
        V = new hv(48);
        W = new hv(49);
        X = new hv(50);
        Y = new hv(51);
        Z = new hv(52);
        aa = new hv(53);
        ab = new hv(54);
        ac = new hv(55);
        ad = new hv(56);
        ae = new hv(57);
        af = new hv(58);
        ag = new hv(59);
        ah = new hv(60);
        ai = new hv(61);
        aj = new hv(62);
        ak = new hv(63);
        al = new hv(64);
        am = new hv(65);
        an = new hv(66);
        ao = new hv(67);
        ap = new hv(68);
        aq = new hv(69);
        ar = new hv(70);
        as = new hv(71);
        at = new hv(72);
        au = new hv(73);
        av = new hv(74);
        aw = new hv(75);
        ax = new hv(76);
        ay = new hv(77);
        az = new hv(78);
        aA = new hv(79);
        aB = new hv(80);
        aC = new hv(81);
        aD = new hv(82);
        aE = new hv(83);
        aF = new hv(84);
        aG = new hv(85);
        aH = new hv(86);
        aI = new hv(87);
        aJ = new hv(88);
        aK = new hv(94);
        aL = new hv(95);
        aM = new hv(96);
        aN = new hv(97);
        aO = new hv(98);
        aP = new hv(99);
        aQ = new hv(100);
        aR = new hv(101);
        aS = new hv(102);
        aT = new hv(103);
        aU = new hv(104);
        aV = new hv(105);
        aW = new hv(106);
        aX = new hv(107);
        aY = new hv(108);
        aZ = new hv(109);
        ba = new hv(110);
        bb = new hv(111);
        bc = new hv(112);
        bd = new hv(120);
        be = new hv(121);
        bf = new hv(122);
        bg = new hv(123);
        bh = new hv(124);
        bi = new hv(125);
        bj = new hv(1001);
        bk = new hv(1002);
        bl = new hv(1003);
        bm = new hv(1004);
        hv[] arrhv = new hv[]{a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p, q, r, s, t, u, v, w, x, y, z, A, B, C, D, E, F, G, H, I, J, K, L, M, N, O, P, Q, R, S, T, U, V, W, X, Y, Z, aa, ab, ac, ad, ae, af, ag, ah, ai, aj, ak, al, am, an, ao, ap, aq, ar, as, at, au, av, aw, ax, ay, az, aA, aB, aC, aD, aE, aF, aG, aH, aI, aJ, aK, aL, aM, aN, aO, aP, aQ, aR, aS, aT, aU, aV, aW, aX, aY, aZ, ba, bb, bc, bd, be, bf, bg, bh, bi, bj, bk, bl, bm};
        a = arrhv;
    }

    private hv(int n5) {
        this.a = n5;
    }

    public static hv valueOf(String string2) {
        return (hv)Enum.valueOf(hv.class, (String)string2);
    }

    public static hv[] values() {
        return (hv[])a.clone();
    }

    public int a() {
        return this.a;
    }
}

