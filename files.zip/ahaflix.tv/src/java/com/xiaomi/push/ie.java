/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.xiaomi.push;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class ie
extends Enum<ie> {
    public static final /* enum */ ie a;
    private static final /* synthetic */ ie[] a;
    public static final /* enum */ ie b;
    public static final /* enum */ ie c;
    private final int a;

    public static {
        ie ie2;
        ie ie3;
        ie ie4;
        a = ie3 = new ie(0);
        b = ie4 = new ie(1);
        c = ie2 = new ie(2);
        a = new ie[]{ie3, ie4, ie2};
    }

    private ie(int n5) {
        this.a = n5;
    }

    public static ie a(int n4) {
        if (n4 != 0) {
            if (n4 != 1) {
                if (n4 != 2) {
                    return null;
                }
                return c;
            }
            return b;
        }
        return a;
    }

    public static ie valueOf(String string2) {
        return (ie)Enum.valueOf(ie.class, (String)string2);
    }

    public static ie[] values() {
        return (ie[])a.clone();
    }

    public int a() {
        return this.a;
    }
}

