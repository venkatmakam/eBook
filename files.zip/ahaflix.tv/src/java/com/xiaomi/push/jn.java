/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.xiaomi.push.jg
 *  java.lang.String
 */
package com.xiaomi.push;

import com.xiaomi.push.jg;

public class jn
extends jg {
    public jn() {
    }

    public jn(int n5, String string) {
        super(string);
    }

    public jn(String string) {
        super(string);
    }
}

