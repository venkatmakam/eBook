/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.security.Key
 *  java.security.spec.AlgorithmParameterSpec
 *  javax.crypto.Cipher
 *  javax.crypto.spec.IvParameterSpec
 *  javax.crypto.spec.SecretKeySpec
 */
package com.xiaomi.push;

import java.security.Key;
import java.security.spec.AlgorithmParameterSpec;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class h {
    private static final byte[] a = new byte[]{100, 23, 84, 114, 72, 0, 4, 97, 73, 97, 2, 52, 84, 102, 18, 32};

    private static Cipher a(byte[] arrby, int n4) {
        SecretKeySpec secretKeySpec = new SecretKeySpec(arrby, "AES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(a);
        Cipher cipher = Cipher.getInstance((String)"AES/CBC/PKCS5Padding");
        cipher.init(n4, (Key)secretKeySpec, (AlgorithmParameterSpec)ivParameterSpec);
        return cipher;
    }

    public static byte[] a(byte[] arrby, byte[] arrby2) {
        return h.a(arrby, 2).doFinal(arrby2);
    }

    public static byte[] b(byte[] arrby, byte[] arrby2) {
        return h.a(arrby, 1).doFinal(arrby2);
    }
}

