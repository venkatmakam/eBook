/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.File
 *  java.io.FileFilter
 *  java.lang.Object
 */
package com.xiaomi.push;

import java.io.File;
import java.io.FileFilter;

public final class z
implements FileFilter {
    public boolean accept(File file) {
        return file.isDirectory();
    }
}

