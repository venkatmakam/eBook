/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.pm.ApplicationInfo
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.text.TextUtils
 *  com.xiaomi.channel.commonutils.logger.b
 *  com.xiaomi.push.bd
 *  e.a.a.a.a
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.ClassNotFoundException
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.lang.reflect.Field
 */
package com.xiaomi.push;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.os.Build;
import android.text.TextUtils;
import com.xiaomi.channel.commonutils.logger.b;
import com.xiaomi.push.bd;
import com.xiaomi.push.l;
import com.xiaomi.push.s;
import e.a.a.a.a;
import java.lang.reflect.Field;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class t {
    private static Context a;
    private static String a;

    public static int a() {
        Class<?> class_;
        block4 : {
            try {
                class_ = t.a(null, "miui.os.Build");
                if (!class_.getField("IS_STABLE_VERSION").getBoolean(null)) break block4;
                return 3;
            }
            catch (Exception exception) {
                return 0;
            }
        }
        boolean bl2 = class_.getField("IS_DEVELOPMENT_VERSION").getBoolean(null);
        if (bl2) {
            return 2;
        }
        return 1;
    }

    public static Context a() {
        return a;
    }

    /*
     * Exception decompiling
     */
    public static Class<?> a(Context var0, String var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl26.3 : FAKE_TRY : trying to set 0 previously set to 1
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static String a() {
        Class<t> class_ = t.class;
        synchronized (t.class) {
            String string2 = a;
            if (string2 != null) {
                // ** MonitorExit[var8] (shouldn't be in output)
                return string2;
            }
            String string3 = Build.VERSION.INCREMENTAL;
            if (t.a() <= 0) {
                String string4 = t.b();
                if (TextUtils.isEmpty((CharSequence)string4) && TextUtils.isEmpty((CharSequence)(string4 = t.c())) && TextUtils.isEmpty((CharSequence)(string4 = t.d()))) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(s.a("ro.product.brand", "Android"));
                    stringBuilder.append("_");
                    stringBuilder.append(string3);
                    string3 = String.valueOf((Object)stringBuilder.toString());
                } else {
                    string3 = string4;
                }
            }
            a = string3;
            // ** MonitorExit[var8] (shouldn't be in output)
            return string3;
        }
    }

    public static String a(Context context) {
        if (l.b()) {
            return "";
        }
        String string2 = (String)bd.a((String)"com.xiaomi.xmsf.helper.MIIDAccountHelper", (String)"getMIID", (Object[])new Object[]{context});
        if (TextUtils.isEmpty((CharSequence)string2)) {
            string2 = "0";
        }
        return string2;
    }

    public static void a(Context context) {
        a = context.getApplicationContext();
    }

    public static boolean a() {
        return TextUtils.equals((CharSequence)((String)bd.a((String)"android.os.SystemProperties", (String)"get", (Object[])new Object[]{"sys.boot_completed"})), (CharSequence)"1");
    }

    public static boolean a(Context context) {
        int n4;
        try {
            n4 = context.getApplicationInfo().flags;
        }
        catch (Exception exception) {
            b.a((Throwable)exception);
            return false;
        }
        int n5 = n4 & 2;
        boolean bl2 = false;
        if (n5 != 0) {
            bl2 = true;
        }
        return bl2;
    }

    private static String b() {
        String string2;
        a = string2 = s.a("ro.build.version.emui", "");
        return string2;
    }

    public static boolean b() {
        try {
            boolean bl2 = t.a(null, "miui.os.Build").getField("IS_GLOBAL_BUILD").getBoolean((Object)Boolean.FALSE);
            return bl2;
        }
        catch (Exception exception) {
            b.a((Throwable)exception);
            return false;
        }
        catch (ClassNotFoundException classNotFoundException) {
            b.d((String)"miui.os.Build ClassNotFound");
            return false;
        }
    }

    private static String c() {
        String string2 = s.a("ro.build.version.opporom", "");
        if (!TextUtils.isEmpty((CharSequence)string2) && !string2.startsWith("ColorOS_")) {
            a = a.h1((String)"ColorOS_", (String)string2);
        }
        return a;
    }

    private static String d() {
        String string2 = s.a("ro.vivo.os.version", "");
        if (!TextUtils.isEmpty((CharSequence)string2) && !string2.startsWith("FuntouchOS_")) {
            a = a.h1((String)"FuntouchOS_", (String)string2);
        }
        return a;
    }
}

