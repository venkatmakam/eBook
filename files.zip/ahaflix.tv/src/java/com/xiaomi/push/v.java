/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  java.io.File
 *  java.io.IOException
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.Throwable
 */
package com.xiaomi.push;

import android.content.Context;
import com.xiaomi.push.u;
import com.xiaomi.push.w;
import java.io.File;
import java.io.IOException;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public abstract class v
implements Runnable {
    private Context a;
    private File a;
    private Runnable a;

    private v(Context context, File file) {
        this.a = context;
        this.a = file;
    }

    public /* synthetic */ v(Context context, File file, w w3) {
        this(context, file);
    }

    public static void a(Context context, File file, Runnable runnable) {
        new w(context, file, runnable).run();
    }

    public abstract void a(Context var1);

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void run() {
        Throwable throwable22;
        u u3;
        block7 : {
            u3 = null;
            try {
                try {
                    File file = this.a;
                    u3 = null;
                    if (file == null) {
                        this.a = new File(this.a.getFilesDir(), "default_locker");
                    }
                    u3 = u.a(this.a, this.a);
                    Runnable runnable = this.a;
                    if (runnable != null) {
                        runnable.run();
                    }
                    this.a(this.a);
                    if (u3 == null) break block7;
                }
                catch (IOException iOException) {
                    iOException.printStackTrace();
                    if (u3 == null) break block7;
                }
            }
            catch (Throwable throwable22) {}
            u3.a();
        }
        return;
        if (u3 != null) {
            u3.a();
        }
        throw throwable22;
    }
}

