/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.xiaomi.push.je
 *  com.xiaomi.push.jw
 *  java.lang.Object
 *  java.lang.System
 */
package com.xiaomi.push;

import com.xiaomi.push.je;
import com.xiaomi.push.jw;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class ju
extends jw {
    private int a;
    private je a;

    public ju(int n5) {
        this.a = new je(n5);
    }

    public int a(byte[] arrby, int n5, int n6) {
        byte[] arrby2 = this.a.a();
        if (n6 > this.a.a() - this.a) {
            n6 = this.a.a() - this.a;
        }
        if (n6 > 0) {
            System.arraycopy((Object)arrby2, (int)this.a, (Object)arrby, (int)n5, (int)n6);
            this.a = n6 + this.a;
        }
        return n6;
    }

    public void a(byte[] arrby, int n5, int n6) {
        this.a.write(arrby, n5, n6);
    }

    public int a_() {
        return this.a.size();
    }
}

