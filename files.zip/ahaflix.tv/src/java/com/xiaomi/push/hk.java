/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.xiaomi.channel.commonutils.logger.b
 *  com.xiaomi.push.fl
 *  com.xiaomi.push.fm
 *  com.xiaomi.push.fn
 *  com.xiaomi.push.hd
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 *  java.util.Hashtable
 */
package com.xiaomi.push;

import com.xiaomi.channel.commonutils.logger.b;
import com.xiaomi.push.fl;
import com.xiaomi.push.fm;
import com.xiaomi.push.fn;
import com.xiaomi.push.hd;
import com.xiaomi.push.hg;
import com.xiaomi.push.hi;
import com.xiaomi.push.ja;
import com.xiaomi.push.service.XMPushService;
import com.xiaomi.push.service.aq;
import java.util.Hashtable;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class hk {
    private static final int a = fl.c.a();

    public static void a() {
        hk.a(0, a);
    }

    public static void a(int n4) {
        fm fm2 = hi.a().b();
        fm2.a(fl.ac.a());
        fm2.c(n4);
        hi.a().d(fm2);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static void a(int n4, int n5) {
        Class<hk> class_ = hk.class;
        synchronized (hk.class) {
            if (n5 < 16777215) {
                int n6 = n5 | n4 << 24;
                a.a.put((Object)n6, (Object)System.currentTimeMillis());
            } else {
                b.d((String)"stats key should less than 16777215");
            }
            // ** MonitorExit[var5_2] (shouldn't be in output)
            return;
        }
    }

    public static void a(int n4, int n5, int n6, String string2, int n7) {
        fm fm2 = hi.a().b();
        fm2.a((byte)n4);
        fm2.a(n5);
        fm2.b(n6);
        fm2.b(string2);
        fm2.c(n7);
        hi.a().d(fm2);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static void a(int n4, int n5, String string2, int n6) {
        Class<hk> class_ = hk.class;
        synchronized (hk.class) {
            long l3 = System.currentTimeMillis();
            int n7 = n5 | n4 << 24;
            if (a.a.containsKey((Object)n7)) {
                fm fm2 = hi.a().b();
                fm2.a(n5);
                fm2.b((int)(l3 - (Long)a.a.get((Object)n7)));
                fm2.b(string2);
                if (n6 > -1) {
                    fm2.c(n6);
                }
                hi.a().d(fm2);
                a.a.remove((Object)n5);
            } else {
                b.d((String)"stats key not found");
            }
            // ** MonitorExit[var14_4] (shouldn't be in output)
            return;
        }
    }

    public static void a(XMPushService xMPushService, aq.b b7) {
        new hd(xMPushService, b7).a();
    }

    public static void a(String string2, int n4, Exception exception) {
        fm fm2 = hi.a().b();
        if (n4 > 0) {
            fm2.a(fl.i.a());
            fm2.b(string2);
            fm2.b(n4);
            hi.a().d(fm2);
            return;
        }
        try {
            hg.a a2 = hg.b(exception);
            fm2.a(a2.a.a());
            fm2.c(a2.b);
            fm2.b(string2);
            hi.a().d(fm2);
        }
        catch (NullPointerException nullPointerException) {}
    }

    public static void a(String string2, Exception exception) {
        try {
            hg.a a2 = hg.c(exception);
            fm fm2 = hi.a().b();
            fm2.a(a2.a.a());
            fm2.c(a2.b);
            fm2.b(string2);
            hi.a().d(fm2);
        }
        catch (NullPointerException nullPointerException) {}
    }

    public static byte[] a() {
        fn fn2 = hi.a().c();
        if (fn2 != null) {
            return ja.a(fn2);
        }
        return null;
    }

    public static void b() {
        hk.a(0, a, null, -1);
    }

    public static void b(String string2, Exception exception) {
        try {
            hg.a a2 = hg.e(exception);
            fm fm2 = hi.a().b();
            fm2.a(a2.a.a());
            fm2.c(a2.b);
            fm2.b(string2);
            hi.a().d(fm2);
        }
        catch (NullPointerException nullPointerException) {}
    }

    public static class a {
        public static Hashtable<Integer, Long> a = new Hashtable();
    }

}

