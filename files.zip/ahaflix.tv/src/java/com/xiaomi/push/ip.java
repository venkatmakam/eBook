/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.xiaomi.push.if
 *  com.xiaomi.push.jb
 *  com.xiaomi.push.jc
 *  com.xiaomi.push.jj
 *  com.xiaomi.push.jl
 *  com.xiaomi.push.jm
 *  com.xiaomi.push.jp
 *  com.xiaomi.push.jr
 *  e.a.a.a.a
 *  java.io.Serializable
 *  java.lang.Boolean
 *  java.lang.Class
 *  java.lang.Cloneable
 *  java.lang.Comparable
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.nio.ByteBuffer
 *  java.util.BitSet
 *  java.util.HashMap
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 */
package com.xiaomi.push;

import com.xiaomi.push.if;
import com.xiaomi.push.jb;
import com.xiaomi.push.jc;
import com.xiaomi.push.jj;
import com.xiaomi.push.jl;
import com.xiaomi.push.jm;
import com.xiaomi.push.jn;
import com.xiaomi.push.jp;
import com.xiaomi.push.jr;
import e.a.a.a.a;
import java.io.Serializable;
import java.nio.ByteBuffer;
import java.util.BitSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class ip
implements jb<ip, Object>,
Serializable,
Cloneable {
    private static final jj a;
    private static final jr a;
    private static final jj b;
    private static final jj c;
    private static final jj d;
    private static final jj e;
    private static final jj f;
    private static final jj g;
    private static final jj h;
    private static final jj i;
    private static final jj j;
    private static final jj k;
    private static final jj l;
    private static final jj m;
    private static final jj n;
    private static final jj o;
    public long a;
    public if a;
    public String a;
    public ByteBuffer a;
    private BitSet a;
    public Map<String, String> a;
    public boolean a = true;
    public String b;
    public boolean b = false;
    public String c;
    public String d;
    public String e;
    public String f;
    public String g;
    public String h;
    public String i;

    public static {
        a = new jr("XmPushActionNotification");
        a = new jj("", 11, 1);
        b = new jj("", 12, 2);
        c = new jj("", 11, 3);
        d = new jj("", 11, 4);
        e = new jj("", 11, 5);
        f = new jj("", 2, 6);
        g = new jj("", 11, 7);
        h = new jj("", 13, 8);
        i = new jj("", 11, 9);
        j = new jj("", 11, 10);
        k = new jj("", 11, 12);
        l = new jj("", 11, 13);
        m = new jj("", 11, 14);
        n = new jj("", 10, 15);
        o = new jj("", 2, 20);
    }

    public ip() {
    }

    public ip(String string, boolean bl) {
        this();
        this.b = string;
        this.a = bl;
        this.a(true);
    }

    public int a(ip ip2) {
        int n5;
        int n6;
        int n7;
        int n8;
        int n9;
        int n10;
        int n11;
        int n12;
        int n13;
        int n14;
        int n15;
        int n16;
        int n17;
        int n18;
        int n19;
        if (!this.getClass().equals((Object)ip2.getClass())) {
            return this.getClass().getName().compareTo(ip2.getClass().getName());
        }
        int n20 = Boolean.valueOf((boolean)this.a()).compareTo(Boolean.valueOf((boolean)ip2.a()));
        if (n20 != 0) {
            return n20;
        }
        if (this.a() && (n12 = jc.a((String)this.a, (String)ip2.a)) != 0) {
            return n12;
        }
        int n21 = Boolean.valueOf((boolean)this.b()).compareTo(Boolean.valueOf((boolean)ip2.b()));
        if (n21 != 0) {
            return n21;
        }
        if (this.b() && (n10 = jc.a((Comparable)this.a, (Comparable)ip2.a)) != 0) {
            return n10;
        }
        int n22 = Boolean.valueOf((boolean)this.c()).compareTo(Boolean.valueOf((boolean)ip2.c()));
        if (n22 != 0) {
            return n22;
        }
        if (this.c() && (n19 = jc.a((String)this.b, (String)ip2.b)) != 0) {
            return n19;
        }
        int n23 = Boolean.valueOf((boolean)this.d()).compareTo(Boolean.valueOf((boolean)ip2.d()));
        if (n23 != 0) {
            return n23;
        }
        if (this.d() && (n18 = jc.a((String)this.c, (String)ip2.c)) != 0) {
            return n18;
        }
        int n24 = Boolean.valueOf((boolean)this.e()).compareTo(Boolean.valueOf((boolean)ip2.e()));
        if (n24 != 0) {
            return n24;
        }
        if (this.e() && (n14 = jc.a((String)this.d, (String)ip2.d)) != 0) {
            return n14;
        }
        int n25 = Boolean.valueOf((boolean)this.f()).compareTo(Boolean.valueOf((boolean)ip2.f()));
        if (n25 != 0) {
            return n25;
        }
        if (this.f() && (n5 = jc.a((boolean)this.a, (boolean)ip2.a)) != 0) {
            return n5;
        }
        int n26 = Boolean.valueOf((boolean)this.g()).compareTo(Boolean.valueOf((boolean)ip2.g()));
        if (n26 != 0) {
            return n26;
        }
        if (this.g() && (n17 = jc.a((String)this.e, (String)ip2.e)) != 0) {
            return n17;
        }
        int n27 = Boolean.valueOf((boolean)this.h()).compareTo(Boolean.valueOf((boolean)ip2.h()));
        if (n27 != 0) {
            return n27;
        }
        if (this.h() && (n15 = jc.a((Map)this.a, (Map)ip2.a)) != 0) {
            return n15;
        }
        int n28 = Boolean.valueOf((boolean)this.i()).compareTo(Boolean.valueOf((boolean)ip2.i()));
        if (n28 != 0) {
            return n28;
        }
        if (this.i() && (n8 = jc.a((String)this.f, (String)ip2.f)) != 0) {
            return n8;
        }
        int n29 = Boolean.valueOf((boolean)this.j()).compareTo(Boolean.valueOf((boolean)ip2.j()));
        if (n29 != 0) {
            return n29;
        }
        if (this.j() && (n16 = jc.a((String)this.g, (String)ip2.g)) != 0) {
            return n16;
        }
        int n30 = Boolean.valueOf((boolean)this.k()).compareTo(Boolean.valueOf((boolean)ip2.k()));
        if (n30 != 0) {
            return n30;
        }
        if (this.k() && (n7 = jc.a((String)this.h, (String)ip2.h)) != 0) {
            return n7;
        }
        int n31 = Boolean.valueOf((boolean)this.l()).compareTo(Boolean.valueOf((boolean)ip2.l()));
        if (n31 != 0) {
            return n31;
        }
        if (this.l() && (n6 = jc.a((String)this.i, (String)ip2.i)) != 0) {
            return n6;
        }
        int n32 = Boolean.valueOf((boolean)this.m()).compareTo(Boolean.valueOf((boolean)ip2.m()));
        if (n32 != 0) {
            return n32;
        }
        if (this.m() && (n11 = jc.a((Comparable)this.a, (Comparable)ip2.a)) != 0) {
            return n11;
        }
        int n33 = Boolean.valueOf((boolean)this.n()).compareTo(Boolean.valueOf((boolean)ip2.n()));
        if (n33 != 0) {
            return n33;
        }
        if (this.n() && (n9 = jc.a((long)this.a, (long)ip2.a)) != 0) {
            return n9;
        }
        int n34 = Boolean.valueOf((boolean)this.o()).compareTo(Boolean.valueOf((boolean)ip2.o()));
        if (n34 != 0) {
            return n34;
        }
        if (this.o() && (n13 = jc.a((boolean)this.b, (boolean)ip2.b)) != 0) {
            return n13;
        }
        return 0;
    }

    public ip a(String string) {
        this.b = string;
        return this;
    }

    public ip a(ByteBuffer byteBuffer) {
        this.a = byteBuffer;
        return this;
    }

    public ip a(Map<String, String> map) {
        this.a = map;
        return this;
    }

    public ip a(boolean bl) {
        this.a = bl;
        this.a(true);
        return this;
    }

    public ip a(byte[] arrby) {
        this.a(ByteBuffer.wrap((byte[])arrby));
        return this;
    }

    public String a() {
        return this.b;
    }

    public Map<String, String> a() {
        return this.a;
    }

    public void a() {
        if (this.b != null) {
            return;
        }
        StringBuilder stringBuilder = a.F1((String)"Required field 'id' was not present! Struct: ");
        stringBuilder.append(this.toString());
        throw new jn(stringBuilder.toString());
    }

    public void a(jm jm2) {
        jm2.a();
        do {
            block21 : {
                jj jj2 = jm2.a();
                byte by = jj2.a;
                if (by == 0) {
                    jm2.f();
                    if (this.f()) {
                        this.a();
                        return;
                    }
                    StringBuilder stringBuilder = a.F1((String)"Required field 'requireAck' was not found in serialized data! Struct: ");
                    stringBuilder.append(this.toString());
                    throw new jn(stringBuilder.toString());
                }
                switch (jj2.a) {
                    default: {
                        break;
                    }
                    case 20: {
                        if (by != 2) break;
                        this.b = jm2.a();
                        this.c(true);
                        break block21;
                    }
                    case 15: {
                        if (by != 10) break;
                        this.a = jm2.a();
                        this.b(true);
                        break block21;
                    }
                    case 14: {
                        if (by != 11) break;
                        this.a = jm2.a();
                        break block21;
                    }
                    case 13: {
                        if (by != 11) break;
                        this.i = jm2.a();
                        break block21;
                    }
                    case 12: {
                        if (by != 11) break;
                        this.h = jm2.a();
                        break block21;
                    }
                    case 10: {
                        if (by != 11) break;
                        this.g = jm2.a();
                        break block21;
                    }
                    case 9: {
                        if (by != 11) break;
                        this.f = jm2.a();
                        break block21;
                    }
                    case 8: {
                        if (by != 13) break;
                        jl jl2 = jm2.a();
                        this.a = new HashMap(2 * jl2.a);
                        for (int i5 = 0; i5 < jl2.a; ++i5) {
                            String string = jm2.a();
                            String string2 = jm2.a();
                            this.a.put((Object)string, (Object)string2);
                        }
                        jm2.h();
                        break block21;
                    }
                    case 7: {
                        if (by != 11) break;
                        this.e = jm2.a();
                        break block21;
                    }
                    case 6: {
                        if (by != 2) break;
                        this.a = jm2.a();
                        this.a(true);
                        break block21;
                    }
                    case 5: {
                        if (by != 11) break;
                        this.d = jm2.a();
                        break block21;
                    }
                    case 4: {
                        if (by != 11) break;
                        this.c = jm2.a();
                        break block21;
                    }
                    case 3: {
                        if (by != 11) break;
                        this.b = jm2.a();
                        break block21;
                    }
                    case 2: {
                        if if_;
                        if (by != 12) break;
                        this.a = if_ = new if();
                        if_.a(jm2);
                        break block21;
                    }
                    case 1: {
                        if (by != 11) break;
                        this.a = jm2.a();
                        break block21;
                    }
                }
                jp.a((jm)jm2, (byte)by);
            }
            jm2.g();
        } while (true);
    }

    public void a(String string, String string2) {
        if (this.a == null) {
            this.a = new HashMap();
        }
        this.a.put((Object)string, (Object)string2);
    }

    public void a(boolean bl) {
        this.a.set(0, bl);
    }

    public boolean a() {
        return this.a != null;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public boolean a(ip ip2) {
        if (ip2 == null) {
            return false;
        }
        boolean bl = this.a();
        boolean bl2 = ip2.a();
        if (bl || bl2) {
            if (!bl) return false;
            if (!bl2) {
                return false;
            }
            if (!this.a.equals((Object)ip2.a)) {
                return false;
            }
        }
        boolean bl3 = this.b();
        boolean bl4 = ip2.b();
        if (bl3 || bl4) {
            if (!bl3) return false;
            if (!bl4) {
                return false;
            }
            if (!this.a.a(ip2.a)) {
                return false;
            }
        }
        boolean bl5 = this.c();
        boolean bl6 = ip2.c();
        if (bl5 || bl6) {
            if (!bl5) return false;
            if (!bl6) {
                return false;
            }
            if (!this.b.equals((Object)ip2.b)) {
                return false;
            }
        }
        boolean bl7 = this.d();
        boolean bl8 = ip2.d();
        if (bl7 || bl8) {
            if (!bl7) return false;
            if (!bl8) {
                return false;
            }
            if (!this.c.equals((Object)ip2.c)) {
                return false;
            }
        }
        boolean bl9 = this.e();
        boolean bl10 = ip2.e();
        if (bl9 || bl10) {
            if (!bl9) return false;
            if (!bl10) {
                return false;
            }
            if (!this.d.equals((Object)ip2.d)) {
                return false;
            }
        }
        if (this.a != ip2.a) {
            return false;
        }
        boolean bl11 = this.g();
        boolean bl12 = ip2.g();
        if (bl11 || bl12) {
            if (!bl11) return false;
            if (!bl12) {
                return false;
            }
            if (!this.e.equals((Object)ip2.e)) {
                return false;
            }
        }
        boolean bl13 = this.h();
        boolean bl14 = ip2.h();
        if (bl13 || bl14) {
            if (!bl13) return false;
            if (!bl14) {
                return false;
            }
            if (!this.a.equals((Object)ip2.a)) {
                return false;
            }
        }
        boolean bl15 = this.i();
        boolean bl16 = ip2.i();
        if (bl15 || bl16) {
            if (!bl15) return false;
            if (!bl16) {
                return false;
            }
            if (!this.f.equals((Object)ip2.f)) {
                return false;
            }
        }
        boolean bl17 = this.j();
        boolean bl18 = ip2.j();
        if (bl17 || bl18) {
            if (!bl17) return false;
            if (!bl18) {
                return false;
            }
            if (!this.g.equals((Object)ip2.g)) {
                return false;
            }
        }
        boolean bl19 = this.k();
        boolean bl20 = ip2.k();
        if (bl19 || bl20) {
            if (!bl19) return false;
            if (!bl20) {
                return false;
            }
            if (!this.h.equals((Object)ip2.h)) {
                return false;
            }
        }
        boolean bl21 = this.l();
        boolean bl22 = ip2.l();
        if (bl21 || bl22) {
            if (!bl21) return false;
            if (!bl22) {
                return false;
            }
            if (!this.i.equals((Object)ip2.i)) {
                return false;
            }
        }
        boolean bl23 = this.m();
        boolean bl24 = ip2.m();
        if (bl23 || bl24) {
            if (!bl23) return false;
            if (!bl24) {
                return false;
            }
            if (!this.a.equals((Object)ip2.a)) {
                return false;
            }
        }
        boolean bl25 = this.n();
        boolean bl26 = ip2.n();
        if (bl25 || bl26) {
            if (!bl25) return false;
            if (!bl26) {
                return false;
            }
            if (this.a != ip2.a) {
                return false;
            }
        }
        boolean bl27 = this.o();
        boolean bl28 = ip2.o();
        if (!bl27 && !bl28) return true;
        if (!bl27) return false;
        if (!bl28) {
            return false;
        }
        if (this.b == ip2.b) return true;
        return false;
    }

    public byte[] a() {
        this.a(jc.a((ByteBuffer)this.a));
        return this.a.array();
    }

    public ip b(String string) {
        this.c = string;
        return this;
    }

    public String b() {
        return this.c;
    }

    public void b(jm jm2) {
        this.a();
        jm2.a(a);
        if (this.a != null && this.a()) {
            jm2.a(a);
            jm2.a(this.a);
            jm2.b();
        }
        if (this.a != null && this.b()) {
            jm2.a(b);
            this.a.b(jm2);
            jm2.b();
        }
        if (this.b != null) {
            jm2.a(c);
            jm2.a(this.b);
            jm2.b();
        }
        if (this.c != null && this.d()) {
            jm2.a(d);
            jm2.a(this.c);
            jm2.b();
        }
        if (this.d != null && this.e()) {
            jm2.a(e);
            jm2.a(this.d);
            jm2.b();
        }
        jm2.a(f);
        jm2.a(this.a);
        jm2.b();
        if (this.e != null && this.g()) {
            jm2.a(g);
            jm2.a(this.e);
            jm2.b();
        }
        if (this.a != null && this.h()) {
            jm2.a(h);
            jm2.a(new jl(11, 11, this.a.size()));
            for (Map.Entry entry : this.a.entrySet()) {
                jm2.a((String)entry.getKey());
                jm2.a((String)entry.getValue());
            }
            jm2.d();
            jm2.b();
        }
        if (this.f != null && this.i()) {
            jm2.a(i);
            jm2.a(this.f);
            jm2.b();
        }
        if (this.g != null && this.j()) {
            jm2.a(j);
            jm2.a(this.g);
            jm2.b();
        }
        if (this.h != null && this.k()) {
            jm2.a(k);
            jm2.a(this.h);
            jm2.b();
        }
        if (this.i != null && this.l()) {
            jm2.a(l);
            jm2.a(this.i);
            jm2.b();
        }
        if (this.a != null && this.m()) {
            jm2.a(m);
            jm2.a(this.a);
            jm2.b();
        }
        if (this.n()) {
            jm2.a(n);
            jm2.a(this.a);
            jm2.b();
        }
        if (this.o()) {
            jm2.a(o);
            jm2.a(this.b);
            jm2.b();
        }
        jm2.c();
        jm2.a();
    }

    public void b(boolean bl) {
        this.a.set(1, bl);
    }

    public boolean b() {
        return this.a != null;
    }

    public ip c(String string) {
        this.d = string;
        return this;
    }

    public String c() {
        return this.f;
    }

    public void c(boolean bl) {
        this.a.set(2, bl);
    }

    public boolean c() {
        return this.b != null;
    }

    public /* synthetic */ int compareTo(Object object) {
        return this.a((ip)object);
    }

    public ip d(String string) {
        this.f = string;
        return this;
    }

    public boolean d() {
        return this.c != null;
    }

    public boolean e() {
        return this.d != null;
    }

    public boolean equals(Object object) {
        if (object == null) {
            return false;
        }
        if (object instanceof ip) {
            return this.a((ip)object);
        }
        return false;
    }

    public boolean f() {
        return this.a.get(0);
    }

    public boolean g() {
        return this.e != null;
    }

    public boolean h() {
        return this.a != null;
    }

    public int hashCode() {
        return 0;
    }

    public boolean i() {
        return this.f != null;
    }

    public boolean j() {
        return this.g != null;
    }

    public boolean k() {
        return this.h != null;
    }

    public boolean l() {
        return this.i != null;
    }

    public boolean m() {
        return this.a != null;
    }

    public boolean n() {
        return this.a.get(1);
    }

    public boolean o() {
        return this.a.get(2);
    }

    public String toString() {
        boolean bl;
        boolean bl2;
        StringBuilder stringBuilder = new StringBuilder("XmPushActionNotification(");
        if (this.a()) {
            stringBuilder.append("debug:");
            String string = this.a;
            if (string == null) {
                stringBuilder.append("null");
            } else {
                stringBuilder.append(string);
            }
            bl = false;
        } else {
            bl = true;
        }
        if (this.b()) {
            if (!bl) {
                stringBuilder.append(", ");
            }
            stringBuilder.append("target:");
            if if_ = this.a;
            if (if_ == null) {
                stringBuilder.append("null");
                bl2 = false;
            } else {
                stringBuilder.append((Object)if_);
                bl2 = false;
            }
        } else {
            bl2 = bl;
        }
        if (!bl2) {
            stringBuilder.append(", ");
        }
        stringBuilder.append("id:");
        String string = this.b;
        if (string == null) {
            stringBuilder.append("null");
        } else {
            stringBuilder.append(string);
        }
        if (this.d()) {
            stringBuilder.append(", ");
            stringBuilder.append("appId:");
            String string2 = this.c;
            if (string2 == null) {
                stringBuilder.append("null");
            } else {
                stringBuilder.append(string2);
            }
        }
        if (this.e()) {
            stringBuilder.append(", ");
            stringBuilder.append("type:");
            String string3 = this.d;
            if (string3 == null) {
                stringBuilder.append("null");
            } else {
                stringBuilder.append(string3);
            }
        }
        stringBuilder.append(", ");
        stringBuilder.append("requireAck:");
        stringBuilder.append(this.a);
        if (this.g()) {
            stringBuilder.append(", ");
            stringBuilder.append("payload:");
            String string4 = this.e;
            if (string4 == null) {
                stringBuilder.append("null");
            } else {
                stringBuilder.append(string4);
            }
        }
        if (this.h()) {
            stringBuilder.append(", ");
            stringBuilder.append("extra:");
            jj jj2 = this.a;
            if (jj2 == null) {
                stringBuilder.append("null");
            } else {
                stringBuilder.append((Object)jj2);
            }
        }
        if (this.i()) {
            stringBuilder.append(", ");
            stringBuilder.append("packageName:");
            String string5 = this.f;
            if (string5 == null) {
                stringBuilder.append("null");
            } else {
                stringBuilder.append(string5);
            }
        }
        if (this.j()) {
            stringBuilder.append(", ");
            stringBuilder.append("category:");
            String string6 = this.g;
            if (string6 == null) {
                stringBuilder.append("null");
            } else {
                stringBuilder.append(string6);
            }
        }
        if (this.k()) {
            stringBuilder.append(", ");
            stringBuilder.append("regId:");
            String string7 = this.h;
            if (string7 == null) {
                stringBuilder.append("null");
            } else {
                stringBuilder.append(string7);
            }
        }
        if (this.l()) {
            stringBuilder.append(", ");
            stringBuilder.append("aliasName:");
            String string8 = this.i;
            if (string8 == null) {
                stringBuilder.append("null");
            } else {
                stringBuilder.append(string8);
            }
        }
        if (this.m()) {
            stringBuilder.append(", ");
            stringBuilder.append("binaryExtra:");
            ByteBuffer byteBuffer = this.a;
            if (byteBuffer == null) {
                stringBuilder.append("null");
            } else {
                jc.a((ByteBuffer)byteBuffer, (StringBuilder)stringBuilder);
            }
        }
        if (this.n()) {
            stringBuilder.append(", ");
            stringBuilder.append("createdTs:");
            stringBuilder.append(this.a);
        }
        if (this.o()) {
            stringBuilder.append(", ");
            stringBuilder.append("alreadyLogClickInXmq:");
            stringBuilder.append(this.b);
        }
        stringBuilder.append(")");
        return stringBuilder.toString();
    }
}

