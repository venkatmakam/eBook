/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 *  com.xiaomi.push.dz
 */
package com.xiaomi.push.mpcd.receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.xiaomi.push.dz;

public class BroadcastActionsReceiver
extends BroadcastReceiver {
    private dz a;

    public BroadcastActionsReceiver(dz dz2) {
        this.a = dz2;
    }

    public void onReceive(Context context, Intent intent) {
        dz dz2 = this.a;
        if (dz2 != null) {
            dz2.a(context, intent);
        }
    }
}

