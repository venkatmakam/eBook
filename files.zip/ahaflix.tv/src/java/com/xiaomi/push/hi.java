/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  com.xiaomi.channel.commonutils.logger.b
 *  com.xiaomi.push.bc
 *  com.xiaomi.push.be
 *  com.xiaomi.push.be$a
 *  com.xiaomi.push.fl
 *  com.xiaomi.push.fm
 *  com.xiaomi.push.fn
 *  com.xiaomi.push.hh
 *  com.xiaomi.push.hj
 *  e.a.a.a.a
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Throwable
 */
package com.xiaomi.push;

import android.content.Context;
import com.xiaomi.channel.commonutils.logger.b;
import com.xiaomi.push.bc;
import com.xiaomi.push.be;
import com.xiaomi.push.fl;
import com.xiaomi.push.fm;
import com.xiaomi.push.fn;
import com.xiaomi.push.hh;
import com.xiaomi.push.hj;
import com.xiaomi.push.service.XMPushService;
import com.xiaomi.push.service.bf;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class hi {
    private int a;
    private long a;
    private be a;
    private hh a;
    private String a;
    private boolean a = be.a();

    private fm a(be.a a2) {
        if (a2.a == 0) {
            Object object = a2.a;
            if (object instanceof fm) {
                return (fm)object;
            }
            return null;
        }
        fm fm2 = this.b();
        fm2.a(fl.ac.a());
        fm2.c(a2.a);
        fm2.c(a2.a);
        return fm2;
    }

    /*
     * Exception decompiling
     */
    private fn a(int var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl74.1 : ALOAD_3 : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static hh a() {
        hi hi2;
        hi hi3 = hi2 = a.a;
        synchronized (hi3) {
            return hi2.a;
        }
    }

    public static hi a() {
        return a.a;
    }

    private void a() {
        if (this.a && System.currentTimeMillis() - this.a > (long)this.a) {
            this.a = false;
            this.a = 0L;
        }
    }

    public void a(int n4) {
        if (n4 > 0) {
            int n5 = n4 * 1000;
            if (n5 > 604800000) {
                n5 = 604800000;
            }
            if (this.a != n5 || !this.a) {
                this.a = true;
                this.a = System.currentTimeMillis();
                this.a = n5;
                StringBuilder stringBuilder = e.a.a.a.a.G1((String)"enable dot duration = ", (int)n5, (String)" start = ");
                stringBuilder.append(this.a);
                b.c((String)stringBuilder.toString());
            }
        }
    }

    public void a(XMPushService xMPushService) {
        hi hi2 = this;
        synchronized (hi2) {
            this.a = new hh(xMPushService);
            this.a = "";
            bf.a().a((bf.a)new hj(this));
            return;
        }
    }

    public boolean a() {
        return this.a;
    }

    public fm b() {
        hi hi2 = this;
        synchronized (hi2) {
            fm fm2 = new fm();
            fm2.a(bc.a((Context)this.a.g));
            fm2.a = 0;
            fm2.b = 1;
            fm2.d((int)(System.currentTimeMillis() / 1000L));
            return fm2;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public fn c() {
        hi hi2 = this;
        synchronized (hi2) {
            Throwable throwable2;
            int n4;
            block5 : {
                boolean bl2;
                try {
                    this.a();
                    if (!this.a) return null;
                    if (this.a.a() <= 0) return null;
                    bl2 = true;
                }
                catch (Throwable throwable2) {}
                fn fn2 = null;
                if (!bl2) return fn2;
                n4 = 750;
                if (bc.d((Context)this.a.g)) break block5;
                n4 = 375;
            }
            return this.a(n4);
            throw throwable2;
        }
    }

    public void d(fm fm2) {
        hi hi2 = this;
        synchronized (hi2) {
            this.a.a((Object)fm2);
            return;
        }
    }

    public static class a {
        public static final hi a = new hi();
    }

}

