/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.xiaomi.push.jw
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 *  java.lang.UnsupportedOperationException
 */
package com.xiaomi.push;

import com.xiaomi.push.jw;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class jv
extends jw {
    private int a;
    private byte[] a;
    private int b;

    public int a() {
        return this.a;
    }

    public int a(byte[] arrby, int n5, int n6) {
        int n7 = this.b();
        if (n6 > n7) {
            n6 = n7;
        }
        if (n6 > 0) {
            System.arraycopy((Object)this.a, (int)this.a, (Object)arrby, (int)n5, (int)n6);
            this.a(n6);
        }
        return n6;
    }

    public void a(int n5) {
        this.a = n5 + this.a;
    }

    public void a(byte[] arrby) {
        this.b(arrby, 0, arrby.length);
    }

    public void a(byte[] arrby, int n5, int n6) {
        throw new UnsupportedOperationException("No writing allowed!");
    }

    public byte[] a() {
        return this.a;
    }

    public int b() {
        return this.b - this.a;
    }

    public void b(byte[] arrby, int n5, int n6) {
        this.a = arrby;
        this.a = n5;
        this.b = n5 + n6;
    }
}

