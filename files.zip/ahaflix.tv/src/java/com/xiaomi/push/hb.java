/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ContentValues
 *  android.content.Context
 *  android.database.sqlite.SQLiteDatabase
 *  android.database.sqlite.SQLiteException
 *  android.net.ConnectivityManager
 *  android.net.NetworkInfo
 *  android.text.TextUtils
 *  com.xiaomi.channel.commonutils.logger.b
 *  com.xiaomi.push.al
 *  com.xiaomi.push.al$b
 *  com.xiaomi.push.hc
 *  java.io.UnsupportedEncodingException
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.Collections
 *  java.util.List
 */
package com.xiaomi.push;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.text.TextUtils;
import com.xiaomi.channel.commonutils.logger.b;
import com.xiaomi.push.al;
import com.xiaomi.push.hc;
import com.xiaomi.push.l;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class hb {
    private static volatile int a;
    private static long a;
    private static al a;
    private static com.xiaomi.push.providers.a a;
    private static final Object a;
    private static String a;
    private static List<a> a;

    public static {
        a = new al(true);
        a = -1;
        a = System.currentTimeMillis();
        a = new Object();
        a = (int)Collections.synchronizedList((List)new ArrayList());
        a = "";
        a = null;
    }

    public static int a(Context context) {
        if (a == -1) {
            a = hb.b(context);
        }
        return a;
    }

    public static int a(String string2) {
        try {
            int n4 = string2.getBytes("UTF-8").length;
            return n4;
        }
        catch (UnsupportedEncodingException unsupportedEncodingException) {
            return string2.getBytes().length;
        }
    }

    private static long a(int n4, long l3, boolean bl2, long l4, boolean bl3) {
        if (bl2 && bl3) {
            long l5 = a;
            a = l4;
            if (l4 - l5 > 30000L && l3 > 1024L) {
                return l3 * 2L;
            }
        }
        int n5 = n4 == 0 ? 13 : 11;
        return l3 * (long)n5 / 10L;
    }

    private static com.xiaomi.push.providers.a a(Context context) {
        com.xiaomi.push.providers.a a2;
        com.xiaomi.push.providers.a a3 = a;
        if (a3 != null) {
            return a3;
        }
        a = a2 = new com.xiaomi.push.providers.a(context);
        return a2;
    }

    private static String a(Context context) {
        Class<hb> class_ = hb.class;
        synchronized (hb.class) {
            if (!TextUtils.isEmpty((CharSequence)a)) {
                String string2 = a;
                // ** MonitorExit[var3_1] (shouldn't be in output)
                return string2;
            }
            return "";
        }
    }

    public static void a(Context context) {
        a = hb.b(context);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    private static void a(Context context, String string2, long l3, boolean bl2, long l4) {
        Object object;
        if (context == null) return;
        if (TextUtils.isEmpty((CharSequence)string2)) return;
        if (!"com.xiaomi.xmsf".equals((Object)context.getPackageName())) return;
        if ("com.xiaomi.xmsf".equals((Object)string2)) {
            return;
        }
        int n4 = hb.a(context);
        if (-1 == n4) {
            return;
        }
        Object object2 = object = a;
        // MONITORENTER : object2
        boolean bl3 = a.isEmpty();
        String string3 = n4 == 0 ? hb.a(context) : "";
        a a2 = new a(string2, l4, n4, (int)bl2, string3, l3);
        hb.a(a2);
        // MONITOREXIT : object2
        if (!bl3) return;
        a.a((al.b)new hc(context), 5000L);
    }

    public static void a(Context context, String string2, long l3, boolean bl2, boolean bl3, long l4) {
        hb.a(context, string2, hb.a(hb.a(context), l3, bl2, l4, bl3), bl2, l4);
    }

    private static void a(a a2) {
        for (a a3 : a) {
            if (!a3.a(a2)) continue;
            a3.b += a2.b;
            return;
        }
        a.add((Object)a2);
    }

    public static void a(String string2) {
        Class<hb> class_ = hb.class;
        synchronized (hb.class) {
            if (!l.d() && !TextUtils.isEmpty((CharSequence)string2)) {
                a = string2;
            }
            // ** MonitorExit[var2_1] (shouldn't be in output)
            return;
        }
    }

    private static int b(Context context) {
        NetworkInfo networkInfo;
        block4 : {
            ConnectivityManager connectivityManager;
            block3 : {
                try {
                    connectivityManager = (ConnectivityManager)context.getSystemService("connectivity");
                    if (connectivityManager != null) break block3;
                    return -1;
                }
                catch (Exception exception) {
                    return -1;
                }
            }
            networkInfo = connectivityManager.getActiveNetworkInfo();
            if (networkInfo != null) break block4;
            return -1;
        }
        return networkInfo.getType();
    }

    public static /* synthetic */ Object b() {
        return a;
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    private static void b(Context context, List<a> list) {
        Object object;
        Object object2 = object = com.xiaomi.push.providers.a.a;
        // MONITORENTER : object2
        SQLiteDatabase sQLiteDatabase = hb.a(context).getWritableDatabase();
        sQLiteDatabase.beginTransaction();
        try {
            for (a a2 : list) {
                ContentValues contentValues = new ContentValues();
                contentValues.put("package_name", a2.a);
                contentValues.put("message_ts", Long.valueOf((long)a2.a));
                contentValues.put("network_type", Integer.valueOf((int)a2.a));
                contentValues.put("bytes", Long.valueOf((long)a2.b));
                contentValues.put("rcv", Integer.valueOf((int)a2.b));
                contentValues.put("imsi", a2.b);
                sQLiteDatabase.insert("traffic", null, contentValues);
            }
            sQLiteDatabase.setTransactionSuccessful();
            return;
        }
        finally {
            sQLiteDatabase.endTransaction();
        }
        catch (SQLiteException sQLiteException) {
            b.a((Throwable)sQLiteException);
            return;
        }
    }

    public static /* synthetic */ List c() {
        return a;
    }

    public static /* synthetic */ void d(Context context, List list) {
        hb.b(context, (List<a>)list);
    }

    /*
     * Duplicate member names - consider using --renamedupmembers true
     */
    public static class a {
        public int a;
        public long a;
        public String a = -1;
        public int b;
        public long b;
        public String b = 0L;

        public a(String string2, long l3, int n4, int n5, String string3, long l4) {
            this.a = string2;
            this.a = l3;
            this.a = n4;
            this.b = n5;
            this.b = string3;
            this.b = l4;
        }

        public boolean a(a a2) {
            return TextUtils.equals((CharSequence)a2.a, (CharSequence)this.a) && TextUtils.equals((CharSequence)a2.b, (CharSequence)this.b) && a2.a == this.a && a2.b == this.b && Math.abs((long)(a2.a - this.a)) <= 5000L;
            {
            }
        }
    }

}

