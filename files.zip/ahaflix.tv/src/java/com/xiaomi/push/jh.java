/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.ByteArrayOutputStream
 *  java.io.OutputStream
 *  java.lang.Object
 */
package com.xiaomi.push;

import com.xiaomi.push.jb;
import com.xiaomi.push.ji;
import com.xiaomi.push.jm;
import com.xiaomi.push.jo;
import com.xiaomi.push.jt;
import com.xiaomi.push.jw;
import java.io.ByteArrayOutputStream;
import java.io.OutputStream;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class jh {
    private jm a;
    private final jt a;
    private final ByteArrayOutputStream a;

    public jh() {
        this(new ji.a());
    }

    public jh(jo jo2) {
        jt jt2;
        ByteArrayOutputStream byteArrayOutputStream;
        this.a = byteArrayOutputStream = new ByteArrayOutputStream();
        this.a = jt2 = new jt((OutputStream)byteArrayOutputStream);
        this.a = jo2.a(jt2);
    }

    public byte[] a(jb jb2) {
        this.a.reset();
        jb2.b(this.a);
        return this.a.toByteArray();
    }
}

