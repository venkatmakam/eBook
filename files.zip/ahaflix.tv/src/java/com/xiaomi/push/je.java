/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.ByteArrayOutputStream
 */
package com.xiaomi.push;

import java.io.ByteArrayOutputStream;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class je
extends ByteArrayOutputStream {
    public je() {
    }

    public je(int n4) {
        super(n4);
    }

    public int a() {
        return this.count;
    }

    public byte[] a() {
        return this.buf;
    }
}

