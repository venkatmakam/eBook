/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.xiaomi.push;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class hw
extends Enum<hw> {
    public static final /* enum */ hw a;
    private static final /* synthetic */ hw[] a;
    public static final /* enum */ hw b;
    private final int a;

    public static {
        hw hw2;
        hw hw3;
        a = hw3 = new hw(1);
        b = hw2 = new hw(2);
        a = new hw[]{hw3, hw2};
    }

    private hw(int n5) {
        this.a = n5;
    }

    public static hw a(int n4) {
        if (n4 != 1) {
            if (n4 != 2) {
                return null;
            }
            return b;
        }
        return a;
    }

    public static hw valueOf(String string2) {
        return (hw)Enum.valueOf(hw.class, (String)string2);
    }

    public static hw[] values() {
        return (hw[])a.clone();
    }

    public int a() {
        return this.a;
    }
}

