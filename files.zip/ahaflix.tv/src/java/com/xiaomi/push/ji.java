/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.xiaomi.push.jg
 *  com.xiaomi.push.jj
 *  com.xiaomi.push.jk
 *  com.xiaomi.push.jl
 *  com.xiaomi.push.jm
 *  com.xiaomi.push.jo
 *  com.xiaomi.push.jq
 *  com.xiaomi.push.jr
 *  com.xiaomi.push.jw
 *  e.a.a.a.a
 *  java.io.UnsupportedEncodingException
 *  java.lang.Double
 *  java.lang.Object
 *  java.lang.String
 *  java.nio.ByteBuffer
 */
package com.xiaomi.push;

import com.xiaomi.push.jg;
import com.xiaomi.push.jj;
import com.xiaomi.push.jk;
import com.xiaomi.push.jl;
import com.xiaomi.push.jm;
import com.xiaomi.push.jo;
import com.xiaomi.push.jq;
import com.xiaomi.push.jr;
import com.xiaomi.push.jw;
import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class ji
extends jm {
    private static final jr a = new jr();
    private byte[] a = new byte[1];
    private byte[] b = new byte[2];
    private byte[] c = new byte[4];
    private byte[] d = new byte[8];
    private byte[] e = new byte[1];
    private byte[] f = new byte[2];
    private byte[] g = new byte[4];
    private byte[] h = new byte[8];
    public int j;
    public boolean k = false;

    public ji(jw jw2, boolean bl, boolean bl2) {
        super(jw2);
    }

    private int a(byte[] arrby, int n5, int n6) {
        this.c(n6);
        return this.i.b(arrby, n5, n6);
    }

    public byte a() {
        if (this.i.b() >= 1) {
            byte by = this.i.a()[this.i.a()];
            this.i.a(1);
            return by;
        }
        this.a(this.e, 0, 1);
        return this.e[0];
    }

    public double a() {
        return Double.longBitsToDouble((long)this.a());
    }

    public int a() {
        byte[] arrby = this.g;
        int n5 = this.i.b();
        int n6 = 0;
        if (n5 >= 4) {
            arrby = this.i.a();
            n6 = this.i.a();
            this.i.a(4);
        } else {
            this.a(this.g, 0, 4);
        }
        return (255 & arrby[n6]) << 24 | (255 & arrby[n6 + 1]) << 16 | (255 & arrby[n6 + 2]) << 8 | 255 & arrby[n6 + 3];
    }

    public long a() {
        byte[] arrby = this.h;
        int n5 = this.i.b();
        int n6 = 0;
        if (n5 >= 8) {
            arrby = this.i.a();
            n6 = this.i.a();
            this.i.a(8);
        } else {
            this.a(this.h, 0, 8);
        }
        return (long)(255 & arrby[n6]) << 56 | (long)(255 & arrby[n6 + 1]) << 48 | (long)(255 & arrby[n6 + 2]) << 40 | (long)(255 & arrby[n6 + 3]) << 32 | (long)(255 & arrby[n6 + 4]) << 24 | (long)(255 & arrby[n6 + 5]) << 16 | (long)(255 & arrby[n6 + 6]) << 8 | (long)(255 & arrby[n6 + 7]);
    }

    public jj a() {
        byte by = this.a();
        short s3 = by == 0 ? (short)0 : this.a();
        return new jj("", by, s3);
    }

    public jk a() {
        return new jk(this.a(), this.a());
    }

    public jl a() {
        return new jl(this.a(), this.a(), this.a());
    }

    public jq a() {
        return new jq(this.a(), this.a());
    }

    public jr a() {
        return a;
    }

    public String a() {
        int n5 = this.a();
        if (this.i.b() >= n5) {
            try {
                String string = new String(this.i.a(), this.i.a(), n5, "UTF-8");
                this.i.a(n5);
                return string;
            }
            catch (UnsupportedEncodingException unsupportedEncodingException) {
                throw new jg("JVM DOES NOT SUPPORT UTF-8");
            }
        }
        return this.a(n5);
    }

    public String a(int n5) {
        try {
            this.c(n5);
            byte[] arrby = new byte[n5];
            this.i.b(arrby, 0, n5);
            String string = new String(arrby, "UTF-8");
            return string;
        }
        catch (UnsupportedEncodingException unsupportedEncodingException) {
            throw new jg("JVM DOES NOT SUPPORT UTF-8");
        }
    }

    public ByteBuffer a() {
        int n5 = this.a();
        this.c(n5);
        if (this.i.b() >= n5) {
            ByteBuffer byteBuffer = ByteBuffer.wrap((byte[])this.i.a(), (int)this.i.a(), (int)n5);
            this.i.a(n5);
            return byteBuffer;
        }
        byte[] arrby = new byte[n5];
        this.i.b(arrby, 0, n5);
        return ByteBuffer.wrap((byte[])arrby);
    }

    public short a() {
        byte[] arrby = this.f;
        int n5 = this.i.b();
        int n6 = 0;
        if (n5 >= 2) {
            arrby = this.i.a();
            n6 = this.i.a();
            this.i.a(2);
        } else {
            this.a(this.f, 0, 2);
        }
        return (short)((255 & arrby[n6]) << 8 | 255 & arrby[n6 + 1]);
    }

    public void a() {
    }

    public void a(byte by) {
        byte[] arrby = this.a;
        arrby[0] = by;
        this.i.a(arrby, 0, 1);
    }

    public void a(int n5) {
        byte[] arrby = this.c;
        arrby[0] = (byte)(255 & n5 >> 24);
        arrby[1] = (byte)(255 & n5 >> 16);
        arrby[2] = (byte)(255 & n5 >> 8);
        arrby[3] = (byte)(n5 & 255);
        this.i.a(arrby, 0, 4);
    }

    public void a(long l2) {
        byte[] arrby = this.d;
        arrby[0] = (byte)(255L & l2 >> 56);
        arrby[1] = (byte)(255L & l2 >> 48);
        arrby[2] = (byte)(255L & l2 >> 40);
        arrby[3] = (byte)(255L & l2 >> 32);
        arrby[4] = (byte)(255L & l2 >> 24);
        arrby[5] = (byte)(255L & l2 >> 16);
        arrby[6] = (byte)(255L & l2 >> 8);
        arrby[7] = (byte)(l2 & 255L);
        this.i.a(arrby, 0, 8);
    }

    public void a(jj jj2) {
        this.a(jj2.a);
        this.a(jj2.a);
    }

    public void a(jk jk2) {
        this.a(jk2.a);
        this.a(jk2.a);
    }

    public void a(jl jl2) {
        this.a(jl2.a);
        this.a(jl2.b);
        this.a(jl2.a);
    }

    public void a(jr jr2) {
    }

    public void a(String string) {
        try {
            byte[] arrby = string.getBytes("UTF-8");
            this.a(arrby.length);
            this.i.a(arrby, 0, arrby.length);
            return;
        }
        catch (UnsupportedEncodingException unsupportedEncodingException) {
            throw new jg("JVM DOES NOT SUPPORT UTF-8");
        }
    }

    public void a(ByteBuffer byteBuffer) {
        int n5 = byteBuffer.limit() - byteBuffer.position() - byteBuffer.arrayOffset();
        this.a(n5);
        this.i.a(byteBuffer.array(), byteBuffer.position() + byteBuffer.arrayOffset(), n5);
    }

    public void a(short s3) {
        byte[] arrby = this.b;
        arrby[0] = (byte)(255 & s3 >> 8);
        arrby[1] = (byte)(s3 & 255);
        this.i.a(arrby, 0, 2);
    }

    public void a(boolean bl) {
        this.a((byte)bl);
    }

    public boolean a() {
        return this.a() == 1;
    }

    public void b() {
    }

    public void b(int n5) {
        this.j = n5;
        this.k = true;
    }

    public void c() {
        this.a((byte)0);
    }

    public void c(int n5) {
        if (n5 >= 0) {
            if (this.k) {
                int n6;
                this.j = n6 = this.j - n5;
                if (n6 >= 0) {
                    return;
                }
                throw new jg(e.a.a.a.a.V0((String)"Message length exceeded: ", (int)n5));
            }
            return;
        }
        throw new jg(e.a.a.a.a.V0((String)"Negative length: ", (int)n5));
    }

    public void d() {
    }

    public void e() {
    }

    public void f() {
    }

    public void g() {
    }

    public void h() {
    }

    public void i() {
    }

    public void j() {
    }

    public static class a
    implements jo {
        public boolean a = false;
        public boolean b = true;
        public int c;

        public a() {
            this(false, true);
        }

        public a(boolean bl, boolean bl2) {
            this(bl, bl2, 0);
        }

        public a(boolean bl, boolean bl2, int n5) {
            this.a = bl;
            this.b = bl2;
            this.c = n5;
        }

        public jm a(jw jw2) {
            ji ji2 = new ji(jw2, this.a, this.b);
            int n5 = this.c;
            if (n5 != 0) {
                ji2.b(n5);
            }
            return ji2;
        }
    }

}

