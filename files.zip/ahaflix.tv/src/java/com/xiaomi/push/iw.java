/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.xiaomi.push.if
 *  com.xiaomi.push.jb
 *  com.xiaomi.push.jc
 *  com.xiaomi.push.jj
 *  com.xiaomi.push.jm
 *  com.xiaomi.push.jp
 *  com.xiaomi.push.jr
 *  e.a.a.a.a
 *  java.io.Serializable
 *  java.lang.Boolean
 *  java.lang.Class
 *  java.lang.Cloneable
 *  java.lang.Comparable
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.BitSet
 */
package com.xiaomi.push;

import com.xiaomi.push.if;
import com.xiaomi.push.jb;
import com.xiaomi.push.jc;
import com.xiaomi.push.jj;
import com.xiaomi.push.jm;
import com.xiaomi.push.jn;
import com.xiaomi.push.jp;
import com.xiaomi.push.jr;
import e.a.a.a.a;
import java.io.Serializable;
import java.util.BitSet;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class iw
implements jb<iw, Object>,
Serializable,
Cloneable {
    private static final jj a;
    private static final jr a;
    private static final jj b;
    private static final jj c;
    private static final jj d;
    private static final jj e;
    private static final jj f;
    private static final jj g;
    private static final jj h;
    private static final jj i;
    private static final jj j;
    private static final jj k;
    private static final jj l;
    public long a;
    public if a;
    public String a;
    private BitSet a;
    public boolean a = true;
    public String b;
    public String c;
    public String d;
    public String e;
    public String f;
    public String g;
    public String h;
    public String i;

    public static {
        a = new jr("XmPushActionUnRegistration");
        a = new jj("", 11, 1);
        b = new jj("", 12, 2);
        c = new jj("", 11, 3);
        d = new jj("", 11, 4);
        e = new jj("", 11, 5);
        f = new jj("", 11, 6);
        g = new jj("", 11, 7);
        h = new jj("", 11, 8);
        i = new jj("", 11, 9);
        j = new jj("", 11, 10);
        k = new jj("", 2, 11);
        l = new jj("", 10, 12);
    }

    public int a(iw iw2) {
        int n5;
        int n6;
        int n7;
        int n8;
        int n9;
        int n10;
        int n11;
        int n12;
        int n13;
        int n14;
        int n15;
        int n16;
        if (!this.getClass().equals((Object)iw2.getClass())) {
            return this.getClass().getName().compareTo(iw2.getClass().getName());
        }
        int n17 = Boolean.valueOf((boolean)this.a()).compareTo(Boolean.valueOf((boolean)iw2.a()));
        if (n17 != 0) {
            return n17;
        }
        if (this.a() && (n8 = jc.a((String)this.a, (String)iw2.a)) != 0) {
            return n8;
        }
        int n18 = Boolean.valueOf((boolean)this.b()).compareTo(Boolean.valueOf((boolean)iw2.b()));
        if (n18 != 0) {
            return n18;
        }
        if (this.b() && (n6 = jc.a((Comparable)this.a, (Comparable)iw2.a)) != 0) {
            return n6;
        }
        int n19 = Boolean.valueOf((boolean)this.c()).compareTo(Boolean.valueOf((boolean)iw2.c()));
        if (n19 != 0) {
            return n19;
        }
        if (this.c() && (n10 = jc.a((String)this.b, (String)iw2.b)) != 0) {
            return n10;
        }
        int n20 = Boolean.valueOf((boolean)this.d()).compareTo(Boolean.valueOf((boolean)iw2.d()));
        if (n20 != 0) {
            return n20;
        }
        if (this.d() && (n14 = jc.a((String)this.c, (String)iw2.c)) != 0) {
            return n14;
        }
        int n21 = Boolean.valueOf((boolean)this.e()).compareTo(Boolean.valueOf((boolean)iw2.e()));
        if (n21 != 0) {
            return n21;
        }
        if (this.e() && (n13 = jc.a((String)this.d, (String)iw2.d)) != 0) {
            return n13;
        }
        int n22 = Boolean.valueOf((boolean)this.f()).compareTo(Boolean.valueOf((boolean)iw2.f()));
        if (n22 != 0) {
            return n22;
        }
        if (this.f() && (n7 = jc.a((String)this.e, (String)iw2.e)) != 0) {
            return n7;
        }
        int n23 = Boolean.valueOf((boolean)this.g()).compareTo(Boolean.valueOf((boolean)iw2.g()));
        if (n23 != 0) {
            return n23;
        }
        if (this.g() && (n5 = jc.a((String)this.f, (String)iw2.f)) != 0) {
            return n5;
        }
        int n24 = Boolean.valueOf((boolean)this.h()).compareTo(Boolean.valueOf((boolean)iw2.h()));
        if (n24 != 0) {
            return n24;
        }
        if (this.h() && (n16 = jc.a((String)this.g, (String)iw2.g)) != 0) {
            return n16;
        }
        int n25 = Boolean.valueOf((boolean)this.i()).compareTo(Boolean.valueOf((boolean)iw2.i()));
        if (n25 != 0) {
            return n25;
        }
        if (this.i() && (n9 = jc.a((String)this.h, (String)iw2.h)) != 0) {
            return n9;
        }
        int n26 = Boolean.valueOf((boolean)this.j()).compareTo(Boolean.valueOf((boolean)iw2.j()));
        if (n26 != 0) {
            return n26;
        }
        if (this.j() && (n15 = jc.a((String)this.i, (String)iw2.i)) != 0) {
            return n15;
        }
        int n27 = Boolean.valueOf((boolean)this.k()).compareTo(Boolean.valueOf((boolean)iw2.k()));
        if (n27 != 0) {
            return n27;
        }
        if (this.k() && (n12 = jc.a((boolean)this.a, (boolean)iw2.a)) != 0) {
            return n12;
        }
        int n28 = Boolean.valueOf((boolean)this.l()).compareTo(Boolean.valueOf((boolean)iw2.l()));
        if (n28 != 0) {
            return n28;
        }
        if (this.l() && (n11 = jc.a((long)this.a, (long)iw2.a)) != 0) {
            return n11;
        }
        return 0;
    }

    public iw a(String string) {
        this.b = string;
        return this;
    }

    public void a() {
        if (this.b != null) {
            if (this.c != null) {
                return;
            }
            StringBuilder stringBuilder = a.F1((String)"Required field 'appId' was not present! Struct: ");
            stringBuilder.append(this.toString());
            throw new jn(stringBuilder.toString());
        }
        StringBuilder stringBuilder = a.F1((String)"Required field 'id' was not present! Struct: ");
        stringBuilder.append(this.toString());
        throw new jn(stringBuilder.toString());
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public void a(jm var1_1) {
        var1_1.a();
        do {
            block16 : {
                var3_2 = var1_1.a();
                var4_3 = var3_2.a;
                if (var4_3 == 0) {
                    var1_1.f();
                    this.a();
                    return;
                }
                switch (var3_2.a) {
                    case 12: {
                        if (var4_3 != 10) break;
                        this.a = var1_1.a();
                        this.b(true);
                        ** break;
                    }
                    case 11: {
                        if (var4_3 != 2) break;
                        this.a = var1_1.a();
                        this.a(true);
                        ** break;
                    }
                    case 10: {
                        if (var4_3 != 11) break;
                        this.i = var1_1.a();
                        ** break;
                    }
                    case 9: {
                        if (var4_3 != 11) break;
                        this.h = var1_1.a();
                        ** break;
                    }
                    case 8: {
                        if (var4_3 != 11) break;
                        this.g = var1_1.a();
                        ** break;
                    }
                    case 7: {
                        if (var4_3 != 11) break;
                        this.f = var1_1.a();
                        ** break;
                    }
                    case 6: {
                        if (var4_3 != 11) break;
                        this.e = var1_1.a();
                        ** break;
                    }
                    case 5: {
                        if (var4_3 != 11) break;
                        this.d = var1_1.a();
                        ** break;
                    }
                    case 4: {
                        if (var4_3 != 11) break;
                        this.c = var1_1.a();
                        ** break;
                    }
                    case 3: {
                        if (var4_3 != 11) break;
                        this.b = var1_1.a();
                        ** break;
                    }
                    case 2: {
                        if (var4_3 != 12) break;
                        this.a = var5_4 = new if();
                        var5_4.a(var1_1);
                        ** break;
                    }
                    case 1: {
                        if (var4_3 != 11) break;
                        this.a = var1_1.a();
                        break block16;
                    }
                }
                jp.a((jm)var1_1, (byte)var4_3);
                ** break;
            }
            var1_1.g();
        } while (true);
    }

    public void a(boolean bl) {
        this.a.set(0, bl);
    }

    public boolean a() {
        return this.a != null;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public boolean a(iw iw2) {
        if (iw2 == null) {
            return false;
        }
        boolean bl = this.a();
        boolean bl2 = iw2.a();
        if (bl || bl2) {
            if (!bl) return false;
            if (!bl2) {
                return false;
            }
            if (!this.a.equals((Object)iw2.a)) {
                return false;
            }
        }
        boolean bl3 = this.b();
        boolean bl4 = iw2.b();
        if (bl3 || bl4) {
            if (!bl3) return false;
            if (!bl4) {
                return false;
            }
            if (!this.a.a(iw2.a)) {
                return false;
            }
        }
        boolean bl5 = this.c();
        boolean bl6 = iw2.c();
        if (bl5 || bl6) {
            if (!bl5) return false;
            if (!bl6) {
                return false;
            }
            if (!this.b.equals((Object)iw2.b)) {
                return false;
            }
        }
        boolean bl7 = this.d();
        boolean bl8 = iw2.d();
        if (bl7 || bl8) {
            if (!bl7) return false;
            if (!bl8) {
                return false;
            }
            if (!this.c.equals((Object)iw2.c)) {
                return false;
            }
        }
        boolean bl9 = this.e();
        boolean bl10 = iw2.e();
        if (bl9 || bl10) {
            if (!bl9) return false;
            if (!bl10) {
                return false;
            }
            if (!this.d.equals((Object)iw2.d)) {
                return false;
            }
        }
        boolean bl11 = this.f();
        boolean bl12 = iw2.f();
        if (bl11 || bl12) {
            if (!bl11) return false;
            if (!bl12) {
                return false;
            }
            if (!this.e.equals((Object)iw2.e)) {
                return false;
            }
        }
        boolean bl13 = this.g();
        boolean bl14 = iw2.g();
        if (bl13 || bl14) {
            if (!bl13) return false;
            if (!bl14) {
                return false;
            }
            if (!this.f.equals((Object)iw2.f)) {
                return false;
            }
        }
        boolean bl15 = this.h();
        boolean bl16 = iw2.h();
        if (bl15 || bl16) {
            if (!bl15) return false;
            if (!bl16) {
                return false;
            }
            if (!this.g.equals((Object)iw2.g)) {
                return false;
            }
        }
        boolean bl17 = this.i();
        boolean bl18 = iw2.i();
        if (bl17 || bl18) {
            if (!bl17) return false;
            if (!bl18) {
                return false;
            }
            if (!this.h.equals((Object)iw2.h)) {
                return false;
            }
        }
        boolean bl19 = this.j();
        boolean bl20 = iw2.j();
        if (bl19 || bl20) {
            if (!bl19) return false;
            if (!bl20) {
                return false;
            }
            if (!this.i.equals((Object)iw2.i)) {
                return false;
            }
        }
        boolean bl21 = this.k();
        boolean bl22 = iw2.k();
        if (bl21 || bl22) {
            if (!bl21) return false;
            if (!bl22) {
                return false;
            }
            if (this.a != iw2.a) {
                return false;
            }
        }
        boolean bl23 = this.l();
        boolean bl24 = iw2.l();
        if (!bl23 && !bl24) return true;
        if (!bl23) return false;
        if (!bl24) {
            return false;
        }
        if (this.a == iw2.a) return true;
        return false;
    }

    public iw b(String string) {
        this.c = string;
        return this;
    }

    public void b(jm jm2) {
        this.a();
        jm2.a(a);
        if (this.a != null && this.a()) {
            jm2.a(a);
            jm2.a(this.a);
            jm2.b();
        }
        if (this.a != null && this.b()) {
            jm2.a(b);
            this.a.b(jm2);
            jm2.b();
        }
        if (this.b != null) {
            jm2.a(c);
            jm2.a(this.b);
            jm2.b();
        }
        if (this.c != null) {
            jm2.a(d);
            jm2.a(this.c);
            jm2.b();
        }
        if (this.d != null && this.e()) {
            jm2.a(e);
            jm2.a(this.d);
            jm2.b();
        }
        if (this.e != null && this.f()) {
            jm2.a(f);
            jm2.a(this.e);
            jm2.b();
        }
        if (this.f != null && this.g()) {
            jm2.a(g);
            jm2.a(this.f);
            jm2.b();
        }
        if (this.g != null && this.h()) {
            jm2.a(h);
            jm2.a(this.g);
            jm2.b();
        }
        if (this.h != null && this.i()) {
            jm2.a(i);
            jm2.a(this.h);
            jm2.b();
        }
        if (this.i != null && this.j()) {
            jm2.a(j);
            jm2.a(this.i);
            jm2.b();
        }
        if (this.k()) {
            jm2.a(k);
            jm2.a(this.a);
            jm2.b();
        }
        if (this.l()) {
            jm2.a(l);
            jm2.a(this.a);
            jm2.b();
        }
        jm2.c();
        jm2.a();
    }

    public void b(boolean bl) {
        this.a.set(1, bl);
    }

    public boolean b() {
        return this.a != null;
    }

    public iw c(String string) {
        this.d = string;
        return this;
    }

    public boolean c() {
        return this.b != null;
    }

    public /* synthetic */ int compareTo(Object object) {
        return this.a((iw)object);
    }

    public iw d(String string) {
        this.f = string;
        return this;
    }

    public boolean d() {
        return this.c != null;
    }

    public iw e(String string) {
        this.g = string;
        return this;
    }

    public boolean e() {
        return this.d != null;
    }

    public boolean equals(Object object) {
        if (object == null) {
            return false;
        }
        if (object instanceof iw) {
            return this.a((iw)object);
        }
        return false;
    }

    public boolean f() {
        return this.e != null;
    }

    public boolean g() {
        return this.f != null;
    }

    public boolean h() {
        return this.g != null;
    }

    public int hashCode() {
        return 0;
    }

    public boolean i() {
        return this.h != null;
    }

    public boolean j() {
        return this.i != null;
    }

    public boolean k() {
        return this.a.get(0);
    }

    public boolean l() {
        return this.a.get(1);
    }

    public String toString() {
        boolean bl;
        boolean bl2;
        StringBuilder stringBuilder = new StringBuilder("XmPushActionUnRegistration(");
        if (this.a()) {
            stringBuilder.append("debug:");
            String string = this.a;
            if (string == null) {
                stringBuilder.append("null");
            } else {
                stringBuilder.append(string);
            }
            bl = false;
        } else {
            bl = true;
        }
        if (this.b()) {
            if (!bl) {
                stringBuilder.append(", ");
            }
            stringBuilder.append("target:");
            if if_ = this.a;
            if (if_ == null) {
                stringBuilder.append("null");
                bl2 = false;
            } else {
                stringBuilder.append((Object)if_);
                bl2 = false;
            }
        } else {
            bl2 = bl;
        }
        if (!bl2) {
            stringBuilder.append(", ");
        }
        stringBuilder.append("id:");
        String string = this.b;
        if (string == null) {
            stringBuilder.append("null");
        } else {
            stringBuilder.append(string);
        }
        stringBuilder.append(", ");
        stringBuilder.append("appId:");
        String string2 = this.c;
        if (string2 == null) {
            stringBuilder.append("null");
        } else {
            stringBuilder.append(string2);
        }
        if (this.e()) {
            stringBuilder.append(", ");
            stringBuilder.append("regId:");
            String string3 = this.d;
            if (string3 == null) {
                stringBuilder.append("null");
            } else {
                stringBuilder.append(string3);
            }
        }
        if (this.f()) {
            stringBuilder.append(", ");
            stringBuilder.append("appVersion:");
            String string4 = this.e;
            if (string4 == null) {
                stringBuilder.append("null");
            } else {
                stringBuilder.append(string4);
            }
        }
        if (this.g()) {
            stringBuilder.append(", ");
            stringBuilder.append("packageName:");
            String string5 = this.f;
            if (string5 == null) {
                stringBuilder.append("null");
            } else {
                stringBuilder.append(string5);
            }
        }
        if (this.h()) {
            stringBuilder.append(", ");
            stringBuilder.append("token:");
            String string6 = this.g;
            if (string6 == null) {
                stringBuilder.append("null");
            } else {
                stringBuilder.append(string6);
            }
        }
        if (this.i()) {
            stringBuilder.append(", ");
            stringBuilder.append("deviceId:");
            String string7 = this.h;
            if (string7 == null) {
                stringBuilder.append("null");
            } else {
                stringBuilder.append(string7);
            }
        }
        if (this.j()) {
            stringBuilder.append(", ");
            stringBuilder.append("aliasName:");
            String string8 = this.i;
            if (string8 == null) {
                stringBuilder.append("null");
            } else {
                stringBuilder.append(string8);
            }
        }
        if (this.k()) {
            stringBuilder.append(", ");
            stringBuilder.append("needAck:");
            stringBuilder.append(this.a);
        }
        if (this.l()) {
            stringBuilder.append(", ");
            stringBuilder.append("createdTs:");
            stringBuilder.append(this.a);
        }
        stringBuilder.append(")");
        return stringBuilder.toString();
    }
}

