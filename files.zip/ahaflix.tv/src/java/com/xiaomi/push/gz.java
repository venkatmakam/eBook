/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.xiaomi.push.al
 *  com.xiaomi.push.al$b
 *  com.xiaomi.push.ha
 *  java.lang.Object
 *  java.lang.Runnable
 */
package com.xiaomi.push;

import com.xiaomi.push.al;
import com.xiaomi.push.ha;

public class gz {
    private static al a = new al(true, 20);

    public static void a(al.b b7) {
        a.a(b7);
    }

    public static void a(al.b b7, long l3) {
        a.a(b7, l3);
    }

    public static void a(Runnable runnable) {
        a.a((al.b)new ha(runnable));
    }
}

