/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.xiaomi.push.hz
 *  com.xiaomi.push.jb
 *  com.xiaomi.push.jc
 *  com.xiaomi.push.jj
 *  com.xiaomi.push.jk
 *  com.xiaomi.push.jm
 *  com.xiaomi.push.jp
 *  com.xiaomi.push.jr
 *  e.a.a.a.a
 *  java.io.Serializable
 *  java.lang.Boolean
 *  java.lang.Class
 *  java.lang.Cloneable
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.List
 */
package com.xiaomi.push;

import com.xiaomi.push.hz;
import com.xiaomi.push.jb;
import com.xiaomi.push.jc;
import com.xiaomi.push.jj;
import com.xiaomi.push.jk;
import com.xiaomi.push.jm;
import com.xiaomi.push.jn;
import com.xiaomi.push.jp;
import com.xiaomi.push.jr;
import e.a.a.a.a;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class io
implements jb<io, Object>,
Serializable,
Cloneable {
    private static final jj a;
    private static final jr a;
    public List<hz> a;

    public static {
        a = new jr("XmPushActionNormalConfig");
        a = new jj("", 15, 1);
    }

    public int a(io io2) {
        int n5;
        if (!this.getClass().equals((Object)io2.getClass())) {
            return this.getClass().getName().compareTo(io2.getClass().getName());
        }
        int n6 = Boolean.valueOf((boolean)this.a()).compareTo(Boolean.valueOf((boolean)io2.a()));
        if (n6 != 0) {
            return n6;
        }
        if (this.a() && (n5 = jc.a((List)this.a, (List)io2.a)) != 0) {
            return n5;
        }
        return 0;
    }

    public List<hz> a() {
        return this.a;
    }

    public void a() {
        if (this.a != null) {
            return;
        }
        StringBuilder stringBuilder = a.F1((String)"Required field 'normalConfigs' was not present! Struct: ");
        stringBuilder.append(this.toString());
        throw new jn(stringBuilder.toString());
    }

    /*
     * Enabled aggressive block sorting
     */
    public void a(jm jm2) {
        jm2.a();
        do {
            jj jj2 = jm2.a();
            byte by = jj2.a;
            if (by == 0) {
                jm2.f();
                this.a();
                return;
            }
            if (jj2.a != 1 || by != 15) {
                jp.a((jm)jm2, (byte)by);
            } else {
                jk jk2 = jm2.a();
                this.a = new ArrayList(jk2.a);
                for (int i5 = 0; i5 < jk2.a; ++i5) {
                    hz hz2 = new hz();
                    hz2.a(jm2);
                    this.a.add((Object)hz2);
                }
                jm2.i();
            }
            jm2.g();
        } while (true);
    }

    public boolean a() {
        return this.a != null;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public boolean a(io io2) {
        if (io2 == null) {
            return false;
        }
        boolean bl = this.a();
        boolean bl2 = io2.a();
        if (!bl && !bl2) return true;
        if (!bl) return false;
        if (!bl2) {
            return false;
        }
        if (this.a.equals((Object)io2.a)) return true;
        return false;
    }

    public void b(jm jm2) {
        this.a();
        jm2.a(a);
        if (this.a != null) {
            jm2.a(a);
            jm2.a(new jk(12, this.a.size()));
            Iterator iterator = this.a.iterator();
            while (iterator.hasNext()) {
                ((hz)iterator.next()).b(jm2);
            }
            jm2.e();
            jm2.b();
        }
        jm2.c();
        jm2.a();
    }

    public /* synthetic */ int compareTo(Object object) {
        return this.a((io)object);
    }

    public boolean equals(Object object) {
        if (object == null) {
            return false;
        }
        if (object instanceof io) {
            return this.a((io)object);
        }
        return false;
    }

    public int hashCode() {
        return 0;
    }

    public String toString() {
        StringBuilder stringBuilder = a.d((String)"XmPushActionNormalConfig(", (String)"normalConfigs:");
        jj jj2 = this.a;
        if (jj2 == null) {
            stringBuilder.append("null");
        } else {
            stringBuilder.append((Object)jj2);
        }
        stringBuilder.append(")");
        return stringBuilder.toString();
    }
}

