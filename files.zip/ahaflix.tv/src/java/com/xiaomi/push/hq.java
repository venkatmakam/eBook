/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.xiaomi.push;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class hq
extends Enum<hq> {
    public static final /* enum */ hq A;
    public static final /* enum */ hq B;
    public static final /* enum */ hq C;
    public static final /* enum */ hq D;
    public static final /* enum */ hq E;
    public static final /* enum */ hq F;
    public static final /* enum */ hq G;
    public static final /* enum */ hq H;
    public static final /* enum */ hq I;
    public static final /* enum */ hq J;
    public static final /* enum */ hq K;
    public static final /* enum */ hq a;
    private static final /* synthetic */ hq[] a;
    public static final /* enum */ hq b;
    public static final /* enum */ hq c;
    public static final /* enum */ hq d;
    public static final /* enum */ hq e;
    public static final /* enum */ hq f;
    public static final /* enum */ hq g;
    public static final /* enum */ hq h;
    public static final /* enum */ hq i;
    public static final /* enum */ hq j;
    public static final /* enum */ hq k;
    public static final /* enum */ hq l;
    public static final /* enum */ hq m;
    public static final /* enum */ hq n;
    public static final /* enum */ hq o;
    public static final /* enum */ hq p;
    public static final /* enum */ hq q;
    public static final /* enum */ hq r;
    public static final /* enum */ hq s;
    public static final /* enum */ hq t;
    public static final /* enum */ hq u;
    public static final /* enum */ hq v;
    public static final /* enum */ hq w;
    public static final /* enum */ hq x;
    public static final /* enum */ hq y;
    public static final /* enum */ hq z;
    private final int a;

    public static {
        hq hq2;
        hq hq3;
        hq hq4;
        hq hq5;
        hq hq6;
        hq hq7;
        hq hq8;
        hq hq9;
        hq hq10;
        hq hq11;
        hq hq12;
        hq hq13;
        hq hq14;
        hq hq15;
        hq hq16;
        hq hq17;
        hq hq18;
        hq hq19;
        hq hq20;
        hq hq21;
        hq hq22;
        hq hq23;
        hq hq24;
        hq hq25;
        hq hq26;
        hq hq27;
        hq hq28;
        hq hq29;
        hq hq30;
        hq hq31;
        hq hq32;
        hq hq33;
        hq hq34;
        hq hq35;
        hq hq36;
        hq hq37;
        hq hq38;
        a = hq7 = new hq(1);
        b = hq32 = new hq(2);
        c = hq3 = new hq(3);
        d = hq12 = new hq(4);
        e = hq30 = new hq(5);
        f = hq6 = new hq(6);
        g = hq22 = new hq(7);
        h = hq23 = new hq(8);
        i = hq8 = new hq(9);
        j = hq17 = new hq(10);
        k = hq10 = new hq(11);
        l = hq16 = new hq(12);
        m = hq37 = new hq(13);
        n = hq18 = new hq(14);
        o = hq27 = new hq(15);
        p = hq11 = new hq(16);
        q = hq13 = new hq(17);
        r = hq36 = new hq(18);
        s = hq21 = new hq(19);
        t = hq35 = new hq(22);
        u = hq28 = new hq(23);
        v = hq19 = new hq(24);
        w = hq33 = new hq(99);
        x = hq15 = new hq(100);
        y = hq9 = new hq(101);
        z = hq25 = new hq(102);
        A = hq14 = new hq(103);
        B = hq38 = new hq(104);
        C = hq26 = new hq(105);
        D = hq2 = new hq(107);
        E = hq34 = new hq(108);
        F = hq24 = new hq(109);
        G = hq5 = new hq(110);
        H = hq31 = new hq(112);
        I = hq29 = new hq(113);
        J = hq4 = new hq(114);
        K = hq20 = new hq(200);
        a = new hq[]{hq7, hq32, hq3, hq12, hq30, hq6, hq22, hq23, hq8, hq17, hq10, hq16, hq37, hq18, hq27, hq11, hq13, hq36, hq21, hq35, hq28, hq19, hq33, hq15, hq9, hq25, hq14, hq38, hq26, hq2, hq34, hq24, hq5, hq31, hq29, hq4, hq20};
    }

    private hq(int n5) {
        this.a = n5;
    }

    public static hq a(int n4) {
        if (n4 != 200) {
            switch (n4) {
                default: {
                    switch (n4) {
                        default: {
                            switch (n4) {
                                default: {
                                    switch (n4) {
                                        default: {
                                            switch (n4) {
                                                default: {
                                                    return null;
                                                }
                                                case 114: {
                                                    return J;
                                                }
                                                case 113: {
                                                    return I;
                                                }
                                                case 112: 
                                            }
                                            return H;
                                        }
                                        case 110: {
                                            return G;
                                        }
                                        case 109: {
                                            return F;
                                        }
                                        case 108: {
                                            return E;
                                        }
                                        case 107: 
                                    }
                                    return D;
                                }
                                case 105: {
                                    return C;
                                }
                                case 104: {
                                    return B;
                                }
                                case 103: {
                                    return A;
                                }
                                case 102: {
                                    return z;
                                }
                                case 101: {
                                    return y;
                                }
                                case 100: {
                                    return x;
                                }
                                case 99: 
                            }
                            return w;
                        }
                        case 24: {
                            return v;
                        }
                        case 23: {
                            return u;
                        }
                        case 22: 
                    }
                    return t;
                }
                case 19: {
                    return s;
                }
                case 18: {
                    return r;
                }
                case 17: {
                    return q;
                }
                case 16: {
                    return p;
                }
                case 15: {
                    return o;
                }
                case 14: {
                    return n;
                }
                case 13: {
                    return m;
                }
                case 12: {
                    return l;
                }
                case 11: {
                    return k;
                }
                case 10: {
                    return j;
                }
                case 9: {
                    return i;
                }
                case 8: {
                    return h;
                }
                case 7: {
                    return g;
                }
                case 6: {
                    return f;
                }
                case 5: {
                    return e;
                }
                case 4: {
                    return d;
                }
                case 3: {
                    return c;
                }
                case 2: {
                    return b;
                }
                case 1: 
            }
            return a;
        }
        return K;
    }

    public static hq valueOf(String string2) {
        return (hq)Enum.valueOf(hq.class, (String)string2);
    }

    public static hq[] values() {
        return (hq[])a.clone();
    }

    public int a() {
        return this.a;
    }
}

