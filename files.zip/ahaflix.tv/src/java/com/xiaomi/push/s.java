/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.xiaomi.channel.commonutils.logger.b
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.reflect.Method
 */
package com.xiaomi.push;

import com.xiaomi.channel.commonutils.logger.b;
import com.xiaomi.push.t;
import java.lang.reflect.Method;

public class s {
    public static String a(String string2, String string3) {
        try {
            String string4 = (String)t.a(null, "android.os.SystemProperties").getMethod("get", new Class[]{String.class, String.class}).invoke(null, new Object[]{string2, string3});
            return string4;
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("SystemProperties.get: ");
            stringBuilder.append((Object)exception);
            b.a((String)stringBuilder.toString());
            return string3;
        }
    }
}

