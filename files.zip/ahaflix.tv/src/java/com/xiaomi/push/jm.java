/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.nio.ByteBuffer
 */
package com.xiaomi.push;

import com.xiaomi.push.jj;
import com.xiaomi.push.jk;
import com.xiaomi.push.jl;
import com.xiaomi.push.jq;
import com.xiaomi.push.jr;
import com.xiaomi.push.jw;
import java.nio.ByteBuffer;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public abstract class jm {
    public jw i;

    public jm(jw jw2) {
        this.i = jw2;
    }

    public abstract byte a();

    public abstract double a();

    public abstract int a();

    public abstract long a();

    public abstract jj a();

    public abstract jk a();

    public abstract jl a();

    public abstract jq a();

    public abstract jr a();

    public abstract String a();

    public abstract ByteBuffer a();

    public abstract short a();

    public abstract void a();

    public abstract void a(byte var1);

    public abstract void a(int var1);

    public abstract void a(long var1);

    public abstract void a(jj var1);

    public abstract void a(jk var1);

    public abstract void a(jl var1);

    public abstract void a(jr var1);

    public abstract void a(String var1);

    public abstract void a(ByteBuffer var1);

    public abstract void a(short var1);

    public abstract void a(boolean var1);

    public abstract boolean a();

    public abstract void b();

    public abstract void c();

    public abstract void d();

    public abstract void e();

    public abstract void f();

    public abstract void g();

    public abstract void h();

    public abstract void i();

    public abstract void j();

    public void k() {
    }
}

