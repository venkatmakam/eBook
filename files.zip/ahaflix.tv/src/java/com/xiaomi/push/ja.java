/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  com.xiaomi.channel.commonutils.logger.b
 *  com.xiaomi.push.ah
 *  com.xiaomi.push.g
 *  com.xiaomi.push.im
 *  com.xiaomi.push.js
 *  com.xiaomi.push.js$a
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 */
package com.xiaomi.push;

import android.content.Context;
import com.xiaomi.channel.commonutils.logger.b;
import com.xiaomi.push.ah;
import com.xiaomi.push.g;
import com.xiaomi.push.im;
import com.xiaomi.push.jb;
import com.xiaomi.push.jf;
import com.xiaomi.push.jg;
import com.xiaomi.push.jh;
import com.xiaomi.push.ji;
import com.xiaomi.push.jo;
import com.xiaomi.push.js;

public class ja {
    public static short a(Context context, im im2) {
        int n4 = 0 + g.a((Context)context, (String)im2.b, (boolean)false).a();
        int n5 = ah.b((Context)context) ? 4 : 0;
        int n6 = n4 + n5;
        boolean bl2 = ah.a((Context)context);
        int n7 = 0;
        if (bl2) {
            n7 = 8;
        }
        return (short)(n6 + n7);
    }

    public static <T extends jb<T, ?>> void a(T t2, byte[] arrby) {
        if (arrby != null) {
            new jf((jo)new js.a(true, true, arrby.length)).a(t2, arrby);
            return;
        }
        throw new jg("the message byte is empty.");
    }

    public static <T extends jb<T, ?>> byte[] a(T t2) {
        if (t2 == null) {
            return null;
        }
        try {
            byte[] arrby = new jh(new ji.a()).a(t2);
            return arrby;
        }
        catch (jg jg2) {
            b.a((String)"convertThriftObjectToBytes catch TException.", (Throwable)jg2);
            return null;
        }
    }
}

