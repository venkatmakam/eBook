/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.xiaomi.push;

import com.xiaomi.push.jb;
import com.xiaomi.push.ji;
import com.xiaomi.push.jm;
import com.xiaomi.push.jo;
import com.xiaomi.push.jv;
import com.xiaomi.push.jw;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class jf {
    private final jm a;
    private final jv a;

    public jf() {
        this(new ji.a());
    }

    public jf(jo jo2) {
        jv jv2;
        this.a = jv2 = new jv();
        this.a = jo2.a(jv2);
    }

    public void a(jb jb2, byte[] arrby) {
        try {
            this.a.a(arrby);
            jb2.a(this.a);
            return;
        }
        finally {
            this.a.k();
        }
    }
}

