/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.pm.PackageManager
 *  java.lang.Object
 *  java.lang.String
 */
package com.xiaomi.push;

import android.content.Context;
import android.content.pm.PackageManager;

public class m {
    public static boolean a(Context context, String string2) {
        String string3 = context.getPackageName();
        return context.getPackageManager().checkPermission(string2, string3) == 0;
    }
}

