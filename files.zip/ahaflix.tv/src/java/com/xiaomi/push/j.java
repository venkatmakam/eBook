/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.content.ServiceConnection
 *  android.content.pm.PackageInfo
 *  android.content.pm.PackageManager
 *  android.os.IBinder
 *  android.os.IInterface
 *  android.os.Looper
 *  android.os.Parcel
 *  java.io.IOException
 *  java.lang.Exception
 *  java.lang.IllegalStateException
 *  java.lang.InterruptedException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.concurrent.LinkedBlockingQueue
 *  java.util.concurrent.TimeUnit
 */
package com.xiaomi.push;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import android.os.Parcel;
import com.xiaomi.push.k;
import java.io.IOException;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

public final class j {
    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static a a(Context context) {
        b b7;
        Throwable throwable2222;
        block6 : {
            if (Looper.myLooper() == Looper.getMainLooper()) throw new IllegalStateException("Cannot be called from the main thread");
            context.getPackageManager().getPackageInfo("com.android.vending", 0);
            b7 = new b(null);
            Intent intent = new Intent("com.google.android.gms.ads.identifier.service.START");
            intent.setPackage("com.google.android.gms");
            if (!context.bindService(intent, (ServiceConnection)b7, 1)) throw new IOException("Google Play connection failed");
            IBinder iBinder = b7.a();
            if (iBinder == null) break block6;
            a a2 = new a(new c(iBinder).a(), false);
            context.unbindService((ServiceConnection)b7);
            return a2;
        }
        context.unbindService((ServiceConnection)b7);
        throw new IOException("Google Play connection failed");
        {
            catch (Throwable throwable2222) {
            }
            catch (Exception exception) {}
            {
                throw exception;
            }
        }
        context.unbindService((ServiceConnection)b7);
        throw throwable2222;
    }

    /*
     * Duplicate member names - consider using --renamedupmembers true
     */
    public static final class a {
        private final String a;
        private final boolean a;

        public a(String string2, boolean bl2) {
            this.a = string2;
            this.a = bl2;
        }

        public String a() {
            return this.a;
        }
    }

    public static final class b
    implements ServiceConnection {
        private final LinkedBlockingQueue<IBinder> a = new LinkedBlockingQueue(1);
        public boolean b = false;

        private b() {
        }

        public /* synthetic */ b(k k3) {
            this();
        }

        public IBinder a() {
            if (!this.b) {
                this.b = true;
                return (IBinder)this.a.poll(30000L, TimeUnit.MILLISECONDS);
            }
            throw new IllegalStateException();
        }

        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            try {
                this.a.put((Object)iBinder);
            }
            catch (InterruptedException interruptedException) {}
        }

        public void onServiceDisconnected(ComponentName componentName) {
        }
    }

    public static final class c
    implements IInterface {
        private IBinder a;

        public c(IBinder iBinder) {
            this.a = iBinder;
        }

        public String a() {
            Parcel parcel = Parcel.obtain();
            Parcel parcel2 = Parcel.obtain();
            try {
                parcel.writeInterfaceToken("com.google.android.gms.ads.identifier.internal.IAdvertisingIdService");
                this.a.transact(1, parcel, parcel2, 0);
                parcel2.readException();
                String string2 = parcel2.readString();
                return string2;
            }
            finally {
                parcel2.recycle();
                parcel.recycle();
            }
        }

        public IBinder asBinder() {
            return this.a;
        }
    }

}

