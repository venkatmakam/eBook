/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.amazon.identity.auth.device.AuthError
 *  com.amazon.identity.auth.device.api.Listener
 *  com.amazon.identity.auth.device.api.authorization.GetTokenResult
 *  java.lang.Object
 */
package com.amazon.identity.auth.device.api.authorization;

import com.amazon.identity.auth.device.AuthError;
import com.amazon.identity.auth.device.api.Listener;
import com.amazon.identity.auth.device.api.authorization.GetTokenResult;

public abstract class GetTokenListener
implements Listener<GetTokenResult, AuthError> {
    public abstract void onError(AuthError var1);

    public abstract void onSuccess(GetTokenResult var1);
}

