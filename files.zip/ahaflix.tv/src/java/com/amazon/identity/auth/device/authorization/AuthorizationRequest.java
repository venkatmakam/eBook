/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.net.Uri
 *  android.os.Bundle
 *  com.amazon.identity.auth.device.AbstractRequest
 *  com.amazon.identity.auth.device.AuthError
 *  com.amazon.identity.auth.device.authorization.AuthorizationHelper
 *  com.amazon.identity.auth.device.authorization.AuthorizationResponseProcessor
 *  java.lang.String
 */
package com.amazon.identity.auth.device.authorization;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import com.amazon.identity.auth.device.AbstractRequest;
import com.amazon.identity.auth.device.AuthError;
import com.amazon.identity.auth.device.api.authorization.AuthorizeRequest;
import com.amazon.identity.auth.device.authorization.AuthorizationHelper;
import com.amazon.identity.auth.device.authorization.AuthorizationResponseProcessor;
import com.amazon.identity.auth.device.authorization.api.AuthorizationListener;
import com.amazon.identity.auth.device.dataobject.AppInfo;
import com.amazon.identity.auth.device.interactive.InteractiveRequest;

public class AuthorizationRequest
extends AbstractRequest {
    private final AppInfo appInfo;
    private final String clientId;
    private final AuthorizationListener listener;
    private final Bundle options;
    private final String[] scopes;

    public AuthorizationRequest(AuthorizeRequest authorizeRequest, String string, String[] arrstring, Bundle bundle, AppInfo appInfo, AuthorizationListener authorizationListener) {
        super((InteractiveRequest)authorizeRequest);
        this.clientId = string;
        this.scopes = arrstring;
        this.options = bundle;
        this.appInfo = appInfo;
        this.listener = authorizationListener;
        if (authorizeRequest != null) {
            bundle.putString("InteractiveRequestType", authorizeRequest.getRequestType());
        }
    }

    public String getUrl(Context context) throws AuthError {
        return AuthorizationHelper.getOAuth2Url((Context)context, (String)context.getPackageName(), (String)this.clientId, (String[])this.scopes, (String)this.requestId, (boolean)true, (boolean)false, (Bundle)this.options, (AppInfo)this.appInfo);
    }

    public boolean handleResponse(Uri uri, Context context) {
        boolean bl = this.originalRequest != null;
        AuthorizationResponseProcessor.handleResponse((Context)context, (Uri)uri, (String[])this.scopes, (boolean)bl, (AuthorizationListener)this.listener);
        return true;
    }
}

