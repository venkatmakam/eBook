/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.amazon.identity.auth.device.dataobject.AuthorizationToken$AUTHZ_TOKEN_TYPE
 *  java.lang.String
 *  java.util.Date
 */
package com.amazon.identity.auth.device.token;

import com.amazon.identity.auth.device.dataobject.AuthorizationToken;
import java.util.Date;

public class RefreshAtzToken
extends AuthorizationToken {
    public RefreshAtzToken() {
        this.mType = AuthorizationToken.AUTHZ_TOKEN_TYPE.REFRESH;
    }

    private RefreshAtzToken(long l, String string, String string2, String string3, Date date, byte[] arrby) {
        super(string, string2, string3, date, date, arrby, AuthorizationToken.AUTHZ_TOKEN_TYPE.REFRESH);
        this.setId(l);
    }

    public RefreshAtzToken(RefreshAtzToken refreshAtzToken) {
        this(refreshAtzToken.getId(), refreshAtzToken.getAppFamilyId(), refreshAtzToken.getDirectedId(), refreshAtzToken.getTokenValue(), new Date(refreshAtzToken.getCreationTime().getTime()), refreshAtzToken.getMiscData());
    }

    public RefreshAtzToken(String string, String string2, String string3, Date date, byte[] arrby) {
        super(string, string2, string3, date, date, arrby, AuthorizationToken.AUTHZ_TOKEN_TYPE.REFRESH);
    }

    public RefreshAtzToken(String string, String string2, String string3, byte[] arrby) {
        this(string, string2, string3, new Date(), arrby);
    }
}

