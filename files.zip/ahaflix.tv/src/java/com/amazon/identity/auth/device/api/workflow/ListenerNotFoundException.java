/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.amazon.identity.auth.device.api.InvalidIntegrationException
 *  java.lang.String
 *  java.lang.Throwable
 */
package com.amazon.identity.auth.device.api.workflow;

import com.amazon.identity.auth.device.api.InvalidIntegrationException;

public class ListenerNotFoundException
extends InvalidIntegrationException {
    private static final long serialVersionUID = 3161216795426082455L;

    public ListenerNotFoundException() {
    }

    public ListenerNotFoundException(String string) {
        super(string);
    }

    public ListenerNotFoundException(String string, Throwable throwable) {
        super(string, throwable);
    }
}

