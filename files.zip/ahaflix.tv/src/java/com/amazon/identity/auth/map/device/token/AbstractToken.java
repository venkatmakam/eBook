/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.text.TextUtils
 *  android.text.format.Time
 *  com.amazon.identity.auth.device.AuthError
 *  com.amazon.identity.auth.map.device.AccountManagerConstants
 *  com.amazon.identity.auth.map.device.AccountManagerConstants$REGION_HINT
 *  com.amazon.identity.auth.map.device.token.Token
 *  com.amazon.identity.auth.map.device.utils.MAPLog
 *  java.lang.CharSequence
 *  java.lang.IllegalArgumentException
 *  java.lang.Long
 *  java.lang.NumberFormatException
 *  java.lang.Object
 *  java.lang.String
 *  java.util.HashMap
 *  java.util.Map
 */
package com.amazon.identity.auth.map.device.token;

import android.text.TextUtils;
import android.text.format.Time;
import com.amazon.identity.auth.device.AuthError;
import com.amazon.identity.auth.map.device.AccountManagerConstants;
import com.amazon.identity.auth.map.device.token.Token;
import com.amazon.identity.auth.map.device.utils.MAPLog;
import java.util.HashMap;
import java.util.Map;

public abstract class AbstractToken
implements Token {
    public static final long ALWAYS_EXPIRE = -1L;
    public static final String KEY_CREATION_TIME = "creation_time";
    public static final String KEY_EXPIRES_IN = "expires_in";
    private static final String LOG_TAG = "com.amazon.identity.auth.map.device.token.AbstractToken";
    public static final long NEVER_EXPIRE;
    private final String _token;
    public final Time localCreationTimestamp;
    public Map<String, String> tokenData;

    private AbstractToken() {
        this.localCreationTimestamp = new Time();
        this._token = null;
    }

    public AbstractToken(AbstractToken abstractToken) {
        Time time;
        this.localCreationTimestamp = time = new Time();
        if (abstractToken != null && !TextUtils.isEmpty((CharSequence)abstractToken.getToken())) {
            this._token = abstractToken.getToken();
            time.set(abstractToken.localCreationTimestamp);
            this.tokenData = new HashMap(abstractToken.tokenData);
            return;
        }
        throw new IllegalArgumentException("Token string may not be null for an AbstractToken");
    }

    public AbstractToken(String string) {
        Time time;
        this.localCreationTimestamp = time = new Time();
        if (!TextUtils.isEmpty((CharSequence)string)) {
            this._token = string;
            time.setToNow();
            this.tokenData = new HashMap();
            this.initTokenData();
            return;
        }
        throw new IllegalArgumentException("Token string may not be null for an AbstractToken");
    }

    public AbstractToken(Map<String, String> map) throws AuthError {
        String string;
        Time time;
        this.localCreationTimestamp = time = new Time();
        this._token = string = (String)map.get((Object)"token");
        if (!TextUtils.isEmpty((CharSequence)string)) {
            this.tokenData = map;
            String string2 = (String)map.get((Object)KEY_CREATION_TIME);
            if (string2 == null) {
                MAPLog.i((String)LOG_TAG, (String)"creation_time not found in token data when creating Token, setting creation time to now");
                time.setToNow();
                map.put((Object)KEY_CREATION_TIME, (Object)String.valueOf((long)time.toMillis(false)));
                return;
            }
            try {
                time.set(Long.parseLong((String)string2));
                return;
            }
            catch (NumberFormatException numberFormatException) {
                MAPLog.e((String)LOG_TAG, (String)"Unable to parse creation_time from token data when creating Token, setting creation time to now");
                this.localCreationTimestamp.setToNow();
                map.put((Object)KEY_CREATION_TIME, (Object)String.valueOf((long)this.localCreationTimestamp.toMillis(false)));
                return;
            }
        }
        throw new IllegalArgumentException("Token string may not be null for an AbstractToken");
    }

    public static AccountManagerConstants.REGION_HINT convertStringToRegionHint(String string) {
        AccountManagerConstants.REGION_HINT rEGION_HINT = AccountManagerConstants.REGION_HINT.EU;
        if (rEGION_HINT.toString().equalsIgnoreCase(string)) {
            return rEGION_HINT;
        }
        AccountManagerConstants.REGION_HINT rEGION_HINT2 = AccountManagerConstants.REGION_HINT.FE;
        if (rEGION_HINT2.toString().equalsIgnoreCase(string)) {
            return rEGION_HINT2;
        }
        AccountManagerConstants.REGION_HINT rEGION_HINT3 = AccountManagerConstants.REGION_HINT.CN;
        if (rEGION_HINT3.toString().equalsIgnoreCase(string)) {
            return rEGION_HINT3;
        }
        return AccountManagerConstants.REGION_HINT.NA;
    }

    private void initTokenData() {
        this.tokenData.put((Object)"token", (Object)this._token);
        this.tokenData.put((Object)KEY_CREATION_TIME, (Object)String.valueOf((long)this.localCreationTimestamp.toMillis(false)));
    }

    public static long millisToSecs(long l) {
        return l / 1000L;
    }

    public static long secsToMillis(long l) {
        return l * 1000L;
    }

    public final Map<String, String> getData() {
        return this.tokenData;
    }

    public String getDirectedId() {
        return (String)this.tokenData.get((Object)"directedid");
    }

    public Time getLocalTimestamp() {
        return this.localCreationTimestamp;
    }

    public final String getToken() {
        return this._token;
    }
}

