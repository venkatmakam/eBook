/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.amazon.identity.auth.device.interactive.InteractiveAPI
 *  com.amazon.identity.auth.device.interactive.InternalInteractiveListener
 *  java.lang.Object
 */
package com.amazon.identity.auth.device.interactive;

import com.amazon.identity.auth.device.api.CancellableListener;
import com.amazon.identity.auth.device.interactive.InteractiveAPI;
import com.amazon.identity.auth.device.interactive.InternalInteractiveListener;

public interface InteractiveListener<T, U, V>
extends CancellableListener<T, U, V>,
InteractiveAPI,
InternalInteractiveListener {
    @Override
    public void onCancel(U var1);

    @Override
    public void onError(V var1);

    @Override
    public void onSuccess(T var1);
}

