/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  com.amazon.identity.auth.device.AuthError
 *  com.amazon.identity.auth.device.AuthError$ERROR_TYPE
 *  com.amazon.identity.auth.device.endpoint.AbstractPandaRequest
 *  com.amazon.identity.auth.device.endpoint.PandaResponse
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.List
 *  org.apache.http.Header
 *  org.apache.http.message.BasicNameValuePair
 */
package com.amazon.identity.auth.device.endpoint;

import android.content.Context;
import com.amazon.identity.auth.device.AuthError;
import com.amazon.identity.auth.device.dataobject.AppInfo;
import com.amazon.identity.auth.device.endpoint.AbstractPandaRequest;
import com.amazon.identity.auth.device.endpoint.PandaResponse;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import org.apache.http.Header;
import org.apache.http.message.BasicNameValuePair;

public abstract class AbstractOauthTokenRequest<T extends PandaResponse>
extends AbstractPandaRequest<T> {
    private static final String APP_CLIENT_ID_PARAM = "client_id";
    public static final String GRANT_TYPE_PARAM = "grant_type";
    public static final String OAUTH_END_POINT = "/auth/o2/token";
    private final String appFamilyId;
    private final String clientId;

    public AbstractOauthTokenRequest(Context context, AppInfo appInfo) throws AuthError {
        super(context, appInfo);
        if (appInfo != null) {
            this.appFamilyId = appInfo.getAppFamilyId();
            this.clientId = appInfo.getClientId();
            return;
        }
        throw new AuthError("Appinfo can not be null to make an OAuthTokenRequest", AuthError.ERROR_TYPE.ERROR_UNKNOWN);
    }

    public String getAppFamilyId() {
        return this.appFamilyId;
    }

    public String getEndPoint() {
        return OAUTH_END_POINT;
    }

    public List<Header> getExtraHeaders() {
        return new ArrayList();
    }

    public abstract List<BasicNameValuePair> getExtraOauthTokenRequestParameters();

    public List<BasicNameValuePair> getExtraParameters() {
        ArrayList arrayList = new ArrayList();
        arrayList.add((Object)new BasicNameValuePair("grant_type", this.getGrantType()));
        arrayList.add((Object)new BasicNameValuePair("client_id", this.clientId));
        List<BasicNameValuePair> list = this.getExtraOauthTokenRequestParameters();
        if (list != null) {
            arrayList.addAll(list);
        }
        return arrayList;
    }

    public abstract String getGrantType();
}

