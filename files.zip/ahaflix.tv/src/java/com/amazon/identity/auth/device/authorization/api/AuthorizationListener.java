/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  com.amazon.identity.auth.device.AuthError
 *  java.lang.Object
 */
package com.amazon.identity.auth.device.authorization.api;

import android.os.Bundle;
import com.amazon.identity.auth.device.AuthError;
import com.amazon.identity.auth.device.api.CancellableListener;
import com.amazon.identity.auth.device.shared.APIListener;

public interface AuthorizationListener
extends APIListener,
CancellableListener<Bundle, Bundle, AuthError> {
    @Override
    public void onCancel(Bundle var1);

    @Override
    public void onError(AuthError var1);

    @Override
    public void onSuccess(Bundle var1);
}

