/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Bundle
 *  androidx.fragment.app.Fragment
 *  androidx.fragment.app.FragmentActivity
 *  androidx.fragment.app.FragmentManager
 *  com.amazon.identity.auth.device.interactive.InteractiveState
 *  com.amazon.identity.auth.device.interactive.InteractiveStateFragment
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.ref.WeakReference
 */
package com.amazon.identity.auth.device.interactive;

import android.content.Context;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import com.amazon.identity.auth.device.interactive.GenericInteractiveState;
import com.amazon.identity.auth.device.interactive.InteractiveState;
import com.amazon.identity.auth.device.interactive.InteractiveStateFragment;
import java.lang.ref.WeakReference;

public final class WorkflowSupportFragment
extends Fragment
implements InteractiveStateFragment {
    private WeakReference<Context> contextWeakReference;
    private GenericInteractiveState state = new GenericInteractiveState(this);

    public Object getApplicationContext() {
        return this.contextWeakReference.get();
    }

    public Object getFragment(Bundle bundle) {
        return this.getFragmentManager().getFragment(bundle, "wrappedFragment");
    }

    public Object getParentActivity() {
        return this.getActivity();
    }

    public InteractiveState getState() {
        return this.state;
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.state.readFromBundle(bundle);
    }

    public void onSaveInstanceState(Bundle bundle) {
        this.state.writeToBundle(bundle);
        super.onSaveInstanceState(bundle);
    }

    public void setApplicationContext(Context context) {
        this.contextWeakReference = new WeakReference((Object)context);
    }

    public void setState(GenericInteractiveState genericInteractiveState) {
        this.state = genericInteractiveState;
    }
}

