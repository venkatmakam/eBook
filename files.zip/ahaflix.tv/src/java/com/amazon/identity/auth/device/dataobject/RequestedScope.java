/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ContentValues
 *  android.content.Context
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.amazon.identity.auth.device.dataobject.AbstractDataObject
 *  com.amazon.identity.auth.device.dataobject.RequestedScope$1
 *  com.amazon.identity.auth.device.dataobject.RequestedScope$COL_INDEX
 *  com.amazon.identity.auth.device.dataobject.RequestedScope$OUTCOME
 *  com.amazon.identity.auth.device.dataobject.Scope
 *  com.amazon.identity.auth.device.datastore.AbstractDataSource
 *  com.amazon.identity.auth.map.device.utils.MAPLog
 *  e.a.a.a.a
 *  java.lang.Boolean
 *  java.lang.CloneNotSupportedException
 *  java.lang.Long
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.amazon.identity.auth.device.dataobject;

import android.content.ContentValues;
import android.content.Context;
import android.os.Parcel;
import android.os.Parcelable;
import com.amazon.identity.auth.device.dataobject.AbstractDataObject;
import com.amazon.identity.auth.device.dataobject.RequestedScope;
import com.amazon.identity.auth.device.dataobject.Scope;
import com.amazon.identity.auth.device.datastore.AbstractDataSource;
import com.amazon.identity.auth.device.datastore.RequestedScopeDataSource;
import com.amazon.identity.auth.map.device.utils.MAPLog;
import e.a.a.a.a;

public class RequestedScope
extends AbstractDataObject
implements Parcelable {
    public static final String[] ALL_COLUMNS;
    public static final Parcelable.Creator<RequestedScope> CREATOR;
    private static final String LOG_TAG;
    private String appFamilyId;
    private String directedId;
    private long mAuthorizationAccessTokenId;
    private long mAuthorizationRefreshTokenId;
    private String scopeValue;

    public static {
        LOG_TAG = RequestedScope.class.getName();
        ALL_COLUMNS = new String[]{"rowid", "Scope", "AppId", "DirectedId", "AtzAccessTokenId", "AtzRefreshTokenId"};
        CREATOR = new 1();
    }

    public RequestedScope() {
        long l;
        this.mAuthorizationAccessTokenId = l = OUTCOME.REJECTED.longVal;
        this.mAuthorizationRefreshTokenId = l;
    }

    private RequestedScope(long l, String string, String string2, String string3, long l2, long l3) {
        this(string, string2, string3, l2, l3);
        this.setRowId(l);
    }

    public RequestedScope(Parcel parcel) {
        long l;
        this.mAuthorizationAccessTokenId = l = OUTCOME.REJECTED.longVal;
        this.mAuthorizationRefreshTokenId = l;
        this.setRowId(parcel.readLong());
        this.scopeValue = parcel.readString();
        this.appFamilyId = parcel.readString();
        this.directedId = parcel.readString();
        this.mAuthorizationAccessTokenId = parcel.readLong();
        this.mAuthorizationRefreshTokenId = parcel.readLong();
    }

    public RequestedScope(String string, String string2, String string3) {
        long l;
        this.mAuthorizationAccessTokenId = l = OUTCOME.REJECTED.longVal;
        this.mAuthorizationRefreshTokenId = l;
        this.scopeValue = string;
        this.appFamilyId = string2;
        this.directedId = string3;
    }

    public RequestedScope(String string, String string2, String string3, long l, long l2) {
        this(string, string2, string3);
        this.mAuthorizationAccessTokenId = l;
        this.mAuthorizationRefreshTokenId = l2;
    }

    public RequestedScope clone() {
        RequestedScope requestedScope = new RequestedScope(this.getRowId(), this.scopeValue, this.appFamilyId, this.directedId, this.mAuthorizationAccessTokenId, this.mAuthorizationRefreshTokenId);
        return requestedScope;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        if (object instanceof RequestedScope) {
            boolean bl;
            block8 : {
                long l;
                long l2;
                RequestedScope requestedScope = (RequestedScope)((Object)object);
                boolean bl2 = this.scopeValue.equals((Object)requestedScope.getScopeValue());
                bl = false;
                if (!bl2) break block8;
                boolean bl3 = this.appFamilyId.equals((Object)requestedScope.getAppFamilyId());
                bl = false;
                if (!bl3) break block8;
                boolean bl4 = this.directedId.equals((Object)requestedScope.getDirectedId());
                bl = false;
                if (!bl4) break block8;
                long l3 = this.mAuthorizationAccessTokenId LCMP requestedScope.getAuthorizationAccessTokenId();
                bl = false;
                if (l3 != false) break block8;
                try {
                    l2 = this.mAuthorizationRefreshTokenId;
                    l = requestedScope.getAuthorizationRefreshTokenId();
                }
                catch (NullPointerException nullPointerException) {
                    String string = LOG_TAG;
                    StringBuilder stringBuilder = a.F1((String)"");
                    stringBuilder.append(nullPointerException.toString());
                    MAPLog.e((String)string, (String)stringBuilder.toString());
                }
                long l4 = l2 LCMP l;
                bl = false;
                if (l4 == false) {
                    bl = true;
                }
            }
            return bl;
        }
        return false;
    }

    public String getAppFamilyId() {
        return this.appFamilyId;
    }

    public long getAuthorizationAccessTokenId() {
        return this.mAuthorizationAccessTokenId;
    }

    public long getAuthorizationRefreshTokenId() {
        return this.mAuthorizationRefreshTokenId;
    }

    public RequestedScopeDataSource getDataSource(Context context) {
        return RequestedScopeDataSource.getInstance(context);
    }

    public String getDirectedId() {
        return this.directedId;
    }

    public Scope getScope() {
        return new Scope(this.scopeValue);
    }

    public String getScopeValue() {
        return this.scopeValue;
    }

    public ContentValues getValuesForInsert() {
        ContentValues contentValues = new ContentValues();
        String[] arrstring = ALL_COLUMNS;
        contentValues.put(arrstring[COL_INDEX.SCOPE.colId], this.scopeValue);
        contentValues.put(arrstring[COL_INDEX.APP_FAMILY_ID.colId], this.appFamilyId);
        contentValues.put(arrstring[COL_INDEX.DIRECTED_ID.colId], this.directedId);
        contentValues.put(arrstring[COL_INDEX.AUTHORIZATION_ACCESS_TOKEN_ID.colId], Long.valueOf((long)this.mAuthorizationAccessTokenId));
        contentValues.put(arrstring[COL_INDEX.AUTHORIZATION_REFRESH_TOKEN_ID.colId], Long.valueOf((long)this.mAuthorizationRefreshTokenId));
        return contentValues;
    }

    public Boolean isGranted() {
        long l = this.mAuthorizationAccessTokenId;
        if (l == OUTCOME.UNKNOWN.longVal) {
            return null;
        }
        if (l == OUTCOME.REJECTED.longVal) {
            return Boolean.FALSE;
        }
        return Boolean.TRUE;
    }

    public void setAppFamilyId(String string) {
        this.appFamilyId = string;
    }

    public void setAuthorizationAccessTokenId(long l) {
        this.mAuthorizationAccessTokenId = l;
    }

    public void setAuthorizationRefreshTokenId(long l) {
        this.mAuthorizationRefreshTokenId = l;
    }

    public void setDirectedId(String string) {
        this.directedId = string;
    }

    public void setIsGranted(Boolean bl) {
        if (bl != this.isGranted()) {
            if (bl == null) {
                OUTCOME oUTCOME = OUTCOME.UNKNOWN;
                this.setAuthorizationAccessTokenId(oUTCOME.longVal);
                this.setAuthorizationRefreshTokenId(oUTCOME.longVal);
                return;
            }
            if (bl == Boolean.FALSE) {
                OUTCOME oUTCOME = OUTCOME.REJECTED;
                this.setAuthorizationAccessTokenId(oUTCOME.longVal);
                this.setAuthorizationRefreshTokenId(oUTCOME.longVal);
                return;
            }
            OUTCOME oUTCOME = OUTCOME.GRANTED_LOCALLY;
            this.setAuthorizationAccessTokenId(oUTCOME.longVal);
            this.setAuthorizationRefreshTokenId(oUTCOME.longVal);
        }
    }

    public void setScopeValue(String string) {
        this.scopeValue = string;
    }

    public String toString() {
        StringBuilder stringBuilder = a.F1((String)"{ rowid=");
        stringBuilder.append(this.getRowId());
        stringBuilder.append(", scope=");
        stringBuilder.append(this.scopeValue);
        stringBuilder.append(", appFamilyId=");
        stringBuilder.append(this.appFamilyId);
        stringBuilder.append(", directedId=<obscured>, atzAccessTokenId=");
        stringBuilder.append(this.mAuthorizationAccessTokenId);
        stringBuilder.append(", atzRefreshTokenId=");
        return a.p1((StringBuilder)stringBuilder, (long)this.mAuthorizationRefreshTokenId, (String)" }");
    }

    public void writeToParcel(Parcel parcel, int n) {
        parcel.writeLong(this.getRowId());
        parcel.writeString(this.scopeValue);
        parcel.writeString(this.appFamilyId);
        parcel.writeString(this.directedId);
        parcel.writeLong(this.mAuthorizationAccessTokenId);
        parcel.writeLong(this.mAuthorizationRefreshTokenId);
    }
}

