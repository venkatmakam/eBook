/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ContentValues
 *  android.content.Context
 *  android.os.Bundle
 *  android.text.TextUtils
 *  com.amazon.identity.auth.device.AuthError
 *  com.amazon.identity.auth.device.AuthError$ERROR_TYPE
 *  com.amazon.identity.auth.device.dataobject.AbstractDataObject
 *  com.amazon.identity.auth.device.dataobject.Profile$COL_INDEX
 *  com.amazon.identity.auth.device.datastore.AbstractDataSource
 *  com.amazon.identity.auth.device.datastore.DatabaseHelper
 *  com.amazon.identity.auth.map.device.utils.MAPLog
 *  e.a.a.a.a
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.Calendar
 *  java.util.Date
 *  java.util.Iterator
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.amazon.identity.auth.device.dataobject;

import android.content.ContentValues;
import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import com.amazon.identity.auth.device.AuthError;
import com.amazon.identity.auth.device.dataobject.AbstractDataObject;
import com.amazon.identity.auth.device.dataobject.Profile;
import com.amazon.identity.auth.device.datastore.AbstractDataSource;
import com.amazon.identity.auth.device.datastore.DatabaseHelper;
import com.amazon.identity.auth.device.datastore.ProfileDataSource;
import com.amazon.identity.auth.map.device.utils.MAPLog;
import e.a.a.a.a;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import org.json.JSONException;
import org.json.JSONObject;

public class Profile
extends AbstractDataObject {
    public static final String[] ALL_COLUMNS = new String[]{"Id", "ExpirationTime", "AppId", "Data"};
    private static final int EXPIRATION_TIME = 3600000;
    private static final String LOG_TAG = "com.amazon.identity.auth.device.dataobject.Profile";
    public String mAppFamilyId;
    public String mData;
    public Date mExpirationTime;

    public Profile() {
    }

    public Profile(String string, String string2) {
        this(string, string2, new Date(3600000L + Calendar.getInstance().getTime().getTime()));
    }

    public Profile(String string, String string2, Date date) {
        this.mAppFamilyId = string;
        this.mData = string2;
        this.mExpirationTime = date;
    }

    private boolean dataEquals(Profile profile) {
        try {
            JSONObject jSONObject = new JSONObject(this.mData);
            JSONObject jSONObject2 = new JSONObject(profile.getData());
            Iterator iterator = jSONObject.keys();
            while (iterator.hasNext()) {
                String string = (String)iterator.next();
                boolean bl = jSONObject.getString(string).equals((Object)jSONObject2.getString(string));
                if (bl) continue;
                return false;
            }
            return true;
        }
        catch (Exception exception) {
            return TextUtils.equals((CharSequence)this.mData, (CharSequence)profile.getData());
        }
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private Bundle getDataFromJSON() throws AuthError {
        Bundle bundle = new Bundle();
        if (this.mData == null) return bundle;
        JSONObject jSONObject = new JSONObject(this.mData);
        try {
            Iterator iterator = jSONObject.keys();
            while (iterator.hasNext()) {
                String string = (String)iterator.next();
                bundle.putString(string, jSONObject.getString(string));
            }
            return bundle;
        }
        catch (JSONException jSONException) {
            String string = LOG_TAG;
            StringBuilder stringBuilder = a.F1((String)"Unable to parse profile data in database ");
            stringBuilder.append(jSONException.getMessage());
            MAPLog.e((String)string, (String)stringBuilder.toString());
            return bundle;
        }
        catch (JSONException jSONException) {
            MAPLog.e((String)LOG_TAG, (String)"JSONException while parsing profile information in database", (Throwable)jSONException);
            throw new AuthError("JSONException while parsing profile information in database", (Throwable)jSONException, AuthError.ERROR_TYPE.ERROR_JSON);
        }
    }

    public boolean equals(Object object) {
        if (object != null && object instanceof Profile) {
            boolean bl;
            block5 : {
                Profile profile = (Profile)((Object)object);
                boolean bl2 = TextUtils.equals((CharSequence)this.mAppFamilyId, (CharSequence)profile.getAppFamilyId());
                bl = false;
                if (!bl2) break block5;
                boolean bl3 = this.areObjectsEqual((Object)this.mExpirationTime, (Object)profile.getExpirationTime());
                bl = false;
                if (!bl3) break block5;
                try {
                    boolean bl4 = this.dataEquals(profile);
                    bl = false;
                    if (!bl4) break block5;
                    bl = true;
                }
                catch (NullPointerException nullPointerException) {
                    String string = LOG_TAG;
                    StringBuilder stringBuilder = a.F1((String)"");
                    stringBuilder.append(nullPointerException.toString());
                    MAPLog.e((String)string, (String)stringBuilder.toString());
                }
            }
            return bl;
        }
        return false;
    }

    public String getAppFamilyId() {
        return this.mAppFamilyId;
    }

    public String getData() {
        return this.mData;
    }

    public Bundle getDataAsBundle() throws AuthError {
        return this.getDataFromJSON();
    }

    public ProfileDataSource getDataSource(Context context) {
        return ProfileDataSource.getInstance(context);
    }

    public Date getExpirationTime() {
        return this.mExpirationTime;
    }

    public long getId() {
        return this.getRowId();
    }

    public ContentValues getValuesForInsert() {
        ContentValues contentValues = new ContentValues();
        String[] arrstring = ALL_COLUMNS;
        contentValues.put(arrstring[COL_INDEX.APP_ID.colId], this.mAppFamilyId);
        if (this.mExpirationTime != null) {
            contentValues.put(arrstring[COL_INDEX.EXPIRATION_TIME.colId], DatabaseHelper.getDateFormat().format(this.mExpirationTime));
        } else {
            contentValues.put(arrstring[COL_INDEX.EXPIRATION_TIME.colId], null);
        }
        contentValues.put(arrstring[COL_INDEX.DATA.colId], this.mData);
        return contentValues;
    }

    public boolean hasExpired() {
        Date date = this.mExpirationTime;
        if (date != null) {
            return date.before(Calendar.getInstance().getTime());
        }
        return true;
    }

    public void setAppId(String string) {
        this.mAppFamilyId = string;
    }

    public void setData(String string) {
        this.mData = string;
    }

    public void setExpirationTime(Date date) {
        this.mExpirationTime = DatabaseHelper.truncateFractionalSeconds((Date)date);
    }

    public void setId(long l) {
        this.setRowId(l);
    }

    public String toLogString() {
        StringBuilder stringBuilder = a.F1((String)"{ rowid=");
        stringBuilder.append(this.getId());
        stringBuilder.append(", appId=");
        stringBuilder.append(this.mAppFamilyId);
        stringBuilder.append(", expirationTime=");
        stringBuilder.append(DatabaseHelper.getDateFormat().format(this.mExpirationTime));
        stringBuilder.append(", data=");
        return a.r1((StringBuilder)stringBuilder, (String)this.mData, (String)" }");
    }

    public String toString() {
        return this.toLogString();
    }
}

