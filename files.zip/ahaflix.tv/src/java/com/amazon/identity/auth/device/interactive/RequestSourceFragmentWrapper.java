/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.annotation.SuppressLint
 *  android.app.Activity
 *  android.app.Fragment
 *  android.app.FragmentManager
 *  android.app.FragmentTransaction
 *  android.content.Context
 *  android.os.Bundle
 *  com.amazon.identity.auth.device.interactive.InteractiveRequestRecord
 *  com.amazon.identity.auth.device.interactive.InteractiveState
 *  com.amazon.identity.auth.device.interactive.InteractiveStateFragment
 *  com.amazon.identity.auth.device.interactive.RequestSource
 *  com.amazon.identity.auth.map.device.utils.MAPLog
 *  e.a.a.a.a
 *  java.lang.Class
 *  java.lang.ClassCastException
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.lang.ref.WeakReference
 */
package com.amazon.identity.auth.device.interactive;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Context;
import android.os.Bundle;
import com.amazon.identity.auth.device.interactive.InteractiveRequestRecord;
import com.amazon.identity.auth.device.interactive.InteractiveState;
import com.amazon.identity.auth.device.interactive.InteractiveStateFragment;
import com.amazon.identity.auth.device.interactive.RequestSource;
import com.amazon.identity.auth.device.interactive.WorkflowFragment;
import com.amazon.identity.auth.map.device.utils.MAPLog;
import e.a.a.a.a;
import java.lang.ref.WeakReference;

@SuppressLint(value={"NewApi"})
public final class RequestSourceFragmentWrapper
implements RequestSource {
    private static final String LOG_TAG = "com.amazon.identity.auth.device.interactive.RequestSourceFragmentWrapper";
    private final WeakReference<Fragment> fragmentReference;

    public RequestSourceFragmentWrapper(Fragment fragment) {
        if (fragment != null) {
            this.fragmentReference = new WeakReference((Object)fragment);
            return;
        }
        throw new IllegalArgumentException("fragment must be non-null");
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private InteractiveState getInteractiveStateAddingRequest(InteractiveRequestRecord interactiveRequestRecord) {
        Fragment fragment = (Fragment)this.fragmentReference.get();
        if (fragment != null) {
            FragmentManager fragmentManager;
            InteractiveStateFragment interactiveStateFragment;
            block5 : {
                String string;
                fragmentManager = fragment.getFragmentManager();
                try {
                    string = InteractiveStateFragment.TAG_ID;
                    interactiveStateFragment = (InteractiveStateFragment)fragmentManager.findFragmentByTag(string);
                    if (interactiveStateFragment != null) break block5;
                }
                catch (ClassCastException classCastException) {
                    String string2 = LOG_TAG;
                    StringBuilder stringBuilder = a.F1((String)"Found an invalid fragment looking for fragment with tag ");
                    stringBuilder.append(InteractiveStateFragment.TAG_ID);
                    stringBuilder.append(". Please use a different fragment tag.");
                    MAPLog.e((String)string2, (String)stringBuilder.toString(), (Throwable)classCastException);
                    return null;
                }
                interactiveStateFragment = new WorkflowFragment();
                fragmentManager.beginTransaction().add((Fragment)interactiveStateFragment, string).commit();
            }
            if (interactiveRequestRecord == null) return interactiveStateFragment.getState();
            Bundle bundle = new Bundle();
            fragmentManager.putFragment(bundle, "wrappedFragment", fragment);
            interactiveRequestRecord.setFragmentWrapper(bundle);
            interactiveStateFragment.getState().onRequestStart(interactiveRequestRecord);
            return interactiveStateFragment.getState();
        }
        MAPLog.e((String)LOG_TAG, (String)"Failed to get InteractiveState for a garbage-collected Fragment");
        return null;
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object == null) {
            return false;
        }
        if (RequestSourceFragmentWrapper.class != object.getClass()) {
            return false;
        }
        RequestSourceFragmentWrapper requestSourceFragmentWrapper = (RequestSourceFragmentWrapper)object;
        WeakReference<Fragment> weakReference = this.fragmentReference;
        if (weakReference == null) {
            if (requestSourceFragmentWrapper.fragmentReference != null) {
                return false;
            }
        } else {
            if (requestSourceFragmentWrapper.fragmentReference == null) {
                return false;
            }
            if (weakReference.get() == null ? requestSourceFragmentWrapper.fragmentReference.get() != null : !((Fragment)this.fragmentReference.get()).equals(requestSourceFragmentWrapper.fragmentReference.get())) {
                return false;
            }
        }
        return true;
    }

    public Object getBackingObject() {
        return this.fragmentReference.get();
    }

    public Context getContext() {
        return ((Fragment)this.fragmentReference.get()).getActivity();
    }

    public InteractiveState getInteractiveState() {
        return this.getInteractiveStateAddingRequest(null);
    }

    public int hashCode() {
        WeakReference<Fragment> weakReference = this.fragmentReference;
        int n = weakReference != null && weakReference.get() != null ? ((Fragment)this.fragmentReference.get()).hashCode() : 0;
        return 31 + n;
    }

    public boolean isHookNeededOnUIResume() {
        return true;
    }

    public void onStartRequest(InteractiveRequestRecord interactiveRequestRecord) {
        this.getInteractiveStateAddingRequest(interactiveRequestRecord);
    }
}

