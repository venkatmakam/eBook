/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Bundle
 *  com.amazon.identity.auth.device.authorization.api.AuthzConstants
 *  com.amazon.identity.auth.device.authorization.api.AuthzConstants$BUNDLE_KEY
 *  com.amazon.identity.auth.device.endpoint.PandaResponse
 *  com.amazon.identity.auth.map.device.utils.MAPLog
 *  e.a.a.a.a
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.List
 *  org.apache.http.Header
 *  org.apache.http.HttpResponse
 *  org.apache.http.message.BasicHeader
 *  org.apache.http.message.BasicNameValuePair
 */
package com.amazon.identity.auth.device.endpoint;

import android.content.Context;
import android.os.Bundle;
import com.amazon.identity.auth.device.authorization.api.AuthzConstants;
import com.amazon.identity.auth.device.dataobject.AppInfo;
import com.amazon.identity.auth.device.endpoint.AbstractPandaGetRequest;
import com.amazon.identity.auth.device.endpoint.PandaResponse;
import com.amazon.identity.auth.device.endpoint.ProfileResponse;
import com.amazon.identity.auth.map.device.utils.MAPLog;
import e.a.a.a.a;
import java.util.ArrayList;
import java.util.List;
import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.message.BasicHeader;
import org.apache.http.message.BasicNameValuePair;

public class ProfileRequest
extends AbstractPandaGetRequest<ProfileResponse> {
    public static final String API_PREFIX_DEVO_SANDBOX = "api-sandbox.integ";
    public static final String API_PREFIX_PRE_PROD_SANDBOX = "api.sandbox";
    public static final String API_PREFIX_PROD_SANDBOX = "api.sandbox";
    private static final String AUTHORIZATION = "Authorization";
    private static final String BEARER_PREFIX = "Bearer ";
    private static final String LOG_TAG = "com.amazon.identity.auth.device.endpoint.ProfileRequest";
    private static final String PROFILE_ENDPOINT = "/user/profile";
    private String authzToken;
    private boolean sandboxMode;

    public ProfileRequest(Bundle bundle, String string, Context context, AppInfo appInfo) {
        super(context, appInfo);
        this.authzToken = string;
        if (bundle != null) {
            this.sandboxMode = bundle.getBoolean(AuthzConstants.BUNDLE_KEY.SANDBOX.val, false);
        }
    }

    public ProfileResponse generateResponse(HttpResponse httpResponse) {
        return new ProfileResponse(httpResponse);
    }

    public String getEndPoint() {
        return PROFILE_ENDPOINT;
    }

    public List<Header> getExtraHeaders() {
        ArrayList arrayList = new ArrayList();
        StringBuilder stringBuilder = a.F1((String)BEARER_PREFIX);
        stringBuilder.append(this.authzToken);
        arrayList.add((Object)new BasicHeader(AUTHORIZATION, stringBuilder.toString()));
        return arrayList;
    }

    public List<BasicNameValuePair> getExtraParameters() {
        return new ArrayList();
    }

    public boolean isSandboxEnabled() {
        return this.sandboxMode;
    }

    public void logRequest() {
        String string = LOG_TAG;
        StringBuilder stringBuilder = a.F1((String)"accessToken=");
        stringBuilder.append(this.authzToken);
        MAPLog.pii((String)string, (String)"Executing profile request", (String)stringBuilder.toString());
    }
}

