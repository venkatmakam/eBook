/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.text.TextUtils
 *  com.amazon.identity.auth.device.AuthError
 *  com.amazon.identity.auth.device.AuthError$ERROR_TYPE
 *  com.amazon.identity.auth.device.dataobject.Scope
 *  com.amazon.identity.auth.device.endpoint.PandaResponse
 *  com.amazon.identity.auth.device.utils.ScopeUtils
 *  com.amazon.identity.auth.map.device.utils.MAPLog
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 *  org.apache.http.HttpResponse
 *  org.apache.http.message.BasicNameValuePair
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.amazon.identity.auth.device.endpoint;

import android.content.Context;
import android.text.TextUtils;
import com.amazon.identity.auth.device.AuthError;
import com.amazon.identity.auth.device.dataobject.AppInfo;
import com.amazon.identity.auth.device.dataobject.Scope;
import com.amazon.identity.auth.device.endpoint.AbstractJsonPandaRequest;
import com.amazon.identity.auth.device.endpoint.CreateCodePairResponse;
import com.amazon.identity.auth.device.endpoint.PandaResponse;
import com.amazon.identity.auth.device.utils.ScopeUtils;
import com.amazon.identity.auth.map.device.utils.MAPLog;
import java.util.ArrayList;
import java.util.List;
import org.apache.http.HttpResponse;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

public class CreateCodePairRequest
extends AbstractJsonPandaRequest<CreateCodePairResponse> {
    private static final String APP_CLIENT_ID_PARAM = "client_id";
    private static final String CREATE_CODE_PAIR_ENDPOINT = "/auth/O2/create/codepair";
    private static final String DEVICE_CODE_GRANT = "device_code";
    private static final String LOG_TAG = "com.amazon.identity.auth.device.endpoint.CreateCodePairRequest";
    private static final String RESPONSE_TYPE_PARAM = "response_type";
    private static final String SCOPE = "scope";
    private static final String SCOPE_DATA = "scope_data";
    private final String mAppId;
    private final String mClientId;
    private final Scope[] mScopes;

    public CreateCodePairRequest(Context context, AppInfo appInfo, Scope[] arrscope) {
        super(context, appInfo);
        this.mScopes = arrscope;
        this.mClientId = appInfo.getClientId();
        this.mAppId = appInfo.getAppFamilyId();
    }

    private String generateScopeDataStringWithScopeName(Scope scope) throws JSONException {
        JSONObject jSONObject = new JSONObject(scope.getScopeData());
        JSONObject jSONObject2 = new JSONObject();
        jSONObject2.put(scope.getScopeName(), (Object)jSONObject);
        return jSONObject2.toString();
    }

    public CreateCodePairResponse generateResponse(HttpResponse httpResponse) {
        return new CreateCodePairResponse(httpResponse, this.mAppId, ScopeUtils.getScopeNamesFromScopeArray((Scope[])this.mScopes));
    }

    public String getEndPoint() {
        return CREATE_CODE_PAIR_ENDPOINT;
    }

    public List<BasicNameValuePair> getExtraParameters() throws AuthError {
        ArrayList arrayList = new ArrayList();
        arrayList.add((Object)new BasicNameValuePair(RESPONSE_TYPE_PARAM, DEVICE_CODE_GRANT));
        for (Scope scope : this.mScopes) {
            String string;
            arrayList.add((Object)new BasicNameValuePair(SCOPE, scope.getScopeName()));
            if (TextUtils.isEmpty((CharSequence)scope.getScopeData())) continue;
            try {
                string = this.generateScopeDataStringWithScopeName(scope);
            }
            catch (JSONException jSONException) {
                MAPLog.e((String)LOG_TAG, (String)"Error create JSON scope data object");
                throw new AuthError("Error create JSON scope data object", AuthError.ERROR_TYPE.ERROR_JSON);
            }
            arrayList.add((Object)new BasicNameValuePair(SCOPE_DATA, string));
        }
        arrayList.add((Object)new BasicNameValuePair(APP_CLIENT_ID_PARAM, this.mClientId));
        return arrayList;
    }

    public void logRequest() {
        MAPLog.i((String)LOG_TAG, (String)"Executing code pair generation");
    }
}

