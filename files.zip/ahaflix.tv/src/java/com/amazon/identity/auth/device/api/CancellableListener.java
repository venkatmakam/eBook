/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.amazon.identity.auth.device.api.Listener
 *  java.lang.Object
 */
package com.amazon.identity.auth.device.api;

import com.amazon.identity.auth.device.api.Listener;

public interface CancellableListener<T, U, V>
extends Listener<T, V> {
    public void onCancel(U var1);

    public void onError(V var1);

    public void onSuccess(T var1);
}

