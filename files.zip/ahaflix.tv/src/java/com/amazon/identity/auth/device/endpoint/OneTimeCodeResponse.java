/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.amazon.identity.auth.device.AuthError
 *  java.io.IOException
 *  java.lang.String
 *  org.apache.http.HttpResponse
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.amazon.identity.auth.device.endpoint;

import com.amazon.identity.auth.device.AuthError;
import com.amazon.identity.auth.device.endpoint.AbstractJSONTokenResponse;
import java.io.IOException;
import org.apache.http.HttpResponse;
import org.json.JSONException;
import org.json.JSONObject;

public class OneTimeCodeResponse
extends AbstractJSONTokenResponse {
    private static final String ONE_TIME_CODE_PARAMETER = "oneTimeCode";
    private String oneTimeCode;

    public OneTimeCodeResponse(HttpResponse httpResponse) {
        super(httpResponse);
    }

    @Override
    public void doParse(JSONObject jSONObject) throws IOException, JSONException, AuthError {
        this.setOneTimeCode(jSONObject.getString(ONE_TIME_CODE_PARAMETER));
    }

    @Override
    public JSONObject extractResponseJSONObject(JSONObject jSONObject) throws JSONException {
        return jSONObject;
    }

    public String getOneTimeCode() {
        return this.oneTimeCode;
    }

    public void setOneTimeCode(String string) {
        this.oneTimeCode = string;
    }
}

