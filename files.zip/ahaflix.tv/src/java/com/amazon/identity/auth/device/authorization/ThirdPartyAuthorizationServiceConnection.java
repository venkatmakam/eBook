/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.IBinder
 *  android.os.IInterface
 *  com.amazon.identity.auth.device.authorization.AmazonAuthorizationServiceInterface
 *  com.amazon.identity.auth.device.authorization.MAPServiceConnection
 *  com.amazon.identity.auth.map.device.utils.MAPLog
 *  java.lang.Class
 *  java.lang.String
 */
package com.amazon.identity.auth.device.authorization;

import android.os.IBinder;
import android.os.IInterface;
import com.amazon.identity.auth.device.authorization.AmazonAuthorizationServiceInterface;
import com.amazon.identity.auth.device.authorization.MAPServiceConnection;
import com.amazon.identity.auth.map.device.utils.MAPLog;

public class ThirdPartyAuthorizationServiceConnection
extends MAPServiceConnection<AmazonAuthorizationServiceInterface> {
    private static final String LOG_TAG = ThirdPartyAuthorizationServiceConnection.class.getName();

    public ThirdPartyAuthorizationServiceConnection() {
        MAPLog.i((String)LOG_TAG, (String)"ThirdPartyAuthorizationServiceInterface created");
    }

    public IInterface getServiceInterface(IBinder iBinder) {
        return AmazonAuthorizationServiceInterface.Stub.asInterface(iBinder);
    }

    public Class<AmazonAuthorizationServiceInterface> getServiceInterfaceClass() {
        return AmazonAuthorizationServiceInterface.class;
    }
}

