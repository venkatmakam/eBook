/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.amazon.identity.auth.device.AuthError
 *  com.amazon.identity.auth.device.AuthError$ERROR_TYPE
 *  com.amazon.identity.auth.map.device.utils.MAPLog
 *  java.lang.String
 *  java.lang.StringBuilder
 *  org.apache.http.HttpResponse
 *  org.json.JSONObject
 */
package com.amazon.identity.auth.device.endpoint;

import com.amazon.identity.auth.device.AuthError;
import com.amazon.identity.auth.device.endpoint.OauthTokenResponse;
import com.amazon.identity.auth.device.token.RefreshAtzToken;
import com.amazon.identity.auth.map.device.utils.MAPLog;
import org.apache.http.HttpResponse;
import org.json.JSONObject;

public class OauthCodeForTokenResponse
extends OauthTokenResponse {
    private static final String LOG_TAG = "com.amazon.identity.auth.device.endpoint.OauthCodeForTokenResponse";

    public OauthCodeForTokenResponse(HttpResponse httpResponse, String string, String string2) {
        super(httpResponse, string, string2);
        String string3 = LOG_TAG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Creating OauthCodeForTokenResponse appId=");
        stringBuilder.append(string);
        MAPLog.i((String)string3, (String)stringBuilder.toString());
    }

    @Override
    public RefreshAtzToken extractRefreshAtzToken(JSONObject jSONObject) throws AuthError {
        RefreshAtzToken refreshAtzToken = super.extractRefreshAtzToken(jSONObject);
        if (refreshAtzToken != null) {
            return refreshAtzToken;
        }
        throw new AuthError("JSON response did not contain an AccessAtzToken", AuthError.ERROR_TYPE.ERROR_JSON);
    }

    @Override
    public boolean isInvalidToken(String string, String string2) {
        return false;
    }
}

