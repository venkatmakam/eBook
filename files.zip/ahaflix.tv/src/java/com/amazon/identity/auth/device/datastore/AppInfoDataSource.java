/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.database.Cursor
 *  android.database.sqlite.SQLiteDatabase
 *  com.amazon.identity.auth.device.dataobject.AbstractDataObject
 *  com.amazon.identity.auth.device.dataobject.AppInfo$COL_INDEX
 *  com.amazon.identity.auth.device.datastore.AbstractDataSource
 *  com.amazon.identity.auth.device.utils.MAPUtils
 *  com.amazon.identity.auth.map.device.utils.MAPLog
 *  e.a.a.a.a
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.List
 */
package com.amazon.identity.auth.device.datastore;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import com.amazon.identity.auth.device.dataobject.AbstractDataObject;
import com.amazon.identity.auth.device.dataobject.AppInfo;
import com.amazon.identity.auth.device.datastore.AbstractDataSource;
import com.amazon.identity.auth.device.utils.MAPUtils;
import com.amazon.identity.auth.map.device.utils.MAPLog;
import e.a.a.a.a;
import java.util.List;

public final class AppInfoDataSource
extends AbstractDataSource<AppInfo> {
    private static final String[] ALL_COLUMNS = AppInfo.ALL_COLUMNS;
    private static AppInfoDataSource INSTANCE;
    private static final String LOG_TAG = "com.amazon.identity.auth.device.datastore.AppInfoDataSource";

    private AppInfoDataSource(SQLiteDatabase sQLiteDatabase) {
        super(sQLiteDatabase);
    }

    public static AppInfoDataSource getInstance(Context context) {
        Class<AppInfoDataSource> class_ = AppInfoDataSource.class;
        synchronized (AppInfoDataSource.class) {
            if (INSTANCE == null) {
                INSTANCE = new AppInfoDataSource(MAPUtils.getMAPdatabase((Context)context));
            }
            AppInfoDataSource appInfoDataSource = INSTANCE;
            // ** MonitorExit[var3_1] (shouldn't be in output)
            return appInfoDataSource;
        }
    }

    public static void resetInstance() {
        INSTANCE = null;
        MAPUtils.resetDatabaseInstance();
    }

    public AppInfo cursorToObject(Cursor cursor) {
        if (cursor != null) {
            if (cursor.getCount() == 0) {
                return null;
            }
            try {
                AppInfo appInfo = new AppInfo();
                appInfo.setRowId(cursor.getLong(this.getColumnIndex(cursor, AppInfo.COL_INDEX.ROW_ID.colId)));
                appInfo.setAppFamilyId(cursor.getString(this.getColumnIndex(cursor, AppInfo.COL_INDEX.APP_FAMILY_ID.colId)));
                appInfo.setAppVariantId(cursor.getString(this.getColumnIndex(cursor, AppInfo.COL_INDEX.APP_VARIANT_ID.colId)));
                appInfo.setPackageName(cursor.getString(this.getColumnIndex(cursor, AppInfo.COL_INDEX.PACKAGE_NAME.colId)));
                appInfo.setAllowedScopes(MAPUtils.toStringArray((String)cursor.getString(this.getColumnIndex(cursor, AppInfo.COL_INDEX.ALLOWED_SCOPES.colId)), (String)","));
                appInfo.setGrantedPermissions(MAPUtils.toStringArray((String)cursor.getString(this.getColumnIndex(cursor, AppInfo.COL_INDEX.GRANTED_PERMISSIONS.colId)), (String)","));
                appInfo.setClientId(cursor.getString(this.getColumnIndex(cursor, AppInfo.COL_INDEX.CLIENT_ID.colId)));
                appInfo.setAuthorizationHost(cursor.getString(this.getColumnIndex(cursor, AppInfo.COL_INDEX.AUTHZ_HOST.colId)));
                appInfo.setExchangeHost(cursor.getString(this.getColumnIndex(cursor, AppInfo.COL_INDEX.EXCHANGE_HOST.colId)));
                appInfo.setPayload(cursor.getString(this.getColumnIndex(cursor, AppInfo.COL_INDEX.PAYLOAD.colId)));
                return appInfo;
            }
            catch (Exception exception) {
                String string = LOG_TAG;
                StringBuilder stringBuilder = a.F1((String)"");
                stringBuilder.append(exception.getMessage());
                MAPLog.e((String)string, (String)stringBuilder.toString(), (Throwable)exception);
            }
        }
        return null;
    }

    public int deleteByAppFamilyId(String string) {
        return this.deleteRowsBySingleColumn(ALL_COLUMNS[AppInfo.COL_INDEX.APP_FAMILY_ID.colId], string);
    }

    public int deleteByPackageName(String string) {
        return this.deleteRowsBySingleColumn(ALL_COLUMNS[AppInfo.COL_INDEX.PACKAGE_NAME.colId], string);
    }

    public List<AppInfo> findByAppFamilyId(String string) {
        return this.findAllRowsBySingleColumn(ALL_COLUMNS[AppInfo.COL_INDEX.APP_FAMILY_ID.colId], string);
    }

    public AppInfo findByAppVariantId(String string) {
        return (AppInfo)this.findOneRowBySingleColumn(ALL_COLUMNS[AppInfo.COL_INDEX.APP_VARIANT_ID.colId], string);
    }

    public AppInfo findByPackageName(String string) {
        return (AppInfo)this.findOneRowBySingleColumn(ALL_COLUMNS[AppInfo.COL_INDEX.PACKAGE_NAME.colId], string);
    }

    public AppInfo findByPrimaryKey(String string) {
        return this.findByAppVariantId(string);
    }

    public String[] getAllColumns() {
        return ALL_COLUMNS;
    }

    public String getLogTag() {
        return LOG_TAG;
    }

    public String getTableName() {
        return "AppInfo";
    }
}

