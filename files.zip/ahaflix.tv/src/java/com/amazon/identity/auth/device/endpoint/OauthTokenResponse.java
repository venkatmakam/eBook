/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.text.TextUtils
 *  com.amazon.identity.auth.device.AuthError
 *  com.amazon.identity.auth.device.AuthError$ERROR_TYPE
 *  com.amazon.identity.auth.map.device.token.Token
 *  com.amazon.identity.auth.map.device.utils.MAPLog
 *  e.a.a.a.a
 *  java.io.IOException
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  org.apache.http.Header
 *  org.apache.http.HttpResponse
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.amazon.identity.auth.device.endpoint;

import android.text.TextUtils;
import com.amazon.identity.auth.device.AuthError;
import com.amazon.identity.auth.device.InvalidTokenAuthError;
import com.amazon.identity.auth.device.dataobject.AuthorizationToken;
import com.amazon.identity.auth.device.endpoint.AbstractJSONTokenResponse;
import com.amazon.identity.auth.device.token.AccessAtzToken;
import com.amazon.identity.auth.device.token.RefreshAtzToken;
import com.amazon.identity.auth.map.device.token.AbstractToken;
import com.amazon.identity.auth.map.device.token.Token;
import com.amazon.identity.auth.map.device.utils.MAPLog;
import e.a.a.a.a;
import java.io.IOException;
import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.json.JSONException;
import org.json.JSONObject;

public class OauthTokenResponse
extends AbstractJSONTokenResponse {
    public static final String AUTHZ_ACCESS_TOKEN = "access_token";
    public static final String AUTHZ_ERROR_DESCIRPTION = "error_description";
    public static final String AUTHZ_INSUFFICIENT_SCOPE = "insufficient_scope";
    public static final String AUTHZ_INVALID_CLIENT = "invalid_client";
    public static final String AUTHZ_INVALID_GRANT = "invalid_grant";
    public static final String AUTHZ_INVALID_REQUEST = "invalid_request";
    public static final String AUTHZ_INVALID_SCOPE = "invalid_scope";
    public static final String AUTHZ_INVALID_TOKEN = "invalid_token";
    public static final String AUTHZ_UNAUTHORIZED_CLIENT = "unauthorized_client";
    public static final String AUTHZ_UNSUPPORTED_GRANT_TYPE = "unsupported_grant_type";
    private static final String LOG_TAG = "com.amazon.identity.auth.device.endpoint.OauthTokenResponse";
    private static final String REQUEST_ID_HEADER = "x-amzn-RequestId";
    public AccessAtzToken mAccessToken;
    private final String mAppFamilyId;
    private String mDirectedId;
    private RefreshAtzToken mRefreshToken = null;

    public OauthTokenResponse(HttpResponse httpResponse, String string, String string2) {
        super(httpResponse);
        this.mAppFamilyId = string;
        this.mDirectedId = string2;
    }

    public Token createPrimaryToken(String string, long l) {
        AccessAtzToken accessAtzToken = new AccessAtzToken(this.mAppFamilyId, this.mDirectedId, string, l, null);
        return accessAtzToken;
    }

    @Override
    public void doParse(JSONObject jSONObject) throws IOException, JSONException, AuthError {
        this.mAccessToken = this.extractAccessAtzToken(jSONObject);
        this.mRefreshToken = this.extractRefreshAtzToken(jSONObject);
    }

    public AccessAtzToken extractAccessAtzToken(JSONObject jSONObject) throws AuthError {
        block3 : {
            String string;
            try {
                if (!jSONObject.has(AUTHZ_ACCESS_TOKEN)) break block3;
                string = jSONObject.getString(AUTHZ_ACCESS_TOKEN);
            }
            catch (JSONException jSONException) {
                MAPLog.e((String)LOG_TAG, (String)"Error reading JSON response, throwing AuthError");
                throw new AuthError("Error reading JSON response", AuthError.ERROR_TYPE.ERROR_JSON);
            }
            return (AccessAtzToken)this.createPrimaryToken(string, AbstractToken.secsToMillis(this.getExpiresIn(jSONObject)));
        }
        MAPLog.e((String)LOG_TAG, (String)"Unable to find AccessAtzToken in JSON response, throwing AuthError");
        throw new AuthError("JSON response did not contain an AccessAtzToken", AuthError.ERROR_TYPE.ERROR_JSON);
    }

    public RefreshAtzToken extractRefreshAtzToken(JSONObject jSONObject) throws AuthError {
        String string = LOG_TAG;
        MAPLog.i((String)string, (String)"Extracting RefreshToken");
        try {
            if (jSONObject.has("refresh_token")) {
                String string2 = jSONObject.getString("refresh_token");
                return new RefreshAtzToken(this.getAppFamilyId(), this.mDirectedId, string2, null);
            }
            MAPLog.e((String)string, (String)"Unable to find RefreshAtzToken in JSON response");
            return null;
        }
        catch (JSONException jSONException) {
            MAPLog.e((String)LOG_TAG, (String)"Error reading JSON response, throwing AuthError");
            throw new AuthError("Error reading JSON response", AuthError.ERROR_TYPE.ERROR_JSON);
        }
    }

    @Override
    public JSONObject extractResponseJSONObject(JSONObject jSONObject) throws JSONException {
        try {
            JSONObject jSONObject2 = super.extractResponseJSONObject(jSONObject);
            return jSONObject2;
        }
        catch (JSONException jSONException) {
            MAPLog.w((String)LOG_TAG, (String)"No Response type in the response");
            return jSONObject;
        }
    }

    public AccessAtzToken getAccessAtzToken() {
        return this.mAccessToken;
    }

    public String getAppFamilyId() {
        return this.mAppFamilyId;
    }

    public AuthorizationToken[] getAtzTokens() {
        AuthorizationToken[] arrauthorizationToken = new AuthorizationToken[]{this.mAccessToken, this.mRefreshToken};
        return arrauthorizationToken;
    }

    public RefreshAtzToken getRefreshAtzToken() {
        return this.mRefreshToken;
    }

    @Override
    public String getVersion() {
        return "3.0.3";
    }

    public void handleInvalidToken(JSONObject jSONObject) throws InvalidTokenAuthError {
        String string = LOG_TAG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("info=");
        stringBuilder.append((Object)jSONObject);
        MAPLog.pii((String)string, (String)"Invalid Token in exchange.", (String)stringBuilder.toString());
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("Invalid Token in exchange.");
        stringBuilder2.append((Object)jSONObject);
        throw new InvalidTokenAuthError(stringBuilder2.toString());
    }

    /*
     * Exception decompiling
     */
    @Override
    public void handleJSONError(JSONObject var1) throws AuthError {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl247 : RETURN : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    public boolean isInsufficientScope(String string, String string2) {
        return AUTHZ_INSUFFICIENT_SCOPE.equals((Object)string);
    }

    public boolean isInvalidClient(String string, String string2) {
        return AUTHZ_INVALID_CLIENT.equals((Object)string);
    }

    public boolean isInvalidGrant(String string, String string2) {
        return AUTHZ_INVALID_GRANT.equals((Object)string) || AUTHZ_UNSUPPORTED_GRANT_TYPE.equals((Object)string);
        {
        }
    }

    public boolean isInvalidScope(String string, String string2) {
        return AUTHZ_INVALID_SCOPE.equals((Object)string);
    }

    public boolean isInvalidToken(String string, String string2) {
        return AUTHZ_INVALID_TOKEN.equals((Object)string) || AUTHZ_INVALID_REQUEST.equals((Object)string) && !TextUtils.isEmpty((CharSequence)string2) && string2.contains((CharSequence)AUTHZ_ACCESS_TOKEN);
        {
        }
    }

    public boolean isUnauthorizedClient(String string, String string2) {
        return AUTHZ_UNAUTHORIZED_CLIENT.equals((Object)string);
    }

    @Override
    public void logRequestId(JSONObject jSONObject) {
        super.logRequestId(jSONObject);
        Header header = this.getResponse().getFirstHeader(REQUEST_ID_HEADER);
        if (header != null) {
            String string = LOG_TAG;
            StringBuilder stringBuilder = a.F1((String)"requestId=");
            stringBuilder.append(header.getValue());
            MAPLog.pii((String)string, (String)"ExchangeRepsonse", (String)stringBuilder.toString());
            return;
        }
        MAPLog.w((String)LOG_TAG, (String)"No RequestId in OAuthTokenRepsonse headers");
    }

    public void testParse(JSONObject jSONObject) throws IOException, JSONException, AuthError {
        this.doParse(jSONObject);
    }
}

