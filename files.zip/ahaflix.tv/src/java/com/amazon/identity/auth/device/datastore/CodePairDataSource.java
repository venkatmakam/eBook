/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.database.Cursor
 *  android.database.sqlite.SQLiteDatabase
 *  com.amazon.identity.auth.device.dataobject.AbstractDataObject
 *  com.amazon.identity.auth.device.dataobject.CodePair$COL_INDEX
 *  com.amazon.identity.auth.device.datastore.AbstractDataSource
 *  com.amazon.identity.auth.device.datastore.DatabaseHelper
 *  com.amazon.identity.auth.device.utils.MAPUtils
 *  com.amazon.identity.auth.device.utils.ScopeUtils
 *  com.amazon.identity.auth.map.device.utils.MAPLog
 *  e.a.a.a.a
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.net.URI
 *  java.util.Date
 */
package com.amazon.identity.auth.device.datastore;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import com.amazon.identity.auth.device.dataobject.AbstractDataObject;
import com.amazon.identity.auth.device.dataobject.CodePair;
import com.amazon.identity.auth.device.datastore.AbstractDataSource;
import com.amazon.identity.auth.device.datastore.DatabaseHelper;
import com.amazon.identity.auth.device.utils.MAPUtils;
import com.amazon.identity.auth.device.utils.ScopeUtils;
import com.amazon.identity.auth.map.device.utils.MAPLog;
import e.a.a.a.a;
import java.net.URI;
import java.util.Date;

public class CodePairDataSource
extends AbstractDataSource<CodePair> {
    private static final String[] ALL_COLUMNS = CodePair.ALL_COLUMNS;
    private static CodePairDataSource INSTANCE;
    private static final String LOG_TAG = "com.amazon.identity.auth.device.datastore.CodePairDataSource";

    public CodePairDataSource(SQLiteDatabase sQLiteDatabase) {
        super(sQLiteDatabase);
    }

    public static CodePairDataSource getInstance(Context context) {
        Class<CodePairDataSource> class_ = CodePairDataSource.class;
        synchronized (CodePairDataSource.class) {
            if (INSTANCE == null) {
                INSTANCE = new CodePairDataSource(MAPUtils.getMAPdatabase((Context)context));
            }
            CodePairDataSource codePairDataSource = INSTANCE;
            // ** MonitorExit[var3_1] (shouldn't be in output)
            return codePairDataSource;
        }
    }

    public static void resetInstance() {
        INSTANCE = null;
        MAPUtils.resetDatabaseInstance();
    }

    public CodePair cursorToObject(Cursor cursor) {
        if (cursor != null) {
            if (cursor.getCount() == 0) {
                return null;
            }
            try {
                String string = cursor.getString(this.getColumnIndex(cursor, CodePair.COL_INDEX.APP_ID.colId));
                String string2 = cursor.getString(this.getColumnIndex(cursor, CodePair.COL_INDEX.USER_CODE.colId));
                String string3 = cursor.getString(this.getColumnIndex(cursor, CodePair.COL_INDEX.DEVICE_CODE.colId));
                String string4 = cursor.getString(this.getColumnIndex(cursor, CodePair.COL_INDEX.VERIFICATION_URI.colId));
                int n = cursor.getInt(this.getColumnIndex(cursor, CodePair.COL_INDEX.INTERVAL.colId));
                Date date = DatabaseHelper.parseDate((String)cursor.getString(this.getColumnIndex(cursor, CodePair.COL_INDEX.CREATION_TIME.colId)));
                Date date2 = DatabaseHelper.parseDate((String)cursor.getString(this.getColumnIndex(cursor, CodePair.COL_INDEX.EXPIRATION_TIME.colId)));
                URI uRI = new URI(string4);
                String[] arrstring = ScopeUtils.convertScopeStringToArray((String)cursor.getString(this.getColumnIndex(cursor, CodePair.COL_INDEX.SCOPES.colId)));
                CodePair codePair = new CodePair(string, string2, string3, uRI, n, date, date2, arrstring);
                codePair.setRowId(cursor.getLong(this.getColumnIndex(cursor, CodePair.COL_INDEX.ID.colId)));
                return codePair;
            }
            catch (Exception exception) {
                String string = LOG_TAG;
                StringBuilder stringBuilder = a.F1((String)"");
                stringBuilder.append(exception.getMessage());
                MAPLog.e((String)string, (String)stringBuilder.toString(), (Throwable)exception);
            }
        }
        return null;
    }

    public String[] getAllColumns() {
        return ALL_COLUMNS;
    }

    public String getLogTag() {
        return LOG_TAG;
    }

    public String getTableName() {
        return "CodePair";
    }
}

