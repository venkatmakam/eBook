/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.annotation.SuppressLint
 *  com.amazon.identity.auth.device.AuthError
 *  com.amazon.identity.auth.device.AuthError$ERROR_TYPE
 *  java.lang.String
 */
package com.amazon.identity.auth.device;

import android.annotation.SuppressLint;
import com.amazon.identity.auth.device.AuthError;

@SuppressLint(value={"ParcelCreator"})
public class InvalidGrantAuthError
extends AuthError {
    private static final long serialVersionUID = 1L;

    public InvalidGrantAuthError(String string) {
        super(string, AuthError.ERROR_TYPE.ERROR_INVALID_GRANT);
    }
}

