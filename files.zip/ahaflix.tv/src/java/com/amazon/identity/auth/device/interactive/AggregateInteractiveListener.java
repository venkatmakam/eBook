/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.net.Uri
 *  com.amazon.identity.auth.device.interactive.InteractiveRequestRecord
 *  com.amazon.identity.auth.device.workflow.WorkflowCancellation
 *  e.a.a.a.a
 *  java.lang.Exception
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.Collections
 *  java.util.Iterator
 *  java.util.Set
 */
package com.amazon.identity.auth.device.interactive;

import android.content.Context;
import android.net.Uri;
import com.amazon.identity.auth.device.interactive.InteractiveListener;
import com.amazon.identity.auth.device.interactive.InteractiveRequestRecord;
import com.amazon.identity.auth.device.workflow.WorkflowCancellation;
import e.a.a.a.a;
import java.util.Collections;
import java.util.Iterator;
import java.util.Set;

public final class AggregateInteractiveListener<T extends InteractiveListener<S, U, V>, S, U, V>
implements InteractiveListener<S, U, V> {
    private Set<T> listeners;
    private String requestType;

    public AggregateInteractiveListener(String string, Set<T> set) {
        this.requestType = string;
        if (set == null) {
            set = Collections.emptySet();
        }
        this.listeners = set;
        for (InteractiveListener interactiveListener : set) {
            if (string.equals((Object)interactiveListener.getRequestType())) continue;
            StringBuilder stringBuilder = a.f((String)"AggregateInteractiveListener created for request type \"", (String)string, (String)"\" but received listener with request type \"");
            stringBuilder.append(interactiveListener.getRequestType());
            stringBuilder.append("\"");
            throw new IllegalStateException(stringBuilder.toString());
        }
    }

    public String getRequestType() {
        return this.requestType;
    }

    @Override
    public void onCancel(U u) {
        Iterator iterator = this.listeners.iterator();
        while (iterator.hasNext()) {
            ((InteractiveListener)iterator.next()).onCancel(u);
        }
    }

    @Override
    public void onError(V v) {
        Iterator iterator = this.listeners.iterator();
        while (iterator.hasNext()) {
            ((InteractiveListener)iterator.next()).onError(v);
        }
    }

    public void onRequestCancel(Context context, InteractiveRequestRecord interactiveRequestRecord, WorkflowCancellation workflowCancellation) {
        Iterator iterator = this.listeners.iterator();
        while (iterator.hasNext()) {
            ((InteractiveListener)iterator.next()).onRequestCancel(context, interactiveRequestRecord, workflowCancellation);
        }
    }

    public void onRequestCompletion(Context context, InteractiveRequestRecord interactiveRequestRecord, Uri uri) {
        Iterator iterator = this.listeners.iterator();
        while (iterator.hasNext()) {
            ((InteractiveListener)iterator.next()).onRequestCompletion(context, interactiveRequestRecord, uri);
        }
    }

    public void onRequestError(Context context, InteractiveRequestRecord interactiveRequestRecord, Exception exception) {
        Iterator iterator = this.listeners.iterator();
        while (iterator.hasNext()) {
            ((InteractiveListener)iterator.next()).onRequestError(context, interactiveRequestRecord, exception);
        }
    }

    @Override
    public void onSuccess(S s) {
        Iterator iterator = this.listeners.iterator();
        while (iterator.hasNext()) {
            ((InteractiveListener)iterator.next()).onSuccess(s);
        }
    }
}

