/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.database.Cursor
 *  android.database.sqlite.SQLiteDatabase
 *  com.amazon.identity.auth.device.dataobject.AbstractDataObject
 *  com.amazon.identity.auth.device.dataobject.RequestedScope$COL_INDEX
 *  com.amazon.identity.auth.device.datastore.AbstractDataSource
 *  com.amazon.identity.auth.device.utils.MAPUtils
 *  com.amazon.identity.auth.map.device.utils.MAPLog
 *  e.a.a.a.a
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.List
 */
package com.amazon.identity.auth.device.datastore;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import com.amazon.identity.auth.device.dataobject.AbstractDataObject;
import com.amazon.identity.auth.device.dataobject.RequestedScope;
import com.amazon.identity.auth.device.datastore.AbstractDataSource;
import com.amazon.identity.auth.device.utils.MAPUtils;
import com.amazon.identity.auth.map.device.utils.MAPLog;
import e.a.a.a.a;
import java.util.List;

public final class RequestedScopeDataSource
extends AbstractDataSource<RequestedScope> {
    private static final String[] ALL_COLUMNS = RequestedScope.ALL_COLUMNS;
    private static RequestedScopeDataSource INSTANCE;
    private static final String LOG_TAG = "com.amazon.identity.auth.device.datastore.RequestedScopeDataSource";

    private RequestedScopeDataSource(SQLiteDatabase sQLiteDatabase) {
        super(sQLiteDatabase);
    }

    public static RequestedScopeDataSource getInstance(Context context) {
        Class<RequestedScopeDataSource> class_ = RequestedScopeDataSource.class;
        synchronized (RequestedScopeDataSource.class) {
            if (INSTANCE == null) {
                INSTANCE = new RequestedScopeDataSource(MAPUtils.getMAPdatabase((Context)context));
            }
            RequestedScopeDataSource requestedScopeDataSource = INSTANCE;
            // ** MonitorExit[var3_1] (shouldn't be in output)
            return requestedScopeDataSource;
        }
    }

    public static void resetInstance() {
        INSTANCE = null;
        MAPUtils.resetDatabaseInstance();
    }

    public RequestedScope cursorToObject(Cursor cursor) {
        if (cursor != null) {
            if (cursor.getCount() == 0) {
                return null;
            }
            try {
                RequestedScope requestedScope = new RequestedScope();
                requestedScope.setRowId(cursor.getLong(this.getColumnIndex(cursor, RequestedScope.COL_INDEX.ROW_ID.colId)));
                requestedScope.setScopeValue(cursor.getString(this.getColumnIndex(cursor, RequestedScope.COL_INDEX.SCOPE.colId)));
                requestedScope.setAppFamilyId(cursor.getString(this.getColumnIndex(cursor, RequestedScope.COL_INDEX.APP_FAMILY_ID.colId)));
                requestedScope.setDirectedId(cursor.getString(this.getColumnIndex(cursor, RequestedScope.COL_INDEX.DIRECTED_ID.colId)));
                requestedScope.setAuthorizationAccessTokenId(cursor.getLong(this.getColumnIndex(cursor, RequestedScope.COL_INDEX.AUTHORIZATION_ACCESS_TOKEN_ID.colId)));
                requestedScope.setAuthorizationRefreshTokenId(cursor.getLong(this.getColumnIndex(cursor, RequestedScope.COL_INDEX.AUTHORIZATION_REFRESH_TOKEN_ID.colId)));
                return requestedScope;
            }
            catch (Exception exception) {
                String string = LOG_TAG;
                StringBuilder stringBuilder = a.F1((String)"");
                stringBuilder.append(exception.getMessage());
                MAPLog.e((String)string, (String)stringBuilder.toString(), (Throwable)exception);
            }
        }
        return null;
    }

    public int deleteByAppFamilyId(String string) {
        return this.deleteRowsBySingleColumn(ALL_COLUMNS[RequestedScope.COL_INDEX.APP_FAMILY_ID.colId], string);
    }

    public int deleteByDirectedId(String string) {
        return this.deleteRowsBySingleColumn(ALL_COLUMNS[RequestedScope.COL_INDEX.DIRECTED_ID.colId], string);
    }

    public int deleteByScope(String string) {
        return this.deleteRowsBySingleColumn(ALL_COLUMNS[RequestedScope.COL_INDEX.SCOPE.colId], string);
    }

    public List<RequestedScope> findByAppFamilyId(String string) {
        return this.findAllRowsBySingleColumn(ALL_COLUMNS[RequestedScope.COL_INDEX.APP_FAMILY_ID.colId], string);
    }

    public List<RequestedScope> findByAuthorizationAccessTokenId(long l) {
        String string = ALL_COLUMNS[RequestedScope.COL_INDEX.AUTHORIZATION_ACCESS_TOKEN_ID.colId];
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(l);
        return this.findAllRowsBySingleColumn(string, stringBuilder.toString());
    }

    public List<RequestedScope> findByAuthorizationRefreshTokenId(long l) {
        String string = ALL_COLUMNS[RequestedScope.COL_INDEX.AUTHORIZATION_REFRESH_TOKEN_ID.colId];
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(l);
        return this.findAllRowsBySingleColumn(string, stringBuilder.toString());
    }

    public List<RequestedScope> findByDirectedId(String string) {
        return this.findAllRowsBySingleColumn(ALL_COLUMNS[RequestedScope.COL_INDEX.DIRECTED_ID.colId], string);
    }

    public RequestedScope findByPrimaryKey(String string, String string2, String string3) {
        String[] arrstring = new String[3];
        String[] arrstring2 = ALL_COLUMNS;
        arrstring[0] = arrstring2[RequestedScope.COL_INDEX.SCOPE.colId];
        arrstring[1] = arrstring2[RequestedScope.COL_INDEX.APP_FAMILY_ID.colId];
        arrstring[2] = arrstring2[RequestedScope.COL_INDEX.DIRECTED_ID.colId];
        return (RequestedScope)this.findOneRow(arrstring, new String[]{string, string2, string3});
    }

    public List<RequestedScope> findByScope(String string) {
        return this.findAllRowsBySingleColumn(ALL_COLUMNS[RequestedScope.COL_INDEX.SCOPE.colId], string);
    }

    public String[] getAllColumns() {
        return ALL_COLUMNS;
    }

    public String getLogTag() {
        return LOG_TAG;
    }

    public String getTableName() {
        return "RequestedScope";
    }
}

