/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.annotation.SuppressLint
 *  android.app.Activity
 *  android.app.Fragment
 *  android.app.FragmentManager
 *  android.content.Context
 *  android.os.Bundle
 *  com.amazon.identity.auth.device.interactive.InteractiveState
 *  com.amazon.identity.auth.device.interactive.InteractiveStateFragment
 *  java.lang.Object
 *  java.lang.String
 */
package com.amazon.identity.auth.device.interactive;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.Context;
import android.os.Bundle;
import com.amazon.identity.auth.device.interactive.GenericInteractiveState;
import com.amazon.identity.auth.device.interactive.InteractiveState;
import com.amazon.identity.auth.device.interactive.InteractiveStateFragment;

@SuppressLint(value={"NewApi"})
public final class WorkflowFragment
extends Fragment
implements InteractiveStateFragment {
    private GenericInteractiveState state = new GenericInteractiveState(this);

    public Object getApplicationContext() {
        Activity activity = this.getActivity();
        if (activity == null) {
            return null;
        }
        return activity.getApplicationContext();
    }

    public Object getFragment(Bundle bundle) {
        return this.getFragmentManager().getFragment(bundle, "wrappedFragment");
    }

    public Object getParentActivity() {
        return this.getActivity();
    }

    public InteractiveState getState() {
        return this.state;
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.state.readFromBundle(bundle);
    }

    public void onSaveInstanceState(Bundle bundle) {
        this.state.writeToBundle(bundle);
        super.onSaveInstanceState(bundle);
    }

    public void setState(GenericInteractiveState genericInteractiveState) {
        this.state = genericInteractiveState;
    }
}

