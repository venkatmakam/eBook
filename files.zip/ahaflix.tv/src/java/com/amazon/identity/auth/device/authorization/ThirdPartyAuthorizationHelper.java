/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Bundle
 *  android.os.Handler
 *  android.os.Looper
 *  android.os.RemoteException
 *  android.text.TextUtils
 *  com.amazon.identity.auth.device.AbstractRequest
 *  com.amazon.identity.auth.device.AuthError
 *  com.amazon.identity.auth.device.AuthError$ERROR_TYPE
 *  com.amazon.identity.auth.device.RequestManager
 *  com.amazon.identity.auth.device.StoredPreferences
 *  com.amazon.identity.auth.device.api.authorization.AuthorizationManager
 *  com.amazon.identity.auth.device.appid.AppIdentifier
 *  com.amazon.identity.auth.device.authorization.AmazonAuthorizationServiceInterface
 *  com.amazon.identity.auth.device.authorization.AuthorizationHelper
 *  com.amazon.identity.auth.device.authorization.CodeChallengeWorkflow
 *  com.amazon.identity.auth.device.authorization.ThirdPartyAuthorizationHelper$1
 *  com.amazon.identity.auth.device.authorization.ThirdPartyServiceHelper
 *  com.amazon.identity.auth.device.authorization.api.AuthzConstants
 *  com.amazon.identity.auth.device.authorization.api.AuthzConstants$BUNDLE_KEY
 *  com.amazon.identity.auth.device.datastore.DatabaseHelper
 *  com.amazon.identity.auth.device.endpoint.TokenVendor
 *  com.amazon.identity.auth.device.thread.ThreadUtils
 *  com.amazon.identity.auth.device.utils.DefaultLibraryInfo
 *  com.amazon.identity.auth.device.utils.LWAConstants
 *  com.amazon.identity.auth.device.utils.LWAConstants$AUTHORIZE_BUNDLE_KEY
 *  com.amazon.identity.auth.device.utils.LWAServiceWrapper
 *  com.amazon.identity.auth.map.device.utils.MAPLog
 *  e.a.a.a.a
 *  java.lang.CharSequence
 *  java.lang.ClassLoader
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.List
 */
package com.amazon.identity.auth.device.authorization;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.RemoteException;
import android.text.TextUtils;
import com.amazon.identity.auth.device.AbstractRequest;
import com.amazon.identity.auth.device.AuthError;
import com.amazon.identity.auth.device.RequestManager;
import com.amazon.identity.auth.device.StoredPreferences;
import com.amazon.identity.auth.device.api.authorization.AuthorizationManager;
import com.amazon.identity.auth.device.api.authorization.AuthorizeRequest;
import com.amazon.identity.auth.device.appid.AppIdentifier;
import com.amazon.identity.auth.device.appid.ThirdPartyAppIdentifier;
import com.amazon.identity.auth.device.authorization.AmazonAuthorizationServiceInterface;
import com.amazon.identity.auth.device.authorization.AuthorizationHelper;
import com.amazon.identity.auth.device.authorization.AuthorizationRequest;
import com.amazon.identity.auth.device.authorization.CodeChallengeWorkflow;
import com.amazon.identity.auth.device.authorization.ThirdPartyAuthorizationHelper;
import com.amazon.identity.auth.device.authorization.ThirdPartyServiceHelper;
import com.amazon.identity.auth.device.authorization.api.AuthorizationListener;
import com.amazon.identity.auth.device.authorization.api.AuthzConstants;
import com.amazon.identity.auth.device.dataobject.AppInfo;
import com.amazon.identity.auth.device.datastore.DatabaseHelper;
import com.amazon.identity.auth.device.datastore.ProfileDataSource;
import com.amazon.identity.auth.device.endpoint.TokenVendor;
import com.amazon.identity.auth.device.thread.ThreadUtils;
import com.amazon.identity.auth.device.utils.DefaultLibraryInfo;
import com.amazon.identity.auth.device.utils.LWAConstants;
import com.amazon.identity.auth.device.utils.LWAServiceWrapper;
import com.amazon.identity.auth.map.device.utils.MAPLog;
import e.a.a.a.a;
import java.util.List;

public class ThirdPartyAuthorizationHelper
extends AuthorizationHelper {
    private static final String CLIENT_ID_PARAM_NAME = "client_id";
    private static final String CODE_KEY = "code";
    private static final String LOG_TAG = "com.amazon.identity.auth.device.authorization.ThirdPartyAuthorizationHelper";
    private static final String SCOPE_DATA_KEY = "scope_data";
    private CodeChallengeWorkflow codeChallengeWorkflow = CodeChallengeWorkflow.getInstance();
    private ThirdPartyServiceHelper mThirdPartyServiceHelper;

    public ThirdPartyAuthorizationHelper() {
        this(new ThirdPartyServiceHelper());
    }

    public ThirdPartyAuthorizationHelper(ThirdPartyServiceHelper thirdPartyServiceHelper) {
        this.mThirdPartyServiceHelper = thirdPartyServiceHelper;
    }

    public static /* synthetic */ void access$000(ThirdPartyAuthorizationHelper thirdPartyAuthorizationHelper, AuthorizeRequest authorizeRequest, Context context, String string, String string2, String[] arrstring, AuthorizationListener authorizationListener, Bundle bundle, AppInfo appInfo) throws AuthError {
        thirdPartyAuthorizationHelper.authorizeWithBrowser(authorizeRequest, context, string, string2, arrstring, authorizationListener, bundle, appInfo);
    }

    private void authorizeWithBrowser(AuthorizeRequest authorizeRequest, Context context, String string, String string2, String[] arrstring, AuthorizationListener authorizationListener, Bundle bundle, AppInfo appInfo) throws AuthError {
        bundle.getBundle(AuthzConstants.BUNDLE_KEY.EXTRA_URL_PARAMS.val).remove(CLIENT_ID_PARAM_NAME);
        AuthorizationRequest authorizationRequest = new AuthorizationRequest(authorizeRequest, string2, arrstring, bundle, appInfo, authorizationListener);
        RequestManager.getInstance().executeRequest((AbstractRequest)authorizationRequest, context);
    }

    private static Bundle authorizeWithService(Context context, String[] arrstring, AmazonAuthorizationServiceInterface amazonAuthorizationServiceInterface, Bundle bundle) throws AuthError, RemoteException {
        Bundle bundle2 = amazonAuthorizationServiceInterface.authorize(bundle, context.getPackageName(), arrstring);
        if (bundle2 != null) {
            bundle2.setClassLoader(context.getClassLoader());
        }
        return bundle2;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private Bundle getExtraUrlParams(Bundle bundle) throws AuthError {
        Bundle bundle2;
        if (bundle.getBoolean(AuthzConstants.BUNDLE_KEY.GET_AUTH_CODE.val, false)) {
            String string = bundle.getString(AuthzConstants.BUNDLE_KEY.CODE_CHALLENGE.val);
            String string2 = bundle.getString(AuthzConstants.BUNDLE_KEY.CODE_CHALLENGE_METHOD.val);
            if (TextUtils.isEmpty((CharSequence)string)) throw new AuthError("Must provide code challenge parameter.", AuthError.ERROR_TYPE.ERROR_MISSING_CODE_CHALLENGE);
            bundle2 = a.y((String)"code_challenge", (String)string, (String)"code_challenge_method", (String)string2);
        } else {
            bundle2 = this.codeChallengeWorkflow.getProofKeyParameters();
        }
        AuthzConstants.BUNDLE_KEY bUNDLE_KEY = AuthzConstants.BUNDLE_KEY.SCOPE_DATA;
        if (bundle.getString(bUNDLE_KEY.val) != null) {
            bundle2.putString(SCOPE_DATA_KEY, bundle.getString(bUNDLE_KEY.val));
        }
        bundle2.putString(CLIENT_ID_PARAM_NAME, bundle.getString(AuthzConstants.BUNDLE_KEY.CLIENT_ID.val));
        return bundle2;
    }

    private void handleCodeForTokenExchange(Context context, String string, String string2, Bundle bundle, Bundle bundle2, final AuthorizationListener authorizationListener) {
        this.doCodeForTokenExchange(context, string, string2, bundle, false, null, new TokenVendor(), (AppIdentifier)new ThirdPartyAppIdentifier(), bundle2, new AuthorizationListener(){

            @Override
            public void onCancel(Bundle bundle) {
                MAPLog.w((String)LOG_TAG, (String)"Code for Token Exchange Cancel");
                AuthorizationListener authorizationListener2 = authorizationListener;
                if (authorizationListener2 != null) {
                    authorizationListener2.onCancel(bundle);
                }
            }

            @Override
            public void onError(AuthError authError) {
                String string = LOG_TAG;
                StringBuilder stringBuilder = a.F1((String)"Code for Token Exchange Error. ");
                stringBuilder.append(authError.getMessage());
                MAPLog.e((String)string, (String)stringBuilder.toString());
                AuthorizationListener authorizationListener2 = authorizationListener;
                if (authorizationListener2 != null) {
                    authorizationListener2.onError(authError);
                }
            }

            @Override
            public void onSuccess(Bundle bundle) {
                MAPLog.i((String)LOG_TAG, (String)"Code for Token Exchange success");
                AuthorizationListener authorizationListener2 = authorizationListener;
                if (authorizationListener2 != null) {
                    authorizationListener2.onSuccess(bundle);
                }
            }
        });
    }

    private Bundle startAuthorizationWithService(Context context, final String[] arrstring, final Bundle bundle) throws AuthError {
        Bundle bundle2 = (Bundle)new LWAServiceWrapper<Bundle>(){

            public Bundle doWork(Context context, AmazonAuthorizationServiceInterface amazonAuthorizationServiceInterface) throws AuthError, RemoteException {
                return ThirdPartyAuthorizationHelper.authorizeWithService(context, arrstring, amazonAuthorizationServiceInterface, bundle);
            }
        }.execute(context, this.mThirdPartyServiceHelper);
        if (bundle2 != null) {
            return bundle2;
        }
        return new Bundle();
    }

    public void authorize(Context context, String string, String string2, String string3, String[] arrstring, boolean bl, TokenVendor tokenVendor, AuthorizationListener authorizationListener) throws AuthError {
        this.authorize(null, context, string, string2, string3, arrstring, bl, tokenVendor, authorizationListener, Bundle.EMPTY);
    }

    public void authorize(Context context, String string, String string2, String string3, String[] arrstring, boolean bl, TokenVendor tokenVendor, AuthorizationListener authorizationListener, Bundle bundle) throws AuthError {
        this.authorize(null, context, string, string2, string3, arrstring, bl, tokenVendor, authorizationListener, bundle);
    }

    public void authorize(AuthorizeRequest authorizeRequest, Context context, String string, String string2, String string3, String[] arrstring, boolean bl, TokenVendor tokenVendor, AuthorizationListener authorizationListener, Bundle bundle) throws AuthError {
        Bundle bundle2 = bundle;
        if (!ThreadUtils.isRunningOnMainThread()) {
            AppInfo appInfo = new ThirdPartyAppIdentifier().getAppInfo(string, context);
            List list = tokenVendor.getCachedScopes(context);
            String[] arrstring2 = AuthorizationHelper.getCommonScopesForAuthorization((Context)context, (String[])arrstring, (List)list);
            boolean bl2 = bundle2.getBoolean(AuthzConstants.BUNDLE_KEY.SANDBOX.val, false);
            Bundle bundle3 = Bundle.EMPTY;
            if (bundle2 == bundle3) {
                bundle2 = new Bundle();
            }
            Bundle bundle4 = bundle2;
            bundle4.putBoolean(AuthzConstants.BUNDLE_KEY.CHECK_API_KEY.val, false);
            bundle4.putBoolean(AuthzConstants.BUNDLE_KEY.RETURN_CODE.val, true);
            bundle4.putString(LWAConstants.AUTHORIZE_BUNDLE_KEY.REGION.val, AuthorizationManager.getRegion((Context)context).getStringValue());
            bundle4.putString(LWAConstants.AUTHORIZE_BUNDLE_KEY.STAGE.val, DefaultLibraryInfo.getOverrideLibraryStage().name());
            bundle4.putString(AuthzConstants.BUNDLE_KEY.CLIENT_ID.val, string2);
            bundle4.putString(AuthzConstants.BUNDLE_KEY.SDK_VERSION.val, "LWAAndroidSDK3.0.3");
            try {
                bundle4.putBundle(AuthzConstants.BUNDLE_KEY.EXTRA_URL_PARAMS.val, this.getExtraUrlParams(bundle4));
            }
            catch (AuthError authError) {
                authorizationListener.onError(authError);
                return;
            }
            if (!bl2 && (StoredPreferences.isTokenObtainedFromSSO((Context)context) || list == null || list.size() == 0)) {
                bundle3 = this.startAuthorizationWithService(context, arrstring2, bundle4);
            }
            if (bundle3.containsKey(CODE_KEY) && !TextUtils.isEmpty((CharSequence)bundle3.getString(CODE_KEY))) {
                if (bundle4.getBoolean(AuthzConstants.BUNDLE_KEY.GET_AUTH_CODE.val, false)) {
                    AuthorizationHelper.sendAuthorizationCodeAsResponse((String)bundle3.getString(CODE_KEY), (String)string2, (String)string3, (AuthorizationListener)authorizationListener);
                    return;
                }
                this.handleCodeForTokenExchange(context, string, this.codeChallengeWorkflow.getCodeVerifier(), bundle3, bundle4, authorizationListener);
                StoredPreferences.setTokenObtainedFromSSO((Context)context, (boolean)true);
                return;
            }
            if (!(bundle3.containsKey("AUTH_ERROR_EXECEPTION") || bundle3.containsKey(AuthzConstants.BUNDLE_KEY.AUTHORIZE.val) || bundle3.containsKey(AuthzConstants.BUNDLE_KEY.CAUSE_ID.val))) {
                ProfileDataSource.getInstance(context).deleteAllRows();
                Handler handler = new Handler(Looper.getMainLooper());
                1 var23_19 = new 1(this, bl, bl2, authorizeRequest, context, string2, arrstring2, authorizationListener, bundle4, appInfo);
                handler.post((Runnable)var23_19);
                return;
            }
            bundle3.setClassLoader(context.getClassLoader());
            if (bundle3.containsKey(AuthzConstants.BUNDLE_KEY.CAUSE_ID.val)) {
                authorizationListener.onCancel(bundle3);
                return;
            }
            if (bundle3.containsKey("AUTH_ERROR_EXECEPTION")) {
                authorizationListener.onError(AuthError.extractError((Bundle)bundle3));
                return;
            }
            DatabaseHelper.clearAuthorizationState((Context)context);
            Bundle bundle5 = new Bundle();
            bundle5.putString(AuthzConstants.BUNDLE_KEY.AUTHORIZE.val, "authorized via service");
            authorizationListener.onSuccess(bundle5);
            return;
        }
        MAPLog.e((String)LOG_TAG, (String)"authorize started on main thread");
        throw new IllegalStateException("authorize started on main thread");
    }

}

