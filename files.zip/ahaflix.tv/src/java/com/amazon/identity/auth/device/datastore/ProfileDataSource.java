/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.database.Cursor
 *  android.database.sqlite.SQLiteDatabase
 *  com.amazon.identity.auth.device.dataobject.AbstractDataObject
 *  com.amazon.identity.auth.device.dataobject.Profile$COL_INDEX
 *  com.amazon.identity.auth.device.datastore.AbstractDataSource
 *  com.amazon.identity.auth.device.datastore.DatabaseHelper
 *  com.amazon.identity.auth.device.utils.MAPUtils
 *  com.amazon.identity.auth.map.device.utils.MAPLog
 *  e.a.a.a.a
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.Date
 */
package com.amazon.identity.auth.device.datastore;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import com.amazon.identity.auth.device.dataobject.AbstractDataObject;
import com.amazon.identity.auth.device.dataobject.Profile;
import com.amazon.identity.auth.device.datastore.AbstractDataSource;
import com.amazon.identity.auth.device.datastore.DatabaseHelper;
import com.amazon.identity.auth.device.utils.MAPUtils;
import com.amazon.identity.auth.map.device.utils.MAPLog;
import e.a.a.a.a;
import java.util.Date;

public class ProfileDataSource
extends AbstractDataSource<Profile> {
    private static final String[] ALL_COLUMNS = Profile.ALL_COLUMNS;
    private static ProfileDataSource INSTANCE;
    private static final String LOG_TAG = "com.amazon.identity.auth.device.datastore.ProfileDataSource";

    public ProfileDataSource(SQLiteDatabase sQLiteDatabase) {
        super(sQLiteDatabase);
    }

    public static ProfileDataSource getInstance(Context context) {
        Class<ProfileDataSource> class_ = ProfileDataSource.class;
        synchronized (ProfileDataSource.class) {
            if (INSTANCE == null) {
                INSTANCE = new ProfileDataSource(MAPUtils.getMAPdatabase((Context)context));
            }
            ProfileDataSource profileDataSource = INSTANCE;
            // ** MonitorExit[var3_1] (shouldn't be in output)
            return profileDataSource;
        }
    }

    public static void resetInstance() {
        INSTANCE = null;
        MAPUtils.resetDatabaseInstance();
    }

    public Profile cursorToObject(Cursor cursor) {
        if (cursor != null) {
            if (cursor.getCount() == 0) {
                return null;
            }
            try {
                Profile profile = new Profile();
                profile.setId(cursor.getLong(this.getColumnIndex(cursor, Profile.COL_INDEX.ID.colId)));
                profile.setAppId(cursor.getString(this.getColumnIndex(cursor, Profile.COL_INDEX.APP_ID.colId)));
                profile.setExpirationTime(DatabaseHelper.parseDate((String)cursor.getString(this.getColumnIndex(cursor, Profile.COL_INDEX.EXPIRATION_TIME.colId))));
                profile.setData(cursor.getString(this.getColumnIndex(cursor, Profile.COL_INDEX.DATA.colId)));
                return profile;
            }
            catch (Exception exception) {
                String string = LOG_TAG;
                StringBuilder stringBuilder = a.F1((String)"");
                stringBuilder.append(exception.getMessage());
                MAPLog.e((String)string, (String)stringBuilder.toString(), (Throwable)exception);
            }
        }
        return null;
    }

    public String[] getAllColumns() {
        return ALL_COLUMNS;
    }

    public String getLogTag() {
        return LOG_TAG;
    }

    public Profile getProfile(String string) {
        return (Profile)this.findOneRowBySingleColumn("AppId", string);
    }

    public String getTableName() {
        return "Profile";
    }
}

