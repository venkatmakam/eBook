/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  com.amazon.identity.auth.device.AuthError
 *  com.amazon.identity.auth.device.AuthError$ERROR_TYPE
 *  com.amazon.identity.auth.device.endpoint.AbstractPandaRequest
 *  com.amazon.identity.auth.device.endpoint.PandaResponse
 *  java.io.UnsupportedEncodingException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.List
 *  org.apache.http.Header
 *  org.apache.http.HttpEntity
 *  org.apache.http.NameValuePair
 *  org.apache.http.client.methods.HttpPost
 *  org.apache.http.client.methods.HttpRequestBase
 *  org.apache.http.entity.StringEntity
 *  org.apache.http.message.BasicHeader
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.amazon.identity.auth.device.endpoint;

import android.content.Context;
import com.amazon.identity.auth.device.AuthError;
import com.amazon.identity.auth.device.dataobject.AppInfo;
import com.amazon.identity.auth.device.endpoint.AbstractPandaRequest;
import com.amazon.identity.auth.device.endpoint.PandaResponse;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.NameValuePair;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.entity.StringEntity;
import org.apache.http.message.BasicHeader;
import org.json.JSONException;
import org.json.JSONObject;

public abstract class AbstractJsonPandaRequest<T extends PandaResponse>
extends AbstractPandaRequest<T> {
    private static final String APPLICATION_JSON_CONTENT_TYPE = "application/json";
    private static final String CONTENT_TYPE_HEADER = "Content-Type";

    public AbstractJsonPandaRequest(Context context, AppInfo appInfo) {
        super(context, appInfo);
    }

    private String getJsonString() throws AuthError {
        JSONObject jSONObject = new JSONObject();
        try {
            for (NameValuePair nameValuePair : this.postParameters) {
                jSONObject.put(nameValuePair.getName(), (Object)nameValuePair.getValue());
            }
            String string = jSONObject.toString();
            return string;
        }
        catch (JSONException jSONException) {
            throw new AuthError("Received JSONException while building request", (Throwable)jSONException, AuthError.ERROR_TYPE.ERROR_BAD_PARAM);
        }
    }

    public List<Header> getExtraHeaders() {
        ArrayList arrayList = new ArrayList();
        arrayList.add((Object)new BasicHeader(CONTENT_TYPE_HEADER, APPLICATION_JSON_CONTENT_TYPE));
        return arrayList;
    }

    public void setEntity() throws UnsupportedEncodingException, AuthError {
        StringEntity stringEntity = new StringEntity(this.getJsonString(), "UTF-8");
        ((HttpPost)this.httpRequest).setEntity((HttpEntity)stringEntity);
    }
}

