/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ContentValues
 *  android.content.Context
 *  android.text.TextUtils
 *  android.text.format.Time
 *  com.amazon.identity.auth.device.dataobject.AbstractDataObject
 *  com.amazon.identity.auth.device.dataobject.AuthorizationToken$AUTHZ_TOKEN_TYPE
 *  com.amazon.identity.auth.device.dataobject.AuthorizationToken$COL_INDEX
 *  com.amazon.identity.auth.device.datastore.AbstractDataSource
 *  com.amazon.identity.auth.device.datastore.DatabaseHelper
 *  com.amazon.identity.auth.map.device.token.Token
 *  com.amazon.identity.auth.map.device.utils.MAPLog
 *  e.a.a.a.a
 *  java.lang.CharSequence
 *  java.lang.Integer
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.text.SimpleDateFormat
 *  java.util.Calendar
 *  java.util.Date
 *  java.util.Map
 */
package com.amazon.identity.auth.device.dataobject;

import android.content.ContentValues;
import android.content.Context;
import android.text.TextUtils;
import android.text.format.Time;
import com.amazon.identity.auth.device.dataobject.AbstractDataObject;
import com.amazon.identity.auth.device.dataobject.AuthorizationToken;
import com.amazon.identity.auth.device.datastore.AbstractDataSource;
import com.amazon.identity.auth.device.datastore.AuthorizationTokenDataSource;
import com.amazon.identity.auth.device.datastore.DatabaseHelper;
import com.amazon.identity.auth.map.device.token.AbstractToken;
import com.amazon.identity.auth.map.device.token.Token;
import com.amazon.identity.auth.map.device.utils.MAPLog;
import e.a.a.a.a;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Map;

public abstract class AuthorizationToken
extends AbstractDataObject
implements Token {
    public static final String[] ALL_COLUMNS = new String[]{"Id", "AppId", "Token", "CreationTime", "ExpirationTime", "MiscData", "type", "directedId"};
    private static final int DEFAULT_MINIMUM_TOKEN_LIFETIME = 300;
    private static final String LOG_TAG = "com.amazon.identity.auth.device.dataobject.AuthorizationToken";
    public String mAppFamilyId;
    public Date mCreationTime;
    private String mDirectedId;
    public Date mExpirationTime;
    public byte[] mMiscData;
    public String mTokenValue;
    public AUTHZ_TOKEN_TYPE mType;

    public AuthorizationToken() {
    }

    public AuthorizationToken(String string, String string2, String string3, Date date, Date date2, byte[] arrby, AUTHZ_TOKEN_TYPE aUTHZ_TOKEN_TYPE) {
        this.mAppFamilyId = string;
        this.mTokenValue = string3;
        this.mCreationTime = DatabaseHelper.truncateFractionalSeconds((Date)date);
        this.mExpirationTime = DatabaseHelper.truncateFractionalSeconds((Date)date2);
        this.mMiscData = arrby;
        this.mType = aUTHZ_TOKEN_TYPE;
        this.mDirectedId = string2;
    }

    public boolean equals(Object object) {
        if (object != null && object instanceof AuthorizationToken) {
            boolean bl;
            block8 : {
                AuthorizationToken authorizationToken = (AuthorizationToken)((Object)object);
                boolean bl2 = TextUtils.equals((CharSequence)this.mAppFamilyId, (CharSequence)authorizationToken.getAppFamilyId());
                bl = false;
                if (!bl2) break block8;
                boolean bl3 = TextUtils.equals((CharSequence)this.mTokenValue, (CharSequence)authorizationToken.getTokenValue());
                bl = false;
                if (!bl3) break block8;
                boolean bl4 = this.areObjectsEqual((Object)this.mCreationTime, (Object)authorizationToken.getCreationTime());
                bl = false;
                if (!bl4) break block8;
                boolean bl5 = this.areObjectsEqual((Object)this.mExpirationTime, (Object)authorizationToken.getExpirationTime());
                bl = false;
                if (!bl5) break block8;
                boolean bl6 = TextUtils.equals((CharSequence)this.getType(), (CharSequence)authorizationToken.getType());
                bl = false;
                if (!bl6) break block8;
                try {
                    boolean bl7 = TextUtils.equals((CharSequence)this.mDirectedId, (CharSequence)authorizationToken.getDirectedId());
                    bl = false;
                    if (!bl7) break block8;
                    bl = true;
                }
                catch (NullPointerException nullPointerException) {
                    String string = LOG_TAG;
                    StringBuilder stringBuilder = a.F1((String)"");
                    stringBuilder.append(nullPointerException.toString());
                    MAPLog.e((String)string, (String)stringBuilder.toString());
                }
            }
            return bl;
        }
        return false;
    }

    public String getAppFamilyId() {
        return this.mAppFamilyId;
    }

    public Date getCreationTime() {
        return this.mCreationTime;
    }

    /*
     * Exception decompiling
     */
    public Map<String, String> getData() {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl19 : ALOAD_2 : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    public AuthorizationTokenDataSource getDataSource(Context context) {
        return AuthorizationTokenDataSource.getInstance(context);
    }

    public String getDirectedId() {
        return this.mDirectedId;
    }

    public Date getExpirationTime() {
        return this.mExpirationTime;
    }

    public long getId() {
        return this.getRowId();
    }

    public Time getLocalTimestamp() {
        Time time = new Time();
        time.set(this.mCreationTime.getTime());
        return time;
    }

    public byte[] getMiscData() {
        return this.mMiscData;
    }

    public String getTokenValue() {
        return this.mTokenValue;
    }

    public String getType() {
        return this.mType.toString();
    }

    public AUTHZ_TOKEN_TYPE getTypeAsEnum() {
        return this.mType;
    }

    public ContentValues getValuesForInsert() {
        ContentValues contentValues = new ContentValues();
        SimpleDateFormat simpleDateFormat = DatabaseHelper.getDateFormat();
        String[] arrstring = ALL_COLUMNS;
        contentValues.put(arrstring[COL_INDEX.APP_FAMILY_ID.colId], this.mAppFamilyId);
        contentValues.put(arrstring[COL_INDEX.TOKEN.colId], this.mTokenValue);
        contentValues.put(arrstring[COL_INDEX.CREATION_TIME.colId], simpleDateFormat.format(this.mCreationTime));
        contentValues.put(arrstring[COL_INDEX.EXPIRATION_TIME.colId], simpleDateFormat.format(this.mExpirationTime));
        contentValues.put(arrstring[COL_INDEX.MISC_DATA.colId], this.mMiscData);
        contentValues.put(arrstring[COL_INDEX.TYPE.colId], Integer.valueOf((int)this.mType.ordinal()));
        contentValues.put(arrstring[COL_INDEX.DIRECTED_ID.colId], this.mDirectedId);
        return contentValues;
    }

    public boolean isRemainingLifeAcceptable() {
        return this.isRemainingLifeAcceptable(300);
    }

    public boolean isRemainingLifeAcceptable(int n) {
        return this.mExpirationTime.getTime() - Calendar.getInstance().getTimeInMillis() >= AbstractToken.secsToMillis(n);
    }

    public void setAppFamilyId(String string) {
        this.mAppFamilyId = string;
    }

    public void setCreationTime(Date date) {
        this.mCreationTime = DatabaseHelper.truncateFractionalSeconds((Date)date);
    }

    public void setDirectedId(String string) {
        this.mDirectedId = string;
    }

    public void setExpirationTime(Date date) {
        this.mExpirationTime = DatabaseHelper.truncateFractionalSeconds((Date)date);
    }

    public void setId(long l) {
        this.setRowId(l);
    }

    public void setMiscData(byte[] arrby) {
        this.mMiscData = arrby;
    }

    public void setTokenValue(String string) {
        this.mTokenValue = string;
    }

    public String toLogString() {
        SimpleDateFormat simpleDateFormat = DatabaseHelper.getDateFormat();
        StringBuilder stringBuilder = a.F1((String)"{ rowid=");
        stringBuilder.append(this.getId());
        stringBuilder.append(", appId=");
        stringBuilder.append(this.mAppFamilyId);
        stringBuilder.append(", token=");
        stringBuilder.append(this.mTokenValue);
        stringBuilder.append(", creationTime=");
        stringBuilder.append(simpleDateFormat.format(this.mCreationTime));
        stringBuilder.append(", expirationTime=");
        stringBuilder.append(simpleDateFormat.format(this.mExpirationTime));
        stringBuilder.append(", type=");
        stringBuilder.append(this.mType.toString());
        stringBuilder.append(", directedId=<obscured> }");
        return stringBuilder.toString();
    }

    public String toString() {
        return this.mTokenValue;
    }
}

