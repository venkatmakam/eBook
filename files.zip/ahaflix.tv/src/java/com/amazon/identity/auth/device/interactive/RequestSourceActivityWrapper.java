/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.annotation.SuppressLint
 *  android.app.Activity
 *  android.app.Fragment
 *  android.app.FragmentManager
 *  android.app.FragmentTransaction
 *  android.content.Context
 *  com.amazon.identity.auth.device.api.InvalidIntegrationException
 *  com.amazon.identity.auth.device.interactive.InteractiveRequestRecord
 *  com.amazon.identity.auth.device.interactive.InteractiveState
 *  com.amazon.identity.auth.device.interactive.InteractiveStateFragment
 *  com.amazon.identity.auth.device.interactive.RequestSource
 *  com.amazon.identity.auth.map.device.utils.MAPLog
 *  e.a.a.a.a
 *  java.lang.Class
 *  java.lang.ClassCastException
 *  java.lang.ClassLoader
 *  java.lang.ClassNotFoundException
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.lang.ref.WeakReference
 */
package com.amazon.identity.auth.device.interactive;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Context;
import com.amazon.identity.auth.device.api.InvalidIntegrationException;
import com.amazon.identity.auth.device.interactive.InteractiveRequestRecord;
import com.amazon.identity.auth.device.interactive.InteractiveState;
import com.amazon.identity.auth.device.interactive.InteractiveStateFragment;
import com.amazon.identity.auth.device.interactive.RequestSource;
import com.amazon.identity.auth.device.interactive.WorkflowFragment;
import com.amazon.identity.auth.map.device.utils.MAPLog;
import e.a.a.a.a;
import java.lang.ref.WeakReference;

public final class RequestSourceActivityWrapper
implements RequestSource {
    private static final String LOG_TAG = "com.amazon.identity.auth.device.interactive.RequestSourceActivityWrapper";
    private static final String SDK_FRAGMENT_CLASS_NAME = "android.app.Fragment";
    private final WeakReference<Activity> activityReference;

    public RequestSourceActivityWrapper(Activity activity) {
        if (activity != null) {
            this.activityReference = new WeakReference((Object)activity);
            return;
        }
        throw new IllegalArgumentException("activity must be non-null");
    }

    private boolean assertFragmentsPresent() {
        try {
            Class class_ = Class.forName((String)SDK_FRAGMENT_CLASS_NAME, (boolean)false, (ClassLoader)this.getClass().getClassLoader());
            boolean bl = false;
            if (class_ != null) {
                bl = true;
            }
            return bl;
        }
        catch (ClassNotFoundException classNotFoundException) {
            throw new InvalidIntegrationException("android.app.Fragment not found. To make a request from an activity, use minSdkVersion of at least 11, or use FragmentActivity from Android Support Library v4", (Throwable)classNotFoundException);
        }
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object == null) {
            return false;
        }
        if (RequestSourceActivityWrapper.class != object.getClass()) {
            return false;
        }
        RequestSourceActivityWrapper requestSourceActivityWrapper = (RequestSourceActivityWrapper)object;
        WeakReference<Activity> weakReference = this.activityReference;
        if (weakReference == null) {
            if (requestSourceActivityWrapper.activityReference != null) {
                return false;
            }
        } else {
            if (requestSourceActivityWrapper.activityReference == null) {
                return false;
            }
            if (weakReference.get() == null ? requestSourceActivityWrapper.activityReference.get() != null : !((Activity)this.activityReference.get()).equals(requestSourceActivityWrapper.activityReference.get())) {
                return false;
            }
        }
        return true;
    }

    public Object getBackingObject() {
        return this.activityReference.get();
    }

    public Context getContext() {
        return (Context)this.activityReference.get();
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @SuppressLint(value={"NewApi"})
    public InteractiveState getInteractiveState() {
        Activity activity = (Activity)this.activityReference.get();
        if (activity != null) {
            InteractiveStateFragment interactiveStateFragment;
            String string;
            this.assertFragmentsPresent();
            FragmentManager fragmentManager = activity.getFragmentManager();
            try {
                string = InteractiveStateFragment.TAG_ID;
                interactiveStateFragment = (InteractiveStateFragment)fragmentManager.findFragmentByTag(string);
                if (interactiveStateFragment != null) return interactiveStateFragment.getState();
            }
            catch (ClassCastException classCastException) {
                String string2 = LOG_TAG;
                StringBuilder stringBuilder = a.F1((String)"Found an invalid fragment looking for fragment with tag ");
                stringBuilder.append(InteractiveStateFragment.TAG_ID);
                stringBuilder.append(". Please use a different fragment tag.");
                MAPLog.e((String)string2, (String)stringBuilder.toString(), (Throwable)classCastException);
                return null;
            }
            interactiveStateFragment = new WorkflowFragment();
            fragmentManager.beginTransaction().add((Fragment)interactiveStateFragment, string).commit();
            return interactiveStateFragment.getState();
        } else {
            MAPLog.e((String)LOG_TAG, (String)"Failed to get InteractiveState on a garbage-collected Activity");
        }
        return null;
    }

    public int hashCode() {
        WeakReference<Activity> weakReference = this.activityReference;
        int n = weakReference != null && weakReference.get() != null ? ((Activity)this.activityReference.get()).hashCode() : 0;
        return 31 + n;
    }

    public boolean isHookNeededOnUIResume() {
        return true;
    }

    public void onStartRequest(InteractiveRequestRecord interactiveRequestRecord) {
        InteractiveState interactiveState = this.getInteractiveState();
        if (interactiveState != null) {
            interactiveState.onRequestStart(interactiveRequestRecord);
        }
    }
}

