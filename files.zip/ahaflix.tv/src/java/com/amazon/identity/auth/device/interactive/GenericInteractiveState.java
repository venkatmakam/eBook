/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 *  android.os.Bundle
 *  com.amazon.identity.auth.device.ResponseManager
 *  com.amazon.identity.auth.device.api.workflow.RequestContext
 *  com.amazon.identity.auth.device.interactive.InteractiveRequestMap
 *  com.amazon.identity.auth.device.interactive.InteractiveRequestRecord
 *  com.amazon.identity.auth.device.interactive.InteractiveState
 *  com.amazon.identity.auth.device.interactive.InteractiveStateFragment
 *  com.amazon.identity.auth.map.device.utils.MAPLog
 *  e.a.a.a.a
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.ref.WeakReference
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.HashSet
 *  java.util.LinkedList
 *  java.util.Set
 *  java.util.UUID
 */
package com.amazon.identity.auth.device.interactive;

import android.net.Uri;
import android.os.Bundle;
import com.amazon.identity.auth.device.ResponseManager;
import com.amazon.identity.auth.device.api.workflow.RequestContext;
import com.amazon.identity.auth.device.interactive.InteractiveRequestMap;
import com.amazon.identity.auth.device.interactive.InteractiveRequestRecord;
import com.amazon.identity.auth.device.interactive.InteractiveState;
import com.amazon.identity.auth.device.interactive.InteractiveStateFragment;
import com.amazon.identity.auth.map.device.utils.MAPLog;
import e.a.a.a.a;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Set;
import java.util.UUID;

public final class GenericInteractiveState
implements InteractiveState {
    public static final String INTERACTIVE_STATE_ID_KEY = "interactiveStateId";
    private static final String LOG_TAG = "com.amazon.identity.auth.device.interactive.GenericInteractiveState";
    public static final String REQUEST_LIST_KEY = "requestRecords";
    public static final String SAVED_INSTANCE_STATE_KEY = a.Q0(InteractiveState.class, (StringBuilder)new StringBuilder(), (String)".instanceState");
    private WeakReference<InteractiveStateFragment> backingFragment;
    private final InteractiveRequestMap interactiveRequestMap;
    private final Set<InteractiveRequestRecord> requests;
    private final ResponseManager responseManager;
    private UUID stateId;

    public GenericInteractiveState(InteractiveStateFragment interactiveStateFragment) {
        this(interactiveStateFragment, ResponseManager.getInstance(), InteractiveRequestMap.getInstance());
    }

    public GenericInteractiveState(InteractiveStateFragment interactiveStateFragment, ResponseManager responseManager, InteractiveRequestMap interactiveRequestMap) {
        this.backingFragment = new WeakReference((Object)interactiveStateFragment);
        this.responseManager = responseManager;
        this.interactiveRequestMap = interactiveRequestMap;
        this.requests = new HashSet();
        this.stateId = UUID.randomUUID();
    }

    public void doProcessPendingResponses(RequestContext requestContext) {
        LinkedList linkedList = new LinkedList();
        for (InteractiveRequestRecord interactiveRequestRecord : this.requests) {
            RequestContext requestContext2;
            String string = interactiveRequestRecord.getRequestId();
            if (!this.responseManager.hasPendingResponseForRequest(string) || (requestContext2 = this.getRequestContextForRequest(interactiveRequestRecord)) != requestContext) continue;
            String string2 = LOG_TAG;
            StringBuilder stringBuilder = a.F1((String)"InteractiveState ");
            stringBuilder.append((Object)this.stateId);
            stringBuilder.append(": Processing request ");
            stringBuilder.append(string);
            MAPLog.d((String)string2, (String)stringBuilder.toString());
            requestContext2.processResponse(interactiveRequestRecord, this.responseManager.removePendingResponse(string));
            linkedList.add((Object)interactiveRequestRecord);
        }
        this.requests.removeAll((Collection)linkedList);
    }

    public String getId() {
        return this.stateId.toString();
    }

    public RequestContext getRequestContextForRequest(InteractiveRequestRecord interactiveRequestRecord) {
        Object object = this.getRequestSourceForRequest(interactiveRequestRecord);
        return this.interactiveRequestMap.getRequestContextForSource(object);
    }

    public Object getRequestSourceForRequest(InteractiveRequestRecord interactiveRequestRecord) {
        Bundle bundle = interactiveRequestRecord.getFragmentWrapper();
        Object object = bundle != null ? ((InteractiveStateFragment)this.backingFragment.get()).getFragment(bundle) : null;
        if (object == null) {
            object = ((InteractiveStateFragment)this.backingFragment.get()).getParentActivity();
        }
        if (object == null) {
            object = ((InteractiveStateFragment)this.backingFragment.get()).getApplicationContext();
        }
        return object;
    }

    public Set<InteractiveRequestRecord> getRequests() {
        return this.requests;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void onRequestStart(InteractiveRequestRecord interactiveRequestRecord) {
        GenericInteractiveState genericInteractiveState = this;
        synchronized (genericInteractiveState) {
            String string = interactiveRequestRecord.getFragmentWrapper() == null ? "activity" : "fragment";
            String string2 = LOG_TAG;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("InteractiveState ");
            stringBuilder.append((Object)this.stateId);
            stringBuilder.append(": Recording ");
            stringBuilder.append(string);
            stringBuilder.append(" request ");
            stringBuilder.append(interactiveRequestRecord.getRequestId());
            MAPLog.d((String)string2, (String)stringBuilder.toString());
            this.requests.add((Object)interactiveRequestRecord);
            return;
        }
    }

    public void processPendingResponses(RequestContext requestContext) {
        GenericInteractiveState genericInteractiveState = this;
        synchronized (genericInteractiveState) {
            if (this.shouldAttemptProcessingResponses()) {
                this.doProcessPendingResponses(requestContext);
            } else {
                String string = LOG_TAG;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("InteractiveState ");
                stringBuilder.append((Object)this.stateId);
                stringBuilder.append(": No responses to process");
                MAPLog.d((String)string, (String)stringBuilder.toString());
            }
            return;
        }
    }

    public void readFromBundle(Bundle bundle) {
        Bundle bundle2;
        if (bundle != null && (bundle2 = bundle.getBundle(SAVED_INSTANCE_STATE_KEY)) != null) {
            String string = LOG_TAG;
            MAPLog.d((String)string, (String)"Restoring interactive state from saved instance state");
            String string2 = bundle2.getString(INTERACTIVE_STATE_ID_KEY);
            if (string2 == null) {
                MAPLog.w((String)string, (String)"Restoring interactive state from instance state but no state ID found");
            } else {
                StringBuilder stringBuilder = a.F1((String)"Reassigning interactive state ");
                stringBuilder.append((Object)this.stateId);
                stringBuilder.append(" to ");
                stringBuilder.append(string2);
                MAPLog.d((String)string, (String)stringBuilder.toString());
                this.stateId = UUID.fromString((String)string2);
            }
            ArrayList arrayList = bundle2.getParcelableArrayList(REQUEST_LIST_KEY);
            if (arrayList != null) {
                this.requests.addAll((Collection)arrayList);
            }
        }
    }

    public boolean shouldAttemptProcessingResponses() {
        boolean bl = this.requests.size() > 0;
        boolean bl2 = this.responseManager.size() > 0;
        return bl && bl2;
    }

    public void writeToBundle(Bundle bundle) {
        if (this.requests.size() > 0) {
            Bundle bundle2 = new Bundle();
            bundle2.putString(INTERACTIVE_STATE_ID_KEY, this.stateId.toString());
            bundle2.putParcelableArrayList(REQUEST_LIST_KEY, new ArrayList(this.requests));
            bundle.putBundle(SAVED_INSTANCE_STATE_KEY, bundle2);
            String string = LOG_TAG;
            StringBuilder stringBuilder = a.F1((String)"InteractiveState ");
            stringBuilder.append((Object)this.stateId);
            stringBuilder.append(": writing to save instance state");
            MAPLog.d((String)string, (String)stringBuilder.toString());
        }
    }
}

