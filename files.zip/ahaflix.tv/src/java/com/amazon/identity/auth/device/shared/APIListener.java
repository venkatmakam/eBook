/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  com.amazon.identity.auth.device.AuthError
 *  com.amazon.identity.auth.device.api.Listener
 *  java.lang.Object
 */
package com.amazon.identity.auth.device.shared;

import android.os.Bundle;
import com.amazon.identity.auth.device.AuthError;
import com.amazon.identity.auth.device.api.Listener;

public interface APIListener
extends Listener<Bundle, AuthError> {
    public void onError(AuthError var1);

    public void onSuccess(Bundle var1);
}

