/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.net.Uri
 *  android.os.Bundle
 *  com.amazon.identity.auth.device.api.workflow.RequestContext
 *  com.amazon.identity.auth.device.interactive.InteractiveAPI
 *  com.amazon.identity.auth.device.interactive.InteractiveRequestRecord
 *  com.amazon.identity.auth.device.workflow.WorkflowCancellation
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 */
package com.amazon.identity.auth.device.interactive;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import com.amazon.identity.auth.device.api.workflow.ListenerNotFoundException;
import com.amazon.identity.auth.device.api.workflow.RequestContext;
import com.amazon.identity.auth.device.interactive.InteractiveAPI;
import com.amazon.identity.auth.device.interactive.InteractiveListener;
import com.amazon.identity.auth.device.interactive.InteractiveRequestRecord;
import com.amazon.identity.auth.device.workflow.WorkflowCancellation;

public abstract class InteractiveRequest<T extends InteractiveListener<S, U, V>, S, U, V>
implements InteractiveAPI,
InteractiveListener<S, U, V> {
    private RequestContext requestContext;

    public InteractiveRequest(RequestContext requestContext) {
        this.setRequestContext(requestContext);
    }

    private InteractiveListener<S, U, V> getAggregateListener() {
        return this.requestContext.getAggregateListener(this);
    }

    public void assertListenerPresent() throws ListenerNotFoundException {
        this.requestContext.assertListenerPresent((InteractiveAPI)this);
    }

    public Context getContext() {
        return this.requestContext.getContext();
    }

    public abstract Class<T> getListenerClass();

    public RequestContext getRequestContext() {
        return this.requestContext;
    }

    public Bundle getRequestExtras() {
        return null;
    }

    public boolean needHookOnActivity() {
        return this.requestContext.isHookNeededOnUIResume();
    }

    @Override
    public void onCancel(U u) {
        this.getAggregateListener().onCancel(u);
    }

    @Override
    public void onError(V v) {
        this.getAggregateListener().onError(v);
    }

    public void onRequestCancel(Context context, InteractiveRequestRecord interactiveRequestRecord, WorkflowCancellation workflowCancellation) {
        this.getAggregateListener().onRequestCancel(context, interactiveRequestRecord, workflowCancellation);
    }

    public void onRequestCompletion(Context context, InteractiveRequestRecord interactiveRequestRecord, Uri uri) {
        this.getAggregateListener().onRequestCompletion(context, interactiveRequestRecord, uri);
    }

    public void onRequestError(Context context, InteractiveRequestRecord interactiveRequestRecord, Exception exception) {
        this.getAggregateListener().onRequestError(context, interactiveRequestRecord, exception);
    }

    @Override
    public void onSuccess(S s) {
        this.getAggregateListener().onSuccess(s);
    }

    public void setRequestContext(RequestContext requestContext) {
        if (requestContext != null) {
            this.requestContext = requestContext;
            return;
        }
        throw new IllegalArgumentException("requestContext must be non-null");
    }
}

