/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.amazon.identity.auth.device.AuthError
 *  com.amazon.identity.auth.device.AuthError$ERROR_TYPE
 *  com.amazon.identity.auth.map.device.utils.MAPLog
 *  java.io.IOException
 *  java.lang.String
 *  java.lang.Throwable
 *  java.net.URI
 *  java.net.URISyntaxException
 *  java.util.Date
 *  org.apache.http.HttpResponse
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.amazon.identity.auth.device.endpoint;

import com.amazon.identity.auth.device.AuthError;
import com.amazon.identity.auth.device.dataobject.CodePair;
import com.amazon.identity.auth.device.endpoint.AbstractJSONTokenResponse;
import com.amazon.identity.auth.map.device.utils.MAPLog;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Date;
import org.apache.http.HttpResponse;
import org.json.JSONException;
import org.json.JSONObject;

public class CreateCodePairResponse
extends AbstractJSONTokenResponse {
    private static final String DEVICE_CODE = "device_code";
    private static final String EXPIRES_IN = "expires_in";
    private static final String INTERVAL = "interval";
    private static final String LOG_TAG = "com.amazon.identity.auth.device.endpoint.CreateCodePairResponse";
    private static final String USER_CODE = "user_code";
    private static final String VERIFICATION_URI = "verification_uri";
    private String mAppId;
    private JSONObject mCreateCodePairResponse;
    private String[] mScopeNames;

    public CreateCodePairResponse(HttpResponse httpResponse, String string, String[] arrstring) {
        super(httpResponse);
        this.mAppId = string;
        this.mScopeNames = arrstring;
    }

    @Override
    public void doParse(JSONObject jSONObject) throws IOException, JSONException, AuthError {
        this.mCreateCodePairResponse = jSONObject;
    }

    @Override
    public JSONObject extractResponseJSONObject(JSONObject jSONObject) throws JSONException {
        try {
            JSONObject jSONObject2 = super.extractResponseJSONObject(jSONObject);
            return jSONObject2;
        }
        catch (JSONException jSONException) {
            MAPLog.e((String)LOG_TAG, (String)"No Response type in the response");
            return jSONObject;
        }
    }

    public CodePair getCodePair() throws AuthError {
        int n;
        String string;
        URI uRI;
        String string2;
        String string3;
        int n2;
        try {
            string3 = this.mCreateCodePairResponse.getString(USER_CODE);
            string2 = this.mCreateCodePairResponse.getString(DEVICE_CODE);
            string = this.mCreateCodePairResponse.getString(VERIFICATION_URI);
            n = this.mCreateCodePairResponse.getInt(EXPIRES_IN);
            n2 = this.mCreateCodePairResponse.getInt(INTERVAL);
        }
        catch (JSONException jSONException) {
            MAPLog.e((String)LOG_TAG, (String)"Error reading JSON response, throwing AuthError", (Throwable)jSONException);
            throw new AuthError("Error reading JSON response", AuthError.ERROR_TYPE.ERROR_JSON);
        }
        try {
            uRI = new URI(string);
        }
        catch (URISyntaxException uRISyntaxException) {
            MAPLog.e((String)LOG_TAG, (String)"Error converting string to URI, throwing AuthError");
            throw new AuthError("Error converting string to URI", AuthError.ERROR_TYPE.ERROR_BAD_PARAM);
        }
        Date date = new Date();
        Date date2 = new Date(date.getTime() + (long)(n * 1000));
        CodePair codePair = new CodePair(this.mAppId, string3, string2, uRI, n2, date, date2, this.mScopeNames);
        return codePair;
    }
}

