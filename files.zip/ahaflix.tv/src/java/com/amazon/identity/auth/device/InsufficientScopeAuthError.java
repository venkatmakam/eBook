/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.annotation.SuppressLint
 *  com.amazon.identity.auth.device.AuthError
 *  com.amazon.identity.auth.device.AuthError$ERROR_TYPE
 *  java.lang.String
 */
package com.amazon.identity.auth.device;

import android.annotation.SuppressLint;
import com.amazon.identity.auth.device.AuthError;

@SuppressLint(value={"ParcelCreator"})
public class InsufficientScopeAuthError
extends AuthError {
    private static final long serialVersionUID = -6744534043432690103L;

    public InsufficientScopeAuthError(String string) {
        super(string, AuthError.ERROR_TYPE.ERROR_BAD_API_PARAM);
    }
}

