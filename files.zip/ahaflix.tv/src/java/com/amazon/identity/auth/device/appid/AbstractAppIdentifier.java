/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  com.amazon.identity.auth.device.appid.APIKeyDecoder
 *  com.amazon.identity.auth.device.appid.AppIdentifier
 *  com.amazon.identity.auth.device.utils.ThirdPartyResourceParser
 *  com.amazon.identity.auth.map.device.utils.MAPLog
 *  e.a.a.a.a
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 */
package com.amazon.identity.auth.device.appid;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import com.amazon.identity.auth.device.appid.APIKeyDecoder;
import com.amazon.identity.auth.device.appid.AppIdentifier;
import com.amazon.identity.auth.device.dataobject.AppInfo;
import com.amazon.identity.auth.device.utils.ThirdPartyResourceParser;
import com.amazon.identity.auth.map.device.utils.MAPLog;
import e.a.a.a.a;

public abstract class AbstractAppIdentifier
implements AppIdentifier {
    public static final /* synthetic */ boolean $assertionsDisabled = false;
    private static final String LOG_TAG = "com.amazon.identity.auth.device.appid.AbstractAppIdentifier";

    private String getAPIKey(String string, Context context) {
        String string2 = LOG_TAG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Finding API Key for ");
        stringBuilder.append(string);
        MAPLog.i((String)string2, (String)stringBuilder.toString());
        return this.getResourceParser(context, string).getApiKey();
    }

    public abstract String getAppFamilyId(String var1, Context var2);

    public AppInfo getAppInfo(String string, Context context) {
        String string2 = LOG_TAG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("getAppInfo : packageName=");
        stringBuilder.append(string);
        MAPLog.i((String)string2, (String)stringBuilder.toString());
        return this.getAppInfoFromAPIKey(string, context);
    }

    public AppInfo getAppInfoFromAPIKey(String string, Context context) {
        String string2 = LOG_TAG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("getAppInfoFromAPIKey : packageName=");
        stringBuilder.append(string);
        MAPLog.i((String)string2, (String)stringBuilder.toString());
        if (string == null) {
            MAPLog.w((String)string2, (String)"packageName can't be null!");
            return null;
        }
        return APIKeyDecoder.decode((String)string, (String)this.getAPIKey(string, context), (Context)context);
    }

    public String getAppLabel(String string, Context context) {
        String string2 = LOG_TAG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("getAppLabel : packageName=");
        stringBuilder.append(string);
        MAPLog.i((String)string2, (String)stringBuilder.toString());
        if (string == null) {
            MAPLog.w((String)string2, (String)"packageName can't be null!");
            return null;
        }
        try {
            ApplicationInfo applicationInfo = context.getPackageManager().getApplicationInfo(string, 0);
            String string3 = (String)context.getPackageManager().getApplicationLabel(applicationInfo);
            return string3;
        }
        catch (PackageManager.NameNotFoundException nameNotFoundException) {
            String string4 = LOG_TAG;
            StringBuilder stringBuilder2 = a.F1((String)"");
            stringBuilder2.append(nameNotFoundException.getMessage());
            MAPLog.e((String)string4, (String)stringBuilder2.toString(), (Throwable)nameNotFoundException);
            return null;
        }
    }

    public abstract String getAppVariantId(String var1, Context var2);

    public abstract String getPackageName(String var1, Context var2);

    public abstract String getPackageNameByVariant(String var1, Context var2);

    public abstract String[] getPackageNames(String var1, Context var2);

    public ThirdPartyResourceParser getResourceParser(Context context, String string) {
        return new ThirdPartyResourceParser(context, string);
    }

    public boolean isAPIKeyValid(Context context) {
        if (context == null) {
            MAPLog.w((String)LOG_TAG, (String)"context can't be null!");
            return false;
        }
        return this.isAPIKeyValid(context.getPackageName(), context);
    }

    public boolean isAPIKeyValid(String string, Context context) {
        String string2 = LOG_TAG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("isAPIKeyValid : packageName=");
        stringBuilder.append(string);
        MAPLog.i((String)string2, (String)stringBuilder.toString());
        if (string == null) {
            MAPLog.w((String)string2, (String)"packageName can't be null!");
            return false;
        }
        AppInfo appInfo = this.getAppInfo(string, context);
        boolean bl = false;
        if (appInfo != null) {
            bl = true;
        }
        return bl;
    }

    public boolean isAPIKeyValid(String string, String string2, Context context) {
        String string3 = LOG_TAG;
        String string4 = a.h1((String)"isAPIKeyValid : packageName=", (String)string);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("apiKey=");
        stringBuilder.append(string2);
        MAPLog.pii((String)string3, (String)string4, (String)stringBuilder.toString());
        if (string == null) {
            MAPLog.w((String)string3, (String)"packageName can't be null!");
            return false;
        }
        if (string2 == null) {
            MAPLog.w((String)string3, (String)"apiKey can't be null!");
            return false;
        }
        AppInfo appInfo = APIKeyDecoder.decode((String)string, (String)string2, (Context)context);
        boolean bl = false;
        if (appInfo != null) {
            bl = true;
        }
        return bl;
    }
}

