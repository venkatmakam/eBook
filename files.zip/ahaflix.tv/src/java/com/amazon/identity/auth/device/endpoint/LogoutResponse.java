/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.amazon.identity.auth.device.AuthError
 *  java.io.IOException
 *  org.apache.http.HttpResponse
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.amazon.identity.auth.device.endpoint;

import com.amazon.identity.auth.device.AuthError;
import com.amazon.identity.auth.device.endpoint.AbstractJSONTokenResponse;
import java.io.IOException;
import org.apache.http.HttpResponse;
import org.json.JSONException;
import org.json.JSONObject;

public class LogoutResponse
extends AbstractJSONTokenResponse {
    private JSONObject logoutResponse;

    public LogoutResponse(HttpResponse httpResponse) {
        super(httpResponse);
    }

    @Override
    public void doParse(JSONObject jSONObject) throws IOException, JSONException, AuthError {
        this.logoutResponse = jSONObject;
    }

    public JSONObject getLogoutResponse() {
        return this.logoutResponse;
    }
}

