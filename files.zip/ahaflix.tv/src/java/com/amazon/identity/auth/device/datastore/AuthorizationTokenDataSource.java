/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.database.Cursor
 *  android.database.sqlite.SQLiteDatabase
 *  com.amazon.identity.auth.device.dataobject.AbstractDataObject
 *  com.amazon.identity.auth.device.dataobject.AuthorizationToken$AUTHZ_TOKEN_TYPE
 *  com.amazon.identity.auth.device.dataobject.AuthorizationToken$COL_INDEX
 *  com.amazon.identity.auth.device.dataobject.AuthorizationTokenFactory
 *  com.amazon.identity.auth.device.datastore.AbstractDataSource
 *  com.amazon.identity.auth.device.datastore.DatabaseHelper
 *  com.amazon.identity.auth.device.utils.MAPUtils
 *  com.amazon.identity.auth.map.device.utils.MAPLog
 *  e.a.a.a.a
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.Date
 *  java.util.List
 */
package com.amazon.identity.auth.device.datastore;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import com.amazon.identity.auth.device.dataobject.AbstractDataObject;
import com.amazon.identity.auth.device.dataobject.AuthorizationToken;
import com.amazon.identity.auth.device.dataobject.AuthorizationTokenFactory;
import com.amazon.identity.auth.device.datastore.AbstractDataSource;
import com.amazon.identity.auth.device.datastore.DatabaseHelper;
import com.amazon.identity.auth.device.utils.MAPUtils;
import com.amazon.identity.auth.map.device.utils.MAPLog;
import e.a.a.a.a;
import java.util.Date;
import java.util.List;

public final class AuthorizationTokenDataSource
extends AbstractDataSource<AuthorizationToken> {
    private static final String[] ALL_COLUMNS = AuthorizationToken.ALL_COLUMNS;
    private static AuthorizationTokenDataSource INSTANCE;
    private static final String LOG_TAG = "com.amazon.identity.auth.device.datastore.AuthorizationTokenDataSource";

    private AuthorizationTokenDataSource(SQLiteDatabase sQLiteDatabase) {
        super(sQLiteDatabase);
    }

    public static AuthorizationTokenDataSource getInstance(Context context) {
        Class<AuthorizationTokenDataSource> class_ = AuthorizationTokenDataSource.class;
        synchronized (AuthorizationTokenDataSource.class) {
            if (INSTANCE == null) {
                INSTANCE = new AuthorizationTokenDataSource(MAPUtils.getMAPdatabase((Context)context));
            }
            AuthorizationTokenDataSource authorizationTokenDataSource = INSTANCE;
            // ** MonitorExit[var3_1] (shouldn't be in output)
            return authorizationTokenDataSource;
        }
    }

    public static void resetInstance() {
        INSTANCE = null;
        MAPUtils.resetDatabaseInstance();
    }

    public AuthorizationToken cursorToObject(Cursor cursor) {
        if (cursor != null) {
            if (cursor.getCount() == 0) {
                return null;
            }
            try {
                AuthorizationToken authorizationToken = AuthorizationTokenFactory.getAuthorizationToken(AuthorizationToken.AUTHZ_TOKEN_TYPE.values()[cursor.getInt(this.getColumnIndex(cursor, AuthorizationToken.COL_INDEX.TYPE.colId))]);
                authorizationToken.setId(cursor.getLong(this.getColumnIndex(cursor, AuthorizationToken.COL_INDEX.ID.colId)));
                authorizationToken.setAppFamilyId(cursor.getString(this.getColumnIndex(cursor, AuthorizationToken.COL_INDEX.APP_FAMILY_ID.colId)));
                authorizationToken.setTokenValue(cursor.getString(this.getColumnIndex(cursor, AuthorizationToken.COL_INDEX.TOKEN.colId)));
                authorizationToken.setCreationTime(DatabaseHelper.parseDate((String)cursor.getString(this.getColumnIndex(cursor, AuthorizationToken.COL_INDEX.CREATION_TIME.colId))));
                authorizationToken.setExpirationTime(DatabaseHelper.parseDate((String)cursor.getString(this.getColumnIndex(cursor, AuthorizationToken.COL_INDEX.EXPIRATION_TIME.colId))));
                authorizationToken.setMiscData(cursor.getBlob(this.getColumnIndex(cursor, AuthorizationToken.COL_INDEX.MISC_DATA.colId)));
                authorizationToken.setDirectedId(cursor.getString(this.getColumnIndex(cursor, AuthorizationToken.COL_INDEX.DIRECTED_ID.colId)));
                return authorizationToken;
            }
            catch (Exception exception) {
                String string = LOG_TAG;
                StringBuilder stringBuilder = a.F1((String)"");
                stringBuilder.append(exception.getMessage());
                MAPLog.e((String)string, (String)stringBuilder.toString(), (Throwable)exception);
            }
        }
        return null;
    }

    public int deleteByAppFamilyId(String string) {
        return this.deleteRowsBySingleColumn(ALL_COLUMNS[AuthorizationToken.COL_INDEX.APP_FAMILY_ID.colId], string);
    }

    public int deleteByDirectedId(String string) {
        return this.deleteRowsBySingleColumn(ALL_COLUMNS[AuthorizationToken.COL_INDEX.DIRECTED_ID.colId], string);
    }

    public List<AuthorizationToken> findByAppFamilyId(String string) {
        return this.findAllRowsBySingleColumn(ALL_COLUMNS[AuthorizationToken.COL_INDEX.APP_FAMILY_ID.colId], string);
    }

    public List<AuthorizationToken> findByDirectedId(String string) {
        return this.findAllRowsBySingleColumn(ALL_COLUMNS[AuthorizationToken.COL_INDEX.DIRECTED_ID.colId], string);
    }

    public AuthorizationToken findById(long l) {
        return (AuthorizationToken)this.findByRowId(l);
    }

    public AuthorizationToken findByPrimaryKey(long l) {
        return (AuthorizationToken)this.findByRowId(l);
    }

    public String[] getAllColumns() {
        return ALL_COLUMNS;
    }

    public String getLogTag() {
        return LOG_TAG;
    }

    public String getTableName() {
        return "AuthorizationToken";
    }
}

