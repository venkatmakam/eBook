/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.net.Uri
 *  android.net.Uri$Builder
 *  android.os.Bundle
 *  com.amazon.identity.auth.device.AbstractRequest
 *  com.amazon.identity.auth.device.AuthError
 *  com.amazon.identity.auth.device.AuthError$ERROR_TYPE
 *  com.amazon.identity.auth.device.authorization.TokenHelper
 *  com.amazon.identity.auth.device.authorization.api.AuthzConstants
 *  com.amazon.identity.auth.device.authorization.api.AuthzConstants$BUNDLE_KEY
 *  com.amazon.identity.auth.device.endpoint.AbstractPandaRequest
 *  com.amazon.identity.auth.device.endpoint.PandaResponse
 *  com.amazon.identity.auth.device.endpoint.ServerCommunication
 *  com.amazon.identity.auth.device.interactive.InteractiveRequestRecord
 *  com.amazon.identity.auth.device.workflow.WorkflowResponse
 *  com.amazon.identity.auth.device.workflow.WorkflowToken
 *  com.amazon.identity.auth.map.device.utils.MAPLog
 *  e.a.a.a.a
 *  java.io.IOException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.amazon.identity.auth.device.workflow;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import com.amazon.identity.auth.device.AbstractRequest;
import com.amazon.identity.auth.device.AuthError;
import com.amazon.identity.auth.device.appid.ThirdPartyAppIdentifier;
import com.amazon.identity.auth.device.authorization.TokenHelper;
import com.amazon.identity.auth.device.authorization.api.AuthzConstants;
import com.amazon.identity.auth.device.dataobject.AppInfo;
import com.amazon.identity.auth.device.endpoint.AbstractPandaRequest;
import com.amazon.identity.auth.device.endpoint.OneTimeCodeRequest;
import com.amazon.identity.auth.device.endpoint.OneTimeCodeResponse;
import com.amazon.identity.auth.device.endpoint.PandaResponse;
import com.amazon.identity.auth.device.endpoint.ServerCommunication;
import com.amazon.identity.auth.device.interactive.InteractiveRequest;
import com.amazon.identity.auth.device.interactive.InteractiveRequestRecord;
import com.amazon.identity.auth.device.workflow.WorkflowResponse;
import com.amazon.identity.auth.device.workflow.WorkflowToken;
import com.amazon.identity.auth.map.device.utils.MAPLog;
import e.a.a.a.a;
import java.io.IOException;
import org.json.JSONException;
import org.json.JSONObject;

public class WorkflowRequest
extends AbstractRequest {
    private static final String LOG_TAG = "com.amazon.identity.auth.device.workflow.WorkflowRequest";
    private static final String RELYING_PARTY_CONTEXT_PARAMETER_NAME = "rpContext";
    private static final String RP_CONTEXT_ONE_TIME_CODE_FIELD = "code";
    private static final String RP_CONTEXT_REDIRECT_URL_FIELD = "redirect_uri";
    private final ThirdPartyAppIdentifier appIdentifier = new ThirdPartyAppIdentifier();
    private final int minTokenLifetime;
    private final ServerCommunication serverCommunication;
    private final WorkflowToken workflowToken;
    private final String workflowUrl;

    public WorkflowRequest(InteractiveRequest<?, ?, ?, ?> interactiveRequest, String string, WorkflowToken workflowToken, int n, ServerCommunication serverCommunication) throws AuthError {
        super(interactiveRequest);
        workflowToken.assertWorkflowUrlIsAllowed(string);
        this.workflowUrl = string;
        this.workflowToken = workflowToken;
        this.minTokenLifetime = n;
        this.serverCommunication = serverCommunication;
    }

    private AppInfo getAppInfo(Context context) {
        return this.appIdentifier.getAppInfo(context.getPackageName(), context);
    }

    private String getOneTimeCode(Context context) throws IOException, AuthError {
        Bundle bundle = new Bundle();
        bundle.putInt(AuthzConstants.BUNDLE_KEY.MINIMUM_TOKEN_LIFETIME.val, this.minTokenLifetime);
        String string = TokenHelper.getTokenInternal((Context)context, (String)context.getPackageName(), (String[])this.workflowToken.getScopes(), (AppInfo)this.appIdentifier.getAppInfo(context.getPackageName(), context), (Bundle)bundle);
        if (string != null) {
            OneTimeCodeRequest oneTimeCodeRequest = new OneTimeCodeRequest(context, this.workflowToken.getClientId(), string, this.getAppInfo(context));
            return ((OneTimeCodeResponse)this.serverCommunication.executeRequest((AbstractPandaRequest)oneTimeCodeRequest, context)).getOneTimeCode();
        }
        throw new AuthError("Could not find token for scopes required to open workflow", AuthError.ERROR_TYPE.ERROR_MISSING_TOKEN_FOR_REQUIRED_SCOPES);
    }

    private String getRedirectUrl(Context context) {
        return this.appIdentifier.getRedirectUrl(context);
    }

    private String getRelyingPartyContextParameter(Context context) throws JSONException, IOException, AuthError {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put(RP_CONTEXT_ONE_TIME_CODE_FIELD, (Object)this.getOneTimeCode(context));
        jSONObject.put(RP_CONTEXT_REDIRECT_URL_FIELD, (Object)this.getRedirectUrl(context));
        jSONObject.put("state", (Object)this.getStateField());
        return jSONObject.toString();
    }

    private String getStateField() throws JSONException {
        Object[] arrobject = new Object[]{"clientRequestId", this.requestId, "InteractiveRequestType", this.originalRequest.getRequestType()};
        return String.format((String)"%s=%s&%s=%s", (Object[])arrobject);
    }

    public int getMaxAttemptCount() {
        return 2;
    }

    public String getUrl(Context context) throws AuthError {
        try {
            String string = Uri.parse((String)this.workflowUrl).buildUpon().appendQueryParameter(RELYING_PARTY_CONTEXT_PARAMETER_NAME, this.getRelyingPartyContextParameter(context)).build().toString();
            return string;
        }
        catch (IOException iOException) {
            throw new AuthError("Error communicating with server", (Throwable)iOException, AuthError.ERROR_TYPE.ERROR_IO);
        }
        catch (JSONException jSONException) {
            throw new AuthError("Error while generating workflow URL", (Throwable)jSONException, AuthError.ERROR_TYPE.ERROR_UNKNOWN);
        }
    }

    public boolean handleResponse(Uri uri, Context context) {
        String string = LOG_TAG;
        StringBuilder stringBuilder = a.F1((String)"response=");
        stringBuilder.append(uri.toString());
        MAPLog.pii((String)string, (String)"Received response from workflow", (String)stringBuilder.toString());
        WorkflowResponse workflowResponse = new WorkflowResponse(uri);
        if (workflowResponse.isError() && workflowResponse.isRecoverable()) {
            MAPLog.d((String)string, (String)"Workflow response is a recoverable error. Retrying.");
            return false;
        }
        this.originalRequest.onRequestCompletion(context, this.getInteractiveRequestRecord(), uri);
        return true;
    }
}

