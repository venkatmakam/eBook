/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ContentValues
 *  android.content.Context
 *  android.text.TextUtils
 *  com.amazon.identity.auth.device.dataobject.AbstractDataObject
 *  com.amazon.identity.auth.device.dataobject.AppInfo$COL_INDEX
 *  com.amazon.identity.auth.device.dataobject.Scope
 *  com.amazon.identity.auth.device.datastore.AbstractDataSource
 *  com.amazon.identity.auth.device.utils.MAPUtils
 *  com.amazon.identity.auth.map.device.utils.MAPLog
 *  e.a.a.a.a
 *  java.lang.CharSequence
 *  java.lang.ClassCastException
 *  java.lang.CloneNotSupportedException
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.Iterator
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.amazon.identity.auth.device.dataobject;

import android.content.ContentValues;
import android.content.Context;
import android.text.TextUtils;
import com.amazon.identity.auth.device.dataobject.AbstractDataObject;
import com.amazon.identity.auth.device.dataobject.AppInfo;
import com.amazon.identity.auth.device.dataobject.Scope;
import com.amazon.identity.auth.device.datastore.AbstractDataSource;
import com.amazon.identity.auth.device.datastore.AppInfoDataSource;
import com.amazon.identity.auth.device.utils.MAPUtils;
import com.amazon.identity.auth.map.device.utils.MAPLog;
import e.a.a.a.a;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import org.json.JSONException;
import org.json.JSONObject;

public class AppInfo
extends AbstractDataObject {
    public static final String[] ALL_COLUMNS = new String[]{"rowid", "AppFamilyId", "PackageName", "AllowedScopes", "GrantedPermissions", "ClientId", "AppVariantId", "AuthzHost", "ExchangeHost", "Payload"};
    public static final String DELIM = ",";
    private static final String LOG_TAG = "com.amazon.identity.auth.device.dataobject.AppInfo";
    private String[] allowedScopes;
    private String appFamilyId;
    private String appVariantId;
    private String clientId;
    private String[] grantedPermissions;
    private String mAuthzHost;
    private String mExchangeHost;
    private String packageName;
    private JSONObject payload;

    public AppInfo() {
    }

    private AppInfo(long l, String string, String string2, String string3, String[] arrstring, String[] arrstring2, String string4, String string5, String string6, JSONObject jSONObject) {
        this(string, string2, string3, arrstring, arrstring2, string4, string5, string6, jSONObject);
        this.setRowId(l);
    }

    public AppInfo(String string, String string2, String string3, String[] arrstring, String[] arrstring2, String string4, String string5, String string6, JSONObject jSONObject) {
        this.appFamilyId = string;
        this.appVariantId = string2;
        this.packageName = string3;
        this.allowedScopes = arrstring;
        this.grantedPermissions = arrstring2;
        this.clientId = string4;
        this.payload = jSONObject;
        this.mAuthzHost = string5;
        this.mExchangeHost = string6;
    }

    private JSONObject getPayload() {
        return this.payload;
    }

    private boolean payloadEquals(AppInfo appInfo) {
        JSONObject jSONObject = appInfo.getPayload();
        JSONObject jSONObject2 = this.payload;
        if (jSONObject2 == null) {
            return jSONObject == null;
        }
        if (jSONObject == null) {
            return false;
        }
        Iterator iterator = jSONObject2.keys();
        while (iterator.hasNext()) {
            String string = (String)iterator.next();
            try {
                if (this.payload.getString(string).equals((Object)jSONObject.getString(string))) continue;
                String string2 = LOG_TAG;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("APIKeys not equal: key ");
                stringBuilder.append(string);
                stringBuilder.append(" not equal");
                MAPLog.e((String)string2, (String)stringBuilder.toString());
                return false;
            }
            catch (ClassCastException classCastException) {
                MAPLog.e((String)LOG_TAG, (String)"APIKeys not equal: ClassCastExceptionException", (Throwable)classCastException);
                return false;
            }
            catch (JSONException jSONException) {
                MAPLog.e((String)LOG_TAG, (String)"APIKeys not equal: JSONException", (Throwable)jSONException);
                return false;
            }
        }
        return true;
    }

    public AppInfo clone() {
        AppInfo appInfo = new AppInfo(this.getRowId(), this.appFamilyId, this.appVariantId, this.packageName, this.allowedScopes, this.grantedPermissions, this.clientId, this.mAuthzHost, this.mExchangeHost, this.payload);
        return appInfo;
    }

    public boolean equals(Object object) {
        boolean bl = object instanceof AppInfo;
        boolean bl2 = false;
        if (bl) {
            AppInfo appInfo = (AppInfo)((Object)object);
            boolean bl3 = TextUtils.equals((CharSequence)this.appFamilyId, (CharSequence)appInfo.getAppFamilyId());
            bl2 = false;
            if (bl3) {
                boolean bl4 = TextUtils.equals((CharSequence)this.appVariantId, (CharSequence)appInfo.getAppVariantId());
                bl2 = false;
                if (bl4) {
                    boolean bl5 = TextUtils.equals((CharSequence)this.packageName, (CharSequence)appInfo.getPackageName());
                    bl2 = false;
                    if (bl5) {
                        boolean bl6 = Arrays.equals((Object[])this.allowedScopes, (Object[])appInfo.getAllowedScopes());
                        bl2 = false;
                        if (bl6) {
                            boolean bl7 = Arrays.equals((Object[])this.grantedPermissions, (Object[])appInfo.getGrantedPermissions());
                            bl2 = false;
                            if (bl7) {
                                boolean bl8 = TextUtils.equals((CharSequence)this.clientId, (CharSequence)appInfo.getClientId());
                                bl2 = false;
                                if (bl8) {
                                    boolean bl9 = TextUtils.equals((CharSequence)this.mAuthzHost, (CharSequence)appInfo.getAuthorizationHost());
                                    bl2 = false;
                                    if (bl9) {
                                        boolean bl10 = TextUtils.equals((CharSequence)this.mExchangeHost, (CharSequence)appInfo.getExchangeHost());
                                        bl2 = false;
                                        if (bl10) {
                                            boolean bl11 = this.payloadEquals(appInfo);
                                            bl2 = false;
                                            if (bl11) {
                                                bl2 = true;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return bl2;
    }

    public String[] getAllowedRemoteScopes() {
        if (this.allowedScopes == null) {
            return null;
        }
        ArrayList arrayList = new ArrayList();
        for (String string : this.allowedScopes) {
            if (Scope.isLocal((String)string)) continue;
            arrayList.add((Object)string);
        }
        return (String[])arrayList.toArray((Object[])new String[arrayList.size()]);
    }

    public String[] getAllowedScopes() {
        return this.allowedScopes;
    }

    public String getAppFamilyId() {
        return this.appFamilyId;
    }

    public String getAppVariantId() {
        return this.appVariantId;
    }

    public String getAttributeByKey(String string) {
        try {
            String string2 = this.payload.getString(string);
            return string2;
        }
        catch (JSONException jSONException) {
            return null;
        }
    }

    public String getAuthorizationHost() {
        return this.mAuthzHost;
    }

    public String getClientId() {
        return this.clientId;
    }

    public AppInfoDataSource getDataSource(Context context) {
        return AppInfoDataSource.getInstance(context);
    }

    public String getExchangeHost() {
        return this.mExchangeHost;
    }

    public String[] getGrantedPermissions() {
        return this.grantedPermissions;
    }

    public String getPackageName() {
        return this.packageName;
    }

    public ContentValues getValuesForInsert() {
        ContentValues contentValues = new ContentValues();
        String[] arrstring = ALL_COLUMNS;
        contentValues.put(arrstring[COL_INDEX.APP_FAMILY_ID.colId], this.appFamilyId);
        contentValues.put(arrstring[COL_INDEX.PACKAGE_NAME.colId], this.packageName);
        contentValues.put(arrstring[COL_INDEX.ALLOWED_SCOPES.colId], MAPUtils.toDelimitedString((String[])this.allowedScopes, (String)DELIM));
        contentValues.put(arrstring[COL_INDEX.GRANTED_PERMISSIONS.colId], MAPUtils.toDelimitedString((String[])this.grantedPermissions, (String)DELIM));
        contentValues.put(arrstring[COL_INDEX.CLIENT_ID.colId], this.clientId);
        contentValues.put(arrstring[COL_INDEX.APP_VARIANT_ID.colId], this.appVariantId);
        contentValues.put(arrstring[COL_INDEX.AUTHZ_HOST.colId], this.mAuthzHost);
        contentValues.put(arrstring[COL_INDEX.EXCHANGE_HOST.colId], this.mExchangeHost);
        String string = arrstring[COL_INDEX.PAYLOAD.colId];
        JSONObject jSONObject = this.payload;
        String string2 = jSONObject != null ? jSONObject.toString() : null;
        contentValues.put(string, string2);
        return contentValues;
    }

    public String getVersion() {
        String string = this.getAttributeByKey("ver");
        if (string != null) {
            return string;
        }
        return "1";
    }

    public void setAllowedScopes(String[] arrstring) {
        this.allowedScopes = arrstring;
    }

    public void setAppFamilyId(String string) {
        this.appFamilyId = string;
    }

    public void setAppVariantId(String string) {
        this.appVariantId = string;
    }

    public void setAuthorizationHost(String string) {
        this.mAuthzHost = string;
    }

    public void setClientId(String string) {
        this.clientId = string;
    }

    public void setExchangeHost(String string) {
        this.mExchangeHost = string;
    }

    public void setGrantedPermissions(String[] arrstring) {
        this.grantedPermissions = arrstring;
    }

    public void setPackageName(String string) {
        this.packageName = string;
    }

    public void setPayload(String string) {
        try {
            this.payload = new JSONObject(string);
            return;
        }
        catch (JSONException jSONException) {
            MAPLog.e((String)LOG_TAG, (String)"Payload String not correct JSON.  Setting payload to null", (Throwable)jSONException);
            return;
        }
    }

    public void setPayload(JSONObject jSONObject) {
        this.payload = jSONObject;
    }

    public String toString() {
        try {
            String string = this.payload.toString(4);
            return string;
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = a.F1((String)"{ rowid=");
            stringBuilder.append(this.getRowId());
            stringBuilder.append(", appFamilyId=");
            stringBuilder.append(this.appFamilyId);
            stringBuilder.append(", appVariantId=");
            stringBuilder.append(this.appVariantId);
            stringBuilder.append(", packageName=");
            stringBuilder.append(this.packageName);
            stringBuilder.append(", allowedScopes=");
            stringBuilder.append(Arrays.toString((Object[])this.allowedScopes));
            stringBuilder.append(", grantedPermissions=");
            stringBuilder.append(Arrays.toString((Object[])this.grantedPermissions));
            stringBuilder.append(", clientId=");
            stringBuilder.append(this.clientId);
            stringBuilder.append(", AuthzHost=");
            stringBuilder.append(this.mAuthzHost);
            stringBuilder.append(", ExchangeHost=");
            return a.r1((StringBuilder)stringBuilder, (String)this.mExchangeHost, (String)" }");
        }
    }
}

