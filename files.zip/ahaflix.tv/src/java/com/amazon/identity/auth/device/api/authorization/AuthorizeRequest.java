/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  com.amazon.identity.auth.device.AuthError
 *  com.amazon.identity.auth.device.api.authorization.AuthCancellation
 *  com.amazon.identity.auth.device.api.authorization.AuthorizeRequest$GrantType
 *  com.amazon.identity.auth.device.api.authorization.AuthorizeResult
 *  com.amazon.identity.auth.device.api.authorization.Scope
 *  com.amazon.identity.auth.device.api.workflow.RequestContext
 *  com.amazon.identity.auth.device.interactive.InteractiveRequest$Builder
 *  com.amazon.identity.auth.device.utils.LWAConstants
 *  com.amazon.identity.auth.device.utils.LWAConstants$AUTHORIZE_BUNDLE_KEY
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Collections
 *  java.util.LinkedList
 *  java.util.List
 */
package com.amazon.identity.auth.device.api.authorization;

import android.os.Bundle;
import com.amazon.identity.auth.device.AuthError;
import com.amazon.identity.auth.device.api.authorization.AuthCancellation;
import com.amazon.identity.auth.device.api.authorization.AuthorizeListener;
import com.amazon.identity.auth.device.api.authorization.AuthorizeRequest;
import com.amazon.identity.auth.device.api.authorization.AuthorizeResult;
import com.amazon.identity.auth.device.api.authorization.Scope;
import com.amazon.identity.auth.device.api.workflow.RequestContext;
import com.amazon.identity.auth.device.interactive.InteractiveRequest;
import com.amazon.identity.auth.device.utils.LWAConstants;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public final class AuthorizeRequest
extends InteractiveRequest<AuthorizeListener, AuthorizeResult, AuthCancellation, AuthError> {
    public static final String EXTRA_REQUESTED_SCOPES = "requestedScopes";
    public static final String EXTRA_SHOULD_RETURN_USER_DATA = "shouldReturnUserData";
    public static final String REQUEST_TYPE = "com.amazon.identity.auth.device.authorization.request.authorize";
    private String codeChallenge;
    private String codeChallengeMethod;
    private GrantType grantType = GrantType.ACCESS_TOKEN;
    private List<Scope> scopes = new LinkedList();
    private boolean shouldReturnUserData = true;
    private boolean shouldShowProgress = true;

    public AuthorizeRequest(RequestContext requestContext) {
        super(requestContext);
    }

    public void addScope(Scope scope) {
        this.scopes.add((Object)scope);
    }

    public /* varargs */ void addScopes(Scope ... arrscope) {
        Collections.addAll(this.scopes, (Object[])arrscope);
    }

    public String getCodeChallenge() {
        return this.codeChallenge;
    }

    public String getCodeChallengeMethod() {
        return this.codeChallengeMethod;
    }

    public GrantType getGrantType() {
        return this.grantType;
    }

    @Override
    public final Class<AuthorizeListener> getListenerClass() {
        return AuthorizeListener.class;
    }

    @Override
    public final Bundle getRequestExtras() {
        Bundle bundle = new Bundle();
        String[] arrstring = new String[this.scopes.size()];
        for (int j = 0; j < this.scopes.size(); ++j) {
            arrstring[j] = ((Scope)this.scopes.get(j)).getName();
        }
        bundle.putStringArray(EXTRA_REQUESTED_SCOPES, arrstring);
        bundle.putBoolean(EXTRA_SHOULD_RETURN_USER_DATA, this.shouldReturnUserData());
        bundle.putBoolean(LWAConstants.AUTHORIZE_BUNDLE_KEY.SHOW_PROGRESS.val, this.shouldShowProgress);
        return bundle;
    }

    public final String getRequestType() {
        return REQUEST_TYPE;
    }

    public List<Scope> getScopes() {
        return this.scopes;
    }

    public void setCodeChallenge(String string) {
        this.codeChallenge = string;
    }

    public void setCodeChallengeMethod(String string) {
        this.codeChallengeMethod = string;
    }

    public void setGrantType(GrantType grantType) {
        this.grantType = grantType;
    }

    public void setProofKeyParameters(String string, String string2) {
        this.setCodeChallenge(string);
        this.setCodeChallengeMethod(string2);
    }

    public void setScopes(List<Scope> list) {
        this.scopes = list;
    }

    public void setShouldReturnUserData(boolean bl) {
        this.shouldReturnUserData = bl;
    }

    public boolean shouldReturnUserData() {
        return this.shouldReturnUserData;
    }

    public boolean shouldShowProgress() {
        return this.shouldShowProgress;
    }

    public void showProgress(boolean bl) {
        this.shouldShowProgress = bl;
    }

    public static final class Builder
    extends InteractiveRequest.Builder<AuthorizeRequest> {
        private final AuthorizeRequest request;

        public Builder(RequestContext requestContext) {
            super(requestContext);
            this.request = new AuthorizeRequest(this.requestContext);
        }

        public Builder addScope(Scope scope) {
            this.request.addScope(scope);
            return this;
        }

        public /* varargs */ Builder addScopes(Scope ... arrscope) {
            this.request.addScopes(arrscope);
            return this;
        }

        public AuthorizeRequest build() {
            return this.request;
        }

        public Builder forGrantType(GrantType grantType) {
            this.request.setGrantType(grantType);
            return this;
        }

        public Builder shouldReturnUserData(boolean bl) {
            this.request.setShouldReturnUserData(bl);
            return this;
        }

        public Builder showProgress(boolean bl) {
            this.request.showProgress(bl);
            return this;
        }

        public Builder withProofKeyParameters(String string, String string2) {
            this.request.setProofKeyParameters(string, string2);
            return this;
        }
    }

}

