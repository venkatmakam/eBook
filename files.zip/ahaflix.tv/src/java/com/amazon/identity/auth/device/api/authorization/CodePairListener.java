/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.amazon.identity.auth.device.CodePairError
 *  com.amazon.identity.auth.device.api.Listener
 *  com.amazon.identity.auth.device.api.authorization.CodePairResult
 *  java.lang.Object
 */
package com.amazon.identity.auth.device.api.authorization;

import com.amazon.identity.auth.device.CodePairError;
import com.amazon.identity.auth.device.api.Listener;
import com.amazon.identity.auth.device.api.authorization.CodePairResult;

public abstract class CodePairListener
implements Listener<CodePairResult, CodePairError> {
    public abstract void onError(CodePairError var1);

    public abstract void onSuccess(CodePairResult var1);
}

