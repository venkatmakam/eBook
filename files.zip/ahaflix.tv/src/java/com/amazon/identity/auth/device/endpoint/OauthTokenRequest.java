/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  com.amazon.identity.auth.device.AuthError
 *  com.amazon.identity.auth.device.endpoint.PandaResponse
 *  com.amazon.identity.auth.map.device.utils.MAPLog
 *  e.a.a.a.a
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.List
 *  org.apache.http.HttpResponse
 *  org.apache.http.message.BasicNameValuePair
 */
package com.amazon.identity.auth.device.endpoint;

import android.content.Context;
import com.amazon.identity.auth.device.AuthError;
import com.amazon.identity.auth.device.dataobject.AppInfo;
import com.amazon.identity.auth.device.endpoint.AbstractOauthTokenRequest;
import com.amazon.identity.auth.device.endpoint.OauthTokenResponse;
import com.amazon.identity.auth.device.endpoint.PandaResponse;
import com.amazon.identity.auth.device.token.RefreshAtzToken;
import com.amazon.identity.auth.map.device.utils.MAPLog;
import e.a.a.a.a;
import java.util.ArrayList;
import java.util.List;
import org.apache.http.HttpResponse;
import org.apache.http.message.BasicNameValuePair;

public class OauthTokenRequest
extends AbstractOauthTokenRequest<OauthTokenResponse> {
    private static final String LOG_TAG = "com.amazon.identity.auth.device.endpoint.OauthTokenRequest";
    public static final String REFRESH_TOKEN = "refresh_token";
    public static final String REFRESH_TOKEN_GRANT = "refresh_token";
    private final RefreshAtzToken mRefreshToken;

    public OauthTokenRequest(Context context, RefreshAtzToken refreshAtzToken, AppInfo appInfo) throws AuthError {
        super(context, appInfo);
        this.mRefreshToken = refreshAtzToken;
    }

    public OauthTokenResponse generateResponse(HttpResponse httpResponse) {
        return new OauthTokenResponse(httpResponse, this.getAppFamilyId(), null);
    }

    @Override
    public List<BasicNameValuePair> getExtraOauthTokenRequestParameters() {
        ArrayList arrayList = new ArrayList();
        arrayList.add((Object)new BasicNameValuePair("refresh_token", this.mRefreshToken.toString()));
        return arrayList;
    }

    @Override
    public String getGrantType() {
        return "refresh_token";
    }

    public void logRequest() {
        String string = LOG_TAG;
        StringBuilder stringBuilder = a.F1((String)"Executing OAuth access token exchange. appId=");
        stringBuilder.append(this.getAppFamilyId());
        String string2 = stringBuilder.toString();
        StringBuilder stringBuilder2 = a.F1((String)"refreshAtzToken=");
        stringBuilder2.append(this.mRefreshToken.toString());
        MAPLog.pii((String)string, (String)string2, (String)stringBuilder2.toString());
    }
}

