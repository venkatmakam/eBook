/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.net.Uri
 *  com.amazon.identity.auth.device.AuthError
 *  com.amazon.identity.auth.device.interactive.InteractiveRequestRecord
 *  com.amazon.identity.auth.device.workflow.WorkflowCancellation
 *  com.amazon.identity.auth.device.workflow.WorkflowResponse
 *  com.amazon.identity.auth.map.device.utils.MAPLog
 *  e.a.a.a.a
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  org.json.JSONObject
 */
package com.amazon.identity.auth.device.workflow;

import android.content.Context;
import android.net.Uri;
import com.amazon.identity.auth.device.AuthError;
import com.amazon.identity.auth.device.interactive.InteractiveListener;
import com.amazon.identity.auth.device.interactive.InteractiveRequestRecord;
import com.amazon.identity.auth.device.workflow.WorkflowCancellation;
import com.amazon.identity.auth.device.workflow.WorkflowResponse;
import com.amazon.identity.auth.map.device.utils.MAPLog;
import e.a.a.a.a;
import org.json.JSONObject;

public abstract class BaseWorkflowListener<T, U, V>
implements InteractiveListener<T, U, V> {
    private static final String LOG_TAG = "com.amazon.identity.auth.device.workflow.BaseWorkflowListener";

    public final void onRequestCancel(Context context, InteractiveRequestRecord interactiveRequestRecord, WorkflowCancellation workflowCancellation) {
        MAPLog.d((String)LOG_TAG, (String)"onRequestCancel");
        this.onWorkflowCancel(context, interactiveRequestRecord, workflowCancellation);
    }

    public final void onRequestCompletion(Context context, InteractiveRequestRecord interactiveRequestRecord, Uri uri) {
        WorkflowResponse workflowResponse = new WorkflowResponse(uri);
        if (workflowResponse.isError()) {
            String string = LOG_TAG;
            StringBuilder stringBuilder = a.F1((String)"onRequestCompletion failure: ");
            stringBuilder.append(workflowResponse.getError().getMessage());
            MAPLog.d((String)string, (String)stringBuilder.toString());
            this.onWorkflowError(context, interactiveRequestRecord, (Exception)((Object)workflowResponse.getError()));
            return;
        }
        String string = LOG_TAG;
        StringBuilder stringBuilder = a.F1((String)"result=");
        stringBuilder.append((Object)workflowResponse.getResultJson());
        MAPLog.pii((String)string, (String)"onRequestCompletion success", (String)stringBuilder.toString());
        this.onWorkflowSuccess(context, interactiveRequestRecord, workflowResponse.getResultJson());
    }

    public final void onRequestError(Context context, InteractiveRequestRecord interactiveRequestRecord, Exception exception) {
        String string = LOG_TAG;
        StringBuilder stringBuilder = a.F1((String)"onRequestError: ");
        stringBuilder.append(exception.getMessage());
        MAPLog.d((String)string, (String)stringBuilder.toString());
        this.onWorkflowError(context, interactiveRequestRecord, exception);
    }

    public abstract void onWorkflowCancel(Context var1, InteractiveRequestRecord var2, WorkflowCancellation var3);

    public abstract void onWorkflowError(Context var1, InteractiveRequestRecord var2, Exception var3);

    public abstract void onWorkflowSuccess(Context var1, InteractiveRequestRecord var2, JSONObject var3);
}

