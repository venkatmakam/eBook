/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  com.amazon.identity.auth.device.AuthError
 *  com.amazon.identity.auth.device.authorization.api.AuthzConstants
 *  com.amazon.identity.auth.device.authorization.api.AuthzConstants$BUNDLE_KEY
 *  com.amazon.identity.auth.device.authorization.api.AuthzConstants$FUTURE_TYPE
 *  com.amazon.identity.auth.device.thread.ThreadUtils
 *  com.amazon.identity.auth.map.device.utils.MAPLog
 *  e.a.a.a.a
 *  java.io.Serializable
 *  java.lang.IllegalStateException
 *  java.lang.InterruptedException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.concurrent.CountDownLatch
 *  java.util.concurrent.ExecutionException
 *  java.util.concurrent.Future
 *  java.util.concurrent.TimeUnit
 *  java.util.concurrent.TimeoutException
 */
package com.amazon.identity.auth.device.thread;

import android.os.Bundle;
import com.amazon.identity.auth.device.AuthError;
import com.amazon.identity.auth.device.authorization.api.AuthorizationListener;
import com.amazon.identity.auth.device.authorization.api.AuthzConstants;
import com.amazon.identity.auth.device.shared.APIListener;
import com.amazon.identity.auth.device.thread.DefaultAuthorizationListener;
import com.amazon.identity.auth.device.thread.ThreadUtils;
import com.amazon.identity.auth.map.device.utils.MAPLog;
import e.a.a.a.a;
import java.io.Serializable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

public class MAPCallbackFuture
implements Future<Bundle>,
APIListener {
    private static final String LOG_TAG = MAPCallbackFuture.class.getName();
    private static final String MAIN_THREAD_ERROR_MSG = "Cannot call get on the main thread, unless you want ANRs";
    public AuthError mError;
    public final CountDownLatch mLatch;
    public final AuthorizationListener mListener;
    public Bundle mSuccessResult;

    public MAPCallbackFuture() {
        this(null);
    }

    public MAPCallbackFuture(AuthorizationListener authorizationListener) {
        if (authorizationListener == null) {
            authorizationListener = new DefaultAuthorizationListener();
        }
        this.mListener = authorizationListener;
        this.mLatch = new CountDownLatch(1);
    }

    private void throwOnMainThread() {
        if (!ThreadUtils.isRunningOnMainThread()) {
            return;
        }
        MAPLog.e((String)LOG_TAG, (String)MAIN_THREAD_ERROR_MSG);
        throw new IllegalStateException(MAIN_THREAD_ERROR_MSG);
    }

    public boolean cancel(boolean bl) {
        return false;
    }

    public Bundle get() throws InterruptedException, ExecutionException {
        this.throwOnMainThread();
        MAPLog.i((String)LOG_TAG, (String)"Running get on Future");
        this.mLatch.await();
        return this.getResultHelper();
    }

    public Bundle get(long l, TimeUnit timeUnit) throws InterruptedException, ExecutionException, TimeoutException {
        this.throwOnMainThread();
        String string = LOG_TAG;
        StringBuilder stringBuilder = a.I1((String)"Running get on Future with timeout=", (long)l, (String)"unit=");
        stringBuilder.append(timeUnit.name());
        MAPLog.i((String)string, (String)stringBuilder.toString());
        this.mLatch.await(l, timeUnit);
        return this.getResultHelper();
    }

    public Bundle getResultHelper() {
        AuthError authError = this.mError;
        if (authError != null) {
            Bundle bundle = AuthError.getErrorBundle((AuthError)authError);
            bundle.putSerializable(AuthzConstants.BUNDLE_KEY.FUTURE.val, (Serializable)AuthzConstants.FUTURE_TYPE.ERROR);
            return bundle;
        }
        return this.mSuccessResult;
    }

    public boolean isCancelled() {
        return false;
    }

    public boolean isDone() {
        return this.mLatch.getCount() == 0L;
    }

    @Override
    public void onError(AuthError authError) {
        this.mError = authError;
        this.mLatch.countDown();
        this.mListener.onError(authError);
    }

    @Override
    public void onSuccess(Bundle bundle) {
        this.mSuccessResult = bundle;
        if (bundle == null) {
            MAPLog.w((String)LOG_TAG, (String)"Null Response");
            this.mSuccessResult = new Bundle();
        }
        this.mSuccessResult.putSerializable(AuthzConstants.BUNDLE_KEY.FUTURE.val, (Serializable)AuthzConstants.FUTURE_TYPE.SUCCESS);
        this.mLatch.countDown();
        this.mListener.onSuccess(bundle);
    }
}

