/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  com.amazon.identity.auth.device.endpoint.PandaResponse
 *  com.amazon.identity.auth.map.device.utils.MAPLog
 *  e.a.a.a.a
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.List
 *  org.apache.http.HttpResponse
 *  org.apache.http.message.BasicNameValuePair
 */
package com.amazon.identity.auth.device.endpoint;

import android.content.Context;
import com.amazon.identity.auth.device.dataobject.AppInfo;
import com.amazon.identity.auth.device.endpoint.AbstractJsonPandaRequest;
import com.amazon.identity.auth.device.endpoint.LogoutResponse;
import com.amazon.identity.auth.device.endpoint.PandaResponse;
import com.amazon.identity.auth.map.device.utils.MAPLog;
import e.a.a.a.a;
import java.util.ArrayList;
import java.util.List;
import org.apache.http.HttpResponse;
import org.apache.http.message.BasicNameValuePair;

public class LogoutRequest
extends AbstractJsonPandaRequest<LogoutResponse> {
    private static final String BEARER = "bearer";
    private static final String LOGOUT_ENDPOINT = "/auth/relyingPartyLogout";
    private static final String LOG_TAG = "com.amazon.identity.auth.device.endpoint.LogoutRequest";
    private static final String TOKEN = "token";
    private static final String TOKEN_TYPE = "token_type";
    private String authzToken;

    public LogoutRequest(Context context, AppInfo appInfo, String string) {
        super(context, appInfo);
        this.authzToken = string;
    }

    public LogoutResponse generateResponse(HttpResponse httpResponse) {
        return new LogoutResponse(httpResponse);
    }

    public String getEndPoint() {
        return LOGOUT_ENDPOINT;
    }

    public List<BasicNameValuePair> getExtraParameters() {
        ArrayList arrayList = new ArrayList();
        arrayList.add((Object)new BasicNameValuePair(TOKEN_TYPE, BEARER));
        arrayList.add((Object)new BasicNameValuePair(TOKEN, this.authzToken));
        return arrayList;
    }

    public void logRequest() {
        String string = LOG_TAG;
        StringBuilder stringBuilder = a.F1((String)"accessToken=");
        stringBuilder.append(this.authzToken);
        MAPLog.pii((String)string, (String)"Executing logout request", (String)stringBuilder.toString());
    }
}

