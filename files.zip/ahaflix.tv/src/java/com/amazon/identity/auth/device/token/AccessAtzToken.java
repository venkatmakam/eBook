/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.amazon.identity.auth.device.dataobject.AuthorizationToken$AUTHZ_TOKEN_TYPE
 *  java.lang.String
 *  java.util.Date
 */
package com.amazon.identity.auth.device.token;

import com.amazon.identity.auth.device.dataobject.AuthorizationToken;
import java.util.Date;

public class AccessAtzToken
extends AuthorizationToken {
    public AccessAtzToken() {
        this.mType = AuthorizationToken.AUTHZ_TOKEN_TYPE.ACCESS;
    }

    private AccessAtzToken(long l, String string, String string2, String string3, Date date, Date date2, byte[] arrby) {
        super(string, string2, string3, date, date2, arrby, AuthorizationToken.AUTHZ_TOKEN_TYPE.ACCESS);
        this.setId(l);
    }

    public AccessAtzToken(AccessAtzToken accessAtzToken) {
        this(accessAtzToken.getId(), accessAtzToken.getAppFamilyId(), accessAtzToken.getDirectedId(), accessAtzToken.getTokenValue(), new Date(accessAtzToken.getCreationTime().getTime()), new Date(accessAtzToken.getExpirationTime().getTime()), accessAtzToken.getMiscData());
    }

    public AccessAtzToken(String string, String string2, String string3, long l, byte[] arrby) {
        this(string, string2, string3, new Date(), l, arrby);
    }

    public AccessAtzToken(String string, String string2, String string3, Date date, long l, byte[] arrby) {
        this(string, string2, string3, date, new Date(l + date.getTime()), arrby);
    }

    public AccessAtzToken(String string, String string2, String string3, Date date, Date date2, byte[] arrby) {
        super(string, string2, string3, date, date2, arrby, AuthorizationToken.AUTHZ_TOKEN_TYPE.ACCESS);
    }
}

