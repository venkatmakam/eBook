/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  com.amazon.identity.auth.device.AuthError
 *  com.amazon.identity.auth.map.device.utils.MAPLog
 *  java.lang.Object
 *  java.lang.String
 */
package com.amazon.identity.auth.device.thread;

import android.os.Bundle;
import com.amazon.identity.auth.device.AuthError;
import com.amazon.identity.auth.device.authorization.api.AuthorizationListener;
import com.amazon.identity.auth.map.device.utils.MAPLog;

public class DefaultAuthorizationListener
implements AuthorizationListener {
    private static final String LOG_TAG = "com.amazon.identity.auth.device.thread.DefaultAuthorizationListener";

    @Override
    public void onCancel(Bundle bundle) {
        MAPLog.i((String)LOG_TAG, (String)"onCancel");
    }

    @Override
    public void onError(AuthError authError) {
        MAPLog.i((String)LOG_TAG, (String)"onError");
    }

    @Override
    public void onSuccess(Bundle bundle) {
        MAPLog.i((String)LOG_TAG, (String)"onSuccess");
    }
}

