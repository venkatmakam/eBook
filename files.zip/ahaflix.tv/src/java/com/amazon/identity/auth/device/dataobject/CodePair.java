/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ContentValues
 *  android.content.Context
 *  android.text.TextUtils
 *  com.amazon.identity.auth.device.dataobject.AbstractDataObject
 *  com.amazon.identity.auth.device.dataobject.CodePair$COL_INDEX
 *  com.amazon.identity.auth.device.datastore.AbstractDataSource
 *  com.amazon.identity.auth.device.datastore.DatabaseHelper
 *  com.amazon.identity.auth.device.utils.ScopeUtils
 *  java.lang.CharSequence
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.net.URI
 *  java.text.SimpleDateFormat
 *  java.util.Date
 */
package com.amazon.identity.auth.device.dataobject;

import android.content.ContentValues;
import android.content.Context;
import android.text.TextUtils;
import com.amazon.identity.auth.device.dataobject.AbstractDataObject;
import com.amazon.identity.auth.device.dataobject.CodePair;
import com.amazon.identity.auth.device.datastore.AbstractDataSource;
import com.amazon.identity.auth.device.datastore.CodePairDataSource;
import com.amazon.identity.auth.device.datastore.DatabaseHelper;
import com.amazon.identity.auth.device.utils.ScopeUtils;
import java.net.URI;
import java.text.SimpleDateFormat;
import java.util.Date;

public class CodePair
extends AbstractDataObject {
    public static final String[] ALL_COLUMNS = new String[]{"Id", "AppId", "UserCode", "DeviceCode", "VerificationUri", "Interval", "CreationTime", "ExpirationTime", "Scopes"};
    private static final String LOG_TAG = "com.amazon.identity.auth.device.dataobject.CodePair";
    private final String mAppId;
    private final Date mCreationTime;
    private final String mDeviceCode;
    private final Date mExpirationTime;
    private final int mInterval;
    private final String[] mScopes;
    private final String mUserCode;
    private final URI mVerificationUri;

    public CodePair(String string, String string2, String string3, URI uRI, int n, Date date, Date date2, String[] arrstring) {
        this.mAppId = string;
        this.mUserCode = string2;
        this.mDeviceCode = string3;
        this.mVerificationUri = uRI;
        this.mInterval = n;
        this.mCreationTime = DatabaseHelper.truncateFractionalSeconds((Date)date);
        this.mExpirationTime = DatabaseHelper.truncateFractionalSeconds((Date)date2);
        this.mScopes = arrstring;
    }

    public boolean equals(Object object) {
        boolean bl = false;
        if (object != null) {
            boolean bl2 = object instanceof CodePair;
            bl = false;
            if (bl2) {
                CodePair codePair = (CodePair)((Object)object);
                boolean bl3 = TextUtils.equals((CharSequence)this.mAppId, (CharSequence)codePair.getAppId());
                bl = false;
                if (bl3) {
                    boolean bl4 = TextUtils.equals((CharSequence)this.mUserCode, (CharSequence)codePair.getUserCode());
                    bl = false;
                    if (bl4) {
                        boolean bl5 = TextUtils.equals((CharSequence)this.mDeviceCode, (CharSequence)codePair.getDeviceCode());
                        bl = false;
                        if (bl5) {
                            boolean bl6 = this.areObjectsEqual((Object)this.mVerificationUri, (Object)codePair.getVerificationUri());
                            bl = false;
                            if (bl6) {
                                boolean bl7 = this.areObjectsEqual((Object)this.mInterval, (Object)codePair.getInterval());
                                bl = false;
                                if (bl7) {
                                    boolean bl8 = this.areObjectsEqual((Object)this.mCreationTime, (Object)codePair.getCreationTime());
                                    bl = false;
                                    if (bl8) {
                                        boolean bl9 = this.areObjectsEqual((Object)this.mExpirationTime, (Object)codePair.getExpirationTime());
                                        bl = false;
                                        if (bl9) {
                                            boolean bl10 = this.areObjectsEqual((Object)this.mScopes, (Object)codePair.getScopes());
                                            bl = false;
                                            if (bl10) {
                                                bl = true;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return bl;
    }

    public String getAppId() {
        return this.mAppId;
    }

    public Date getCreationTime() {
        return this.mCreationTime;
    }

    public CodePairDataSource getDataSource(Context context) {
        return CodePairDataSource.getInstance(context);
    }

    public String getDeviceCode() {
        return this.mDeviceCode;
    }

    public Date getExpirationTime() {
        return this.mExpirationTime;
    }

    public int getInterval() {
        return this.mInterval;
    }

    public String[] getScopes() {
        return this.mScopes;
    }

    public String getUserCode() {
        return this.mUserCode;
    }

    public ContentValues getValuesForInsert() {
        ContentValues contentValues = new ContentValues();
        SimpleDateFormat simpleDateFormat = DatabaseHelper.getDateFormat();
        String[] arrstring = ALL_COLUMNS;
        contentValues.put(arrstring[COL_INDEX.APP_ID.colId], this.mAppId);
        contentValues.put(arrstring[COL_INDEX.USER_CODE.colId], this.mUserCode);
        contentValues.put(arrstring[COL_INDEX.DEVICE_CODE.colId], this.mDeviceCode);
        contentValues.put(arrstring[COL_INDEX.VERIFICATION_URI.colId], this.mVerificationUri.toString());
        contentValues.put(arrstring[COL_INDEX.INTERVAL.colId], Integer.valueOf((int)this.mInterval));
        contentValues.put(arrstring[COL_INDEX.CREATION_TIME.colId], simpleDateFormat.format(this.mCreationTime));
        contentValues.put(arrstring[COL_INDEX.EXPIRATION_TIME.colId], simpleDateFormat.format(this.mExpirationTime));
        String string = ScopeUtils.convertScopeArrayToString((String[])this.mScopes);
        contentValues.put(arrstring[COL_INDEX.SCOPES.colId], string);
        return contentValues;
    }

    public URI getVerificationUri() {
        return this.mVerificationUri;
    }
}

