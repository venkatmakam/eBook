/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.text.TextUtils
 *  com.amazon.identity.auth.device.AuthError
 *  com.amazon.identity.auth.device.AuthError$ERROR_TYPE
 *  com.amazon.identity.auth.device.endpoint.PandaResponse
 *  com.amazon.identity.auth.map.device.utils.MAPLog
 *  e.a.a.a.a
 *  java.io.ByteArrayOutputStream
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.IllegalArgumentException
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.zip.GZIPInputStream
 *  org.apache.http.Header
 *  org.apache.http.HeaderElement
 *  org.apache.http.HttpEntity
 *  org.apache.http.HttpResponse
 *  org.apache.http.ParseException
 *  org.apache.http.StatusLine
 *  org.apache.http.util.EntityUtils
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.amazon.identity.auth.device.endpoint;

import android.text.TextUtils;
import com.amazon.identity.auth.device.AuthError;
import com.amazon.identity.auth.device.InvalidTokenAuthError;
import com.amazon.identity.auth.device.endpoint.PandaResponse;
import com.amazon.identity.auth.map.device.utils.MAPLog;
import e.a.a.a.a;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.zip.GZIPInputStream;
import org.apache.http.Header;
import org.apache.http.HeaderElement;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.ParseException;
import org.apache.http.StatusLine;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;

public abstract class AbstractJSONTokenResponse
implements PandaResponse {
    public static final String ACCESS_TOKEN = "access_token";
    public static final String COOKIE = "cookie";
    private static final String DEFAULT_CHAR_SET = "UTF-8";
    public static final String EXPIRES_IN = "expires_in";
    public static final String FORCE_UPDATE = "force_update";
    private static final String FORCE_UPDATE_REQUESTED = "1";
    private static final String INVALID_SOURCE_TOKEN = "InvalidSourceToken";
    private static final String INVALID_TOKEN = "INVALID_TOKEN";
    private static final String INVALID_TOKEN_CODE = "InvalidToken";
    private static final String JSON_CODE_FIELD = "code";
    public static final String JSON_ERROR_FIELD = "error";
    private static final String JSON_MESSAGE_FIELD = "message";
    private static final String LOG_TAG = "com.amazon.identity.auth.device.endpoint.AbstractJSONTokenResponse";
    public static final String REFRESH_TOKEN = "refresh_token";
    public static final String REQUEST_ID = "request_id";
    public static final String RESPONSE = "response";
    private static final String SERVER_ERROR = "ServerError";
    private static final String SERVER_ERROR_PAGE_IDENTIFIER = "!DOCTYPE html";
    public static final String TOKEN = "token";
    public static final String TOKEN_EXPIRES_IN = "token_expires_in";
    public static final String TOKEN_TYPE = "token_type";
    public static final String VER_UNKOWN = "Unkown";
    private final HttpResponse _response;
    private String _sEntity;

    public AbstractJSONTokenResponse(HttpResponse httpResponse) {
        this._response = httpResponse;
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private String getEntityString(HttpEntity httpEntity) throws IOException {
        InputStream inputStream;
        void var2_10;
        block9 : {
            block8 : {
                String string;
                inputStream = httpEntity.getContent();
                try {
                    int n;
                    if (this.isGZIPEncoded(httpEntity)) {
                        inputStream = new GZIPInputStream(inputStream);
                    }
                    if (httpEntity.getContentLength() > Integer.MAX_VALUE) break block8;
                    String string2 = EntityUtils.getContentCharSet((HttpEntity)httpEntity);
                    if (string2 == null) {
                        string2 = DEFAULT_CHAR_SET;
                    }
                    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                    byte[] arrby = new byte[1024];
                    while ((n = inputStream.read(arrby)) != -1) {
                        byteArrayOutputStream.write(arrby, 0, n);
                    }
                    string = new String(byteArrayOutputStream.toByteArray(), string2);
                }
                catch (Throwable throwable) {}
                inputStream.close();
                return string;
            }
            throw new IllegalArgumentException("HTTP entity too large to be buffered in memory");
            break block9;
            catch (Throwable throwable) {
                inputStream = null;
            }
        }
        if (inputStream == null) throw var2_10;
        inputStream.close();
        throw var2_10;
    }

    public static boolean hasReceived500Error(HttpResponse httpResponse) {
        int n = httpResponse.getStatusLine().getStatusCode();
        return n >= 500 && n <= 599;
    }

    private boolean isGZIPEncoded(HttpEntity httpEntity) {
        Header header = httpEntity.getContentEncoding();
        if (header != null) {
            HeaderElement[] arrheaderElement = header.getElements();
            for (int j = 0; j < arrheaderElement.length; ++j) {
                if (!arrheaderElement[j].getName().equalsIgnoreCase("gzip")) continue;
                return true;
            }
        }
        return false;
    }

    public abstract void doParse(JSONObject var1) throws IOException, JSONException, AuthError;

    public JSONObject extractResponseJSONObject(JSONObject jSONObject) throws JSONException {
        return jSONObject.getJSONObject("response");
    }

    public String getEntity() {
        return this._sEntity;
    }

    public long getExpiresIn(JSONObject jSONObject) {
        long l;
        block4 : {
            try {
                if (jSONObject.has("token_expires_in")) {
                    l = jSONObject.getLong("token_expires_in");
                    break block4;
                }
                if (jSONObject.has("expires_in")) {
                    l = jSONObject.getLong("expires_in");
                    break block4;
                }
                MAPLog.w((String)LOG_TAG, (String)"Unable to find expiration time in JSON response, AccessToken will not expire locally");
                return 0L;
            }
            catch (JSONException jSONException) {
                MAPLog.e((String)LOG_TAG, (String)"Unable to parse expiration time in JSON response, AccessToken will not expire locally");
                return 0L;
            }
        }
        return l;
    }

    public JSONObject getJSONResponse() throws IOException, JSONException {
        this._sEntity = this.getEntityString(this._response.getEntity()).trim();
        String string = LOG_TAG;
        StringBuilder stringBuilder = a.F1((String)"entity=");
        stringBuilder.append(this._sEntity);
        MAPLog.pii((String)string, (String)"Entity Extracted", (String)stringBuilder.toString());
        JSONObject jSONObject = new JSONObject(this._sEntity);
        JSONObject jSONObject2 = this.extractResponseJSONObject(jSONObject);
        this.logRequestId(jSONObject);
        return jSONObject2;
    }

    public HttpResponse getResponse() {
        return this._response;
    }

    public int getStatusCode() throws AuthError {
        try {
            int n = this._response.getStatusLine().getStatusCode();
            return n;
        }
        catch (NullPointerException nullPointerException) {
            throw new AuthError("StatusLine is null", (Throwable)nullPointerException, AuthError.ERROR_TYPE.ERROR_COM);
        }
    }

    public String getVersion() {
        return "3.5.4";
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public void handleForceUpdate(JSONObject jSONObject) throws AuthError {
        JSONException jSONException;
        String string;
        block10 : {
            ParseException parseException;
            block9 : {
                string = null;
                String string2 = jSONObject.getString("force_update");
                if (string2 == null) return;
                try {
                    if (!string2.equals((Object)"1")) {
                        return;
                    }
                    String string3 = this.getVersion();
                    String string4 = LOG_TAG;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Force update requested ver:");
                    stringBuilder.append(string3);
                    MAPLog.e((String)string4, (String)stringBuilder.toString());
                    StringBuilder stringBuilder2 = new StringBuilder();
                    stringBuilder2.append("Server denied request, requested Force Update ver:");
                    stringBuilder2.append(string3);
                    throw new AuthError(stringBuilder2.toString(), null, AuthError.ERROR_TYPE.ERROR_FORCE_UPDATE);
                }
                catch (ParseException parseException2) {
                    string = string2;
                    parseException = parseException2;
                    break block9;
                }
                catch (JSONException jSONException2) {
                    string = string2;
                    jSONException = jSONException2;
                    break block10;
                }
                catch (ParseException parseException3) {
                    // empty catch block
                }
            }
            if (TextUtils.isEmpty(string)) {
                return;
            }
            String string5 = LOG_TAG;
            StringBuilder stringBuilder = a.F1((String)"JSON parsing exception force update parsing response:");
            stringBuilder.append(parseException.toString());
            MAPLog.e((String)string5, (String)stringBuilder.toString());
            throw new AuthError(parseException.getMessage(), (Throwable)parseException, AuthError.ERROR_TYPE.ERROR_PARSE);
            catch (JSONException jSONException3) {
                // empty catch block
            }
        }
        if (TextUtils.isEmpty(string)) {
            return;
        }
        string = LOG_TAG;
        StringBuilder stringBuilder = a.F1((String)"JSON exception parsing force update response:");
        stringBuilder.append(jSONException.toString());
        MAPLog.e((String)string, (String)stringBuilder.toString());
        throw new AuthError(jSONException.getMessage(), (Throwable)jSONException, AuthError.ERROR_TYPE.ERROR_JSON);
    }

    public void handleJSONError(JSONObject jSONObject) throws AuthError, JSONException {
        JSONObject jSONObject2 = null;
        try {
            jSONObject2 = jSONObject.getJSONObject("error");
            String string = jSONObject2.getString("code");
            if ("ServerError".equalsIgnoreCase(string)) {
                if (!jSONObject2.getString("message").startsWith("INVALID_TOKEN")) {
                    this.throwUnknownAuthError(string);
                    return;
                }
                throw new InvalidTokenAuthError("Invalid Exchange parameter - SERVER_ERROR.");
            }
            if (!"InvalidSourceToken".equalsIgnoreCase(string)) {
                if (!"InvalidToken".equals((Object)string)) {
                    if (AbstractJSONTokenResponse.hasReceived500Error(this._response)) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("500 error (status=");
                        stringBuilder.append(this.getStatusCode());
                        stringBuilder.append(")");
                        stringBuilder.append(string);
                        this.throwUnknownAuthError(stringBuilder.toString());
                        return;
                    }
                    this.throwUnknownAuthError(string);
                    return;
                }
                throw new InvalidTokenAuthError("Token used is invalid.");
            }
            throw new InvalidTokenAuthError("Invalid Source Token in exchange parameter");
        }
        catch (ParseException parseException) {
            if (jSONObject2 == null) {
                return;
            }
            throw new AuthError("Exception parsing response", (Throwable)parseException, AuthError.ERROR_TYPE.ERROR_PARSE);
        }
        catch (JSONException jSONException) {
            if (jSONObject2 == null) {
                return;
            }
            throw new AuthError("JSON exception parsing json error response:", (Throwable)jSONException, AuthError.ERROR_TYPE.ERROR_JSON);
        }
    }

    public void logRequestId(JSONObject jSONObject) {
        try {
            String string = jSONObject.getString("request_id");
            String string2 = LOG_TAG;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("requestId=");
            stringBuilder.append(string);
            MAPLog.pii((String)string2, (String)"ExchangeRepsonse", (String)stringBuilder.toString());
            return;
        }
        catch (JSONException jSONException) {
            MAPLog.w((String)LOG_TAG, (String)"No RequestId in JSON response");
            return;
        }
    }

    /*
     * Exception decompiling
     */
    public void parse() throws AuthError {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [7[CATCHBLOCK]], but top level block is 2[TRYBLOCK]
        // org.benf.cfr.reader.b.a.a.j.a(Op04StructuredStatement.java:432)
        // org.benf.cfr.reader.b.a.a.j.d(Op04StructuredStatement.java:484)
        // org.benf.cfr.reader.b.a.a.i.a(Op03SimpleStatement.java:607)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:692)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    public void throwUnknownAuthError(String string) throws AuthError {
        Object[] arrobject = new Object[]{string, this._sEntity};
        throw new AuthError(a.h1((String)"Server Error : ", (String)String.format((String)"Error code: %s Server response: %s", (Object[])arrobject)), AuthError.ERROR_TYPE.ERROR_SERVER_REPSONSE);
    }
}

