/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.net.Uri
 *  android.os.Bundle
 *  com.amazon.identity.auth.device.AuthError
 *  com.amazon.identity.auth.device.AuthError$ERROR_TYPE
 *  com.amazon.identity.auth.device.api.Listener
 *  com.amazon.identity.auth.device.api.authorization.AuthCancellation
 *  com.amazon.identity.auth.device.api.authorization.AuthorizeResult
 *  com.amazon.identity.auth.device.api.authorization.User
 *  com.amazon.identity.auth.device.authorization.AuthorizationResponseProcessor
 *  com.amazon.identity.auth.device.authorization.api.AuthzConstants
 *  com.amazon.identity.auth.device.authorization.api.AuthzConstants$BUNDLE_KEY
 *  com.amazon.identity.auth.device.interactive.InteractiveRequestRecord
 *  com.amazon.identity.auth.device.workflow.WorkflowCancellation
 *  com.amazon.identity.auth.map.device.utils.MAPLog
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 */
package com.amazon.identity.auth.device.api.authorization;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import com.amazon.identity.auth.device.AuthError;
import com.amazon.identity.auth.device.api.Listener;
import com.amazon.identity.auth.device.api.authorization.AuthCancellation;
import com.amazon.identity.auth.device.api.authorization.AuthorizeResult;
import com.amazon.identity.auth.device.api.authorization.User;
import com.amazon.identity.auth.device.authorization.AuthorizationResponseProcessor;
import com.amazon.identity.auth.device.authorization.api.AuthorizationListener;
import com.amazon.identity.auth.device.authorization.api.AuthzConstants;
import com.amazon.identity.auth.device.interactive.InteractiveListener;
import com.amazon.identity.auth.device.interactive.InteractiveRequestRecord;
import com.amazon.identity.auth.device.workflow.WorkflowCancellation;
import com.amazon.identity.auth.map.device.utils.MAPLog;

public abstract class AuthorizeListener
implements InteractiveListener<AuthorizeResult, AuthCancellation, AuthError> {
    private static final String LOG_TAG = "com.amazon.identity.auth.device.api.authorization.AuthorizeListener";

    public static void onAuthFetchingUserData(Context context, final Bundle bundle, final InteractiveListener<AuthorizeResult, AuthCancellation, AuthError> interactiveListener) {
        MAPLog.i((String)LOG_TAG, (String)"Fetching User as part of authorize request");
        User.fetch((Context)context, (Listener)new Listener<User, AuthError>(){

            public void onError(AuthError authError) {
                interactiveListener.onError(authError);
            }

            public void onSuccess(User user) {
                interactiveListener.onSuccess(new AuthorizeResult(bundle, user));
            }
        });
    }

    public static void onAuthorizationSuccess(Context context, Bundle bundle, InteractiveListener<AuthorizeResult, AuthCancellation, AuthError> interactiveListener, boolean bl) {
        if (bundle.getString(AuthzConstants.BUNDLE_KEY.AUTHORIZATION_CODE.val) == null && bl) {
            AuthorizeListener.onAuthFetchingUserData(context, bundle, interactiveListener);
            return;
        }
        interactiveListener.onSuccess(new AuthorizeResult(bundle));
    }

    public final String getRequestType() {
        return "com.amazon.identity.auth.device.authorization.request.authorize";
    }

    @Override
    public abstract void onCancel(AuthCancellation var1);

    @Override
    public abstract void onError(AuthError var1);

    public final void onRequestCancel(Context context, InteractiveRequestRecord interactiveRequestRecord, WorkflowCancellation workflowCancellation) {
        MAPLog.e((String)LOG_TAG, (String)"Unexpected invocation of onRequestCancel");
    }

    public final void onRequestCompletion(final Context context, InteractiveRequestRecord interactiveRequestRecord, Uri uri) {
        Bundle bundle = interactiveRequestRecord.getRequestExtras();
        AuthorizationResponseProcessor.handleResponse((Context)context, (Uri)uri, (String[])bundle.getStringArray("requestedScopes"), (boolean)true, (AuthorizationListener)new AuthorizationListener(bundle.getBoolean("shouldReturnUserData")){
            public final /* synthetic */ boolean val$shouldReturnUserData;
            {
                this.val$shouldReturnUserData = bl;
            }

            @Override
            public void onCancel(Bundle bundle) {
                AuthorizeListener.this.onCancel(new AuthCancellation(bundle));
            }

            @Override
            public void onError(AuthError authError) {
                AuthorizeListener.this.onError(authError);
            }

            @Override
            public void onSuccess(Bundle bundle) {
                AuthorizeListener.onAuthorizationSuccess(context, bundle, AuthorizeListener.this, this.val$shouldReturnUserData);
            }
        });
    }

    public final void onRequestError(Context context, InteractiveRequestRecord interactiveRequestRecord, Exception exception) {
        if (exception instanceof AuthError) {
            this.onError((AuthError)exception);
            return;
        }
        this.onError(new AuthError("Could not complete the authorization request", (Throwable)exception, AuthError.ERROR_TYPE.ERROR_UNKNOWN));
    }

    @Override
    public abstract void onSuccess(AuthorizeResult var1);

}

