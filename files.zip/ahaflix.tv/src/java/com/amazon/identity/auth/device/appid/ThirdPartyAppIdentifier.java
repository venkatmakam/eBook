/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  com.amazon.identity.auth.device.appid.APIKeyDecoder
 *  com.amazon.identity.auth.map.device.utils.MAPLog
 *  e.a.a.a.a
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.amazon.identity.auth.device.appid;

import android.content.Context;
import com.amazon.identity.auth.device.appid.APIKeyDecoder;
import com.amazon.identity.auth.device.appid.AbstractAppIdentifier;
import com.amazon.identity.auth.device.dataobject.AppInfo;
import com.amazon.identity.auth.map.device.utils.MAPLog;
import e.a.a.a.a;

public final class ThirdPartyAppIdentifier
extends AbstractAppIdentifier {
    private static final String LOG_TAG = "com.amazon.identity.auth.device.appid.ThirdPartyAppIdentifier";
    private static final String REDIRECT_URI_PREFIX = "amzn://";

    public String[] getAllowedScopes(String string, Context context) {
        String string2 = LOG_TAG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("getAllowedScopes : packageName=");
        stringBuilder.append(string);
        MAPLog.i((String)string2, (String)stringBuilder.toString());
        if (string == null) {
            MAPLog.w((String)string2, (String)"packageName can't be null!");
            return null;
        }
        AppInfo appInfo = this.getAppInfo(string, context);
        if (appInfo == null) {
            return null;
        }
        return appInfo.getAllowedScopes();
    }

    @Override
    public String getAppFamilyId(String string, Context context) {
        String string2 = LOG_TAG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("getAppFamilyId : packageName=");
        stringBuilder.append(string);
        MAPLog.i((String)string2, (String)stringBuilder.toString());
        if (string == null) {
            MAPLog.w((String)string2, (String)"packageName can't be null!");
            return null;
        }
        AppInfo appInfo = this.getAppInfo(string, context);
        if (appInfo == null) {
            return null;
        }
        return appInfo.getAppFamilyId();
    }

    public AppInfo getAppInfoByApiKey(String string, String string2, Context context) {
        String string3 = LOG_TAG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("getAppInfo : packageName=");
        stringBuilder.append(string);
        MAPLog.i((String)string3, (String)stringBuilder.toString());
        if (string == null) {
            MAPLog.w((String)string3, (String)"packageName can't be null!");
            return null;
        }
        return APIKeyDecoder.doDecode((String)string, (String)string2, (boolean)false, (Context)context);
    }

    public String[] getAppPermissions(String string, Context context) {
        String string2 = LOG_TAG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("getAppPermissions : packageName=");
        stringBuilder.append(string);
        MAPLog.i((String)string2, (String)stringBuilder.toString());
        if (string == null) {
            MAPLog.w((String)string2, (String)"packageName can't be null!");
            return null;
        }
        AppInfo appInfo = this.getAppInfo(string, context);
        if (appInfo == null) {
            return null;
        }
        return appInfo.getGrantedPermissions();
    }

    @Override
    public String getAppVariantId(String string, Context context) {
        String string2 = LOG_TAG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("getAppVariantId : packageName=");
        stringBuilder.append(string);
        MAPLog.i((String)string2, (String)stringBuilder.toString());
        if (string == null) {
            MAPLog.w((String)string2, (String)"packageName can't be null!");
            return null;
        }
        AppInfo appInfo = this.getAppInfo(string, context);
        if (appInfo == null) {
            return null;
        }
        return appInfo.getAppVariantId();
    }

    @Override
    public String getPackageName(String string, Context context) {
        return null;
    }

    @Override
    public String getPackageNameByVariant(String string, Context context) {
        return null;
    }

    @Override
    public String[] getPackageNames(String string, Context context) {
        return null;
    }

    public String getRedirectUrl(Context context) {
        StringBuilder stringBuilder = a.F1((String)REDIRECT_URI_PREFIX);
        stringBuilder.append(context.getPackageName());
        return stringBuilder.toString();
    }

    public boolean isAPIKeyValidFormat(String string, String string2, Context context) {
        String string3 = LOG_TAG;
        String string4 = a.h1((String)"isAPIKeyValid : packageName=", (String)string);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("apiKey=");
        stringBuilder.append(string2);
        MAPLog.pii((String)string3, (String)string4, (String)stringBuilder.toString());
        if (string == null) {
            MAPLog.w((String)string3, (String)"packageName can't be null!");
            return false;
        }
        if (string2 == null) {
            MAPLog.w((String)string3, (String)"apiKey can't be null!");
            return false;
        }
        AppInfo appInfo = APIKeyDecoder.doDecode((String)string, (String)string2, (boolean)false, (Context)context);
        boolean bl = false;
        if (appInfo != null) {
            bl = true;
        }
        return bl;
    }
}

