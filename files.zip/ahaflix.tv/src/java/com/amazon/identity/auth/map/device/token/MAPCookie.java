/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.text.TextUtils
 *  android.text.format.Time
 *  com.amazon.identity.auth.device.AuthError
 *  com.amazon.identity.auth.map.device.token.Token
 *  com.amazon.identity.auth.map.device.utils.MAPLog
 *  e.a.a.a.a
 *  java.io.Serializable
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Throwable
 *  java.text.ParseException
 *  java.text.SimpleDateFormat
 *  java.util.ArrayList
 *  java.util.Calendar
 *  java.util.Date
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Locale
 *  java.util.Map
 *  java.util.StringTokenizer
 *  java.util.TimeZone
 *  org.apache.http.cookie.Cookie
 */
package com.amazon.identity.auth.map.device.token;

import android.content.Context;
import android.text.TextUtils;
import android.text.format.Time;
import com.amazon.identity.auth.device.AuthError;
import com.amazon.identity.auth.map.device.token.Token;
import com.amazon.identity.auth.map.device.utils.MAPLog;
import e.a.a.a.a;
import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.TimeZone;
import org.apache.http.cookie.Cookie;

public class MAPCookie
implements Cookie,
Token,
Serializable {
    private static final String COOKIE_ATTRIBUTE_SEPERATOR = ";";
    public static final String COOKIE_DATE_FORMAT = "dd MMM yyyy kk:mm:ss z";
    private static final String COOKIE_NAME_VALUE_SEPERATOR = "=";
    private static final String DOMAIN_PREFIX = "www";
    private static final String DOT = ".";
    private static final String EMPTY_COOKIE = "";
    private static final String GMT = "GMT";
    public static final String KEY_COMMENT = "Comment";
    public static final String KEY_COMMENT_URL = "CommentUrl";
    public static final String KEY_DIRECTED_ID = "DirectedId";
    public static final String KEY_DOMAIN = "Domain";
    public static final String KEY_EXPIRES = "Expires";
    public static final String KEY_HTTP_ONLY = "HttpOnly";
    public static final String KEY_NAME = "Name";
    public static final String KEY_PATH = "Path";
    public static final String KEY_PERSISTANT = "Persistant";
    public static final String KEY_SECURE = "Secure";
    public static final String KEY_VALUE = "Value";
    public static final String KEY_VERSION = "Version";
    private static final String LOG_TAG = MAPCookie.class.getName();
    public static final int NO_VERSION = -1;
    private static final long serialVersionUID = 551200964665L;
    private final Map<String, String> _cookieData;
    private final transient Time _localCreationTimestamp = new Time();
    private int[] _ports;

    public MAPCookie(String string, String string2, String string3, String string4, boolean bl) {
        HashMap hashMap;
        this._cookieData = hashMap = new HashMap();
        hashMap.put((Object)KEY_NAME, (Object)string);
        hashMap.put((Object)KEY_VALUE, (Object)string2);
        hashMap.put((Object)KEY_DIRECTED_ID, (Object)string4);
        hashMap.put((Object)KEY_DOMAIN, (Object)string3);
        this.setSecure(bl);
        this.logCookie();
    }

    public MAPCookie(Map<String, String> map) throws AuthError {
        this._cookieData = map;
        this.logCookie();
    }

    /*
     * Exception decompiling
     */
    public static void clearCookieInCookieManager(Context var0, Cookie var1, String var2, String var3) throws AuthError {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl13 : INVOKESTATIC : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    public static String[] extractCookieStringArray(List<Cookie> list) {
        if (list != null) {
            ArrayList arrayList = new ArrayList();
            Iterator iterator = list.iterator();
            while (iterator.hasNext()) {
                arrayList.add((Object)MAPCookie.getSetCookieHeader((Cookie)iterator.next()));
            }
            return (String[])arrayList.toArray((Object[])new String[arrayList.size()]);
        }
        return null;
    }

    public static String formatDate(Date date) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(COOKIE_DATE_FORMAT, Locale.US);
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone((String)GMT));
        return simpleDateFormat.format(date);
    }

    private static final String getClearSetCookieHeader(Cookie cookie) {
        Date date;
        StringBuilder stringBuilder = new StringBuilder(cookie.getName().trim());
        stringBuilder.append(COOKIE_NAME_VALUE_SEPERATOR);
        stringBuilder.append(EMPTY_COOKIE);
        stringBuilder.append("; path=/");
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("; domain=");
        stringBuilder2.append(cookie.getDomain().trim());
        stringBuilder.append(stringBuilder2.toString());
        if (cookie.isSecure()) {
            stringBuilder.append("; secure");
        }
        if ((date = cookie.getExpiryDate()) != null) {
            stringBuilder.append("; expires=");
            if (date.before(Calendar.getInstance().getTime())) {
                String string = LOG_TAG;
                StringBuilder stringBuilder3 = a.F1((String)"Cookie ");
                stringBuilder3.append(cookie.getName());
                stringBuilder3.append(" expired : ");
                stringBuilder3.append((Object)date);
                MAPLog.i((String)string, (String)stringBuilder3.toString());
            }
            stringBuilder.append(MAPCookie.formatDate(date));
        }
        return stringBuilder.toString();
    }

    private static Date getCookieExpireDate(String string) throws ParseException {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(COOKIE_DATE_FORMAT, Locale.US);
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone((String)GMT));
        return simpleDateFormat.parse(string);
    }

    public static List<Cookie> getCookiesFromCookieManager(Context context, String string, String string2) throws AuthError {
        String string3 = MAPCookie.getCookiesStringFromCookieManager(context, string);
        String string4 = LOG_TAG;
        String string5 = a.h1((String)"Extracting cookie list for domain=", (String)string);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("directedId=");
        stringBuilder.append(string2);
        MAPLog.pii((String)string4, (String)string5, (String)stringBuilder.toString());
        ArrayList arrayList = new ArrayList();
        if (string3 != null) {
            StringTokenizer stringTokenizer = new StringTokenizer(string3, COOKIE_ATTRIBUTE_SEPERATOR);
            while (stringTokenizer.hasMoreTokens()) {
                StringTokenizer stringTokenizer2 = new StringTokenizer(stringTokenizer.nextToken().trim(), COOKIE_NAME_VALUE_SEPERATOR);
                if (!stringTokenizer2.hasMoreTokens()) continue;
                String string6 = stringTokenizer2.nextToken();
                String string7 = stringTokenizer2.hasMoreTokens() ? stringTokenizer2.nextToken() : EMPTY_COOKIE;
                String string8 = string7;
                MAPCookie mAPCookie = new MAPCookie(string6, string8, string, string2, false);
                arrayList.add((Object)mAPCookie);
            }
        } else {
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append("No cookies in Cookie manager for ");
            stringBuilder2.append(string);
            MAPLog.i((String)string4, (String)stringBuilder2.toString());
        }
        return arrayList;
    }

    /*
     * Exception decompiling
     */
    public static String getCookiesStringFromCookieManager(Context var0, String var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl13 : INVOKESTATIC : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    public static final String getSetCookieHeader(Cookie cookie) {
        Date date;
        StringBuilder stringBuilder = new StringBuilder(cookie.getName().trim());
        stringBuilder.append(COOKIE_NAME_VALUE_SEPERATOR);
        stringBuilder.append(cookie.getValue().trim());
        stringBuilder.append("; path=/");
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("; domain=");
        stringBuilder2.append(cookie.getDomain().trim());
        stringBuilder.append(stringBuilder2.toString());
        if (cookie.isSecure()) {
            stringBuilder.append("; secure");
        }
        if ((date = cookie.getExpiryDate()) != null) {
            stringBuilder.append("; expires=");
            if (date.before(Calendar.getInstance().getTime())) {
                String string = LOG_TAG;
                StringBuilder stringBuilder3 = a.F1((String)"Cookie ");
                stringBuilder3.append(cookie.getName());
                stringBuilder3.append(" expired : ");
                stringBuilder3.append((Object)date);
                MAPLog.i((String)string, (String)stringBuilder3.toString());
            }
            stringBuilder.append(MAPCookie.formatDate(date));
        }
        return stringBuilder.toString();
    }

    private void logCookie() {
        String string = LOG_TAG;
        StringBuilder stringBuilder = a.F1((String)"Creating Cookie from data. name=");
        stringBuilder.append(this.getName());
        String string2 = stringBuilder.toString();
        StringBuilder stringBuilder2 = a.F1((String)"domain:");
        stringBuilder2.append(this.getDomain());
        stringBuilder2.append(" directedId:");
        stringBuilder2.append(this.getDirectedId());
        stringBuilder2.append(" cookie:");
        stringBuilder2.append(this.getValue());
        MAPLog.pii((String)string, (String)string2, (String)stringBuilder2.toString());
    }

    public String getAttribute(String string) {
        return (String)this._cookieData.get((Object)string);
    }

    public String getComment() {
        return this.getAttribute(KEY_COMMENT);
    }

    public String getCommentURL() {
        return this.getAttribute(KEY_COMMENT_URL);
    }

    public Map<String, String> getData() {
        return this._cookieData;
    }

    public String getDirectedId() {
        return this.getAttribute(KEY_DIRECTED_ID);
    }

    public String getDomain() {
        return this.getAttribute(KEY_DOMAIN);
    }

    public Date getExpiryDate() {
        String string = this.getAttribute(KEY_EXPIRES);
        if (string != null) {
            try {
                Date date = MAPCookie.getCookieExpireDate(string);
                return date;
            }
            catch (ParseException parseException) {
                MAPLog.e((String)LOG_TAG, (String)"Date parse error on MAP Cookie", (Throwable)parseException);
            }
        }
        return null;
    }

    public Time getLocalTimestamp() {
        return this._localCreationTimestamp;
    }

    public String getName() {
        return this.getAttribute(KEY_NAME);
    }

    public String getPath() {
        return this.getAttribute(KEY_PATH);
    }

    public int[] getPorts() {
        return this._ports;
    }

    public String getType() {
        return this.getName();
    }

    public String getValue() {
        return this.getAttribute(KEY_VALUE);
    }

    public int getVersion() {
        if (TextUtils.isEmpty((CharSequence)this.getAttribute(KEY_VERSION))) {
            return -1;
        }
        return Integer.parseInt((String)this.getAttribute(KEY_VERSION));
    }

    public boolean hasExpired() {
        return this.isExpired(Calendar.getInstance().getTime());
    }

    public boolean isExpired(Date date) {
        if (this.getExpiryDate() == null) {
            return false;
        }
        if (date == null) {
            date = Calendar.getInstance().getTime();
        }
        return this.getExpiryDate().before(date);
    }

    public boolean isHttpOnly() {
        String string = this.getAttribute(KEY_HTTP_ONLY);
        if (TextUtils.isEmpty((CharSequence)string)) {
            return false;
        }
        return Boolean.parseBoolean((String)string);
    }

    public boolean isPersistent() {
        return Boolean.parseBoolean((String)this.getAttribute(KEY_PERSISTANT));
    }

    public boolean isSecure() {
        return Boolean.parseBoolean((String)this.getAttribute(KEY_SECURE));
    }

    public String setAttribute(String string, String string2) {
        return (String)this._cookieData.put((Object)string, (Object)string2);
    }

    public void setExpiryDate(String string) {
        this.setAttribute(KEY_EXPIRES, string);
    }

    public void setHttpOnly(boolean bl) {
        this._cookieData.put((Object)KEY_HTTP_ONLY, (Object)Boolean.toString((boolean)bl));
    }

    public void setPath(String string) {
        this.setAttribute(KEY_PATH, string);
    }

    public void setPorts(int[] arrn) {
        int[] arrn2 = new int[arrn.length];
        this._ports = arrn2;
        System.arraycopy((Object)arrn, (int)0, (Object)arrn2, (int)0, (int)arrn.length);
    }

    public void setSecure(boolean bl) {
        this.setAttribute(KEY_SECURE, Boolean.toString((boolean)bl));
    }
}

