/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  com.amazon.identity.auth.device.endpoint.AbstractPandaRequest
 *  com.amazon.identity.auth.device.endpoint.PandaResponse
 *  java.io.IOException
 *  java.io.UnsupportedEncodingException
 *  java.lang.String
 *  org.apache.http.client.methods.HttpGet
 *  org.apache.http.client.methods.HttpRequestBase
 */
package com.amazon.identity.auth.device.endpoint;

import android.content.Context;
import com.amazon.identity.auth.device.dataobject.AppInfo;
import com.amazon.identity.auth.device.endpoint.AbstractPandaRequest;
import com.amazon.identity.auth.device.endpoint.PandaResponse;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpRequestBase;

public abstract class AbstractPandaGetRequest<T extends PandaResponse>
extends AbstractPandaRequest<T> {
    public AbstractPandaGetRequest(Context context, AppInfo appInfo) {
        super(context, appInfo);
    }

    public void consumeEntity() throws IOException {
    }

    public HttpRequestBase initializeRequest(String string) {
        return new HttpGet(string);
    }

    public void setEntity() throws UnsupportedEncodingException {
    }
}

