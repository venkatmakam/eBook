/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  androidx.fragment.app.Fragment
 *  androidx.fragment.app.FragmentActivity
 *  androidx.fragment.app.FragmentManager
 *  androidx.fragment.app.FragmentTransaction
 *  com.amazon.identity.auth.device.interactive.InteractiveRequestRecord
 *  com.amazon.identity.auth.device.interactive.InteractiveState
 *  com.amazon.identity.auth.device.interactive.InteractiveStateFragment
 *  com.amazon.identity.auth.device.interactive.RequestSource
 *  com.amazon.identity.auth.map.device.utils.MAPLog
 *  e.a.a.a.a
 *  java.lang.Class
 *  java.lang.ClassCastException
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.lang.ref.WeakReference
 */
package com.amazon.identity.auth.device.interactive;

import android.content.Context;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import com.amazon.identity.auth.device.interactive.InteractiveRequestRecord;
import com.amazon.identity.auth.device.interactive.InteractiveState;
import com.amazon.identity.auth.device.interactive.InteractiveStateFragment;
import com.amazon.identity.auth.device.interactive.RequestSource;
import com.amazon.identity.auth.device.interactive.WorkflowSupportFragment;
import com.amazon.identity.auth.map.device.utils.MAPLog;
import e.a.a.a.a;
import java.lang.ref.WeakReference;

public final class RequestSourceFragmentActivityWrapper
implements RequestSource {
    private static final String LOG_TAG = "com.amazon.identity.auth.device.interactive.RequestSourceFragmentActivityWrapper";
    private final WeakReference<FragmentActivity> activityReference;

    public RequestSourceFragmentActivityWrapper(FragmentActivity fragmentActivity) {
        if (fragmentActivity != null) {
            this.activityReference = new WeakReference((Object)fragmentActivity);
            return;
        }
        throw new IllegalArgumentException("activity must be non-null");
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object == null) {
            return false;
        }
        if (RequestSourceFragmentActivityWrapper.class != object.getClass()) {
            return false;
        }
        RequestSourceFragmentActivityWrapper requestSourceFragmentActivityWrapper = (RequestSourceFragmentActivityWrapper)object;
        WeakReference<FragmentActivity> weakReference = this.activityReference;
        if (weakReference == null) {
            if (requestSourceFragmentActivityWrapper.activityReference != null) {
                return false;
            }
        } else {
            if (requestSourceFragmentActivityWrapper.activityReference == null) {
                return false;
            }
            if (weakReference.get() == null ? requestSourceFragmentActivityWrapper.activityReference.get() != null : !((FragmentActivity)this.activityReference.get()).equals(requestSourceFragmentActivityWrapper.activityReference.get())) {
                return false;
            }
        }
        return true;
    }

    public Object getBackingObject() {
        return this.activityReference.get();
    }

    public Context getContext() {
        return (Context)this.activityReference.get();
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public InteractiveState getInteractiveState() {
        FragmentActivity fragmentActivity = (FragmentActivity)this.activityReference.get();
        if (fragmentActivity != null) {
            InteractiveStateFragment interactiveStateFragment;
            String string;
            FragmentManager fragmentManager = fragmentActivity.getSupportFragmentManager();
            try {
                string = InteractiveStateFragment.TAG_ID;
                interactiveStateFragment = (InteractiveStateFragment)fragmentManager.findFragmentByTag(string);
                if (interactiveStateFragment != null) return interactiveStateFragment.getState();
            }
            catch (ClassCastException classCastException) {
                String string2 = LOG_TAG;
                StringBuilder stringBuilder = a.F1((String)"Found an invalid fragment looking for fragment with tag ");
                stringBuilder.append(InteractiveStateFragment.TAG_ID);
                stringBuilder.append(". Please use a different fragment tag.");
                MAPLog.e((String)string2, (String)stringBuilder.toString(), (Throwable)classCastException);
                return null;
            }
            interactiveStateFragment = new WorkflowSupportFragment();
            fragmentManager.beginTransaction().add((Fragment)interactiveStateFragment, string).commit();
            return interactiveStateFragment.getState();
        } else {
            MAPLog.e((String)LOG_TAG, (String)"Failed to get InteractiveState on a garbage-collected FragmentActivity");
        }
        return null;
    }

    public int hashCode() {
        WeakReference<FragmentActivity> weakReference = this.activityReference;
        int n = weakReference != null && weakReference.get() != null ? ((FragmentActivity)this.activityReference.get()).hashCode() : 0;
        return 31 + n;
    }

    public boolean isHookNeededOnUIResume() {
        return true;
    }

    public void onStartRequest(InteractiveRequestRecord interactiveRequestRecord) {
        InteractiveState interactiveState = this.getInteractiveState();
        if (interactiveState != null) {
            interactiveState.onRequestStart(interactiveRequestRecord);
        }
    }
}

