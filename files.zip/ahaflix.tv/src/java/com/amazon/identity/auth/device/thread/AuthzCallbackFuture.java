/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  com.amazon.identity.auth.device.AuthError
 *  com.amazon.identity.auth.device.authorization.api.AuthzConstants
 *  com.amazon.identity.auth.device.authorization.api.AuthzConstants$BUNDLE_KEY
 *  com.amazon.identity.auth.device.authorization.api.AuthzConstants$FUTURE_TYPE
 *  com.amazon.identity.auth.map.device.utils.MAPLog
 *  java.io.Serializable
 *  java.lang.Object
 *  java.lang.String
 *  java.util.concurrent.CountDownLatch
 */
package com.amazon.identity.auth.device.thread;

import android.os.Bundle;
import com.amazon.identity.auth.device.AuthError;
import com.amazon.identity.auth.device.authorization.api.AuthorizationListener;
import com.amazon.identity.auth.device.authorization.api.AuthzConstants;
import com.amazon.identity.auth.device.shared.APIListener;
import com.amazon.identity.auth.device.thread.MAPCallbackFuture;
import com.amazon.identity.auth.map.device.utils.MAPLog;
import java.io.Serializable;
import java.util.concurrent.CountDownLatch;

public class AuthzCallbackFuture
extends MAPCallbackFuture
implements AuthorizationListener {
    private static final String LOG_TAG = AuthzCallbackFuture.class.getName();
    private Bundle mCancelResult;

    public AuthzCallbackFuture() {
        this(null);
    }

    public AuthzCallbackFuture(AuthorizationListener authorizationListener) {
        super(authorizationListener);
    }

    public AuthzCallbackFuture(APIListener aPIListener) {
        super(new AuthorizationListener(){

            @Override
            public void onCancel(Bundle bundle) {
                MAPLog.w((String)LOG_TAG, (String)"onCancel called in for APIListener");
            }

            @Override
            public void onError(AuthError authError) {
                APIListener aPIListener = APIListener.this;
                if (aPIListener != null) {
                    aPIListener.onError(authError);
                }
            }

            @Override
            public void onSuccess(Bundle bundle) {
                APIListener aPIListener = APIListener.this;
                if (aPIListener != null) {
                    aPIListener.onSuccess(bundle);
                }
            }
        });
    }

    @Override
    public Bundle getResultHelper() {
        Bundle bundle = this.mCancelResult;
        if (bundle != null) {
            return bundle;
        }
        return super.getResultHelper();
    }

    @Override
    public void onCancel(Bundle bundle) {
        this.mCancelResult = bundle;
        bundle.putSerializable(AuthzConstants.BUNDLE_KEY.FUTURE.val, (Serializable)AuthzConstants.FUTURE_TYPE.CANCEL);
        this.mLatch.countDown();
        this.mListener.onCancel(this.mCancelResult);
    }

}

