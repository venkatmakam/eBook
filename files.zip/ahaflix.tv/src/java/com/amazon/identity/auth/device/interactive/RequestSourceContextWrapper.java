/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  com.amazon.identity.auth.device.interactive.InteractiveRequestRecord
 *  com.amazon.identity.auth.device.interactive.InteractiveState
 *  com.amazon.identity.auth.device.interactive.RequestSource
 *  java.lang.Class
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.ref.WeakReference
 */
package com.amazon.identity.auth.device.interactive;

import android.content.Context;
import com.amazon.identity.auth.device.interactive.InteractiveRequestRecord;
import com.amazon.identity.auth.device.interactive.InteractiveState;
import com.amazon.identity.auth.device.interactive.RequestSource;
import com.amazon.identity.auth.device.interactive.WorkflowSupportFragment;
import java.lang.ref.WeakReference;

public class RequestSourceContextWrapper
implements RequestSource {
    private static final String LOG_TAG = "com.amazon.identity.auth.device.interactive.RequestSourceContextWrapper";
    private final WeakReference<Context> contextWeakReference;
    private WorkflowSupportFragment workflowSupportFragment;

    public RequestSourceContextWrapper(Context context) {
        if (context != null) {
            this.contextWeakReference = new WeakReference((Object)context);
            this.workflowSupportFragment = null;
            return;
        }
        throw new IllegalArgumentException("context must be non-null");
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object == null) {
            return false;
        }
        if (this.getClass() != object.getClass()) {
            return false;
        }
        RequestSourceContextWrapper requestSourceContextWrapper = (RequestSourceContextWrapper)object;
        WeakReference<Context> weakReference = this.contextWeakReference;
        if (weakReference == null) {
            if (requestSourceContextWrapper.contextWeakReference != null) {
                return false;
            }
        } else {
            if (requestSourceContextWrapper.contextWeakReference == null) {
                return false;
            }
            if (weakReference.get() == null ? requestSourceContextWrapper.contextWeakReference.get() != null : !((Context)this.contextWeakReference.get()).equals(requestSourceContextWrapper.contextWeakReference.get())) {
                return false;
            }
        }
        return true;
    }

    public Object getBackingObject() {
        return this.contextWeakReference.get();
    }

    public Context getContext() {
        return (Context)this.contextWeakReference.get();
    }

    public InteractiveState getInteractiveState() {
        if (this.workflowSupportFragment == null) {
            WorkflowSupportFragment workflowSupportFragment;
            this.workflowSupportFragment = workflowSupportFragment = new WorkflowSupportFragment();
            workflowSupportFragment.setApplicationContext((Context)this.contextWeakReference.get());
        }
        return this.workflowSupportFragment.getState();
    }

    public int hashCode() {
        WeakReference<Context> weakReference = this.contextWeakReference;
        int n = weakReference != null && weakReference.get() != null ? ((Context)this.contextWeakReference.get()).hashCode() : 0;
        return 31 + n;
    }

    public boolean isHookNeededOnUIResume() {
        return false;
    }

    public void onStartRequest(InteractiveRequestRecord interactiveRequestRecord) {
        InteractiveState interactiveState = this.getInteractiveState();
        if (interactiveState != null) {
            interactiveState.onRequestStart(interactiveRequestRecord);
        }
    }
}

