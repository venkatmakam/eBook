/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  com.amazon.identity.auth.device.AuthError
 *  com.amazon.identity.auth.device.endpoint.PandaResponse
 *  com.amazon.identity.auth.map.device.utils.MAPLog
 *  e.a.a.a.a
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.List
 *  org.apache.http.HttpResponse
 *  org.apache.http.message.BasicNameValuePair
 */
package com.amazon.identity.auth.device.endpoint;

import android.content.Context;
import com.amazon.identity.auth.device.AuthError;
import com.amazon.identity.auth.device.dataobject.AppInfo;
import com.amazon.identity.auth.device.endpoint.AbstractOauthTokenRequest;
import com.amazon.identity.auth.device.endpoint.OauthCodeForTokenResponse;
import com.amazon.identity.auth.device.endpoint.PandaResponse;
import com.amazon.identity.auth.map.device.utils.MAPLog;
import e.a.a.a.a;
import java.util.ArrayList;
import java.util.List;
import org.apache.http.HttpResponse;
import org.apache.http.message.BasicNameValuePair;

public class OauthCodeForTokenRequest
extends AbstractOauthTokenRequest<OauthCodeForTokenResponse> {
    public static final String AUTHORIZATION_CODE_GRANT = "authorization_code";
    public static final String AUTHORIZATION_CODE_PARAM = "code";
    private static final String LOG_TAG = "com.amazon.identity.auth.device.endpoint.OauthCodeForTokenRequest";
    public static final String REDIRECT_URI_PARAM = "redirect_uri";
    private final String mCode;
    private final String mCodeVerifier;
    private final String mDirectedId;
    private final String mRedirectUri;

    public OauthCodeForTokenRequest(String string, String string2, String string3, String string4, AppInfo appInfo, Context context) throws AuthError {
        super(context, appInfo);
        this.mCode = string;
        this.mRedirectUri = string3;
        this.mDirectedId = string4;
        this.mCodeVerifier = string2;
    }

    public OauthCodeForTokenResponse generateResponse(HttpResponse httpResponse) {
        return new OauthCodeForTokenResponse(httpResponse, this.getAppFamilyId(), this.mDirectedId);
    }

    @Override
    public List<BasicNameValuePair> getExtraOauthTokenRequestParameters() {
        ArrayList arrayList = new ArrayList();
        arrayList.add((Object)new BasicNameValuePair(AUTHORIZATION_CODE_PARAM, this.mCode));
        arrayList.add((Object)new BasicNameValuePair(REDIRECT_URI_PARAM, this.mRedirectUri));
        arrayList.add((Object)new BasicNameValuePair("code_verifier", this.mCodeVerifier));
        return arrayList;
    }

    @Override
    public String getGrantType() {
        return AUTHORIZATION_CODE_GRANT;
    }

    public void logRequest() {
        String string = LOG_TAG;
        StringBuilder stringBuilder = a.F1((String)"Executing OAuth Code for Token Exchange. redirectUri=");
        stringBuilder.append(this.mRedirectUri);
        stringBuilder.append(" appId=");
        stringBuilder.append(this.getAppFamilyId());
        String string2 = stringBuilder.toString();
        StringBuilder stringBuilder2 = a.F1((String)"code=");
        stringBuilder2.append(this.mCode);
        MAPLog.pii((String)string, (String)string2, (String)stringBuilder2.toString());
    }
}

