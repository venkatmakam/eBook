/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  com.amazon.identity.auth.device.endpoint.PandaResponse
 *  com.amazon.identity.auth.map.device.utils.MAPLog
 *  e.a.a.a.a
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.List
 *  org.apache.http.HttpResponse
 *  org.apache.http.message.BasicNameValuePair
 */
package com.amazon.identity.auth.device.endpoint;

import android.content.Context;
import com.amazon.identity.auth.device.dataobject.AppInfo;
import com.amazon.identity.auth.device.endpoint.AbstractJsonPandaRequest;
import com.amazon.identity.auth.device.endpoint.OneTimeCodeResponse;
import com.amazon.identity.auth.device.endpoint.PandaResponse;
import com.amazon.identity.auth.map.device.utils.MAPLog;
import e.a.a.a.a;
import java.util.ArrayList;
import java.util.List;
import org.apache.http.HttpResponse;
import org.apache.http.message.BasicNameValuePair;

public class OneTimeCodeRequest
extends AbstractJsonPandaRequest<OneTimeCodeResponse> {
    private static final String ACCESS_TOKEN_PARAMETER = "accessToken";
    private static final String LOG_TAG = "com.amazon.identity.auth.device.endpoint.OneTimeCodeRequest";
    private static final String ONE_TIME_CODE_ENDPOINT = "/auth/create/oneTimeCode";
    private static final String WORKFLOW_CLIENT_ID_PARAMETER = "workflowClientId";
    private String accessToken;
    private String workflowClientId;

    public OneTimeCodeRequest(Context context, String string, String string2, AppInfo appInfo) {
        super(context, appInfo);
        this.workflowClientId = string;
        this.accessToken = string2;
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object == null) {
            return false;
        }
        if (this.getClass() != object.getClass()) {
            return false;
        }
        OneTimeCodeRequest oneTimeCodeRequest = (OneTimeCodeRequest)((Object)object);
        String string = this.accessToken;
        if (string == null && oneTimeCodeRequest.accessToken != null) {
            return false;
        }
        if (!string.equals((Object)oneTimeCodeRequest.accessToken)) {
            return false;
        }
        String string2 = this.workflowClientId;
        if (string2 == null && oneTimeCodeRequest.workflowClientId != null) {
            return false;
        }
        return string2.equals((Object)oneTimeCodeRequest.workflowClientId);
    }

    public OneTimeCodeResponse generateResponse(HttpResponse httpResponse) {
        return new OneTimeCodeResponse(httpResponse);
    }

    public String getEndPoint() {
        return ONE_TIME_CODE_ENDPOINT;
    }

    public List<BasicNameValuePair> getExtraParameters() {
        ArrayList arrayList = new ArrayList();
        arrayList.add((Object)new BasicNameValuePair(WORKFLOW_CLIENT_ID_PARAMETER, this.workflowClientId));
        arrayList.add((Object)new BasicNameValuePair(ACCESS_TOKEN_PARAMETER, this.accessToken));
        return arrayList;
    }

    public int hashCode() {
        String string = this.accessToken;
        int n = string == null ? 0 : string.hashCode();
        int n2 = 31 * (n + 31);
        String string2 = this.workflowClientId;
        int n3 = string2 == null ? 0 : string2.hashCode();
        return n2 + n3;
    }

    public void logRequest() {
        String string = LOG_TAG;
        StringBuilder stringBuilder = a.F1((String)"Executing create one time code request. workflowClientId=");
        stringBuilder.append(this.workflowClientId);
        String string2 = stringBuilder.toString();
        StringBuilder stringBuilder2 = a.F1((String)"accessToken=");
        stringBuilder2.append(this.accessToken);
        MAPLog.pii((String)string, (String)string2, (String)stringBuilder2.toString());
    }
}

