/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Bundle
 *  androidx.fragment.app.Fragment
 *  androidx.fragment.app.FragmentActivity
 *  androidx.fragment.app.FragmentManager
 *  androidx.fragment.app.FragmentTransaction
 *  com.amazon.identity.auth.device.interactive.InteractiveRequestRecord
 *  com.amazon.identity.auth.device.interactive.InteractiveState
 *  com.amazon.identity.auth.device.interactive.InteractiveStateFragment
 *  com.amazon.identity.auth.device.interactive.RequestSource
 *  com.amazon.identity.auth.map.device.utils.MAPLog
 *  e.a.a.a.a
 *  java.lang.Class
 *  java.lang.ClassCastException
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.lang.ref.WeakReference
 */
package com.amazon.identity.auth.device.interactive;

import android.content.Context;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import com.amazon.identity.auth.device.interactive.InteractiveRequestRecord;
import com.amazon.identity.auth.device.interactive.InteractiveState;
import com.amazon.identity.auth.device.interactive.InteractiveStateFragment;
import com.amazon.identity.auth.device.interactive.RequestSource;
import com.amazon.identity.auth.device.interactive.WorkflowSupportFragment;
import com.amazon.identity.auth.map.device.utils.MAPLog;
import e.a.a.a.a;
import java.lang.ref.WeakReference;

public final class RequestSourceSupportFragmentWrapper
implements RequestSource {
    private static final String LOG_TAG = "com.amazon.identity.auth.device.interactive.RequestSourceSupportFragmentWrapper";
    private final WeakReference<Fragment> fragmentReference;

    public RequestSourceSupportFragmentWrapper(Fragment fragment) {
        if (fragment != null) {
            this.fragmentReference = new WeakReference((Object)fragment);
            return;
        }
        throw new IllegalArgumentException("fragment must be non-null");
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private InteractiveState getInteractiveStateAddingRequest(InteractiveRequestRecord interactiveRequestRecord) {
        Fragment fragment = (Fragment)this.fragmentReference.get();
        if (fragment != null) {
            FragmentManager fragmentManager;
            InteractiveStateFragment interactiveStateFragment;
            block5 : {
                String string;
                fragmentManager = fragment.getFragmentManager();
                try {
                    string = InteractiveStateFragment.TAG_ID;
                    interactiveStateFragment = (InteractiveStateFragment)fragmentManager.findFragmentByTag(string);
                    if (interactiveStateFragment != null) break block5;
                }
                catch (ClassCastException classCastException) {
                    String string2 = LOG_TAG;
                    StringBuilder stringBuilder = a.F1((String)"Found an invalid fragment looking for fragment with tag ");
                    stringBuilder.append(InteractiveStateFragment.TAG_ID);
                    stringBuilder.append(". Please use a different fragment tag.");
                    MAPLog.e((String)string2, (String)stringBuilder.toString(), (Throwable)classCastException);
                    return null;
                }
                interactiveStateFragment = new WorkflowSupportFragment();
                fragmentManager.beginTransaction().add((Fragment)interactiveStateFragment, string).commit();
            }
            if (interactiveRequestRecord == null) return interactiveStateFragment.getState();
            Bundle bundle = new Bundle();
            fragmentManager.putFragment(bundle, "wrappedFragment", fragment);
            interactiveRequestRecord.setFragmentWrapper(bundle);
            interactiveStateFragment.getState().onRequestStart(interactiveRequestRecord);
            return interactiveStateFragment.getState();
        }
        MAPLog.e((String)LOG_TAG, (String)"Failed to get InteractiveState on a garbage-collected Fragment");
        return null;
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object == null) {
            return false;
        }
        if (RequestSourceSupportFragmentWrapper.class != object.getClass()) {
            return false;
        }
        RequestSourceSupportFragmentWrapper requestSourceSupportFragmentWrapper = (RequestSourceSupportFragmentWrapper)object;
        WeakReference<Fragment> weakReference = this.fragmentReference;
        if (weakReference == null) {
            if (requestSourceSupportFragmentWrapper.fragmentReference != null) {
                return false;
            }
        } else {
            if (requestSourceSupportFragmentWrapper.fragmentReference == null) {
                return false;
            }
            if (weakReference.get() == null ? requestSourceSupportFragmentWrapper.fragmentReference.get() != null : !((Fragment)this.fragmentReference.get()).equals(requestSourceSupportFragmentWrapper.fragmentReference.get())) {
                return false;
            }
        }
        return true;
    }

    public Object getBackingObject() {
        return this.fragmentReference.get();
    }

    public Context getContext() {
        return ((Fragment)this.fragmentReference.get()).getActivity();
    }

    public InteractiveState getInteractiveState() {
        return this.getInteractiveStateAddingRequest(null);
    }

    public int hashCode() {
        WeakReference<Fragment> weakReference = this.fragmentReference;
        int n = weakReference != null && weakReference.get() != null ? ((Fragment)this.fragmentReference.get()).hashCode() : 0;
        return 31 + n;
    }

    public boolean isHookNeededOnUIResume() {
        return true;
    }

    public void onStartRequest(InteractiveRequestRecord interactiveRequestRecord) {
        this.getInteractiveStateAddingRequest(interactiveRequestRecord);
    }
}

