/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.amazon.device.iap.internal.b.a
 *  com.amazon.device.iap.internal.b.d
 *  com.amazon.device.iap.internal.b.d.b
 *  com.amazon.device.iap.internal.b.e
 *  com.amazon.device.iap.internal.b.h
 *  com.amazon.device.iap.internal.model.PurchaseUpdatesResponseBuilder
 *  com.amazon.device.iap.internal.model.UserDataBuilder
 *  com.amazon.device.iap.internal.util.a
 *  com.amazon.device.iap.internal.util.e
 *  com.amazon.device.iap.model.PurchaseUpdatesResponse
 *  com.amazon.device.iap.model.PurchaseUpdatesResponse$RequestStatus
 *  com.amazon.device.iap.model.Receipt
 *  com.amazon.device.iap.model.RequestId
 *  com.amazon.device.iap.model.UserData
 *  com.amazon.venezia.command.SuccessResult
 *  e.a.a.a.a
 *  java.lang.Boolean
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.List
 *  java.util.Map
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.amazon.device.iap.internal.b.d;

import com.amazon.device.iap.internal.b.a;
import com.amazon.device.iap.internal.b.d;
import com.amazon.device.iap.internal.b.d.b;
import com.amazon.device.iap.internal.b.e;
import com.amazon.device.iap.internal.b.h;
import com.amazon.device.iap.internal.model.PurchaseUpdatesResponseBuilder;
import com.amazon.device.iap.internal.model.UserDataBuilder;
import com.amazon.device.iap.model.PurchaseUpdatesResponse;
import com.amazon.device.iap.model.Receipt;
import com.amazon.device.iap.model.RequestId;
import com.amazon.device.iap.model.UserData;
import com.amazon.venezia.command.SuccessResult;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class c
extends b {
    private static final String b = c.class.getSimpleName();

    public c(e e2, boolean bl) {
        super(e2, "2.0", bl);
    }

    private List<Receipt> a(String string, String string2, String string3) throws JSONException {
        ArrayList arrayList = new ArrayList();
        JSONArray jSONArray = new JSONArray(string2);
        for (int j = 0; j < jSONArray.length(); ++j) {
            try {
                arrayList.add((Object)com.amazon.device.iap.internal.util.a.a((JSONObject)jSONArray.getJSONObject(j), (String)string, (String)string3));
                continue;
            }
            catch (Throwable throwable) {
                String string4 = b;
                StringBuilder stringBuilder = e.a.a.a.a.F1((String)"fail to verify receipt, requestId:");
                stringBuilder.append(throwable.getMessage());
                com.amazon.device.iap.internal.util.e.b((String)string4, (String)stringBuilder.toString());
                continue;
            }
            catch (d d2) {
                String string5 = b;
                StringBuilder stringBuilder = e.a.a.a.a.F1((String)"fail to verify receipt, requestId:");
                stringBuilder.append(d2.a());
                com.amazon.device.iap.internal.util.e.b((String)string5, (String)stringBuilder.toString());
                continue;
            }
            catch (a a2) {
                String string6 = b;
                StringBuilder stringBuilder = e.a.a.a.a.F1((String)"fail to parse receipt, requestId:");
                stringBuilder.append(a2.a());
                com.amazon.device.iap.internal.util.e.b((String)string6, (String)stringBuilder.toString());
            }
        }
        return arrayList;
    }

    public boolean a(SuccessResult successResult) throws Exception {
        Map map = successResult.getData();
        String string = b;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("data: ");
        stringBuilder.append((Object)map);
        com.amazon.device.iap.internal.util.e.a((String)string, (String)stringBuilder.toString());
        String string2 = (String)map.get((Object)"userId");
        String string3 = (String)map.get((Object)"marketplace");
        String string4 = (String)map.get((Object)"requestId");
        List<Receipt> list = this.a(string2, (String)map.get((Object)"receipts"), string4);
        String string5 = (String)map.get((Object)"cursor");
        boolean bl = Boolean.valueOf((String)((String)map.get((Object)"hasMore")));
        e e2 = this.b();
        UserData userData = new UserDataBuilder().setUserId(string2).setMarketplace(string3).build();
        PurchaseUpdatesResponse purchaseUpdatesResponse = new PurchaseUpdatesResponseBuilder().setRequestId(e2.c()).setRequestStatus(PurchaseUpdatesResponse.RequestStatus.SUCCESSFUL).setUserData(userData).setReceipts(list).setHasMore(bl).build();
        e2.d().a("newCursor", (Object)string5);
        e2.d().a((Object)purchaseUpdatesResponse);
        return true;
    }
}

