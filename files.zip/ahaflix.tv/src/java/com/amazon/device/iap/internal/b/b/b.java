/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.amazon.android.framework.exception.KiwiException
 *  com.amazon.device.iap.internal.b.b.a
 *  com.amazon.device.iap.internal.b.e
 *  com.amazon.device.iap.internal.c.b
 *  java.lang.String
 */
package com.amazon.device.iap.internal.b.b;

import com.amazon.android.framework.exception.KiwiException;
import com.amazon.device.iap.internal.b.b.a;
import com.amazon.device.iap.internal.b.e;

public final class b
extends a {
    public b(e e2, String string) {
        super(e2, "1.0", string);
    }

    public void preExecution() throws KiwiException {
        super.preExecution();
        com.amazon.device.iap.internal.c.b.a().b(this.c());
    }
}

