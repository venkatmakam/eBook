/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.amazon.device.iap.internal.b.e
 *  com.amazon.device.iap.internal.b.f.a
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Map
 */
package com.amazon.device.iap.internal.b.f;

import com.amazon.device.iap.internal.b.e;
import com.amazon.device.iap.internal.b.f.a;
import java.util.Map;

public final class b
extends a {
    public b(e e2, String string) {
        super(e2, "1.0");
        this.getCommandData().put((Object)"requestId", (Object)string);
    }
}

