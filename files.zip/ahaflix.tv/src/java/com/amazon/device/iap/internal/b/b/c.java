/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.amazon.device.iap.internal.b.b.a
 *  com.amazon.device.iap.internal.b.e
 *  java.lang.String
 */
package com.amazon.device.iap.internal.b.b;

import com.amazon.device.iap.internal.b.b.a;
import com.amazon.device.iap.internal.b.e;

public final class c
extends a {
    public c(e e2, String string) {
        super(e2, "2.0", string);
    }
}

