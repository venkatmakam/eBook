/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.RemoteException
 *  com.amazon.android.framework.exception.KiwiException
 *  com.amazon.device.iap.internal.b.e
 *  com.amazon.device.iap.internal.b.e.b
 *  com.amazon.device.iap.internal.b.h
 *  com.amazon.device.iap.internal.model.UserDataBuilder
 *  com.amazon.device.iap.internal.model.UserDataResponseBuilder
 *  com.amazon.device.iap.internal.util.d
 *  com.amazon.device.iap.internal.util.e
 *  com.amazon.device.iap.model.RequestId
 *  com.amazon.device.iap.model.UserData
 *  com.amazon.device.iap.model.UserDataResponse
 *  com.amazon.device.iap.model.UserDataResponse$RequestStatus
 *  com.amazon.venezia.command.SuccessResult
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.Map
 */
package com.amazon.device.iap.internal.b.e;

import android.os.RemoteException;
import com.amazon.android.framework.exception.KiwiException;
import com.amazon.device.iap.internal.b.e;
import com.amazon.device.iap.internal.b.e.b;
import com.amazon.device.iap.internal.b.h;
import com.amazon.device.iap.internal.model.UserDataBuilder;
import com.amazon.device.iap.internal.model.UserDataResponseBuilder;
import com.amazon.device.iap.model.RequestId;
import com.amazon.device.iap.model.UserData;
import com.amazon.device.iap.model.UserDataResponse;
import com.amazon.venezia.command.SuccessResult;
import java.util.Map;

public final class d
extends b {
    private static final String b = d.class.getSimpleName();

    public d(e e2) {
        super(e2, "1.0");
    }

    public boolean a(SuccessResult successResult) throws RemoteException, KiwiException {
        String string = b;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("onSuccessInternal: result = ");
        stringBuilder.append((Object)successResult);
        com.amazon.device.iap.internal.util.e.a((String)string, (String)stringBuilder.toString());
        Map map = successResult.getData();
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("data: ");
        stringBuilder2.append((Object)map);
        com.amazon.device.iap.internal.util.e.a((String)string, (String)stringBuilder2.toString());
        String string2 = (String)map.get((Object)"userId");
        e e2 = this.b();
        if (com.amazon.device.iap.internal.util.d.a((String)string2)) {
            e2.d().a((Object)new UserDataResponseBuilder().setRequestId(e2.c()).setRequestStatus(UserDataResponse.RequestStatus.FAILED).build());
            return false;
        }
        UserData userData = new UserDataBuilder().setUserId(string2).setMarketplace(b.a).build();
        UserDataResponse userDataResponse = new UserDataResponseBuilder().setRequestId(e2.c()).setRequestStatus(UserDataResponse.RequestStatus.SUCCESSFUL).setUserData(userData).build();
        e2.d().a("userId", (Object)userData.getUserId());
        e2.d().a((Object)userDataResponse);
        return true;
    }
}

