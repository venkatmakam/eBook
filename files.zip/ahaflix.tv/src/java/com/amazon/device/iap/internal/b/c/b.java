/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.RemoteException
 *  com.amazon.android.framework.exception.KiwiException
 *  com.amazon.device.iap.internal.b.c.c
 *  com.amazon.device.iap.internal.b.e
 *  com.amazon.device.iap.internal.b.h
 *  com.amazon.device.iap.internal.model.ProductBuilder
 *  com.amazon.device.iap.internal.model.ProductDataResponseBuilder
 *  com.amazon.device.iap.internal.util.e
 *  com.amazon.device.iap.model.Product
 *  com.amazon.device.iap.model.ProductDataResponse
 *  com.amazon.device.iap.model.ProductDataResponse$RequestStatus
 *  com.amazon.device.iap.model.ProductType
 *  com.amazon.device.iap.model.RequestId
 *  com.amazon.venezia.command.SuccessResult
 *  e.a.a.a.a
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.HashMap
 *  java.util.LinkedHashSet
 *  java.util.Map
 *  java.util.Set
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.amazon.device.iap.internal.b.c;

import android.os.RemoteException;
import com.amazon.android.framework.exception.KiwiException;
import com.amazon.device.iap.internal.b.c.c;
import com.amazon.device.iap.internal.b.e;
import com.amazon.device.iap.internal.b.h;
import com.amazon.device.iap.internal.model.ProductBuilder;
import com.amazon.device.iap.internal.model.ProductDataResponseBuilder;
import com.amazon.device.iap.model.Product;
import com.amazon.device.iap.model.ProductDataResponse;
import com.amazon.device.iap.model.ProductType;
import com.amazon.device.iap.model.RequestId;
import com.amazon.venezia.command.SuccessResult;
import e.a.a.a.a;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import org.json.JSONException;
import org.json.JSONObject;

public final class b
extends c {
    private static final String b = b.class.getSimpleName();

    public b(e e2, Set<String> set) {
        super(e2, "1.0", set);
    }

    private Product a(String string, Map map) throws IllegalArgumentException {
        String string2 = (String)map.get((Object)string);
        try {
            JSONObject jSONObject = new JSONObject(string2);
            ProductType productType = ProductType.valueOf((String)jSONObject.getString("itemType").toUpperCase());
            String string3 = jSONObject.getString("description");
            String string4 = jSONObject.optString("price");
            String string5 = jSONObject.getString("title");
            String string6 = jSONObject.getString("iconUrl");
            int n = jSONObject.optInt("coinsRewardAmount", 0);
            Product product = new ProductBuilder().setSku(string).setProductType(productType).setDescription(string3).setPrice(string4).setSmallIconUrl(string6).setTitle(string5).setCoinsRewardAmount(n).build();
            return product;
        }
        catch (JSONException jSONException) {
            throw new IllegalArgumentException(a.h1((String)"error in parsing json string", (String)string2));
        }
    }

    public boolean a(SuccessResult successResult) throws RemoteException, KiwiException {
        Map map = successResult.getData();
        String string = b;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("data: ");
        stringBuilder.append((Object)map);
        com.amazon.device.iap.internal.util.e.a((String)string, (String)stringBuilder.toString());
        LinkedHashSet linkedHashSet = new LinkedHashSet();
        HashMap hashMap = new HashMap();
        for (String string2 : this.a) {
            if (!map.containsKey((Object)string2)) {
                linkedHashSet.add((Object)string2);
                continue;
            }
            try {
                hashMap.put((Object)string2, (Object)this.a(string2, map));
            }
            catch (IllegalArgumentException illegalArgumentException) {
                linkedHashSet.add((Object)string2);
                String string3 = b;
                StringBuilder stringBuilder2 = a.f((String)"Error parsing JSON for SKU ", (String)string2, (String)": ");
                stringBuilder2.append(illegalArgumentException.getMessage());
                com.amazon.device.iap.internal.util.e.b((String)string3, (String)stringBuilder2.toString());
            }
        }
        e e2 = this.b();
        ProductDataResponse productDataResponse = new ProductDataResponseBuilder().setRequestId(e2.c()).setRequestStatus(ProductDataResponse.RequestStatus.SUCCESSFUL).setUnavailableSkus((Set)linkedHashSet).setProductData((Map)hashMap).build();
        e2.d().a((Object)productDataResponse);
        return true;
    }
}

