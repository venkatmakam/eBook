/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.amazon.device.iap.internal.b.a.c
 *  com.amazon.device.iap.internal.b.e
 *  com.amazon.device.iap.internal.b.h
 *  com.amazon.device.iap.internal.c.a
 *  com.amazon.device.iap.internal.c.b
 *  com.amazon.device.iap.internal.model.PurchaseResponseBuilder
 *  com.amazon.device.iap.internal.model.UserDataBuilder
 *  com.amazon.device.iap.internal.util.a
 *  com.amazon.device.iap.internal.util.d
 *  com.amazon.device.iap.internal.util.e
 *  com.amazon.device.iap.model.ProductType
 *  com.amazon.device.iap.model.PurchaseResponse
 *  com.amazon.device.iap.model.PurchaseResponse$RequestStatus
 *  com.amazon.device.iap.model.Receipt
 *  com.amazon.device.iap.model.RequestId
 *  com.amazon.device.iap.model.UserData
 *  com.amazon.venezia.command.SuccessResult
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.Map
 *  org.json.JSONObject
 */
package com.amazon.device.iap.internal.b.a;

import com.amazon.device.iap.internal.b.a.c;
import com.amazon.device.iap.internal.b.e;
import com.amazon.device.iap.internal.b.h;
import com.amazon.device.iap.internal.model.PurchaseResponseBuilder;
import com.amazon.device.iap.internal.model.UserDataBuilder;
import com.amazon.device.iap.internal.util.a;
import com.amazon.device.iap.internal.util.d;
import com.amazon.device.iap.model.ProductType;
import com.amazon.device.iap.model.PurchaseResponse;
import com.amazon.device.iap.model.Receipt;
import com.amazon.device.iap.model.RequestId;
import com.amazon.device.iap.model.UserData;
import com.amazon.venezia.command.SuccessResult;
import java.util.Map;
import org.json.JSONObject;

public final class b
extends c {
    private static final String a = b.class.getSimpleName();

    public b(e e2) {
        super(e2, "1.0");
    }

    private void a(String string, String string2, String string3) {
        if (string != null && string2 != null) {
            if (string3 == null) {
                return;
            }
            try {
                JSONObject jSONObject = new JSONObject(string3);
                if (PurchaseResponse.RequestStatus.safeValueOf((String)jSONObject.getString("orderStatus")) == PurchaseResponse.RequestStatus.SUCCESSFUL) {
                    Receipt receipt = a.a((JSONObject)jSONObject, (String)string2, (String)string);
                    com.amazon.device.iap.internal.c.a.a().a(string, string2, receipt.getReceiptId(), string3);
                    return;
                }
            }
            catch (Throwable throwable) {
                String string4 = a;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Error in savePendingReceipt: ");
                stringBuilder.append((Object)throwable);
                com.amazon.device.iap.internal.util.e.b((String)string4, (String)stringBuilder.toString());
            }
        }
    }

    public boolean a(SuccessResult successResult) throws Exception {
        Map map = successResult.getData();
        String string = a;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("data: ");
        stringBuilder.append((Object)map);
        com.amazon.device.iap.internal.util.e.a((String)string, (String)stringBuilder.toString());
        String string2 = (String)this.getCommandData().get((Object)"requestId");
        String string3 = (String)map.get((Object)"userId");
        String string4 = (String)map.get((Object)"marketplace");
        String string5 = (String)map.get((Object)"receipt");
        if (string2 != null && com.amazon.device.iap.internal.c.b.a().a(string2)) {
            Receipt receipt;
            PurchaseResponse.RequestStatus requestStatus;
            if (d.a((String)string5)) {
                this.a(string3, string4, string2, PurchaseResponse.RequestStatus.FAILED);
                return false;
            }
            JSONObject jSONObject = new JSONObject(string5);
            requestStatus = PurchaseResponse.RequestStatus.safeValueOf((String)jSONObject.getString("orderStatus"));
            PurchaseResponse.RequestStatus requestStatus2 = PurchaseResponse.RequestStatus.SUCCESSFUL;
            receipt = null;
            if (requestStatus == requestStatus2) {
                try {
                    receipt = a.a((JSONObject)jSONObject, (String)string3, (String)string2);
                }
                catch (Throwable throwable) {
                    this.a(string3, string4, string2, PurchaseResponse.RequestStatus.FAILED);
                    return false;
                }
                if (ProductType.CONSUMABLE == receipt.getProductType()) {
                    this.a(string2, string3, string5);
                }
            }
            e e2 = this.b();
            UserData userData = new UserDataBuilder().setUserId(string3).setMarketplace(string4).build();
            PurchaseResponse purchaseResponse = new PurchaseResponseBuilder().setRequestId(e2.c()).setRequestStatus(requestStatus).setUserData(userData).setReceipt(receipt).build();
            e2.d().a((Object)purchaseResponse);
            return true;
        }
        this.b().d().b();
        return true;
    }
}

