/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.amazon.device.iap.internal.b.e
 *  com.amazon.device.iap.internal.b.f.a
 *  com.amazon.device.iap.internal.b.h
 *  com.amazon.device.iap.internal.b.i
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.lang.String
 */
package com.amazon.device.iap.internal.b.f;

import com.amazon.device.iap.internal.b.e;
import com.amazon.device.iap.internal.b.f.a;
import com.amazon.device.iap.internal.b.h;
import com.amazon.device.iap.internal.b.i;

public final class c
extends a {
    public c(e e2, boolean bl) {
        super(e2, "2.0");
        this.a("receiptDelivered", (Object)bl);
    }

    public void a_() {
        Boolean bl;
        Object object = this.b().d().a("notifyListenerResult");
        if (object != null && (bl = Boolean.TRUE).equals(object)) {
            this.a("notifyListenerSucceeded", (Object)bl);
        } else {
            this.a("notifyListenerSucceeded", (Object)Boolean.FALSE);
        }
        i.super.a_();
    }
}

