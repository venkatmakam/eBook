/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.RemoteException
 *  com.amazon.android.framework.exception.KiwiException
 *  com.amazon.device.iap.internal.b.c.c
 *  com.amazon.device.iap.internal.b.e
 *  com.amazon.device.iap.internal.b.h
 *  com.amazon.device.iap.internal.model.ProductBuilder
 *  com.amazon.device.iap.internal.model.ProductDataResponseBuilder
 *  com.amazon.device.iap.internal.util.MetricsHelper
 *  com.amazon.device.iap.internal.util.d
 *  com.amazon.device.iap.internal.util.e
 *  com.amazon.device.iap.model.Product
 *  com.amazon.device.iap.model.ProductDataResponse
 *  com.amazon.device.iap.model.ProductDataResponse$RequestStatus
 *  com.amazon.device.iap.model.ProductType
 *  com.amazon.device.iap.model.RequestId
 *  com.amazon.venezia.command.SuccessResult
 *  e.a.a.a.a
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.math.BigDecimal
 *  java.util.Currency
 *  java.util.HashMap
 *  java.util.LinkedHashSet
 *  java.util.Map
 *  java.util.Set
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.amazon.device.iap.internal.b.c;

import android.os.RemoteException;
import com.amazon.android.framework.exception.KiwiException;
import com.amazon.device.iap.internal.b.c.c;
import com.amazon.device.iap.internal.b.e;
import com.amazon.device.iap.internal.b.h;
import com.amazon.device.iap.internal.model.ProductBuilder;
import com.amazon.device.iap.internal.model.ProductDataResponseBuilder;
import com.amazon.device.iap.internal.util.MetricsHelper;
import com.amazon.device.iap.internal.util.d;
import com.amazon.device.iap.model.Product;
import com.amazon.device.iap.model.ProductDataResponse;
import com.amazon.device.iap.model.ProductType;
import com.amazon.device.iap.model.RequestId;
import com.amazon.venezia.command.SuccessResult;
import java.math.BigDecimal;
import java.util.Currency;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import org.json.JSONException;
import org.json.JSONObject;

public final class a
extends c {
    private static final String b = a.class.getSimpleName();

    public a(e e2, Set<String> set) {
        super(e2, "2.0", set);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private Product a(String string, Map map) throws IllegalArgumentException {
        String string2 = (String)map.get((Object)string);
        try {
            JSONObject jSONObject;
            JSONObject jSONObject2 = new JSONObject(string2);
            ProductType productType = ProductType.valueOf((String)jSONObject2.getString("itemType").toUpperCase());
            String string3 = jSONObject2.getString("description");
            String string4 = jSONObject2.optString("price", null);
            if (d.a((String)string4) && (jSONObject = jSONObject2.optJSONObject("priceJson")) != null) {
                Currency currency = Currency.getInstance((String)jSONObject.getString("currency"));
                BigDecimal bigDecimal = new BigDecimal(jSONObject.getString("value"));
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(currency.getSymbol());
                stringBuilder.append((Object)bigDecimal);
                string4 = stringBuilder.toString();
            }
            String string5 = jSONObject2.getString("title");
            String string6 = jSONObject2.getString("iconUrl");
            int n = jSONObject2.optInt("coinsRewardAmount", 0);
            return new ProductBuilder().setSku(string).setProductType(productType).setDescription(string3).setPrice(string4).setSmallIconUrl(string6).setTitle(string5).setCoinsRewardAmount(n).build();
        }
        catch (JSONException jSONException) {
            throw new IllegalArgumentException(e.a.a.a.a.h1((String)"error in parsing json string", (String)string2));
        }
    }

    public boolean a(SuccessResult successResult) throws RemoteException, KiwiException {
        Map map = successResult.getData();
        String string = b;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("data: ");
        stringBuilder.append((Object)map);
        com.amazon.device.iap.internal.util.e.a((String)string, (String)stringBuilder.toString());
        LinkedHashSet linkedHashSet = new LinkedHashSet();
        HashMap hashMap = new HashMap();
        for (String string2 : this.a) {
            if (!map.containsKey((Object)string2)) {
                linkedHashSet.add((Object)string2);
                continue;
            }
            try {
                hashMap.put((Object)string2, (Object)this.a(string2, map));
            }
            catch (IllegalArgumentException illegalArgumentException) {
                linkedHashSet.add((Object)string2);
                String string3 = (String)map.get((Object)string2);
                String string4 = this.c();
                StringBuilder stringBuilder2 = new StringBuilder();
                String string5 = b;
                stringBuilder2.append(string5);
                stringBuilder2.append(".onResult()");
                MetricsHelper.submitJsonParsingExceptionMetrics((String)string4, (String)string3, (String)stringBuilder2.toString());
                StringBuilder stringBuilder3 = new StringBuilder();
                stringBuilder3.append("Error parsing JSON for SKU ");
                stringBuilder3.append(string2);
                stringBuilder3.append(": ");
                stringBuilder3.append(illegalArgumentException.getMessage());
                com.amazon.device.iap.internal.util.e.b((String)string5, (String)stringBuilder3.toString());
            }
        }
        e e2 = this.b();
        ProductDataResponse productDataResponse = new ProductDataResponseBuilder().setRequestId(e2.c()).setRequestStatus(ProductDataResponse.RequestStatus.SUCCESSFUL).setUnavailableSkus((Set)linkedHashSet).setProductData((Map)hashMap).build();
        e2.d().a((Object)productDataResponse);
        return true;
    }
}

