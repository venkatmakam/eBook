/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.freshchat.consumer.sdk.Event
 *  com.freshchat.consumer.sdk.Event$EventName
 *  com.freshchat.consumer.sdk.j.bg
 *  com.freshchat.consumer.sdk.j.bg$a
 *  com.freshchat.consumer.sdk.j.bg$b
 *  java.lang.Object
 */
package com.freshchat.consumer.sdk.j;

import com.freshchat.consumer.sdk.Event;
import com.freshchat.consumer.sdk.j.bg;

public final class bj
implements bg.b {
    public Event gy() {
        return bg.a.a((bg.a)bg.b((Event.EventName)Event.EventName.FCEventScreenView));
    }
}

