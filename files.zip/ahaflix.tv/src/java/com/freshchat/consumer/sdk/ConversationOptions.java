/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.annotation.Nullable
 *  com.freshchat.consumer.sdk.j.k
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Collection
 */
package com.freshchat.consumer.sdk;

import androidx.annotation.Nullable;
import com.freshchat.consumer.sdk.j.k;
import com.freshchat.consumer.sdk.j.z;
import java.util.ArrayList;
import java.util.Collection;

public class ConversationOptions
implements z {
    private String filteredViewTitle;
    private Collection<String> tags = new ArrayList();

    public ConversationOptions filterByTags(@Nullable Collection<String> collection, @Nullable String string) {
        this.tags.clear();
        if (k.b(collection)) {
            this.tags.addAll(k.d(collection));
            this.filteredViewTitle = string;
        }
        return this;
    }

    public String getFilteredViewTitle() {
        return this.filteredViewTitle;
    }

    public Collection<String> getTags() {
        ArrayList arrayList = new ArrayList();
        if (k.b(this.tags)) {
            arrayList.addAll(this.tags);
        }
        return arrayList;
    }
}

