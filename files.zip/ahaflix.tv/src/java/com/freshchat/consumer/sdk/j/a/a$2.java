/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Process
 *  com.freshchat.consumer.sdk.j.a.a
 *  com.freshchat.consumer.sdk.j.a.a$1
 *  com.freshchat.consumer.sdk.j.a.a$e
 *  java.lang.Exception
 *  java.lang.Object
 */
package com.freshchat.consumer.sdk.j.a;

import android.os.Process;
import com.freshchat.consumer.sdk.j.a.a;

public class a$2
extends a.e<Params, Result> {
    public final /* synthetic */ a iU;

    public a$2(a a2) {
        this.iU = a2;
        super(null);
    }

    public Result call() throws Exception {
        a.a((a)this.iU).set(true);
        Process.setThreadPriority((int)10);
        a a2 = this.iU;
        return (Result)a.a((a)a2, (Object)a2.doInBackground(this.jg));
    }
}

