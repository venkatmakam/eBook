/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  com.freshchat.consumer.sdk.Event
 *  com.freshchat.consumer.sdk.Event$EventName
 *  com.freshchat.consumer.sdk.Event$Property
 *  com.freshchat.consumer.sdk.beans.Channel
 *  com.freshchat.consumer.sdk.beans.Conversation
 *  com.freshchat.consumer.sdk.j.bg
 *  com.freshchat.consumer.sdk.j.bg$a
 *  com.freshchat.consumer.sdk.j.bg$b
 *  java.lang.Object
 *  java.lang.String
 */
package com.freshchat.consumer.sdk.j;

import android.content.Context;
import com.freshchat.consumer.sdk.Event;
import com.freshchat.consumer.sdk.beans.Channel;
import com.freshchat.consumer.sdk.beans.Conversation;
import com.freshchat.consumer.sdk.j.bg;

public final class bn
implements bg.b {
    public final /* synthetic */ long fk;
    public final /* synthetic */ Context iI;

    public bn(Context context, long l) {
        this.iI = context;
        this.fk = l;
    }

    public Event gy() {
        bg.a a2 = bg.b((Event.EventName)Event.EventName.FCEventMessageSent);
        Channel channel = bg.m((Context)this.iI, (long)this.fk);
        if (channel != null) {
            bg.a.a((bg.a)bg.a.a((bg.a)a2, (Event.Property)Event.Property.FCPropertyChannelID, (Object)channel.getChannelAlias()), (Event.Property)Event.Property.FCPropertyChannelName, (Object)channel.getName());
            Conversation conversation = bg.n((Context)this.iI, (long)this.fk);
            if (conversation != null) {
                bg.a.a((bg.a)a2, (Event.Property)Event.Property.FCPropertyConversationID, (Object)conversation.getConversationId());
            }
        }
        return bg.a.a((bg.a)a2);
    }
}

