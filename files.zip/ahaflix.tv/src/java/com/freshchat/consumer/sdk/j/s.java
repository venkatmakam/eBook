/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  androidx.annotation.Nullable
 *  com.freshchat.consumer.sdk.j.af
 *  com.freshchat.consumer.sdk.j.q
 *  com.squareup.picasso.Transformation
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 */
package com.freshchat.consumer.sdk.j;

import android.graphics.Bitmap;
import androidx.annotation.Nullable;
import com.freshchat.consumer.sdk.j.af;
import com.freshchat.consumer.sdk.j.q;
import com.squareup.picasso.Transformation;

public class s
implements Transformation {
    public String key() {
        return "circularly_cropped_bitmap";
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Nullable
    public Bitmap transform(Bitmap bitmap) {
        boolean bl2;
        Bitmap bitmap2;
        Bitmap bitmap3 = af.a((Bitmap)bitmap);
        if (bitmap3 == null) {
            bitmap2 = bitmap;
            bl2 = false;
        } else {
            bitmap2 = bitmap3;
            bl2 = true;
        }
        if (!bl2) return bitmap2;
        bitmap.recycle();
        return bitmap2;
        {
            catch (Throwable throwable) {
                throw throwable;
            }
            catch (Exception exception) {}
            {
                q.a((Throwable)exception);
                return null;
            }
        }
    }
}

