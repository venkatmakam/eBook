/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  androidx.annotation.NonNull
 *  androidx.annotation.Nullable
 *  com.freshchat.consumer.sdk.activity.ChannelListActivity
 *  com.freshchat.consumer.sdk.activity.ConversationDetailActivity
 *  com.freshchat.consumer.sdk.activity.InterstitialActivity
 *  com.freshchat.consumer.sdk.beans.Channel
 *  com.freshchat.consumer.sdk.j.c
 *  com.freshchat.consumer.sdk.j.k
 *  com.freshchat.consumer.sdk.j.l
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 */
package com.freshchat.consumer.sdk.j;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.freshchat.consumer.sdk.ConversationOptions;
import com.freshchat.consumer.sdk.activity.ChannelListActivity;
import com.freshchat.consumer.sdk.activity.ConversationDetailActivity;
import com.freshchat.consumer.sdk.activity.InterstitialActivity;
import com.freshchat.consumer.sdk.beans.Channel;
import com.freshchat.consumer.sdk.j.c;
import com.freshchat.consumer.sdk.j.k;
import com.freshchat.consumer.sdk.j.l;
import com.freshchat.consumer.sdk.j.z;
import java.util.List;

public class m
extends c<ConversationOptions> {
    public void c(@NonNull Channel channel) {
        if (channel != null) {
            this.a(ConversationDetailActivity.class);
            Bundle bundle = new Bundle();
            bundle.putLong("CHANNEL_ID", channel.getId());
            bundle.putString("CHANNEL_NAME", channel.getName());
            bundle.putString("CHANNEL_TYPE", channel.getChannelType());
            this.b(bundle);
        }
    }

    public void ea() {
        this.ev();
    }

    public Bundle eb() {
        Bundle bundle = new Bundle();
        bundle.putAll(l.a((ConversationOptions)((ConversationOptions)this.ec())));
        bundle.putString("OPTIONS_TYPE", ConversationOptions.class.getSimpleName());
        return bundle;
    }

    public void eu() {
        this.a(ChannelListActivity.class);
        this.b(null);
    }

    public void ev() {
        this.a(InterstitialActivity.class);
        this.b(null);
    }

    public void u(@Nullable List<Channel> list) {
        if (k.c(list) == 1 && list.get(0) != null) {
            this.c((Channel)list.get(0));
            return;
        }
        this.eu();
    }
}

