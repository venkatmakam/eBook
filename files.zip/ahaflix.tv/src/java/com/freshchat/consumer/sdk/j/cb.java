/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.freshchat.consumer.sdk.beans.UserEvent
 *  com.freshchat.consumer.sdk.j.by
 *  com.freshchat.consumer.sdk.j.by$a
 *  com.google.gson.reflect.TypeToken
 *  java.lang.String
 *  java.util.LinkedHashMap
 */
package com.freshchat.consumer.sdk.j;

import com.freshchat.consumer.sdk.beans.UserEvent;
import com.freshchat.consumer.sdk.j.by;
import com.google.gson.reflect.TypeToken;
import java.util.LinkedHashMap;

public class cb
extends TypeToken<LinkedHashMap<String, UserEvent>> {
    public final /* synthetic */ by.a mQ;

    public cb(by.a a2) {
        this.mQ = a2;
    }
}

