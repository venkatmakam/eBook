/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  com.freshchat.consumer.sdk.Event
 *  com.freshchat.consumer.sdk.Event$EventName
 *  com.freshchat.consumer.sdk.Event$Property
 *  com.freshchat.consumer.sdk.beans.Category
 *  com.freshchat.consumer.sdk.j.as
 *  com.freshchat.consumer.sdk.j.bg
 *  com.freshchat.consumer.sdk.j.bg$a
 *  com.freshchat.consumer.sdk.j.bg$b
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Arrays
 */
package com.freshchat.consumer.sdk.j;

import android.content.Context;
import com.freshchat.consumer.sdk.Event;
import com.freshchat.consumer.sdk.beans.Category;
import com.freshchat.consumer.sdk.j.as;
import com.freshchat.consumer.sdk.j.bg;
import java.util.Arrays;

public final class bq
implements bg.b {
    public final /* synthetic */ Context iI;
    public final /* synthetic */ String lM;
    public final /* synthetic */ String lP;
    public final /* synthetic */ String[] lS;

    public bq(String string2, Context context, String string3, String[] arrstring) {
        this.lM = string2;
        this.iI = context;
        this.lP = string3;
        this.lS = arrstring;
    }

    public Event gy() {
        bg.a a2 = bg.a.a((bg.a)bg.b((Event.EventName)Event.EventName.FCEventFAQListOpen), (Event.Property)Event.Property.FCPropertyFAQCategoryName, (Object)this.lM);
        Category category = bg.B((Context)this.iI, (String)this.lP);
        if (category != null) {
            bg.a.a((bg.a)a2, (Event.Property)Event.Property.FCPropertyFAQCategoryID, (Object)category.getCategoryAlias());
        }
        if (as.f((String[])this.lS)) {
            bg.a.a((bg.a)a2, (Event.Property)Event.Property.FCPropertyInputTags, (Object)Arrays.toString((Object[])this.lS));
        }
        return bg.a.a((bg.a)a2);
    }
}

