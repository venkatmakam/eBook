/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Bitmap
 *  android.net.Uri
 *  android.widget.ImageView
 *  androidx.annotation.NonNull
 *  androidx.annotation.Nullable
 *  androidx.annotation.WorkerThread
 *  com.freshchat.consumer.sdk.FreshchatImageLoader
 *  com.freshchat.consumer.sdk.FreshchatImageLoaderRequest
 *  com.freshchat.consumer.sdk.FreshchatImageLoaderRequest$TransformType
 *  com.freshchat.consumer.sdk.b.c
 *  com.freshchat.consumer.sdk.j.ai
 *  com.freshchat.consumer.sdk.j.ba
 *  com.freshchat.consumer.sdk.j.q
 *  com.squareup.picasso.Picasso
 *  com.squareup.picasso.RequestCreator
 *  com.squareup.picasso.Transformation
 *  e.a.a.a.a
 *  java.io.IOException
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 */
package com.freshchat.consumer.sdk.j;

import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.WorkerThread;
import com.freshchat.consumer.sdk.FreshchatImageLoader;
import com.freshchat.consumer.sdk.FreshchatImageLoaderRequest;
import com.freshchat.consumer.sdk.b.c;
import com.freshchat.consumer.sdk.j.ai;
import com.freshchat.consumer.sdk.j.ba;
import com.freshchat.consumer.sdk.j.q;
import com.freshchat.consumer.sdk.j.s;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.RequestCreator;
import com.squareup.picasso.Transformation;
import e.a.a.a.a;
import java.io.IOException;

public class t
implements FreshchatImageLoader {
    @Nullable
    private final Picasso la;

    /*
     * Exception decompiling
     */
    public t(@NonNull Context var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl18 : ALOAD_0 : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    private void a(@NonNull FreshchatImageLoaderRequest freshchatImageLoaderRequest, @NonNull String string2) {
        if (freshchatImageLoaderRequest != null) {
            return;
        }
        throw new IllegalArgumentException(a.h1((String)"FreshchatImageLoaderRequest instance must not be null in ", (String)string2));
    }

    @Nullable
    public static t bu(@NonNull Context context) {
        if (ba.fZ()) {
            ai.k((String)"FRESHCHAT_WARNING", (String)c.kY.toString());
            return null;
        }
        return new t(context);
    }

    @WorkerThread
    public void fetch(@NonNull FreshchatImageLoaderRequest freshchatImageLoaderRequest) {
        this.a(freshchatImageLoaderRequest, "fetch");
        Picasso picasso = this.la;
        if (picasso == null) {
            ai.k((String)"FRESHCHAT", (String)c.kK.toString());
            return;
        }
        picasso.load(freshchatImageLoaderRequest.getUri()).fetch();
    }

    @Nullable
    public Bitmap get(@NonNull FreshchatImageLoaderRequest freshchatImageLoaderRequest) {
        this.a(freshchatImageLoaderRequest, "get");
        Picasso picasso = this.la;
        if (picasso == null) {
            ai.k((String)"FRESHCHAT", (String)c.kK.toString());
            return null;
        }
        try {
            Bitmap bitmap = picasso.load(freshchatImageLoaderRequest.getUri()).get();
            return bitmap;
        }
        catch (IOException iOException) {
            q.a((Throwable)iOException);
            return null;
        }
    }

    public void load(@NonNull FreshchatImageLoaderRequest freshchatImageLoaderRequest, @NonNull ImageView imageView) {
        if (imageView != null) {
            this.a(freshchatImageLoaderRequest, "load");
            Picasso picasso = this.la;
            if (picasso == null) {
                ai.k((String)"FRESHCHAT", (String)c.kK.toString());
                return;
            }
            RequestCreator requestCreator = picasso.load(freshchatImageLoaderRequest.getUri());
            if (freshchatImageLoaderRequest.getTargetHeight() != 0 || freshchatImageLoaderRequest.getTargetWidth() != 0) {
                requestCreator.resize(freshchatImageLoaderRequest.getTargetWidth(), freshchatImageLoaderRequest.getTargetHeight());
                if (freshchatImageLoaderRequest.shouldMaintainAspectRatio()) {
                    requestCreator.centerInside();
                }
            }
            if (freshchatImageLoaderRequest.getTransformToApply() == FreshchatImageLoaderRequest.TransformType.CIRCULAR) {
                requestCreator.transform((Transformation)new s());
            }
            requestCreator.into(imageView);
            return;
        }
        throw new IllegalArgumentException("Target must not be null.");
    }
}

