/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.freshchat.consumer.sdk.Event
 *  com.freshchat.consumer.sdk.Event$EventName
 *  com.freshchat.consumer.sdk.Event$Property
 *  com.freshchat.consumer.sdk.j.bg
 *  com.freshchat.consumer.sdk.j.bg$a
 *  com.freshchat.consumer.sdk.j.bg$b
 *  java.lang.Object
 *  java.lang.String
 */
package com.freshchat.consumer.sdk.j;

import com.freshchat.consumer.sdk.Event;
import com.freshchat.consumer.sdk.j.bg;

public final class bs
implements bg.b {
    public final /* synthetic */ String lU;
    public final /* synthetic */ int lV;
    public final /* synthetic */ boolean lW;

    public bs(String string2, int n2, boolean bl2) {
        this.lU = string2;
        this.lV = n2;
        this.lW = bl2;
    }

    public Event gy() {
        return bg.a.a((bg.a)bg.a.a((bg.a)bg.a.a((bg.a)bg.a.a((bg.a)bg.b((Event.EventName)Event.EventName.FCEventFAQSearch), (Event.Property)Event.Property.FCPropertySearchKey, (Object)this.lU), (Event.Property)Event.Property.FCPropertySearchFAQCount, (Object)this.lV), (Event.Property)Event.Property.FCPropertyIsRelevant, (Object)this.lW));
    }
}

