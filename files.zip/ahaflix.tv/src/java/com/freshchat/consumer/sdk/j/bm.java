/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  com.freshchat.consumer.sdk.Event
 *  com.freshchat.consumer.sdk.Event$EventName
 *  com.freshchat.consumer.sdk.Event$Property
 *  com.freshchat.consumer.sdk.beans.Article
 *  com.freshchat.consumer.sdk.beans.Category
 *  com.freshchat.consumer.sdk.j.as
 *  com.freshchat.consumer.sdk.j.bg
 *  com.freshchat.consumer.sdk.j.bg$a
 *  com.freshchat.consumer.sdk.j.bg$b
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Arrays
 */
package com.freshchat.consumer.sdk.j;

import android.content.Context;
import com.freshchat.consumer.sdk.Event;
import com.freshchat.consumer.sdk.beans.Article;
import com.freshchat.consumer.sdk.beans.Category;
import com.freshchat.consumer.sdk.j.as;
import com.freshchat.consumer.sdk.j.bg;
import java.util.Arrays;

public final class bm
implements bg.b {
    public final /* synthetic */ Context iI;
    public final /* synthetic */ String lM;
    public final /* synthetic */ String lN;
    public final /* synthetic */ String lP;
    public final /* synthetic */ String lQ;
    public final /* synthetic */ String[] lS;

    public bm(String string2, String string3, Context context, String string4, String string5, String[] arrstring) {
        this.lN = string2;
        this.lM = string3;
        this.iI = context;
        this.lP = string4;
        this.lQ = string5;
        this.lS = arrstring;
    }

    public Event gy() {
        Article article;
        bg.a a2 = bg.a.a((bg.a)bg.a.a((bg.a)bg.b((Event.EventName)Event.EventName.FCEventFAQOpen), (Event.Property)Event.Property.FCPropertyFAQTitle, (Object)this.lN), (Event.Property)Event.Property.FCPropertyFAQCategoryName, (Object)this.lM);
        Category category = bg.B((Context)this.iI, (String)this.lP);
        if (category != null) {
            bg.a.a((bg.a)a2, (Event.Property)Event.Property.FCPropertyFAQCategoryID, (Object)category.getCategoryAlias());
        }
        if ((article = bg.C((Context)this.iI, (String)this.lQ)) != null) {
            bg.a.a((bg.a)a2, (Event.Property)Event.Property.FCPropertyFAQID, (Object)article.getArticleAlias());
        }
        if (as.f((String[])this.lS)) {
            bg.a.a((bg.a)a2, (Event.Property)Event.Property.FCPropertyInputTags, (Object)Arrays.toString((Object[])this.lS));
        }
        return bg.a.a((bg.a)a2);
    }
}

