/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  com.freshchat.consumer.sdk.Event
 *  com.freshchat.consumer.sdk.Event$EventName
 *  com.freshchat.consumer.sdk.Event$Property
 *  com.freshchat.consumer.sdk.beans.Article
 *  com.freshchat.consumer.sdk.beans.Category
 *  com.freshchat.consumer.sdk.j.bg
 *  com.freshchat.consumer.sdk.j.bg$a
 *  com.freshchat.consumer.sdk.j.bg$b
 *  com.freshchat.consumer.sdk.service.e.n
 *  com.freshchat.consumer.sdk.service.e.n$a
 *  java.lang.Object
 *  java.lang.String
 */
package com.freshchat.consumer.sdk.j;

import android.content.Context;
import com.freshchat.consumer.sdk.Event;
import com.freshchat.consumer.sdk.beans.Article;
import com.freshchat.consumer.sdk.beans.Category;
import com.freshchat.consumer.sdk.j.bg;
import com.freshchat.consumer.sdk.service.e.n;

public final class bh
implements bg.b {
    public final /* synthetic */ Context iI;
    public final /* synthetic */ String lM;
    public final /* synthetic */ String lN;
    public final /* synthetic */ n.a lO;
    public final /* synthetic */ String lP;
    public final /* synthetic */ String lQ;

    public bh(String string2, String string3, n.a a2, Context context, String string4, String string5) {
        this.lM = string2;
        this.lN = string3;
        this.lO = a2;
        this.iI = context;
        this.lP = string4;
        this.lQ = string5;
    }

    public Event gy() {
        Article article;
        bg.a a2 = bg.a.a((bg.a)bg.a.a((bg.a)bg.b((Event.EventName)Event.EventName.FCEventFAQVote), (Event.Property)Event.Property.FCPropertyFAQCategoryName, (Object)this.lM), (Event.Property)Event.Property.FCPropertyFAQTitle, (Object)this.lN);
        Event.Property property = Event.Property.FCPropertyIsHelpful;
        boolean bl2 = this.lO == n.a.gv;
        bg.a a3 = bg.a.a((bg.a)a2, (Event.Property)property, (Object)bl2);
        Category category = bg.B((Context)this.iI, (String)this.lP);
        if (category != null) {
            bg.a.a((bg.a)a3, (Event.Property)Event.Property.FCPropertyFAQCategoryID, (Object)category.getCategoryAlias());
        }
        if ((article = bg.C((Context)this.iI, (String)this.lQ)) != null) {
            bg.a.a((bg.a)a3, (Event.Property)Event.Property.FCPropertyFAQID, (Object)article.getArticleAlias());
        }
        return bg.a.a((bg.a)a3);
    }
}

