/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  com.freshchat.consumer.sdk.Event
 *  com.freshchat.consumer.sdk.Event$EventName
 *  com.freshchat.consumer.sdk.Event$Property
 *  com.freshchat.consumer.sdk.beans.Channel
 *  com.freshchat.consumer.sdk.j.bg
 *  com.freshchat.consumer.sdk.j.bg$a
 *  com.freshchat.consumer.sdk.j.bg$b
 *  java.lang.Object
 *  java.lang.String
 */
package com.freshchat.consumer.sdk.j;

import android.content.Context;
import com.freshchat.consumer.sdk.Event;
import com.freshchat.consumer.sdk.beans.Channel;
import com.freshchat.consumer.sdk.j.bg;

public final class bk
implements bg.b {
    public final /* synthetic */ long fk;
    public final /* synthetic */ Context iI;
    public final /* synthetic */ long lR;

    public bk(long l, Context context, long l2) {
        this.lR = l;
        this.iI = context;
        this.fk = l2;
    }

    public Event gy() {
        bg.a a2 = bg.a.a((bg.a)bg.b((Event.EventName)Event.EventName.FCEventNotificationReceive), (Event.Property)Event.Property.FCPropertyConversationID, (Object)this.lR);
        Channel channel = bg.m((Context)this.iI, (long)this.fk);
        if (channel != null) {
            bg.a.a((bg.a)bg.a.a((bg.a)a2, (Event.Property)Event.Property.FCPropertyChannelID, (Object)channel.getChannelAlias()), (Event.Property)Event.Property.FCPropertyChannelName, (Object)channel.getName());
        }
        return bg.a.a((bg.a)a2);
    }
}

