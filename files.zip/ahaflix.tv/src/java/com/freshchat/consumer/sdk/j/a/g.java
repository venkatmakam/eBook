/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Bitmap
 *  android.net.ConnectivityManager
 *  android.net.NetworkInfo
 *  com.freshchat.consumer.sdk.R
 *  com.freshchat.consumer.sdk.R$string
 *  com.freshchat.consumer.sdk.b.i
 *  com.freshchat.consumer.sdk.j.a.b
 *  com.freshchat.consumer.sdk.j.a.d
 *  com.freshchat.consumer.sdk.j.a.f
 *  com.freshchat.consumer.sdk.j.ad
 *  com.freshchat.consumer.sdk.j.ai
 *  com.freshchat.consumer.sdk.j.as
 *  com.freshchat.consumer.sdk.j.q
 *  com.google.firebase.perf.network.FirebasePerfUrlConnection
 *  java.io.BufferedInputStream
 *  java.io.BufferedOutputStream
 *  java.io.Closeable
 *  java.io.File
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.OutputStream
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.net.HttpURLConnection
 *  java.net.URL
 *  java.net.URLConnection
 */
package com.freshchat.consumer.sdk.j.a;

import android.content.Context;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import com.freshchat.consumer.sdk.R;
import com.freshchat.consumer.sdk.b.i;
import com.freshchat.consumer.sdk.j.a.b;
import com.freshchat.consumer.sdk.j.a.d;
import com.freshchat.consumer.sdk.j.a.e;
import com.freshchat.consumer.sdk.j.a.f;
import com.freshchat.consumer.sdk.j.ad;
import com.freshchat.consumer.sdk.j.ai;
import com.freshchat.consumer.sdk.j.as;
import com.freshchat.consumer.sdk.j.q;
import com.google.firebase.perf.network.FirebasePerfUrlConnection;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;

public class g
extends e {
    private static b jW;
    private static File jX;
    private static boolean jY = true;
    private static final Object jZ;
    private static g lv;

    public static {
        jZ = new Object();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public g(Context context, int n) {
        super(context, n);
        if (lv != null) {
            return;
        }
        Class<g> class_ = g.class;
        synchronized (g.class) {
            if (lv == null) {
                lv = this;
                this.d(context);
            }
            // ** MonitorExit[var4_3] (shouldn't be in output)
            return;
        }
    }

    /*
     * Exception decompiling
     */
    private Bitmap aW(String var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Underrun type stack
        // org.benf.cfr.reader.b.a.c.e.a(StackSim.java:35)
        // org.benf.cfr.reader.b.b.af.a(OperationFactoryPop.java:20)
        // org.benf.cfr.reader.b.b.e.a(JVMInstr.java:315)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:195)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    private void bi(Context context) {
        NetworkInfo networkInfo = ((ConnectivityManager)context.getSystemService("connectivity")).getActiveNetworkInfo();
        if (networkInfo == null || !networkInfo.isConnectedOrConnecting()) {
            i.a((Context)context, (int)R.string.freshchat_error_message_not_connected_to_internet);
        }
    }

    private void d(Context context) {
        this.bi(context);
        jX = d.y((Context)context, (String)"http");
    }

    /*
     * Exception decompiling
     */
    private void fn() {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl33 : ICONST_0 : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    public static void fo() {
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public boolean a(String string2, OutputStream outputStream) {
        void var8_11;
        URLConnection uRLConnection;
        BufferedInputStream bufferedInputStream;
        BufferedOutputStream bufferedOutputStream;
        block21 : {
            block22 : {
                URLConnection uRLConnection2;
                block20 : {
                    block19 : {
                        if (as.isEmpty((CharSequence)string2)) {
                            return false;
                        }
                        g.fo();
                        uRLConnection = null;
                        uRLConnection2 = (URLConnection)FirebasePerfUrlConnection.instrument((Object)new URL(string2).openConnection());
                        bufferedInputStream = new BufferedInputStream(uRLConnection2.getInputStream(), 8192);
                        bufferedOutputStream = new BufferedOutputStream(outputStream, 8192);
                        try {
                            int n;
                            while ((n = bufferedInputStream.read()) != -1) {
                                bufferedOutputStream.write(n);
                            }
                        }
                        catch (Throwable throwable) {
                            break block19;
                        }
                        catch (IOException iOException) {
                            break block20;
                        }
                        if (uRLConnection2 instanceof HttpURLConnection) {
                            ((HttpURLConnection)uRLConnection2).disconnect();
                        }
                        ad.a((Closeable[])new Closeable[]{bufferedInputStream, bufferedOutputStream});
                        return true;
                        catch (Throwable throwable) {
                            bufferedOutputStream = null;
                            break block19;
                        }
                        catch (IOException iOException) {
                            bufferedOutputStream = null;
                            break block20;
                        }
                        catch (Throwable throwable) {
                            bufferedInputStream = null;
                            bufferedOutputStream = null;
                        }
                    }
                    uRLConnection = uRLConnection2;
                    break block21;
                    catch (IOException iOException) {
                        bufferedInputStream = null;
                        bufferedOutputStream = null;
                    }
                }
                uRLConnection = uRLConnection2;
                break block22;
                catch (Throwable throwable) {
                    uRLConnection = null;
                    bufferedInputStream = null;
                    bufferedOutputStream = null;
                    break block21;
                }
                catch (IOException iOException) {
                    bufferedInputStream = null;
                    bufferedOutputStream = null;
                }
            }
            try {
                void var4_17;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Failed to load URL ");
                stringBuilder.append(string2);
                ai.i((String)"FRESHCHAT", (String)stringBuilder.toString());
                q.a((Throwable)var4_17);
            }
            catch (Throwable throwable) {
                // empty catch block
            }
            if (uRLConnection != null && uRLConnection instanceof HttpURLConnection) {
                ((HttpURLConnection)uRLConnection).disconnect();
            }
            ad.a((Closeable[])new Closeable[]{bufferedInputStream, bufferedOutputStream});
            return false;
        }
        if (uRLConnection != null && uRLConnection instanceof HttpURLConnection) {
            ((HttpURLConnection)uRLConnection).disconnect();
        }
        ad.a((Closeable[])new Closeable[]{bufferedInputStream, bufferedOutputStream});
        throw var8_11;
    }

    @Override
    public Bitmap d(Object object) {
        return this.aW(String.valueOf((Object)object));
    }

    public void fp() {
        f.super.fp();
        this.fn();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void fr() {
        Object object;
        f.super.fr();
        Object object2 = object = jZ;
        synchronized (object2) {
            boolean bl2;
            b b2 = jW;
            if (b2 != null && !(bl2 = b2.isClosed())) {
                try {
                    jW.delete();
                    ai.i((String)"ImageFetcher", (String)"HTTP cache cleared");
                }
                catch (IOException iOException) {
                    q.a((Throwable)iOException);
                }
                jW = null;
                jY = true;
                this.fn();
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void fs() {
        Object object;
        f.super.fs();
        Object object2 = object = jZ;
        synchronized (object2) {
            b b2 = jW;
            if (b2 != null) {
                try {
                    b2.flush();
                    ai.i((String)"ImageFetcher", (String)"HTTP cache flushed");
                }
                catch (IOException iOException) {
                    q.a((Throwable)iOException);
                }
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void ft() {
        Object object;
        f.super.ft();
        Object object2 = object = jZ;
        synchronized (object2) {
            b b2 = jW;
            if (b2 != null) {
                try {
                    if (!b2.isClosed()) {
                        jW.close();
                        jW = null;
                        ai.i((String)"ImageFetcher", (String)"HTTP cache closed");
                    }
                }
                catch (IOException iOException) {
                    q.a((Throwable)iOException);
                }
            }
            return;
        }
    }
}

