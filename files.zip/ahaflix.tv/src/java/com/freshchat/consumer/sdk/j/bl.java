/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 *  com.freshchat.consumer.sdk.Event
 *  com.freshchat.consumer.sdk.Event$EventName
 *  com.freshchat.consumer.sdk.Event$Property
 *  com.freshchat.consumer.sdk.j.bg
 *  com.freshchat.consumer.sdk.j.bg$a
 *  com.freshchat.consumer.sdk.j.bg$b
 *  java.lang.Object
 *  java.lang.String
 */
package com.freshchat.consumer.sdk.j;

import android.net.Uri;
import com.freshchat.consumer.sdk.Event;
import com.freshchat.consumer.sdk.j.bg;

public final class bl
implements bg.b {
    public final /* synthetic */ Uri iD;

    public bl(Uri uri) {
        this.iD = uri;
    }

    public Event gy() {
        return bg.a.a((bg.a)bg.a.a((bg.a)bg.b((Event.EventName)Event.EventName.FCEventLinkTap), (Event.Property)Event.Property.FCPropertyURL, (Object)this.iD.toString()));
    }
}

