/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  com.freshchat.consumer.sdk.Event
 *  com.freshchat.consumer.sdk.Event$EventName
 *  com.freshchat.consumer.sdk.Event$Property
 *  com.freshchat.consumer.sdk.beans.Channel
 *  com.freshchat.consumer.sdk.beans.Conversation
 *  com.freshchat.consumer.sdk.j.as
 *  com.freshchat.consumer.sdk.j.bg
 *  com.freshchat.consumer.sdk.j.bg$a
 *  com.freshchat.consumer.sdk.j.bg$b
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 */
package com.freshchat.consumer.sdk.j;

import android.content.Context;
import com.freshchat.consumer.sdk.Event;
import com.freshchat.consumer.sdk.beans.Channel;
import com.freshchat.consumer.sdk.beans.Conversation;
import com.freshchat.consumer.sdk.j.as;
import com.freshchat.consumer.sdk.j.bg;

public final class bx
implements bg.b {
    public final /* synthetic */ boolean bq;
    public final /* synthetic */ long fk;
    public final /* synthetic */ Context iI;
    public final /* synthetic */ int lY;
    public final /* synthetic */ String lZ;

    public bx(Context context, long l, boolean bl2, int n2, String string2) {
        this.iI = context;
        this.fk = l;
        this.bq = bl2;
        this.lY = n2;
        this.lZ = string2;
    }

    public Event gy() {
        int n2;
        bg.a a2 = bg.b((Event.EventName)Event.EventName.FCEventCsatSubmit);
        Channel channel = bg.m((Context)this.iI, (long)this.fk);
        if (channel != null) {
            bg.a.a((bg.a)bg.a.a((bg.a)a2, (Event.Property)Event.Property.FCPropertyChannelID, (Object)channel.getChannelAlias()), (Event.Property)Event.Property.FCPropertyChannelName, (Object)channel.getName());
            Conversation conversation = bg.n((Context)this.iI, (long)channel.getId());
            if (conversation != null) {
                bg.a.a((bg.a)bg.a.a((bg.a)a2, (Event.Property)Event.Property.FCPropertyConversationID, (Object)conversation.getConversationId()), (Event.Property)Event.Property.FCPropertyResolutionStatus, (Object)this.bq);
            }
        }
        if ((n2 = this.lY) > 0) {
            bg.a.a((bg.a)a2, (Event.Property)Event.Property.FCPropertyRating, (Object)n2);
        }
        if (as.a((CharSequence)this.lZ)) {
            bg.a.a((bg.a)a2, (Event.Property)Event.Property.FCPropertyComment, (Object)this.lZ);
        }
        return bg.a.a((bg.a)a2);
    }
}

