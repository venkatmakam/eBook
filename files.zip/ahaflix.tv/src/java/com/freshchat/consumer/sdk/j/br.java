/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.freshchat.consumer.sdk.Event
 *  com.freshchat.consumer.sdk.Event$EventName
 *  com.freshchat.consumer.sdk.Event$Property
 *  com.freshchat.consumer.sdk.j.as
 *  com.freshchat.consumer.sdk.j.bg
 *  com.freshchat.consumer.sdk.j.bg$a
 *  com.freshchat.consumer.sdk.j.bg$b
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Arrays
 */
package com.freshchat.consumer.sdk.j;

import com.freshchat.consumer.sdk.Event;
import com.freshchat.consumer.sdk.j.as;
import com.freshchat.consumer.sdk.j.bg;
import java.util.Arrays;

public final class br
implements bg.b {
    public final /* synthetic */ String[] lS;

    public br(String[] arrstring) {
        this.lS = arrstring;
    }

    public Event gy() {
        bg.a a2 = bg.b((Event.EventName)Event.EventName.FCEventFAQCategoryListOpen);
        if (as.f((String[])this.lS)) {
            bg.a.a((bg.a)a2, (Event.Property)Event.Property.FCPropertyInputTags, (Object)Arrays.toString((Object[])this.lS));
        }
        return bg.a.a((bg.a)a2);
    }
}

