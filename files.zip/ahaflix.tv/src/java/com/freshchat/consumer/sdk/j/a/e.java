/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Resources
 *  android.graphics.Bitmap
 *  android.graphics.BitmapFactory
 *  android.graphics.BitmapFactory$Options
 *  com.freshchat.consumer.sdk.j.a.f
 *  com.freshchat.consumer.sdk.j.ai
 *  java.io.FileDescriptor
 *  java.lang.Boolean
 *  java.lang.Integer
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.freshchat.consumer.sdk.j.a;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import com.freshchat.consumer.sdk.j.a.f;
import com.freshchat.consumer.sdk.j.ai;
import java.io.FileDescriptor;

public class e
extends f {
    public int ka;
    public int kb;

    public e(Context context, int n) {
        super(context);
        this.A(n);
    }

    private Bitmap B(int n) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("processBitmap - ");
        stringBuilder.append(n);
        ai.i((String)"ImageResizer", (String)stringBuilder.toString());
        return e.a(this.kj, n, this.ka, this.kb);
    }

    public static int a(BitmapFactory.Options options, int n, int n2) {
        float f2;
        float f3;
        int n3 = options.outHeight;
        int n4 = options.outWidth;
        if (n3 <= n2 && n4 <= n) {
            return 1;
        }
        if (n4 > n3) {
            f3 = n3;
            f2 = n2;
        } else {
            f3 = n4;
            f2 = n;
        }
        int n5 = Math.round((float)(f3 / f2));
        float f4 = n4 * n3;
        float f5 = 2 * (n * n2);
        while (f4 / (float)(n5 * n5) > f5) {
            ++n5;
        }
        return n5;
    }

    public static Bitmap a(Resources resources, int n, int n2, int n3) {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeResource((Resources)resources, (int)n, (BitmapFactory.Options)options);
        options.inSampleSize = e.a(options, n2, n3);
        options.inJustDecodeBounds = false;
        return BitmapFactory.decodeResource((Resources)resources, (int)n, (BitmapFactory.Options)options);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static Bitmap a(FileDescriptor var0, int var1_1, int var2_2) {
        block3 : {
            block2 : {
                var3_3 = Boolean.TRUE;
                var4_4 = new BitmapFactory.Options();
                var4_4.inJustDecodeBounds = true;
                BitmapFactory.decodeFileDescriptor((FileDescriptor)var0, null, (BitmapFactory.Options)var4_4);
                var4_4.inSampleSize = e.a(var4_4, var1_1, var2_2);
                var6_5 = var4_4.outHeight;
                var7_6 = var4_4.outWidth;
                var8_7 = Boolean.FALSE;
                if (var6_5 <= var2_2 && var7_6 <= var1_1) ** GOTO lbl-1000
                if (var7_6 <= var6_5) break block2;
                if (2048 >= var7_6) ** GOTO lbl-1000
                var6_5 = Math.round((float)((float)var6_5 * ((float)2048 / (float)var7_6)));
                var7_6 = 2048;
                break block3;
            }
            if (2048 < var6_5) {
                var7_6 = Math.round((float)((float)var7_6 * ((float)2048 / (float)var6_5)));
                var6_5 = 2048;
            } else lbl-1000: // 3 sources:
            {
                var3_3 = var8_7;
            }
        }
        var4_4.inJustDecodeBounds = false;
        var9_8 = BitmapFactory.decodeFileDescriptor((FileDescriptor)var0, null, (BitmapFactory.Options)var4_4);
        if (var3_3 == false) return var9_8;
        return Bitmap.createScaledBitmap((Bitmap)var9_8, (int)var7_6, (int)var6_5, (boolean)false);
    }

    public void A(int n) {
        this.c(n, n);
    }

    public void c(int n, int n2) {
        this.ka = n;
        this.kb = n2;
    }

    public Bitmap d(Object object) {
        return this.B(Integer.parseInt((String)String.valueOf((Object)object)));
    }
}

