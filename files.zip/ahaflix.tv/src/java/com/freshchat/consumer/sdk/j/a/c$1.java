/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  androidx.collection.LruCache
 *  com.freshchat.consumer.sdk.j.a.d
 *  java.lang.Object
 *  java.lang.String
 */
package com.freshchat.consumer.sdk.j.a;

import android.graphics.Bitmap;
import androidx.collection.LruCache;
import com.freshchat.consumer.sdk.j.a.d;

public class c$1
extends LruCache<String, Bitmap> {
    public final /* synthetic */ d jL;

    public c$1(d d2, int n) {
        this.jL = d2;
        super(n);
    }

    public int b(String string, Bitmap bitmap) {
        return d.b((Bitmap)bitmap);
    }

    public /* synthetic */ int sizeOf(Object object, Object object2) {
        return this.b((String)object, (Bitmap)object2);
    }
}

