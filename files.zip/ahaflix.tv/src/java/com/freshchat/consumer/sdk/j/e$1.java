/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.freshchat.consumer.sdk.j.e
 *  com.freshchat.consumer.sdk.service.a
 *  com.freshchat.consumer.sdk.service.e.k
 *  java.lang.Object
 */
package com.freshchat.consumer.sdk.j;

import com.freshchat.consumer.sdk.j.e;
import com.freshchat.consumer.sdk.service.a;
import com.freshchat.consumer.sdk.service.e.k;

public final class e$1
implements a {
    public void a(k k2) {
        if (k2 != null && k2.isSuccess()) {
            e.eg().set(true);
        }
    }
}

