/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.annotation.NonNull
 *  com.urbanairship.UAirship
 *  com.urbanairship.actions.ActionArguments
 *  com.urbanairship.actions.OpenExternalUrlAction
 *  java.lang.String
 */
package com.urbanairship.actions;

import androidx.annotation.NonNull;
import com.urbanairship.UAirship;
import com.urbanairship.actions.ActionArguments;
import com.urbanairship.actions.OpenExternalUrlAction;

public class WalletAction
extends OpenExternalUrlAction {
    @NonNull
    public static final String DEFAULT_REGISTRY_NAME = "wallet_action";
    @NonNull
    public static final String DEFAULT_REGISTRY_SHORT_NAME = "^w";

    public boolean acceptsArguments(@NonNull ActionArguments actionArguments) {
        if (UAirship.shared().getPlatformType() != 2) {
            return false;
        }
        return super.acceptsArguments(actionArguments);
    }
}

