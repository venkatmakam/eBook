/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.annotation.SuppressLint
 *  android.app.AlertDialog
 *  android.app.AlertDialog$Builder
 *  android.app.Application
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnCancelListener
 *  android.content.DialogInterface$OnClickListener
 *  android.content.Intent
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.net.Uri
 *  android.os.Bundle
 *  android.os.Parcelable
 *  android.view.View
 *  androidx.annotation.NonNull
 *  androidx.annotation.Nullable
 *  androidx.fragment.app.FragmentActivity
 *  com.urbanairship.Autopilot
 *  com.urbanairship.Logger
 *  com.urbanairship.R
 *  com.urbanairship.R$string
 *  com.urbanairship.UAirship
 *  com.urbanairship.actions.RateAppActivity$1
 *  com.urbanairship.actions.RateAppActivity$2
 *  com.urbanairship.actions.RateAppActivity$3
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanairship.actions;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Application;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.FragmentActivity;
import com.urbanairship.Autopilot;
import com.urbanairship.Logger;
import com.urbanairship.R;
import com.urbanairship.UAirship;
import com.urbanairship.actions.RateAppActivity;
import com.urbanairship.activity.ThemedActivity;

public class RateAppActivity
extends ThemedActivity {
    private AlertDialog dialog;

    private void displayDialog() {
        AlertDialog alertDialog;
        AlertDialog alertDialog2 = this.dialog;
        if (alertDialog2 != null && alertDialog2.isShowing()) {
            return;
        }
        Intent intent = this.getIntent();
        if (intent == null) {
            Logger.error((String)"RateAppActivity - Started activity with null intent.", (Object[])new Object[0]);
            this.finish();
            return;
        }
        Uri uri = (Uri)intent.getParcelableExtra("store_uri");
        if (uri == null) {
            Logger.error((String)"RateAppActivity - Missing store URI.", (Object[])new Object[0]);
            this.finish();
            return;
        }
        AlertDialog.Builder builder = new AlertDialog.Builder((Context)this);
        if (intent.getStringExtra("title") != null) {
            builder.setTitle((CharSequence)intent.getStringExtra("title"));
        } else {
            int n = R.string.ua_rate_app_action_default_title;
            Object[] arrobject = new Object[]{this.getAppName()};
            builder.setTitle((CharSequence)this.getString(n, arrobject));
        }
        if (intent.getStringExtra("body") != null) {
            builder.setMessage((CharSequence)intent.getStringExtra("body"));
        } else {
            String string2 = this.getString(R.string.ua_rate_app_action_default_rate_positive_button);
            builder.setMessage((CharSequence)this.getString(R.string.ua_rate_app_action_default_body, new Object[]{string2}));
        }
        builder.setPositiveButton((CharSequence)this.getString(R.string.ua_rate_app_action_default_rate_positive_button), (DialogInterface.OnClickListener)new 1(this, uri));
        builder.setNegativeButton((CharSequence)this.getString(R.string.ua_rate_app_action_default_rate_negative_button), (DialogInterface.OnClickListener)new 2(this));
        builder.setOnCancelListener((DialogInterface.OnCancelListener)new 3(this));
        this.dialog = alertDialog = builder.create();
        alertDialog.setCancelable(true);
        this.dialog.show();
    }

    @NonNull
    private String getAppName() {
        String string2 = UAirship.getApplicationContext().getPackageName();
        PackageManager packageManager = UAirship.getApplicationContext().getPackageManager();
        try {
            String string3 = (String)packageManager.getApplicationLabel(packageManager.getApplicationInfo(string2, 128));
            return string3;
        }
        catch (PackageManager.NameNotFoundException nameNotFoundException) {
            return "";
        }
    }

    private void restartActivity(@Nullable Uri uri, @Nullable Bundle bundle) {
        Logger.debug((String)"Relaunching activity", (Object[])new Object[0]);
        this.finish();
        Intent intent = new Intent().setClass((Context)this, this.getClass()).setData(uri).setFlags(268435456);
        if (bundle != null) {
            intent.putExtras(bundle);
        }
        this.startActivity(intent);
    }

    public void onCloseButtonClick(@NonNull View view) {
        this.finish();
    }

    @SuppressLint(value={"NewApi"})
    @Override
    public final void onCreate(@Nullable Bundle bundle) {
        super.onCreate(bundle);
        Autopilot.automaticTakeOff((Application)this.getApplication());
        if (!UAirship.isTakingOff() && !UAirship.isFlying()) {
            Logger.error((String)"RateAppActivity - unable to create activity, takeOff not called.", (Object[])new Object[0]);
            this.finish();
        }
    }

    public void onNewIntent(@NonNull Intent intent) {
        FragmentActivity.super.onNewIntent(intent);
        Logger.debug((String)"RateAppActivity - New intent received for rate app activity", (Object[])new Object[0]);
        this.restartActivity(intent.getData(), intent.getExtras());
    }

    @SuppressLint(value={"NewApi"})
    public void onPause() {
        FragmentActivity.super.onPause();
    }

    @SuppressLint(value={"NewApi"})
    public void onResume() {
        FragmentActivity.super.onResume();
        this.displayDialog();
    }
}

