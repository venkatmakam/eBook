/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.annotation.NonNull
 *  com.urbanairship.Logger
 *  com.urbanairship.UAirship
 *  com.urbanairship.actions.ActionArguments
 *  com.urbanairship.actions.ActionResult
 *  com.urbanairship.actions.tags.BaseTagsAction
 *  com.urbanairship.channel.AirshipChannel
 *  com.urbanairship.channel.TagEditor
 *  com.urbanairship.channel.TagGroupsEditor
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 */
package com.urbanairship.actions.tags;

import androidx.annotation.NonNull;
import com.urbanairship.Logger;
import com.urbanairship.UAirship;
import com.urbanairship.actions.ActionArguments;
import com.urbanairship.actions.ActionResult;
import com.urbanairship.actions.tags.BaseTagsAction;
import com.urbanairship.channel.AirshipChannel;
import com.urbanairship.channel.NamedUser;
import com.urbanairship.channel.TagEditor;
import com.urbanairship.channel.TagGroupsEditor;
import java.util.Map;
import java.util.Set;

public class RemoveTagsAction
extends BaseTagsAction {
    @NonNull
    public static final String DEFAULT_REGISTRY_NAME = "remove_tags_action";
    @NonNull
    public static final String DEFAULT_REGISTRY_SHORT_NAME = "^-t";

    public void b(@NonNull Map<String, Set<String>> map) {
        Logger.info((String)"RemoveTagsAction - Removing channel tag groups: %s", (Object[])new Object[]{map});
        TagGroupsEditor tagGroupsEditor = this.getChannel().editTagGroups();
        for (Map.Entry entry : map.entrySet()) {
            tagGroupsEditor.removeTags((String)entry.getKey(), (Set)entry.getValue());
        }
        tagGroupsEditor.apply();
    }

    public void c(@NonNull Set<String> set) {
        Logger.info((String)"RemoveTagsAction - Removing tags: %s", (Object[])new Object[]{set});
        this.getChannel().editTags().removeTags(set).apply();
    }

    public void d(@NonNull Map<String, Set<String>> map) {
        Logger.info((String)"RemoveTagsAction - Removing named user tag groups: %s", (Object[])new Object[]{map});
        TagGroupsEditor tagGroupsEditor = UAirship.shared().getNamedUser().editTagGroups();
        for (Map.Entry entry : map.entrySet()) {
            tagGroupsEditor.removeTags((String)entry.getKey(), (Set)entry.getValue());
        }
        tagGroupsEditor.apply();
    }
}

