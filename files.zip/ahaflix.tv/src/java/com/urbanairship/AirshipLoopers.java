/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Looper
 *  androidx.annotation.NonNull
 *  com.urbanairship.util.AirshipHandlerThread
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanairship;

import android.os.Looper;
import androidx.annotation.NonNull;
import com.urbanairship.util.AirshipHandlerThread;

public class AirshipLoopers {
    private static Looper backgroundLooper;

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @NonNull
    public static Looper getBackgroundLooper() {
        if (backgroundLooper != null) return backgroundLooper;
        Class<AirshipLoopers> class_ = AirshipLoopers.class;
        synchronized (AirshipLoopers.class) {
            if (backgroundLooper != null) return backgroundLooper;
            AirshipHandlerThread airshipHandlerThread = new AirshipHandlerThread("background");
            airshipHandlerThread.start();
            backgroundLooper = airshipHandlerThread.getLooper();
            // ** MonitorExit[var2] (shouldn't be in output)
            return backgroundLooper;
        }
    }
}

