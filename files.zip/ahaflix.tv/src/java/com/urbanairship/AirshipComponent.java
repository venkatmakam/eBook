/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  androidx.annotation.CallSuper
 *  androidx.annotation.NonNull
 *  androidx.annotation.Nullable
 *  androidx.annotation.RestrictTo
 *  androidx.annotation.RestrictTo$Scope
 *  androidx.annotation.WorkerThread
 *  com.urbanairship.AirshipComponent$1
 *  com.urbanairship.PreferenceDataStore
 *  com.urbanairship.PreferenceDataStore$PreferenceChangeListener
 *  com.urbanairship.UAirship
 *  com.urbanairship.job.JobInfo
 *  com.urbanairship.json.JsonMap
 *  e.a.a.a.a
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.concurrent.Executor
 */
package com.urbanairship;

import android.content.Context;
import androidx.annotation.CallSuper;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import androidx.annotation.WorkerThread;
import com.urbanairship.AirshipComponent;
import com.urbanairship.AirshipExecutors;
import com.urbanairship.PreferenceDataStore;
import com.urbanairship.UAirship;
import com.urbanairship.job.JobInfo;
import com.urbanairship.json.JsonMap;
import e.a.a.a.a;
import java.util.concurrent.Executor;

public abstract class AirshipComponent {
    private static final String ENABLE_KEY_PREFIX = "airshipComponent.enable_";
    private final Context context;
    private final PreferenceDataStore dataStore;
    private final String enableKey;
    private final Executor jobExecutor = AirshipExecutors.newSerialExecutor();

    @RestrictTo(value={RestrictTo.Scope.LIBRARY_GROUP})
    public AirshipComponent(@NonNull Context context, @NonNull PreferenceDataStore preferenceDataStore) {
        this.context = context.getApplicationContext();
        this.dataStore = preferenceDataStore;
        StringBuilder stringBuilder = a.F1((String)ENABLE_KEY_PREFIX);
        stringBuilder.append(this.getClass().getName());
        this.enableKey = stringBuilder.toString();
    }

    public static /* synthetic */ String a(AirshipComponent airshipComponent) {
        return airshipComponent.enableKey;
    }

    @RestrictTo(value={RestrictTo.Scope.LIBRARY_GROUP})
    public int getComponentGroup() {
        return -1;
    }

    @NonNull
    @RestrictTo(value={RestrictTo.Scope.LIBRARY_GROUP})
    public Context getContext() {
        return this.context;
    }

    @NonNull
    @RestrictTo(value={RestrictTo.Scope.LIBRARY_GROUP})
    public PreferenceDataStore getDataStore() {
        return this.dataStore;
    }

    @NonNull
    @RestrictTo(value={RestrictTo.Scope.LIBRARY_GROUP})
    public Executor getJobExecutor(@NonNull JobInfo jobInfo) {
        return this.jobExecutor;
    }

    @CallSuper
    @RestrictTo(value={RestrictTo.Scope.LIBRARY_GROUP})
    public void init() {
        this.dataStore.addListener((PreferenceDataStore.PreferenceChangeListener)new 1(this));
    }

    @RestrictTo(value={RestrictTo.Scope.LIBRARY_GROUP})
    public boolean isComponentEnabled() {
        return this.dataStore.getBoolean(this.enableKey, true);
    }

    @RestrictTo(value={RestrictTo.Scope.LIBRARY_GROUP})
    public boolean isDataCollectionEnabled() {
        return this.dataStore.getBoolean("com.urbanairship.DATA_COLLECTION_ENABLED", true);
    }

    @RestrictTo(value={RestrictTo.Scope.LIBRARY_GROUP})
    @WorkerThread
    public void onAirshipReady(@NonNull UAirship uAirship) {
    }

    @RestrictTo(value={RestrictTo.Scope.LIBRARY_GROUP})
    public void onComponentEnableChange(boolean bl) {
    }

    @RestrictTo(value={RestrictTo.Scope.LIBRARY_GROUP})
    public void onDataCollectionEnabledChanged(boolean bl) {
    }

    @RestrictTo(value={RestrictTo.Scope.LIBRARY_GROUP})
    public void onNewConfig(@Nullable JsonMap jsonMap) {
    }

    @RestrictTo(value={RestrictTo.Scope.LIBRARY_GROUP})
    @WorkerThread
    public int onPerformJob(@NonNull UAirship uAirship, @NonNull JobInfo jobInfo) {
        return 0;
    }

    @RestrictTo(value={RestrictTo.Scope.LIBRARY_GROUP})
    public void setComponentEnabled(boolean bl) {
        this.dataStore.put(this.enableKey, bl);
    }

    @RestrictTo(value={RestrictTo.Scope.LIBRARY_GROUP})
    public void tearDown() {
    }
}

