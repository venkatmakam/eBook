/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Bundle
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.Button
 *  android.widget.ListAdapter
 *  android.widget.ListView
 *  android.widget.SimpleAdapter
 *  android.widget.TextView
 *  androidx.annotation.NonNull
 *  androidx.annotation.Nullable
 *  com.urbanairship.ChannelCaptureActivity$1
 *  com.urbanairship.ChannelCaptureActivity$2
 *  com.urbanairship.ChannelCaptureActivity$3
 *  com.urbanairship.Logger
 *  com.urbanairship.R
 *  com.urbanairship.R$id
 *  com.urbanairship.R$layout
 *  com.urbanairship.UAirship
 *  com.urbanairship.push.PushManager
 *  com.urbanairship.util.UAStringUtil
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.HashMap
 *  java.util.List
 *  java.util.Map
 */
package com.urbanairship;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.urbanairship.ChannelCaptureActivity;
import com.urbanairship.Logger;
import com.urbanairship.R;
import com.urbanairship.UAirship;
import com.urbanairship.activity.ThemedActivity;
import com.urbanairship.channel.NamedUser;
import com.urbanairship.push.PushManager;
import com.urbanairship.util.UAStringUtil;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ChannelCaptureActivity
extends ThemedActivity {
    private static final String NAMED_USER_HEADER = "Named User";
    private static final String USER_NOTIFICATION_ENABLED_HEADER = "User Notifications Enabled";

    private void addChannelAttribute(@NonNull List<Map<String, String>> list, @NonNull String string, @Nullable String string2) {
        if (!UAStringUtil.isEmpty((String)string2)) {
            HashMap hashMap = new HashMap();
            hashMap.put((Object)"header", (Object)string);
            hashMap.put((Object)"data", (Object)string2);
            list.add((Object)hashMap);
        }
    }

    @NonNull
    private List<Map<String, String>> getChannelData() {
        ArrayList arrayList = new ArrayList();
        PushManager pushManager = UAirship.shared().getPushManager();
        this.addChannelAttribute((List<Map<String, String>>)arrayList, NAMED_USER_HEADER, UAirship.shared().getNamedUser().getId());
        this.addChannelAttribute((List<Map<String, String>>)arrayList, USER_NOTIFICATION_ENABLED_HEADER, String.valueOf((boolean)pushManager.getUserNotificationsEnabled()));
        return arrayList;
    }

    @Override
    public void onCreate(@Nullable Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(R.layout.ua_activity_channel_capture);
        Logger.debug((String)"Creating channel capture activity.", (Object[])new Object[0]);
        Intent intent = this.getIntent();
        if (intent == null) {
            Logger.warn((String)"ChannelCaptureActivity - Started activity with null intent", (Object[])new Object[0]);
            this.finish();
            return;
        }
        String string = intent.getStringExtra("channel");
        String string2 = intent.getStringExtra("url");
        ((TextView)this.findViewById(R.id.channel_id)).setText((CharSequence)string);
        ((Button)this.findViewById(R.id.share_button)).setOnClickListener((View.OnClickListener)new 1(this, string));
        ((Button)this.findViewById(R.id.copy_button)).setOnClickListener((View.OnClickListener)new 2(this, string));
        Button button = (Button)this.findViewById(R.id.open_button);
        if (string2 != null) {
            button.setEnabled(true);
            button.setOnClickListener((View.OnClickListener)new 3(this, string2));
        }
        ListView listView = (ListView)this.findViewById(R.id.channel_information);
        SimpleAdapter simpleAdapter = new SimpleAdapter((Context)this, this.getChannelData(), 17367044, new String[]{"header", "data"}, new int[]{16908308, 16908309});
        listView.setAdapter((ListAdapter)simpleAdapter);
    }
}

