/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.annotation.SuppressLint
 *  android.app.Activity
 *  android.content.res.Configuration
 *  android.os.Bundle
 *  android.view.MenuInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  androidx.annotation.LayoutRes
 *  androidx.annotation.NonNull
 *  androidx.annotation.Nullable
 *  androidx.fragment.app.FragmentActivity
 *  com.urbanairship.activity.AppCompatDelegateWrapper
 *  java.lang.Boolean
 *  java.lang.CharSequence
 */
package com.urbanairship.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.LayoutRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.FragmentActivity;
import com.urbanairship.activity.AppCompatDelegateWrapper;

public abstract class ThemedActivity
extends FragmentActivity {
    private static Boolean isAppCompatDependencyAvailable;
    private AppCompatDelegateWrapper delegate;

    @SuppressLint(value={"UnknownNullness"})
    public void addContentView(View view, ViewGroup.LayoutParams layoutParams) {
        AppCompatDelegateWrapper appCompatDelegateWrapper = this.delegate;
        if (appCompatDelegateWrapper != null) {
            appCompatDelegateWrapper.a(view, layoutParams);
            return;
        }
        Activity.super.addContentView(view, layoutParams);
    }

    @NonNull
    public MenuInflater getMenuInflater() {
        AppCompatDelegateWrapper appCompatDelegateWrapper = this.delegate;
        if (appCompatDelegateWrapper != null) {
            return appCompatDelegateWrapper.c();
        }
        return Activity.super.getMenuInflater();
    }

    public void invalidateOptionsMenu() {
        AppCompatDelegateWrapper appCompatDelegateWrapper = this.delegate;
        if (appCompatDelegateWrapper != null) {
            appCompatDelegateWrapper.d();
            return;
        }
        Activity.super.invalidateOptionsMenu();
    }

    public void onConfigurationChanged(@NonNull Configuration configuration) {
        super.onConfigurationChanged(configuration);
        AppCompatDelegateWrapper appCompatDelegateWrapper = this.delegate;
        if (appCompatDelegateWrapper != null) {
            appCompatDelegateWrapper.e(configuration);
        }
    }

    /*
     * Exception decompiling
     */
    public void onCreate(@Nullable Bundle var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl11 : GETSTATIC : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    public void onDestroy() {
        super.onDestroy();
        AppCompatDelegateWrapper appCompatDelegateWrapper = this.delegate;
        if (appCompatDelegateWrapper != null) {
            appCompatDelegateWrapper.g();
        }
    }

    public void onPostCreate(@Nullable Bundle bundle) {
        Activity.super.onPostCreate(bundle);
        AppCompatDelegateWrapper appCompatDelegateWrapper = this.delegate;
        if (appCompatDelegateWrapper != null) {
            appCompatDelegateWrapper.h(bundle);
        }
    }

    public void onPostResume() {
        super.onPostResume();
        AppCompatDelegateWrapper appCompatDelegateWrapper = this.delegate;
        if (appCompatDelegateWrapper != null) {
            appCompatDelegateWrapper.i();
        }
    }

    public void onStop() {
        super.onStop();
        AppCompatDelegateWrapper appCompatDelegateWrapper = this.delegate;
        if (appCompatDelegateWrapper != null) {
            appCompatDelegateWrapper.j();
        }
    }

    @SuppressLint(value={"UnknownNullness"})
    public void onTitleChanged(CharSequence charSequence, int n) {
        Activity.super.onTitleChanged(charSequence, n);
        AppCompatDelegateWrapper appCompatDelegateWrapper = this.delegate;
        if (appCompatDelegateWrapper != null) {
            appCompatDelegateWrapper.n(charSequence);
        }
    }

    public void setContentView(@LayoutRes int n) {
        AppCompatDelegateWrapper appCompatDelegateWrapper = this.delegate;
        if (appCompatDelegateWrapper != null) {
            appCompatDelegateWrapper.k(n);
            return;
        }
        Activity.super.setContentView(n);
    }

    @SuppressLint(value={"UnknownNullness"})
    public void setContentView(View view) {
        AppCompatDelegateWrapper appCompatDelegateWrapper = this.delegate;
        if (appCompatDelegateWrapper != null) {
            appCompatDelegateWrapper.l(view);
            return;
        }
        Activity.super.setContentView(view);
    }

    @SuppressLint(value={"UnknownNullness"})
    public void setContentView(View view, ViewGroup.LayoutParams layoutParams) {
        AppCompatDelegateWrapper appCompatDelegateWrapper = this.delegate;
        if (appCompatDelegateWrapper != null) {
            appCompatDelegateWrapper.m(view, layoutParams);
            return;
        }
        Activity.super.setContentView(view, layoutParams);
    }
}

