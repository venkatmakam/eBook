/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.annotation.NonNull
 *  androidx.annotation.RestrictTo
 *  androidx.annotation.RestrictTo$Scope
 *  com.urbanairship.util.AirshipThreadFactory
 *  com.urbanairship.util.SerialExecutor
 *  java.lang.Object
 *  java.lang.Runtime
 *  java.util.concurrent.BlockingQueue
 *  java.util.concurrent.Executor
 *  java.util.concurrent.ExecutorService
 *  java.util.concurrent.LinkedBlockingQueue
 *  java.util.concurrent.ThreadFactory
 *  java.util.concurrent.ThreadPoolExecutor
 *  java.util.concurrent.TimeUnit
 */
package com.urbanairship;

import androidx.annotation.NonNull;
import androidx.annotation.RestrictTo;
import com.urbanairship.util.AirshipThreadFactory;
import com.urbanairship.util.SerialExecutor;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

@RestrictTo(value={RestrictTo.Scope.LIBRARY_GROUP})
public class AirshipExecutors {
    @NonNull
    public static final ExecutorService THREAD_POOL_EXECUTOR;

    public static {
        int n = 2 * Runtime.getRuntime().availableProcessors();
        ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(2, n, (long)30, TimeUnit.SECONDS, (BlockingQueue)new LinkedBlockingQueue(), (ThreadFactory)AirshipThreadFactory.DEFAULT_THREAD_FACTORY);
        threadPoolExecutor.allowCoreThreadTimeOut(true);
        THREAD_POOL_EXECUTOR = threadPoolExecutor;
    }

    @NonNull
    public static Executor newSerialExecutor() {
        return new SerialExecutor((Executor)THREAD_POOL_EXECUTOR);
    }
}

