/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.net.Uri
 *  androidx.annotation.ColorInt
 *  androidx.annotation.DrawableRes
 *  androidx.annotation.NonNull
 *  androidx.annotation.Nullable
 *  androidx.annotation.RestrictTo
 *  androidx.annotation.RestrictTo$Scope
 *  androidx.annotation.XmlRes
 *  com.urbanairship.Logger
 *  com.urbanairship.push.PushProvider
 *  com.urbanairship.util.ConfigParser
 *  com.urbanairship.util.PropertiesConfigParser
 *  com.urbanairship.util.UAStringUtil
 *  com.urbanairship.util.XmlConfigParser
 *  e.a.a.a.a
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.IllegalArgumentException
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.lang.annotation.Annotation
 *  java.lang.annotation.Retention
 *  java.lang.annotation.RetentionPolicy
 *  java.lang.reflect.Field
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.List
 *  java.util.Properties
 *  java.util.regex.Matcher
 *  java.util.regex.Pattern
 */
package com.urbanairship;

import android.content.Context;
import android.net.Uri;
import androidx.annotation.ColorInt;
import androidx.annotation.DrawableRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import androidx.annotation.XmlRes;
import com.urbanairship.Logger;
import com.urbanairship.push.PushProvider;
import com.urbanairship.util.ConfigParser;
import com.urbanairship.util.PropertiesConfigParser;
import com.urbanairship.util.UAStringUtil;
import com.urbanairship.util.XmlConfigParser;
import e.a.a.a.a;
import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AirshipConfigOptions {
    @NonNull
    public static final String ADM_TRANSPORT = "ADM";
    private static final Pattern APP_CREDENTIAL_PATTERN = Pattern.compile((String)"^[a-zA-Z0-9\\-_]{22}$");
    private static final long DEFAULT_BG_REPORTING_INTERVAL_MS = 86400000L;
    private static final int DEFAULT_DEVELOPMENT_LOG_LEVEL = 3;
    private static final int DEFAULT_PRODUCTION_LOG_LEVEL = 6;
    private static final String EU_ANALYTICS_URL = "https://combine.asnapieu.com/";
    private static final String EU_DEVICE_URL = "https://device-api.asnapieu.com/";
    private static final String EU_REMOTE_DATA_URL = "https://remote-data.asnapieu.com/";
    private static final String EU_WALLET_URL = "https://wallet-api.asnapieu.com";
    @NonNull
    public static final String FCM_TRANSPORT = "FCM";
    @NonNull
    public static final String HMS_TRANSPORT = "HMS";
    private static final long MAX_BG_REPORTING_INTERVAL_MS = 86400000L;
    private static final long MIN_BG_REPORTING_INTERVAL_MS = 60000L;
    @NonNull
    public static final String SITE_EU = "EU";
    @NonNull
    public static final String SITE_US = "US";
    private static final String US_ANALYTICS_URL = "https://combine.urbanairship.com/";
    private static final String US_DEVICE_URL = "https://device-api.urbanairship.com/";
    private static final String US_REMOTE_DATA_URL = "https://remote-data.urbanairship.com/";
    private static final String US_WALLET_URL = "https://wallet-api.urbanairship.com";
    @NonNull
    public final List<String> allowedTransports;
    public final boolean analyticsEnabled;
    @NonNull
    @RestrictTo(value={RestrictTo.Scope.LIBRARY_GROUP})
    public final String analyticsUrl;
    @NonNull
    public final String appKey;
    @NonNull
    public final String appSecret;
    @Nullable
    public final Uri appStoreUri;
    public final boolean autoLaunchApplication;
    public final long backgroundReportingIntervalMS;
    public final boolean channelCaptureEnabled;
    public final boolean channelCreationDelayEnabled;
    @Nullable
    public final PushProvider customPushProvider;
    public final boolean dataCollectionOptInEnabled;
    @NonNull
    @RestrictTo(value={RestrictTo.Scope.LIBRARY_GROUP})
    public final String deviceUrl;
    public final boolean enableUrlWhitelisting;
    public final boolean extendedBroadcastsEnabled;
    @Nullable
    public final String fcmSenderId;
    public final boolean inProduction;
    public final int logLevel;
    @ColorInt
    public final int notificationAccentColor;
    @Nullable
    public final String notificationChannel;
    @DrawableRes
    public final int notificationIcon;
    @DrawableRes
    public final int notificationLargeIcon;
    @NonNull
    @RestrictTo(value={RestrictTo.Scope.LIBRARY_GROUP})
    public final String remoteDataUrl;
    @NonNull
    @RestrictTo(value={RestrictTo.Scope.LIBRARY_GROUP})
    public final String walletUrl;
    @NonNull
    public final List<String> whitelist;

    private AirshipConfigOptions(@NonNull Builder builder) {
        if (builder.inProduction.booleanValue()) {
            String[] arrstring = new String[]{builder.productionAppKey, builder.appKey};
            this.appKey = AirshipConfigOptions.firstOrEmpty(arrstring);
            String[] arrstring2 = new String[]{builder.productionAppSecret, builder.appSecret};
            this.appSecret = AirshipConfigOptions.firstOrEmpty(arrstring2);
            String[] arrstring3 = new String[]{builder.productionFcmSenderId, builder.fcmSenderId};
            this.fcmSenderId = AirshipConfigOptions.firstOrNull(arrstring3);
            Integer[] arrinteger = new Integer[]{builder.productionLogLevel, builder.logLevel, 6};
            this.logLevel = AirshipConfigOptions.first(arrinteger);
        } else {
            String[] arrstring = new String[]{builder.developmentAppKey, builder.appKey};
            this.appKey = AirshipConfigOptions.firstOrEmpty(arrstring);
            String[] arrstring4 = new String[]{builder.developmentAppSecret, builder.appSecret};
            this.appSecret = AirshipConfigOptions.firstOrEmpty(arrstring4);
            String[] arrstring5 = new String[]{builder.developmentFcmSenderId, builder.fcmSenderId};
            this.fcmSenderId = AirshipConfigOptions.firstOrNull(arrstring5);
            Integer[] arrinteger = new Integer[]{builder.developmentLogLevel, builder.logLevel, 3};
            this.logLevel = AirshipConfigOptions.first(arrinteger);
        }
        String string = builder.site;
        int n = -1;
        int n2 = string.hashCode();
        if (n2 != 2224) {
            if (n2 == 2718 && string.equals((Object)SITE_US)) {
                n = 1;
            }
        } else if (string.equals((Object)SITE_EU)) {
            n = 0;
        }
        if (n != 0) {
            String[] arrstring = new String[]{builder.deviceUrl, US_DEVICE_URL};
            this.deviceUrl = AirshipConfigOptions.firstOrEmpty(arrstring);
            String[] arrstring6 = new String[]{builder.analyticsUrl, US_ANALYTICS_URL};
            this.analyticsUrl = AirshipConfigOptions.firstOrEmpty(arrstring6);
            String[] arrstring7 = new String[]{builder.remoteDataUrl, US_REMOTE_DATA_URL};
            this.remoteDataUrl = AirshipConfigOptions.firstOrEmpty(arrstring7);
            String[] arrstring8 = new String[]{builder.walletUrl, US_WALLET_URL};
            this.walletUrl = AirshipConfigOptions.firstOrEmpty(arrstring8);
        } else {
            String[] arrstring = new String[]{builder.deviceUrl, EU_DEVICE_URL};
            this.deviceUrl = AirshipConfigOptions.firstOrEmpty(arrstring);
            String[] arrstring9 = new String[]{builder.analyticsUrl, EU_ANALYTICS_URL};
            this.analyticsUrl = AirshipConfigOptions.firstOrEmpty(arrstring9);
            String[] arrstring10 = new String[]{builder.remoteDataUrl, EU_REMOTE_DATA_URL};
            this.remoteDataUrl = AirshipConfigOptions.firstOrEmpty(arrstring10);
            String[] arrstring11 = new String[]{builder.walletUrl, EU_WALLET_URL};
            this.walletUrl = AirshipConfigOptions.firstOrEmpty(arrstring11);
        }
        this.allowedTransports = Collections.unmodifiableList((List)new ArrayList((Collection)builder.allowedTransports));
        this.whitelist = Collections.unmodifiableList((List)new ArrayList((Collection)builder.whitelist));
        this.inProduction = builder.inProduction;
        this.analyticsEnabled = builder.analyticsEnabled;
        this.backgroundReportingIntervalMS = builder.backgroundReportingIntervalMS;
        this.autoLaunchApplication = builder.autoLaunchApplication;
        this.channelCreationDelayEnabled = builder.channelCreationDelayEnabled;
        this.channelCaptureEnabled = builder.channelCaptureEnabled;
        this.notificationIcon = builder.notificationIcon;
        this.notificationLargeIcon = builder.notificationLargeIcon;
        this.notificationAccentColor = builder.notificationAccentColor;
        this.notificationChannel = builder.notificationChannel;
        this.enableUrlWhitelisting = builder.enableUrlWhitelisting;
        this.customPushProvider = builder.customPushProvider;
        this.appStoreUri = builder.appStoreUri;
        this.dataCollectionOptInEnabled = builder.dataCollectionOptInEnabled;
        this.extendedBroadcastsEnabled = builder.extendedBroadcastsEnabled;
    }

    public /* synthetic */ AirshipConfigOptions(Builder builder, 1 var2_2) {
        this(builder);
    }

    public static /* synthetic */ String a(String string) {
        return AirshipConfigOptions.parseSite(string);
    }

    private static /* varargs */ int first(Integer ... arrinteger) {
        for (Integer n : arrinteger) {
            if (n == null) continue;
            return n;
        }
        return 0;
    }

    @NonNull
    private static /* varargs */ String firstOrEmpty(@NonNull String ... arrstring) {
        for (String string : arrstring) {
            if (UAStringUtil.isEmpty((String)string)) continue;
            return string;
        }
        return "";
    }

    @Nullable
    private static /* varargs */ String firstOrNull(@NonNull String ... arrstring) {
        for (String string : arrstring) {
            if (UAStringUtil.isEmpty((String)string)) continue;
            return string;
        }
        return null;
    }

    @NonNull
    public static Builder newBuilder() {
        return new Builder();
    }

    @NonNull
    private static String parseSite(String string) {
        if (SITE_EU.equalsIgnoreCase(string)) {
            return SITE_EU;
        }
        if (SITE_US.equalsIgnoreCase(string)) {
            return SITE_US;
        }
        throw new IllegalArgumentException(a.h1((String)"Invalid site: ", (String)string));
    }

    public void validate() {
        String string = this.inProduction ? "production" : "development";
        Pattern pattern = APP_CREDENTIAL_PATTERN;
        if (pattern.matcher((CharSequence)this.appKey).matches()) {
            if (pattern.matcher((CharSequence)this.appSecret).matches()) {
                long l = this.backgroundReportingIntervalMS;
                if (l < 60000L) {
                    Object[] arrobject = new Object[]{l};
                    Logger.warn((String)"AirshipConfigOptions - The backgroundReportingIntervalMS %s may decrease battery life.", (Object[])arrobject);
                    return;
                }
                if (l > 86400000L) {
                    Object[] arrobject = new Object[]{l};
                    Logger.warn((String)"AirshipConfigOptions - The backgroundReportingIntervalMS %s may provide less detailed analytic reports.", (Object[])arrobject);
                }
                return;
            }
            throw new IllegalArgumentException(a.t1((StringBuilder)a.F1((String)"AirshipConfigOptions: "), (String)this.appSecret, (String)" is not a valid ", (String)string, (String)" app secret"));
        }
        throw new IllegalArgumentException(a.t1((StringBuilder)a.F1((String)"AirshipConfigOptions: "), (String)this.appKey, (String)" is not a valid ", (String)string, (String)" app key"));
    }

    public static final class Builder {
        private static final String CONFIG_ELEMENT = "AirshipConfigOptions";
        private static final String DEFAULT_PROPERTIES_FILENAME = "airshipconfig.properties";
        private static final String FIELD_ALLOWED_TRANSPORTS = "allowedTransports";
        private static final String FIELD_ANALYTICS_ENABLED = "analyticsEnabled";
        private static final String FIELD_ANALYTICS_URL = "analyticsUrl";
        private static final String FIELD_APP_KEY = "appKey";
        private static final String FIELD_APP_SECRET = "appSecret";
        private static final String FIELD_APP_STORE_URI = "appStoreUri";
        private static final String FIELD_AUTO_LAUNCH_APPLICATION = "autoLaunchApplication";
        private static final String FIELD_BACKGROUND_REPORTING_INTERVAL_MS = "backgroundReportingIntervalMS";
        private static final String FIELD_CHANNEL_CAPTURE_ENABLED = "channelCaptureEnabled";
        private static final String FIELD_CHANNEL_CREATION_DELAY_ENABLED = "channelCreationDelayEnabled";
        private static final String FIELD_CUSTOM_PUSH_PROVIDER = "customPushProvider";
        private static final String FIELD_DATA_COLLECTION_OPT_IN_ENABLED = "dataCollectionOptInEnabled";
        private static final String FIELD_DEVELOPMENT_APP_KEY = "developmentAppKey";
        private static final String FIELD_DEVELOPMENT_APP_SECRET = "developmentAppSecret";
        private static final String FIELD_DEVELOPMENT_FCM_SENDER_ID = "developmentFcmSenderId";
        private static final String FIELD_DEVELOPMENT_LOG_LEVEL = "developmentLogLevel";
        private static final String FIELD_DEVICE_URL = "deviceUrl";
        private static final String FIELD_ENABLE_URL_WHITELISTING = "enableUrlWhitelisting";
        private static final String FIELD_EXTENDED_BROADCASTS_ENABLED = "extendedBroadcastsEnabled";
        private static final String FIELD_FCM_SENDER_ID = "fcmSenderId";
        private static final String FIELD_GCM_SENDER = "gcmSender";
        private static final String FIELD_IN_PRODUCTION = "inProduction";
        private static final String FIELD_LEGACY_ANALYTICS_SERVER = "analyticsServer";
        private static final String FIELD_LEGACY_DEVICE_URL = "hostURL";
        private static final String FIELD_LEGACY_REMOTE_DATA_URL = "remoteDataURL";
        private static final String FIELD_LOG_LEVEL = "logLevel";
        private static final String FIELD_NOTIFICATION_ACCENT_COLOR = "notificationAccentColor";
        private static final String FIELD_NOTIFICATION_CHANNEL = "notificationChannel";
        private static final String FIELD_NOTIFICATION_ICON = "notificationIcon";
        private static final String FIELD_NOTIFICATION_LARGE_ICON = "notificationLargeIcon";
        private static final String FIELD_PRODUCTION_APP_KEY = "productionAppKey";
        private static final String FIELD_PRODUCTION_APP_SECRET = "productionAppSecret";
        private static final String FIELD_PRODUCTION_FCM_SENDER_ID = "productionFcmSenderId";
        private static final String FIELD_PRODUCTION_LOG_LEVEL = "productionLogLevel";
        private static final String FIELD_REMOTE_DATA_URL = "remoteDataUrl";
        private static final String FIELD_SITE = "site";
        private static final String FIELD_WALLET_URL = "walletUrl";
        private static final String FIELD_WHITELIST = "whitelist";
        private List<String> allowedTransports = new ArrayList((Collection)Arrays.asList((Object[])new String[]{"ADM", "FCM", "HMS"}));
        private boolean analyticsEnabled = true;
        private String analyticsUrl;
        private String appKey;
        private String appSecret;
        private Uri appStoreUri;
        private boolean autoLaunchApplication = true;
        private long backgroundReportingIntervalMS = 86400000L;
        private boolean channelCaptureEnabled = true;
        private boolean channelCreationDelayEnabled = false;
        private PushProvider customPushProvider;
        private boolean dataCollectionOptInEnabled;
        private String developmentAppKey;
        private String developmentAppSecret;
        private String developmentFcmSenderId;
        private Integer developmentLogLevel;
        private String deviceUrl;
        private boolean enableUrlWhitelisting;
        private boolean extendedBroadcastsEnabled;
        private String fcmSenderId;
        private Boolean inProduction = null;
        private Integer logLevel;
        private int notificationAccentColor = 0;
        private String notificationChannel;
        private int notificationIcon;
        private int notificationLargeIcon;
        private String productionAppKey;
        private String productionAppSecret;
        private String productionFcmSenderId;
        private Integer productionLogLevel;
        private String remoteDataUrl;
        private String site = "US";
        private String walletUrl;
        private List<String> whitelist = new ArrayList();

        /*
         * Exception decompiling
         */
        private void applyConfigParser(Context var1_1, ConfigParser var2_2) {
            // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
            // org.benf.cfr.reader.util.ConfusedCFRException: Extractable last case doesn't follow previous
            // org.benf.cfr.reader.b.a.a.b.as.a(SwitchReplacer.java:478)
            // org.benf.cfr.reader.b.a.a.b.as.a(SwitchReplacer.java:61)
            // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:372)
            // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
            // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
            // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
            // org.benf.cfr.reader.entities.g.p(Method.java:396)
            // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
            // org.benf.cfr.reader.entities.d.c(ClassFile.java:773)
            // org.benf.cfr.reader.entities.d.e(ClassFile.java:870)
            // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
            // org.benf.cfr.reader.b.a(Driver.java:128)
            // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
            // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
            // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
            // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
            // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
            // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
            // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
            // java.lang.Thread.run(Thread.java:923)
            throw new IllegalStateException("Decompilation failed");
        }

        /*
         * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
         * Unable to fully structure code
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         * Lifted jumps to return sites
         */
        @NonNull
        public Builder applyConfig(@NonNull Context context, @XmlRes int n) {
            xmlConfigParser = null;
            xmlConfigParser = XmlConfigParser.parseElement((Context)context, (int)n, (String)"AirshipConfigOptions");
            this.applyConfigParser(context, (ConfigParser)xmlConfigParser);
            if (xmlConfigParser == null) return this;
lbl6: // 2 sources:
            do {
                xmlConfigParser.close();
                return this;
                break;
            } while (true);
            {
                catch (Throwable throwable22) {
                }
                catch (Exception exception) {}
                {
                    Logger.error((Throwable)exception, (String)"AirshipConfigOptions - Unable to apply config.", (Object[])new Object[0]);
                    if (xmlConfigParser == null) return this;
                    ** continue;
                }
            }
            if (xmlConfigParser == null) throw throwable22;
            xmlConfigParser.close();
            throw throwable22;
        }

        @NonNull
        public Builder applyDefaultProperties(@NonNull Context context) {
            return this.applyProperties(context, DEFAULT_PROPERTIES_FILENAME);
        }

        @NonNull
        public Builder applyProperties(@NonNull Context context, @NonNull String string) {
            try {
                this.applyConfigParser(context, (ConfigParser)PropertiesConfigParser.fromAssets((Context)context, (String)string));
                return this;
            }
            catch (Exception exception) {
                Logger.error((Throwable)exception, (String)"AirshipConfigOptions - Unable to apply config.", (Object[])new Object[0]);
                return this;
            }
        }

        @NonNull
        public Builder applyProperties(@NonNull Context context, @NonNull Properties properties) {
            try {
                this.applyConfigParser(context, (ConfigParser)PropertiesConfigParser.fromProperties((Context)context, (Properties)properties));
                return this;
            }
            catch (Exception exception) {
                Logger.error((Throwable)exception, (String)"AirshipConfigOptions - Unable to apply config.", (Object[])new Object[0]);
                return this;
            }
        }

        @NonNull
        public AirshipConfigOptions build() {
            String string;
            String string2;
            if (this.inProduction == null) {
                this.inProduction = Boolean.FALSE;
            }
            if ((string2 = this.productionAppKey) != null && string2.equals((Object)this.developmentAppKey)) {
                Logger.warn((String)"Production App Key matches Development App Key", (Object[])new Object[0]);
            }
            if ((string = this.productionAppSecret) != null && string.equals((Object)this.developmentAppSecret)) {
                Logger.warn((String)"Production App Secret matches Development App Secret", (Object[])new Object[0]);
            }
            return new AirshipConfigOptions(this, null);
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        @NonNull
        public Builder detectProvisioningMode(@NonNull Context context) {
            try {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(context.getPackageName());
                stringBuilder.append(".BuildConfig");
                boolean bl = (Boolean)Class.forName((String)stringBuilder.toString()).getField("DEBUG").get(null) == false;
                this.inProduction = bl;
                return this;
            }
            catch (Exception exception) {
                Logger.warn((String)"AirshipConfigOptions - Unable to determine the build mode. Defaulting to debug.", (Object[])new Object[0]);
                this.inProduction = Boolean.FALSE;
                return this;
            }
        }

        @NonNull
        public Builder setAllowedTransports(@Nullable String[] arrstring) {
            this.allowedTransports.clear();
            if (arrstring != null) {
                this.allowedTransports.addAll((Collection)Arrays.asList((Object[])arrstring));
            }
            return this;
        }

        @NonNull
        public Builder setAnalyticsEnabled(boolean bl) {
            this.analyticsEnabled = bl;
            return this;
        }

        @NonNull
        @RestrictTo(value={RestrictTo.Scope.LIBRARY_GROUP})
        public Builder setAnalyticsUrl(@NonNull String string) {
            this.analyticsUrl = string;
            return this;
        }

        @NonNull
        public Builder setAppKey(@Nullable String string) {
            this.appKey = string;
            return this;
        }

        @NonNull
        public Builder setAppSecret(@Nullable String string) {
            this.appSecret = string;
            return this;
        }

        @NonNull
        public Builder setAppStoreUri(@Nullable Uri uri) {
            this.appStoreUri = uri;
            return this;
        }

        @NonNull
        public Builder setAutoLaunchApplication(boolean bl) {
            this.autoLaunchApplication = bl;
            return this;
        }

        @NonNull
        public Builder setBackgroundReportingIntervalMS(long l) {
            this.backgroundReportingIntervalMS = l;
            return this;
        }

        @NonNull
        public Builder setChannelCaptureEnabled(boolean bl) {
            this.channelCaptureEnabled = bl;
            return this;
        }

        @NonNull
        public Builder setChannelCreationDelayEnabled(boolean bl) {
            this.channelCreationDelayEnabled = bl;
            return this;
        }

        @NonNull
        public Builder setCustomPushProvider(@Nullable PushProvider pushProvider) {
            this.customPushProvider = pushProvider;
            return this;
        }

        @NonNull
        public Builder setDataCollectionOptInEnabled(boolean bl) {
            this.dataCollectionOptInEnabled = bl;
            return this;
        }

        @NonNull
        public Builder setDevelopmentAppKey(@Nullable String string) {
            this.developmentAppKey = string;
            return this;
        }

        @NonNull
        public Builder setDevelopmentAppSecret(@Nullable String string) {
            this.developmentAppSecret = string;
            return this;
        }

        @NonNull
        public Builder setDevelopmentFcmSenderId(@Nullable String string) {
            this.developmentFcmSenderId = string;
            return this;
        }

        @NonNull
        public Builder setDevelopmentLogLevel(int n) {
            this.developmentLogLevel = n;
            return this;
        }

        @NonNull
        @RestrictTo(value={RestrictTo.Scope.LIBRARY_GROUP})
        public Builder setDeviceUrl(@NonNull String string) {
            this.deviceUrl = string;
            return this;
        }

        @NonNull
        public Builder setEnableUrlWhitelisting(boolean bl) {
            this.enableUrlWhitelisting = bl;
            return this;
        }

        @NonNull
        public Builder setExtendedBroadcastsEnabled(boolean bl) {
            this.extendedBroadcastsEnabled = bl;
            return this;
        }

        @NonNull
        public Builder setFcmSenderId(@Nullable String string) {
            this.fcmSenderId = string;
            return this;
        }

        @NonNull
        public Builder setInProduction(boolean bl) {
            this.inProduction = bl;
            return this;
        }

        @NonNull
        public Builder setLogLevel(int n) {
            this.logLevel = n;
            return this;
        }

        @NonNull
        public Builder setNotificationAccentColor(@ColorInt int n) {
            this.notificationAccentColor = n;
            return this;
        }

        @NonNull
        public Builder setNotificationChannel(@Nullable String string) {
            this.notificationChannel = string;
            return this;
        }

        @NonNull
        public Builder setNotificationIcon(@DrawableRes int n) {
            this.notificationIcon = n;
            return this;
        }

        @NonNull
        public Builder setNotificationLargeIcon(@DrawableRes int n) {
            this.notificationLargeIcon = n;
            return this;
        }

        @NonNull
        public Builder setProductionAppKey(@Nullable String string) {
            this.productionAppKey = string;
            return this;
        }

        @NonNull
        public Builder setProductionAppSecret(@Nullable String string) {
            this.productionAppSecret = string;
            return this;
        }

        @NonNull
        public Builder setProductionFcmSenderId(@Nullable String string) {
            this.productionFcmSenderId = string;
            return this;
        }

        @NonNull
        public Builder setProductionLogLevel(int n) {
            this.productionLogLevel = n;
            return this;
        }

        @NonNull
        @RestrictTo(value={RestrictTo.Scope.LIBRARY_GROUP})
        public Builder setRemoteDataUrl(@Nullable String string) {
            this.remoteDataUrl = string;
            return this;
        }

        @NonNull
        public Builder setSite(@NonNull String string) {
            this.site = string;
            return this;
        }

        @NonNull
        @RestrictTo(value={RestrictTo.Scope.LIBRARY_GROUP})
        public Builder setWalletUrl(@NonNull String string) {
            this.walletUrl = string;
            return this;
        }

        @NonNull
        public Builder setWhitelist(@Nullable String[] arrstring) {
            this.whitelist.clear();
            if (arrstring != null) {
                this.whitelist.addAll((Collection)Arrays.asList((Object[])arrstring));
            }
            return this;
        }
    }

    @Retention(value=RetentionPolicy.SOURCE)
    public static @interface Site {
    }

}

