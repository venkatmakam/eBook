/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  androidx.annotation.NonNull
 *  androidx.annotation.Nullable
 *  androidx.annotation.RestrictTo
 *  androidx.annotation.RestrictTo$Scope
 *  androidx.annotation.Size
 *  androidx.annotation.VisibleForTesting
 *  androidx.annotation.WorkerThread
 *  com.urbanairship.AirshipComponent
 *  com.urbanairship.Logger
 *  com.urbanairship.PreferenceDataStore
 *  com.urbanairship.UAirship
 *  com.urbanairship.channel.AirshipChannel
 *  com.urbanairship.channel.AirshipChannel$ChannelRegistrationPayloadExtender
 *  com.urbanairship.channel.AirshipChannelListener
 *  com.urbanairship.channel.AttributeApiClient
 *  com.urbanairship.channel.AttributeEditor
 *  com.urbanairship.channel.NamedUser$1
 *  com.urbanairship.channel.NamedUser$2
 *  com.urbanairship.channel.NamedUser$3
 *  com.urbanairship.channel.NamedUser$4
 *  com.urbanairship.channel.NamedUserApiClient
 *  com.urbanairship.channel.PendingAttributeMutationStore
 *  com.urbanairship.channel.TagGroupRegistrar
 *  com.urbanairship.channel.TagGroupsEditor
 *  com.urbanairship.config.AirshipRuntimeConfig
 *  com.urbanairship.http.RequestException
 *  com.urbanairship.http.Response
 *  com.urbanairship.job.JobDispatcher
 *  com.urbanairship.job.JobInfo
 *  com.urbanairship.job.JobInfo$Builder
 *  com.urbanairship.util.UAStringUtil
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.List
 *  java.util.UUID
 */
package com.urbanairship.channel;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import androidx.annotation.Size;
import androidx.annotation.VisibleForTesting;
import androidx.annotation.WorkerThread;
import com.urbanairship.AirshipComponent;
import com.urbanairship.Logger;
import com.urbanairship.PreferenceDataStore;
import com.urbanairship.UAirship;
import com.urbanairship.channel.AirshipChannel;
import com.urbanairship.channel.AirshipChannelListener;
import com.urbanairship.channel.AttributeApiClient;
import com.urbanairship.channel.AttributeEditor;
import com.urbanairship.channel.NamedUser;
import com.urbanairship.channel.NamedUserApiClient;
import com.urbanairship.channel.PendingAttributeMutationStore;
import com.urbanairship.channel.TagGroupRegistrar;
import com.urbanairship.channel.TagGroupsEditor;
import com.urbanairship.config.AirshipRuntimeConfig;
import com.urbanairship.http.RequestException;
import com.urbanairship.http.Response;
import com.urbanairship.job.JobDispatcher;
import com.urbanairship.job.JobInfo;
import com.urbanairship.util.UAStringUtil;
import java.util.List;
import java.util.UUID;

public class NamedUser
extends AirshipComponent {
    private static final String ATTRIBUTE_MUTATION_STORE_KEY = "com.urbanairship.nameduser.ATTRIBUTE_MUTATION_STORE_KEY";
    private static final String CHANGE_TOKEN_KEY = "com.urbanairship.nameduser.CHANGE_TOKEN_KEY";
    private static final String LAST_UPDATED_TOKEN_KEY = "com.urbanairship.nameduser.LAST_UPDATED_TOKEN_KEY";
    private static final int MAX_NAMED_USER_ID_LENGTH = 128;
    private static final String NAMED_USER_ID_KEY = "com.urbanairship.nameduser.NAMED_USER_ID_KEY";
    private final AirshipChannel airshipChannel;
    private final AttributeApiClient attributeApiClient;
    private final PendingAttributeMutationStore attributeMutationStore;
    private final Object idLock;
    private final JobDispatcher jobDispatcher;
    private final NamedUserApiClient namedUserApiClient;
    private final PreferenceDataStore preferenceDataStore;
    private final TagGroupRegistrar tagGroupRegistrar;

    public NamedUser(@NonNull Context context, @NonNull PreferenceDataStore preferenceDataStore, @NonNull AirshipRuntimeConfig airshipRuntimeConfig, @NonNull TagGroupRegistrar tagGroupRegistrar, @NonNull AirshipChannel airshipChannel) {
        JobDispatcher jobDispatcher = JobDispatcher.shared((Context)context);
        NamedUserApiClient namedUserApiClient = new NamedUserApiClient(airshipRuntimeConfig);
        AttributeApiClient attributeApiClient = new AttributeApiClient(airshipRuntimeConfig);
        super(context, preferenceDataStore);
        this.idLock = new Object();
        this.preferenceDataStore = preferenceDataStore;
        this.tagGroupRegistrar = tagGroupRegistrar;
        this.airshipChannel = airshipChannel;
        this.jobDispatcher = jobDispatcher;
        this.namedUserApiClient = namedUserApiClient;
        this.attributeApiClient = attributeApiClient;
        this.attributeMutationStore = new PendingAttributeMutationStore(preferenceDataStore, ATTRIBUTE_MUTATION_STORE_KEY);
    }

    public static /* synthetic */ TagGroupRegistrar b(NamedUser namedUser) {
        return namedUser.tagGroupRegistrar;
    }

    public static /* synthetic */ PendingAttributeMutationStore c(NamedUser namedUser) {
        return namedUser.attributeMutationStore;
    }

    private void clearPendingNamedUserUpdates() {
        Logger.verbose((String)"Clearing pending Named Users tag updates.", (Object[])new Object[0]);
        this.tagGroupRegistrar.clearMutations(1);
    }

    @Nullable
    private String getChangeToken() {
        return this.preferenceDataStore.getString(CHANGE_TOKEN_KEY, null);
    }

    @WorkerThread
    private int onUpdateNamedUser() {
        int n;
        String string = this.airshipChannel.getId();
        if (UAStringUtil.isEmpty((String)string)) {
            Logger.verbose((String)"NamedUser - The channel ID does not exist. Will retry when channel ID is available.", (Object[])new Object[0]);
            return 0;
        }
        if (!this.e() && (n = this.updateNamedUserId(string)) != 0) {
            return n;
        }
        String string2 = this.getId();
        if (this.e() && string2 != null) {
            int n2 = this.updateTagGroups(string2);
            int n3 = this.updateAttributes(string2);
            if (n2 == 1 || n3 == 1) {
                return 1;
            }
        }
        return 0;
    }

    @WorkerThread
    private int updateAttributes(@NonNull String string) {
        while (this.e()) {
            Response response;
            this.attributeMutationStore.c();
            List list = this.attributeMutationStore.e();
            if (list == null) {
                return 0;
            }
            try {
                response = this.attributeApiClient.b(string, list);
            }
            catch (RequestException requestException) {
                Logger.debug((Throwable)requestException, (String)"NamedUser - Failed to update attributes", (Object[])new Object[0]);
                return 1;
            }
            Logger.debug((String)"NamedUser - Updated attributes response: %s", (Object[])new Object[]{response});
            if (!response.isServerError()) {
                if (response.isTooManyRequestsError()) {
                    return 1;
                }
                if (response.isClientError()) {
                    Object[] arrobject = new Object[]{list, response.getStatus(), response.getResponseBody()};
                    Logger.error((String)"NamedUser - Dropping attributes %s due to error: %s message: %s", (Object[])arrobject);
                }
                this.attributeMutationStore.f();
                continue;
            }
            return 1;
        }
        return 0;
    }

    private void updateChangeToken() {
        this.preferenceDataStore.put(CHANGE_TOKEN_KEY, UUID.randomUUID().toString());
    }

    /*
     * Exception decompiling
     */
    @WorkerThread
    private int updateNamedUserId(@NonNull String var1_1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [9[SIMPLE_IF_TAKEN]], but top level block is 1[TRYBLOCK]
        // org.benf.cfr.reader.b.a.a.j.a(Op04StructuredStatement.java:432)
        // org.benf.cfr.reader.b.a.a.j.d(Op04StructuredStatement.java:484)
        // org.benf.cfr.reader.b.a.a.i.a(Op03SimpleStatement.java:607)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:692)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    @WorkerThread
    private int updateTagGroups(@NonNull String string) {
        return !this.tagGroupRegistrar.uploadMutations(1, string);
    }

    public void d() {
        JobInfo jobInfo = JobInfo.newBuilder().setAction("ACTION_UPDATE_NAMED_USER").setId(2).setNetworkAccessRequired(true).setAirshipComponent(NamedUser.class).build();
        this.jobDispatcher.dispatch(jobInfo);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @VisibleForTesting
    public boolean e() {
        Object object;
        Object object2 = object = this.idLock;
        synchronized (object2) {
            String string = this.getChangeToken();
            String string2 = this.preferenceDataStore.getString(LAST_UPDATED_TOKEN_KEY, null);
            String string3 = this.getId();
            boolean bl = true;
            if (string3 == null && string == null) {
                return bl;
            }
            if (string2 == null) return false;
            if (string2.equals((Object)string)) return bl;
            return false;
        }
    }

    @NonNull
    public AttributeEditor editAttributes() {
        return new 4(this);
    }

    @NonNull
    public TagGroupsEditor editTagGroups() {
        return new 3(this);
    }

    public void forceUpdate() {
        Logger.debug((String)"NamedUser - force named user update.", (Object[])new Object[0]);
        this.updateChangeToken();
        this.d();
    }

    @RestrictTo(value={RestrictTo.Scope.LIBRARY_GROUP})
    public int getComponentGroup() {
        return 5;
    }

    @Nullable
    public String getId() {
        return this.preferenceDataStore.getString(NAMED_USER_ID_KEY, null);
    }

    public void init() {
        super.init();
        this.airshipChannel.addChannelListener((AirshipChannelListener)new 1(this));
        this.airshipChannel.addChannelRegistrationPayloadExtender((AirshipChannel.ChannelRegistrationPayloadExtender)new 2(this));
        if (!(this.airshipChannel.getId() == null || this.e() && this.getId() == null)) {
            this.d();
        }
    }

    public void onDataCollectionEnabledChanged(boolean bl) {
        if (!bl) {
            this.clearPendingNamedUserUpdates();
            this.setId(null);
        }
    }

    @RestrictTo(value={RestrictTo.Scope.LIBRARY_GROUP})
    @WorkerThread
    public int onPerformJob(@NonNull UAirship uAirship, @NonNull JobInfo jobInfo) {
        if ("ACTION_UPDATE_NAMED_USER".equals((Object)jobInfo.getAction())) {
            return this.onUpdateNamedUser();
        }
        return 0;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void setId(@Nullable @Size(max=128L) String string) {
        Object object;
        if (string != null && !this.isDataCollectionEnabled()) {
            Logger.debug((String)"NamedUser - Data collection is disabled, ignoring named user association.", (Object[])new Object[0]);
            return;
        }
        boolean bl = UAStringUtil.isEmpty((String)string);
        String string2 = null;
        if (!bl && (UAStringUtil.isEmpty((String)(string2 = string.trim())) || string2.length() > 128)) {
            Logger.error((String)"Failed to set named user ID. The named user ID must be composedof non-whitespace characters and be less than 129 characters in length.", (Object[])new Object[0]);
            return;
        }
        Object object2 = object = this.idLock;
        synchronized (object2) {
            if (!UAStringUtil.equals((String)this.getId(), (String)string2)) {
                this.preferenceDataStore.put(NAMED_USER_ID_KEY, string2);
                this.updateChangeToken();
                this.clearPendingNamedUserUpdates();
                this.d();
                if (string2 != null) {
                    this.airshipChannel.updateRegistration();
                }
            } else {
                Object[] arrobject = new Object[]{this.getId()};
                Logger.debug((String)"NamedUser - Skipping update. Named user ID trimmed already matches existing named user: %s", (Object[])arrobject);
            }
            return;
        }
    }
}

