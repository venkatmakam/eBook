/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.annotation.NonNull
 *  androidx.annotation.RestrictTo
 *  androidx.annotation.RestrictTo$Scope
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanairship;

import androidx.annotation.NonNull;
import androidx.annotation.RestrictTo;

@RestrictTo(value={RestrictTo.Scope.LIBRARY_GROUP})
public interface AirshipVersionInfo {
    @NonNull
    public String getAirshipVersion();

    @NonNull
    public String getPackageVersion();
}

