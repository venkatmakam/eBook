/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.ByteArrayOutputStream
 *  java.io.Closeable
 *  java.io.EOFException
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.UnsupportedEncodingException
 *  java.lang.AssertionError
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.nio.charset.Charset
 */
package com.jakewharton.disklrucache;

import com.jakewharton.disklrucache.Util;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;

public class StrictLineReader
implements Closeable {
    private static final byte CR = 13;
    private static final byte LF = 10;
    private byte[] buf;
    private final Charset charset;
    private int end;
    private final InputStream in;
    private int pos;

    public StrictLineReader(InputStream inputStream, int n, Charset charset) {
        if (inputStream != null && charset != null) {
            if (n >= 0) {
                if (charset.equals((Object)Util.a)) {
                    this.in = inputStream;
                    this.charset = charset;
                    this.buf = new byte[n];
                    return;
                }
                throw new IllegalArgumentException("Unsupported encoding");
            }
            throw new IllegalArgumentException("capacity <= 0");
        }
        throw null;
    }

    public StrictLineReader(InputStream inputStream, Charset charset) {
        this(inputStream, 8192, charset);
    }

    private void fillBuf() throws IOException {
        InputStream inputStream = this.in;
        byte[] arrby = this.buf;
        int n = inputStream.read(arrby, 0, arrby.length);
        if (n != -1) {
            this.pos = 0;
            this.end = n;
            return;
        }
        throw new EOFException();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void close() throws IOException {
        InputStream inputStream;
        InputStream inputStream2 = inputStream = this.in;
        synchronized (inputStream2) {
            if (this.buf != null) {
                this.buf = null;
                this.in.close();
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public String readLine() throws IOException {
        InputStream inputStream;
        InputStream inputStream2 = inputStream = this.in;
        synchronized (inputStream2) {
            if (this.buf == null) {
                throw new IOException("LineReader is closed");
            }
            if (this.pos >= this.end) {
                this.fillBuf();
            }
            int n = this.pos;
            do {
                if (n == this.end) break;
                byte[] arrby = this.buf;
                if (arrby[n] == 10) {
                    int n2;
                    if (n != this.pos && arrby[n2 = n - 1] == 13) {
                    } else {
                        n2 = n;
                    }
                    byte[] arrby2 = this.buf;
                    int n3 = this.pos;
                    String string2 = new String(arrby2, n3, n2 - n3, this.charset.name());
                    this.pos = n + 1;
                    return string2;
                }
                ++n;
            } while (true);
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(80 + (this.end - this.pos)){

                public String toString() {
                    int n = this.count;
                    if (n > 0 && this.buf[n - 1] == 13) {
                        --n;
                    }
                    try {
                        String string2 = new String(this.buf, 0, n, StrictLineReader.this.charset.name());
                        return string2;
                    }
                    catch (UnsupportedEncodingException unsupportedEncodingException) {
                        throw new AssertionError((Object)unsupportedEncodingException);
                    }
                }
            };
            block4 : do {
                byte[] arrby = this.buf;
                int n4 = this.pos;
                byteArrayOutputStream.write(arrby, n4, this.end - n4);
                this.end = -1;
                this.fillBuf();
                int n5 = this.pos;
                do {
                    if (n5 == this.end) continue block4;
                    byte[] arrby3 = this.buf;
                    if (arrby3[n5] == 10) {
                        int n6 = this.pos;
                        if (n5 != n6) {
                            byteArrayOutputStream.write(arrby3, n6, n5 - n6);
                        }
                        this.pos = n5 + 1;
                        return byteArrayOutputStream.toString();
                    }
                    ++n5;
                } while (true);
                break;
            } while (true);
        }
    }

}

