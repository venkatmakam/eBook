/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  e.a.a.a.a
 *  java.io.BufferedWriter
 *  java.io.Closeable
 *  java.io.EOFException
 *  java.io.File
 *  java.io.FileInputStream
 *  java.io.FileNotFoundException
 *  java.io.FileOutputStream
 *  java.io.FilterOutputStream
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.InputStreamReader
 *  java.io.OutputStream
 *  java.io.OutputStreamWriter
 *  java.io.PrintStream
 *  java.io.StringWriter
 *  java.io.Writer
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.IllegalArgumentException
 *  java.lang.IllegalStateException
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.NumberFormatException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Throwable
 *  java.lang.Void
 *  java.nio.charset.Charset
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.Collection
 *  java.util.Iterator
 *  java.util.LinkedHashMap
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 *  java.util.concurrent.BlockingQueue
 *  java.util.concurrent.Callable
 *  java.util.concurrent.Future
 *  java.util.concurrent.LinkedBlockingQueue
 *  java.util.concurrent.ThreadPoolExecutor
 *  java.util.concurrent.TimeUnit
 *  java.util.regex.Matcher
 *  java.util.regex.Pattern
 */
package com.jakewharton.disklrucache;

import com.jakewharton.disklrucache.StrictLineReader;
import com.jakewharton.disklrucache.Util;
import e.a.a.a.a;
import java.io.BufferedWriter;
import java.io.Closeable;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.io.StringWriter;
import java.io.Writer;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Callable;
import java.util.concurrent.Future;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class DiskLruCache
implements Closeable {
    private static final String CLEAN = "CLEAN";
    private static final String DIRTY = "DIRTY";
    private static final OutputStream NULL_OUTPUT_STREAM;
    private static final String READ = "READ";
    private static final String REMOVE = "REMOVE";
    public static final Pattern b;
    public final ThreadPoolExecutor a;
    private final int appVersion;
    private final Callable<Void> cleanupCallable;
    private final File directory;
    private final File journalFile;
    private final File journalFileBackup;
    private final File journalFileTmp;
    private Writer journalWriter;
    private final LinkedHashMap<String, Entry> lruEntries = new LinkedHashMap(0, 0.75f, true);
    private long maxSize;
    private long nextSequenceNumber = 0L;
    private int redundantOpCount;
    private long size = 0L;
    private final int valueCount;

    public static {
        b = Pattern.compile((String)"[a-z0-9_-]{1,64}");
        NULL_OUTPUT_STREAM = new OutputStream(){

            public void write(int n) throws IOException {
            }
        };
    }

    private DiskLruCache(File file, int n, int n2, long l) {
        ThreadPoolExecutor threadPoolExecutor;
        this.a = threadPoolExecutor = new ThreadPoolExecutor(0, 1, 60L, TimeUnit.SECONDS, (BlockingQueue)new LinkedBlockingQueue());
        this.cleanupCallable = new Callable<Void>(){

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            public Void call() throws Exception {
                DiskLruCache diskLruCache;
                DiskLruCache diskLruCache2 = diskLruCache = DiskLruCache.this;
                synchronized (diskLruCache2) {
                    if (DiskLruCache.this.journalWriter == null) {
                        return null;
                    }
                    DiskLruCache.this.trimToSize();
                    if (DiskLruCache.this.journalRebuildRequired()) {
                        DiskLruCache.this.rebuildJournal();
                        DiskLruCache.this.redundantOpCount = 0;
                    }
                    return null;
                }
            }
        };
        this.directory = file;
        this.appVersion = n;
        this.journalFile = new File(file, "journal");
        this.journalFileTmp = new File(file, "journal.tmp");
        this.journalFileBackup = new File(file, "journal.bkp");
        this.valueCount = n2;
        this.maxSize = l;
    }

    private void checkNotClosed() {
        if (this.journalWriter != null) {
            return;
        }
        throw new IllegalStateException("cache is closed");
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void completeEdit(Editor editor, boolean bl) throws IOException {
        DiskLruCache diskLruCache = this;
        synchronized (diskLruCache) {
            Entry entry = editor.entry;
            if (entry.currentEditor != editor) {
                throw new IllegalStateException();
            }
            int n = 0;
            if (bl) {
                boolean bl2 = entry.readable;
                n = 0;
                if (!bl2) {
                    int n2 = 0;
                    do {
                        int n3 = this.valueCount;
                        n = 0;
                        if (n2 >= n3) break;
                        if (!editor.written[n2]) {
                            editor.abort();
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append("Newly created entry didn't create value for index ");
                            stringBuilder.append(n2);
                            throw new IllegalStateException(stringBuilder.toString());
                        }
                        if (!entry.getDirtyFile(n2).exists()) {
                            editor.abort();
                            return;
                        }
                        ++n2;
                    } while (true);
                }
            }
            do {
                if (n < this.valueCount) {
                    File file = entry.getDirtyFile(n);
                    if (bl) {
                        if (file.exists()) {
                            long l;
                            File file2 = entry.getCleanFile(n);
                            file.renameTo(file2);
                            long l2 = entry.lengths[n];
                            Entry.a((Entry)entry)[n] = l = file2.length();
                            this.size = l + (this.size - l2);
                        }
                    } else {
                        DiskLruCache.deleteIfExists(file);
                    }
                } else {
                    this.redundantOpCount = 1 + this.redundantOpCount;
                    entry.currentEditor = null;
                    if (bl | entry.readable) {
                        entry.readable = true;
                        Writer writer = this.journalWriter;
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("CLEAN ");
                        stringBuilder.append(entry.key);
                        stringBuilder.append(entry.getLengths());
                        stringBuilder.append('\n');
                        writer.write(stringBuilder.toString());
                        if (bl) {
                            long l = this.nextSequenceNumber;
                            this.nextSequenceNumber = 1L + l;
                            entry.sequenceNumber = l;
                        }
                    } else {
                        this.lruEntries.remove((Object)entry.key);
                        Writer writer = this.journalWriter;
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("REMOVE ");
                        stringBuilder.append(entry.key);
                        stringBuilder.append('\n');
                        writer.write(stringBuilder.toString());
                    }
                    this.journalWriter.flush();
                    if (this.size > this.maxSize || this.journalRebuildRequired()) {
                        this.a.submit(this.cleanupCallable);
                    }
                    return;
                }
                ++n;
            } while (true);
        }
    }

    private static void deleteIfExists(File file) throws IOException {
        if (file.exists()) {
            if (file.delete()) {
                return;
            }
            throw new IOException();
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private Editor edit(String string2, long l) throws IOException {
        DiskLruCache diskLruCache = this;
        synchronized (diskLruCache) {
            long l2;
            this.checkNotClosed();
            this.validateKey(string2);
            Entry entry = (Entry)this.lruEntries.get((Object)string2);
            if (l != -1L && (entry == null || (l2 = entry.sequenceNumber) != l)) {
                return null;
            }
            if (entry == null) {
                entry = new Entry(string2, null);
                this.lruEntries.put((Object)string2, (Object)entry);
            } else {
                Editor editor = entry.currentEditor;
                if (editor != null) {
                    return null;
                }
            }
            Editor editor = new Editor(entry, null);
            entry.currentEditor = editor;
            Writer writer = this.journalWriter;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("DIRTY ");
            stringBuilder.append(string2);
            stringBuilder.append('\n');
            writer.write(stringBuilder.toString());
            this.journalWriter.flush();
            return editor;
        }
    }

    public static /* synthetic */ OutputStream h() {
        return NULL_OUTPUT_STREAM;
    }

    private static String inputStreamToString(InputStream inputStream) throws IOException {
        InputStreamReader inputStreamReader = new InputStreamReader(inputStream, Util.b);
        try {
            int n;
            StringWriter stringWriter = new StringWriter();
            char[] arrc = new char[1024];
            while ((n = inputStreamReader.read(arrc)) != -1) {
                stringWriter.write(arrc, 0, n);
            }
            String string2 = stringWriter.toString();
            return string2;
        }
        finally {
            inputStreamReader.close();
        }
    }

    private boolean journalRebuildRequired() {
        int n = this.redundantOpCount;
        return n >= 2000 && n >= this.lruEntries.size();
    }

    public static DiskLruCache open(File file, int n, int n2, long l) throws IOException {
        if (l > 0L) {
            if (n2 > 0) {
                File file2 = new File(file, "journal.bkp");
                if (file2.exists()) {
                    File file3 = new File(file, "journal");
                    if (file3.exists()) {
                        file2.delete();
                    } else {
                        DiskLruCache.renameTo(file2, file3, false);
                    }
                }
                DiskLruCache diskLruCache = new DiskLruCache(file, n, n2, l);
                if (diskLruCache.journalFile.exists()) {
                    try {
                        diskLruCache.readJournal();
                        diskLruCache.processJournal();
                        diskLruCache.journalWriter = new BufferedWriter((Writer)new OutputStreamWriter((OutputStream)new FileOutputStream(diskLruCache.journalFile, true), Util.a));
                        return diskLruCache;
                    }
                    catch (IOException iOException) {
                        PrintStream printStream = System.out;
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("DiskLruCache ");
                        stringBuilder.append((Object)file);
                        stringBuilder.append(" is corrupt: ");
                        stringBuilder.append(iOException.getMessage());
                        stringBuilder.append(", removing");
                        printStream.println(stringBuilder.toString());
                        diskLruCache.delete();
                    }
                }
                file.mkdirs();
                DiskLruCache diskLruCache2 = new DiskLruCache(file, n, n2, l);
                diskLruCache2.rebuildJournal();
                return diskLruCache2;
            }
            throw new IllegalArgumentException("valueCount <= 0");
        }
        throw new IllegalArgumentException("maxSize <= 0");
    }

    private void processJournal() throws IOException {
        DiskLruCache.deleteIfExists(this.journalFileTmp);
        Iterator iterator = this.lruEntries.values().iterator();
        while (iterator.hasNext()) {
            int n;
            Entry entry = (Entry)iterator.next();
            Editor editor = entry.currentEditor;
            if (editor == null) {
                for (n = 0; n < this.valueCount; ++n) {
                    this.size += entry.lengths[n];
                }
                continue;
            }
            entry.currentEditor = null;
            while (n < this.valueCount) {
                DiskLruCache.deleteIfExists(entry.getCleanFile(n));
                DiskLruCache.deleteIfExists(entry.getDirtyFile(n));
                ++n;
            }
            iterator.remove();
        }
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private void readJournal() throws IOException {
        boolean bl;
        StrictLineReader strictLineReader = new StrictLineReader((InputStream)new FileInputStream(this.journalFile), Util.a);
        String string5 = strictLineReader.readLine();
        String string4 = strictLineReader.readLine();
        String string6 = strictLineReader.readLine();
        String string2 = strictLineReader.readLine();
        String string3 = strictLineReader.readLine();
        if (!("libcore.io.DiskLruCache".equals((Object)string5) && "1".equals((Object)string4) && Integer.toString((int)this.appVersion).equals((Object)string6) && Integer.toString((int)this.valueCount).equals((Object)string2) && (bl = "".equals((Object)string3)))) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("unexpected journal header: [");
            stringBuilder.append(string5);
            stringBuilder.append(", ");
            stringBuilder.append(string4);
            stringBuilder.append(", ");
            stringBuilder.append(string2);
            stringBuilder.append(", ");
            stringBuilder.append(string3);
            stringBuilder.append("]");
            throw new IOException(stringBuilder.toString());
        }
        int n = 0;
        {
            catch (Throwable throwable) {
                throw throwable;
            }
            try {
                do {
                    this.readJournalLine(strictLineReader.readLine());
                    ++n;
                } while (true);
            }
            catch (EOFException eOFException) {}
            this.redundantOpCount = n - this.lruEntries.size();
            return;
        }
    }

    private void readJournalLine(String string2) throws IOException {
        int n = string2.indexOf(32);
        if (n != -1) {
            Entry entry;
            String string3;
            int n2 = n + 1;
            int n3 = string2.indexOf(32, n2);
            if (n3 == -1) {
                string3 = string2.substring(n2);
                if (n == 6 && string2.startsWith(REMOVE)) {
                    this.lruEntries.remove((Object)string3);
                    return;
                }
            } else {
                string3 = string2.substring(n2, n3);
            }
            if ((entry = (Entry)this.lruEntries.get((Object)string3)) == null) {
                entry = new Entry(string3, null);
                this.lruEntries.put((Object)string3, (Object)entry);
            }
            if (n3 != -1 && n == 5 && string2.startsWith(CLEAN)) {
                String[] arrstring = string2.substring(n3 + 1).split(" ");
                entry.readable = true;
                entry.currentEditor = null;
                entry.setLengths(arrstring);
                return;
            }
            if (n3 == -1 && n == 5 && string2.startsWith(DIRTY)) {
                entry.currentEditor = new Editor(entry, null);
                return;
            }
            if (n3 == -1 && n == 4 && string2.startsWith(READ)) {
                return;
            }
            throw new IOException(a.h1((String)"unexpected journal line: ", (String)string2));
        }
        throw new IOException(a.h1((String)"unexpected journal line: ", (String)string2));
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void rebuildJournal() throws IOException {
        DiskLruCache diskLruCache = this;
        synchronized (diskLruCache) {
            BufferedWriter bufferedWriter;
            block9 : {
                Writer writer = this.journalWriter;
                if (writer != null) {
                    writer.close();
                }
                bufferedWriter = new BufferedWriter((Writer)new OutputStreamWriter((OutputStream)new FileOutputStream(this.journalFileTmp), Util.a));
                bufferedWriter.write("libcore.io.DiskLruCache");
                bufferedWriter.write("\n");
                bufferedWriter.write("1");
                bufferedWriter.write("\n");
                bufferedWriter.write(Integer.toString((int)this.appVersion));
                bufferedWriter.write("\n");
                bufferedWriter.write(Integer.toString((int)this.valueCount));
                bufferedWriter.write("\n");
                bufferedWriter.write("\n");
                for (Entry entry : this.lruEntries.values()) {
                    if (entry.currentEditor != null) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("DIRTY ");
                        stringBuilder.append(entry.key);
                        stringBuilder.append('\n');
                        bufferedWriter.write(stringBuilder.toString());
                        continue;
                    }
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("CLEAN ");
                    stringBuilder.append(entry.key);
                    stringBuilder.append(entry.getLengths());
                    stringBuilder.append('\n');
                    bufferedWriter.write(stringBuilder.toString());
                }
                if (!this.journalFile.exists()) break block9;
                DiskLruCache.renameTo(this.journalFile, this.journalFileBackup, true);
            }
            DiskLruCache.renameTo(this.journalFileTmp, this.journalFile, false);
            this.journalFileBackup.delete();
            this.journalWriter = new BufferedWriter((Writer)new OutputStreamWriter((OutputStream)new FileOutputStream(this.journalFile, true), Util.a));
            return;
            finally {
                bufferedWriter.close();
            }
        }
    }

    private static void renameTo(File file, File file2, boolean bl) throws IOException {
        if (bl) {
            DiskLruCache.deleteIfExists(file2);
        }
        if (file.renameTo(file2)) {
            return;
        }
        throw new IOException();
    }

    private void trimToSize() throws IOException {
        while (this.size > this.maxSize) {
            this.remove((String)((Map.Entry)this.lruEntries.entrySet().iterator().next()).getKey());
        }
    }

    private void validateKey(String string2) {
        if (b.matcher((CharSequence)string2).matches()) {
            return;
        }
        throw new IllegalArgumentException(a.i1((String)"keys must match regex [a-z0-9_-]{1,64}: \"", (String)string2, (String)"\""));
    }

    public void close() throws IOException {
        DiskLruCache diskLruCache = this;
        synchronized (diskLruCache) {
            block5 : {
                Writer writer = this.journalWriter;
                if (writer != null) break block5;
                return;
            }
            for (Entry entry : new ArrayList(this.lruEntries.values())) {
                if (entry.currentEditor == null) continue;
                entry.currentEditor.abort();
            }
            this.trimToSize();
            this.journalWriter.close();
            this.journalWriter = null;
            return;
        }
    }

    public void delete() throws IOException {
        this.close();
        Util.b(this.directory);
    }

    public Editor edit(String string2) throws IOException {
        return this.edit(string2, -1L);
    }

    public void flush() throws IOException {
        DiskLruCache diskLruCache = this;
        synchronized (diskLruCache) {
            this.checkNotClosed();
            this.trimToSize();
            this.journalWriter.flush();
            return;
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public Snapshot get(String var1_1) throws IOException {
        var17_2 = this;
        // MONITORENTER : var17_2
        this.checkNotClosed();
        this.validateKey(var1_1);
        var3_3 = (Entry)this.lruEntries.get((Object)var1_1);
        if (var3_3 == null) {
            // MONITOREXIT : var17_2
            return null;
        }
        var4_4 = Entry.e(var3_3);
        if (!var4_4) {
            // MONITOREXIT : var17_2
            return null;
        }
        var5_5 = new InputStream[this.valueCount];
        var7_7 = 0;
        try {
            do {
                var8_8 = this.valueCount;
                var6_6 = 0;
                if (var7_7 >= var8_8) ** break;
                var5_5[var7_7] = new FileInputStream(var3_3.getCleanFile(var7_7));
                ++var7_7;
            } while (true);
        }
        catch (FileNotFoundException v0) {
            for (var6_6 = 0; var6_6 < this.valueCount && var5_5[var6_6] != null; ++var6_6) {
                Util.a((Closeable)var5_5[var6_6]);
            }
            // MONITOREXIT : var17_2
            return null;
        }
        this.redundantOpCount = 1 + this.redundantOpCount;
        var9_9 = this.journalWriter;
        var10_10 = new StringBuilder();
        var10_10.append("READ ");
        var10_10.append(var1_1);
        var10_10.append('\n');
        var9_9.append((CharSequence)var10_10.toString());
        if (this.journalRebuildRequired()) {
            this.a.submit(this.cleanupCallable);
        }
        var15_11 = new Snapshot(var1_1, Entry.c(var3_3), var5_5, Entry.a(var3_3), null);
        // MONITOREXIT : var17_2
        return var15_11;
    }

    public File getDirectory() {
        return this.directory;
    }

    public long getMaxSize() {
        DiskLruCache diskLruCache = this;
        synchronized (diskLruCache) {
            long l = this.maxSize;
            return l;
        }
    }

    public boolean isClosed() {
        DiskLruCache diskLruCache = this;
        synchronized (diskLruCache) {
            Writer writer = this.journalWriter;
            boolean bl = writer == null;
            return bl;
        }
    }

    public boolean remove(String string2) throws IOException {
        DiskLruCache diskLruCache = this;
        synchronized (diskLruCache) {
            block9 : {
                this.checkNotClosed();
                this.validateKey(string2);
                Entry entry = (Entry)this.lruEntries.get((Object)string2);
                if (entry == null) break block9;
                Editor editor = entry.currentEditor;
                int n = 0;
                if (editor != null) break block9;
                do {
                    if (n >= this.valueCount) break;
                    File file = entry.getCleanFile(n);
                    if (file.exists() && !file.delete()) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("failed to delete ");
                        stringBuilder.append((Object)file);
                        throw new IOException(stringBuilder.toString());
                    }
                    this.size -= entry.lengths[n];
                    Entry.a((Entry)entry)[n] = 0L;
                    ++n;
                } while (true);
                this.redundantOpCount = 1 + this.redundantOpCount;
                Writer writer = this.journalWriter;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("REMOVE ");
                stringBuilder.append(string2);
                stringBuilder.append('\n');
                writer.append((CharSequence)stringBuilder.toString());
                this.lruEntries.remove((Object)string2);
                if (this.journalRebuildRequired()) {
                    this.a.submit(this.cleanupCallable);
                }
                return true;
            }
            return false;
        }
    }

    public void setMaxSize(long l) {
        DiskLruCache diskLruCache = this;
        synchronized (diskLruCache) {
            this.maxSize = l;
            this.a.submit(this.cleanupCallable);
            return;
        }
    }

    public long size() {
        DiskLruCache diskLruCache = this;
        synchronized (diskLruCache) {
            long l = this.size;
            return l;
        }
    }

    public final class Editor {
        private boolean committed;
        private final Entry entry;
        private boolean hasErrors;
        private final boolean[] written;

        private Editor(Entry entry) {
            this.entry = entry;
            boolean[] arrbl = entry.readable ? null : new boolean[DiskLruCache.this.valueCount];
            this.written = arrbl;
        }

        public /* synthetic */ Editor(Entry entry, 1 var3_3) {
            this(entry);
        }

        public void abort() throws IOException {
            DiskLruCache.this.completeEdit(this, false);
        }

        /*
         * Exception decompiling
         */
        public void abortUnlessCommitted() {
            // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
            // org.benf.cfr.reader.util.ConfusedCFRException: Underrun type stack
            // org.benf.cfr.reader.b.a.c.e.a(StackSim.java:35)
            // org.benf.cfr.reader.b.b.af.a(OperationFactoryPop.java:20)
            // org.benf.cfr.reader.b.b.e.a(JVMInstr.java:315)
            // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:195)
            // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
            // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
            // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
            // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
            // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
            // org.benf.cfr.reader.entities.g.p(Method.java:396)
            // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
            // org.benf.cfr.reader.entities.d.c(ClassFile.java:773)
            // org.benf.cfr.reader.entities.d.e(ClassFile.java:870)
            // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
            // org.benf.cfr.reader.b.a(Driver.java:128)
            // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
            // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
            // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
            // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
            // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
            // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
            // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
            // java.lang.Thread.run(Thread.java:923)
            throw new IllegalStateException("Decompilation failed");
        }

        public void commit() throws IOException {
            if (this.hasErrors) {
                DiskLruCache.this.completeEdit(this, false);
                DiskLruCache.this.remove(this.entry.key);
            } else {
                DiskLruCache.this.completeEdit(this, true);
            }
            this.committed = true;
        }

        public String getString(int n) throws IOException {
            InputStream inputStream = this.newInputStream(n);
            if (inputStream != null) {
                return DiskLruCache.inputStreamToString(inputStream);
            }
            return null;
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        public InputStream newInputStream(int n) throws IOException {
            DiskLruCache diskLruCache;
            DiskLruCache diskLruCache2 = diskLruCache = DiskLruCache.this;
            synchronized (diskLruCache2) {
                if (this.entry.currentEditor != this) {
                    throw new IllegalStateException();
                }
                if (!this.entry.readable) {
                    return null;
                }
                try {
                    return new FileInputStream(this.entry.getCleanFile(n));
                }
                catch (FileNotFoundException fileNotFoundException) {
                    return null;
                }
            }
        }

        /*
         * Exception decompiling
         */
        public OutputStream newOutputStream(int var1) throws IOException {
            // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
            // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl43 : NEW : trying to set 1 previously set to 0
            // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
            // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
            // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
            // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
            // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
            // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
            // org.benf.cfr.reader.entities.g.p(Method.java:396)
            // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
            // org.benf.cfr.reader.entities.d.c(ClassFile.java:773)
            // org.benf.cfr.reader.entities.d.e(ClassFile.java:870)
            // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
            // org.benf.cfr.reader.b.a(Driver.java:128)
            // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
            // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
            // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
            // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
            // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
            // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
            // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
            // java.lang.Thread.run(Thread.java:923)
            throw new IllegalStateException("Decompilation failed");
        }

        /*
         * Loose catch block
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         * Lifted jumps to return sites
         */
        public void set(int n, String string2) throws IOException {
            void var5_7;
            OutputStreamWriter outputStreamWriter;
            block4 : {
                outputStreamWriter = null;
                OutputStreamWriter outputStreamWriter2 = new OutputStreamWriter(this.newOutputStream(n), Util.b);
                try {
                    outputStreamWriter2.write(string2);
                }
                catch (Throwable throwable) {
                    outputStreamWriter = outputStreamWriter2;
                    break block4;
                }
                Util.a((Closeable)outputStreamWriter2);
                return;
                catch (Throwable throwable) {
                    // empty catch block
                }
            }
            Util.a(outputStreamWriter);
            throw var5_7;
        }

        public class FaultHidingOutputStream
        extends FilterOutputStream {
            private FaultHidingOutputStream(OutputStream outputStream) {
                super(outputStream);
            }

            public /* synthetic */ FaultHidingOutputStream(OutputStream outputStream, 1 var3_3) {
                this(outputStream);
            }

            public void close() {
                try {
                    this.out.close();
                    return;
                }
                catch (IOException iOException) {
                    Editor.this.hasErrors = true;
                    return;
                }
            }

            public void flush() {
                try {
                    this.out.flush();
                    return;
                }
                catch (IOException iOException) {
                    Editor.this.hasErrors = true;
                    return;
                }
            }

            public void write(int n) {
                try {
                    this.out.write(n);
                    return;
                }
                catch (IOException iOException) {
                    Editor.this.hasErrors = true;
                    return;
                }
            }

            public void write(byte[] arrby, int n, int n2) {
                try {
                    this.out.write(arrby, n, n2);
                    return;
                }
                catch (IOException iOException) {
                    Editor.this.hasErrors = true;
                    return;
                }
            }
        }

    }

    public final class Entry {
        private Editor currentEditor;
        private final String key;
        private final long[] lengths;
        private boolean readable;
        private long sequenceNumber;

        private Entry(String string2) {
            this.key = string2;
            this.lengths = new long[DiskLruCache.this.valueCount];
        }

        public /* synthetic */ Entry(String string2, 1 var3_3) {
            this(string2);
        }

        private IOException invalidLengths(String[] arrstring) throws IOException {
            StringBuilder stringBuilder = a.F1((String)"unexpected journal line: ");
            stringBuilder.append(Arrays.toString((Object[])arrstring));
            throw new IOException(stringBuilder.toString());
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        private void setLengths(String[] arrstring) throws IOException {
            if (arrstring.length != DiskLruCache.this.valueCount) {
                throw this.invalidLengths(arrstring);
            }
            try {
                for (int n = 0; n < arrstring.length; ++n) {
                    this.lengths[n] = Long.parseLong((String)arrstring[n]);
                }
                return;
            }
            catch (NumberFormatException numberFormatException) {
                throw this.invalidLengths(arrstring);
            }
        }

        public File getCleanFile(int n) {
            File file = DiskLruCache.this.directory;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(this.key);
            stringBuilder.append(".");
            stringBuilder.append(n);
            return new File(file, stringBuilder.toString());
        }

        public File getDirtyFile(int n) {
            File file = DiskLruCache.this.directory;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(this.key);
            stringBuilder.append(".");
            stringBuilder.append(n);
            stringBuilder.append(".tmp");
            return new File(file, stringBuilder.toString());
        }

        public String getLengths() throws IOException {
            StringBuilder stringBuilder = new StringBuilder();
            for (long l : this.lengths) {
                stringBuilder.append(' ');
                stringBuilder.append(l);
            }
            return stringBuilder.toString();
        }
    }

    public final class Snapshot
    implements Closeable {
        private final InputStream[] ins;
        private final String key;
        private final long[] lengths;
        private final long sequenceNumber;

        private Snapshot(String string2, long l, InputStream[] arrinputStream, long[] arrl) {
            this.key = string2;
            this.sequenceNumber = l;
            this.ins = arrinputStream;
            this.lengths = arrl;
        }

        public /* synthetic */ Snapshot(String string2, long l, InputStream[] arrinputStream, long[] arrl, 1 var7_6) {
            this(string2, l, arrinputStream, arrl);
        }

        public void close() {
            InputStream[] arrinputStream = this.ins;
            int n = arrinputStream.length;
            for (int i = 0; i < n; ++i) {
                Util.a((Closeable)arrinputStream[i]);
            }
        }

        public Editor edit() throws IOException {
            return DiskLruCache.this.edit(this.key, this.sequenceNumber);
        }

        public InputStream getInputStream(int n) {
            return this.ins[n];
        }

        public long getLength(int n) {
            return this.lengths[n];
        }

        public String getString(int n) throws IOException {
            return DiskLruCache.inputStreamToString(this.getInputStream(n));
        }
    }

}

