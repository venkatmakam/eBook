/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.net.Uri
 *  com.google.firebase.perf.network.FirebasePerfOkHttpClient
 *  com.squareup.picasso.Downloader
 *  com.squareup.picasso.Downloader$Response
 *  com.squareup.picasso.Downloader$ResponseException
 *  com.squareup.picasso.NetworkPolicy
 *  e.a.a.a.a
 *  java.io.File
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  okhttp3.Cache
 *  okhttp3.CacheControl
 *  okhttp3.CacheControl$Builder
 *  okhttp3.Call
 *  okhttp3.Call$Factory
 *  okhttp3.OkHttpClient
 *  okhttp3.OkHttpClient$Builder
 *  okhttp3.Request
 *  okhttp3.Request$Builder
 *  okhttp3.Response
 *  okhttp3.ResponseBody
 */
package com.jakewharton.picasso;

import android.content.Context;
import android.net.Uri;
import com.google.firebase.perf.network.FirebasePerfOkHttpClient;
import com.squareup.picasso.Downloader;
import com.squareup.picasso.NetworkPolicy;
import e.a.a.a.a;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import okhttp3.Cache;
import okhttp3.CacheControl;
import okhttp3.Call;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;

public final class OkHttp3Downloader
implements Downloader {
    private static final int MAX_DISK_CACHE_SIZE = 52428800;
    private static final int MIN_DISK_CACHE_SIZE = 5242880;
    private static final String PICASSO_CACHE = "picasso-cache";
    private final Cache cache;
    private final Call.Factory client;

    public OkHttp3Downloader(Context context) {
        this(OkHttp3Downloader.defaultCacheDir(context));
    }

    public OkHttp3Downloader(Context context, long l) {
        this(OkHttp3Downloader.defaultCacheDir(context), l);
    }

    public OkHttp3Downloader(File file) {
        this(file, OkHttp3Downloader.calculateDiskCacheSize(file));
    }

    public OkHttp3Downloader(File file, long l) {
        this(OkHttp3Downloader.createOkHttpClient(file, l));
    }

    public OkHttp3Downloader(Call.Factory factory) {
        this.client = factory;
        this.cache = null;
    }

    public OkHttp3Downloader(OkHttpClient okHttpClient) {
        this.client = okHttpClient;
        this.cache = okHttpClient.cache();
    }

    /*
     * Exception decompiling
     */
    private static long calculateDiskCacheSize(File var0) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl20 : LLOAD_2 : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    public static Cache createDefaultCache(Context context) {
        File file = OkHttp3Downloader.defaultCacheDir(context);
        return new Cache(file, OkHttp3Downloader.calculateDiskCacheSize(file));
    }

    private static OkHttpClient createOkHttpClient(File file, long l) {
        return new OkHttpClient.Builder().cache(new Cache(file, l)).build();
    }

    private static File defaultCacheDir(Context context) {
        File file = new File(context.getApplicationContext().getCacheDir(), PICASSO_CACHE);
        if (!file.exists()) {
            file.mkdirs();
        }
        return file;
    }

    public Downloader.Response load(Uri uri, int n) throws IOException {
        Response response;
        int n2;
        CacheControl cacheControl;
        if (n != 0) {
            if (NetworkPolicy.isOfflineOnly((int)n)) {
                cacheControl = CacheControl.FORCE_CACHE;
            } else {
                CacheControl.Builder builder = new CacheControl.Builder();
                if (!NetworkPolicy.shouldReadFromDiskCache((int)n)) {
                    builder.noCache();
                }
                if (!NetworkPolicy.shouldWriteToDiskCache((int)n)) {
                    builder.noStore();
                }
                cacheControl = builder.build();
            }
        } else {
            cacheControl = null;
        }
        Request.Builder builder = new Request.Builder().url(uri.toString());
        if (cacheControl != null) {
            builder.cacheControl(cacheControl);
        }
        if ((n2 = (response = FirebasePerfOkHttpClient.execute((Call)this.client.newCall(builder.build()))).code()) < 300) {
            boolean bl = response.cacheResponse() != null;
            ResponseBody responseBody = response.body();
            return new Downloader.Response(responseBody.byteStream(), bl, responseBody.contentLength());
        }
        response.body().close();
        StringBuilder stringBuilder = a.C1((int)n2, (String)" ");
        stringBuilder.append(response.message());
        throw new Downloader.ResponseException(stringBuilder.toString(), n, n2);
    }

    /*
     * Exception decompiling
     */
    public void shutdown() {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Underrun type stack
        // org.benf.cfr.reader.b.a.c.e.a(StackSim.java:35)
        // org.benf.cfr.reader.b.b.af.a(OperationFactoryPop.java:20)
        // org.benf.cfr.reader.b.b.e.a(JVMInstr.java:315)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:195)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }
}

