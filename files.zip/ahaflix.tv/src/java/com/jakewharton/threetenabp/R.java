/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.jakewharton.threetenabp;

public final class R {
    private R() {
    }
}

