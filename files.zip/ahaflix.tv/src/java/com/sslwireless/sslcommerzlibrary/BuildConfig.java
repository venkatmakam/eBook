/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.sslwireless.sslcommerzlibrary;

public final class BuildConfig {
    public static final String BASE_URL = "https://securepay.sslcommerz.com/gwprocess/v4/";
    public static final String BASE_URL_SANDBOX = "https://sandbox.sslcommerz.com/gwprocess/v4/";
    public static final String BUILD_TYPE = "release";
    public static final boolean DEBUG = false;
    public static final String LIBRARY_PACKAGE_NAME = "com.sslwireless.sslcommerzlibrary";
    public static final String MAIN_LIVE_URL = "https://api-epay.sslcommerz.com/securepay/api.php/";
    public static final String MAIN_SANDBOX_URL = "https://sandbox.sslcommerz.com/securepay/api.php/";
    public static final String MERCHANT_VALIDATOR_LIVE_URL = "https://securepay.sslcommerz.com/validator/api/";
    public static final String MERCHANT_VALIDATOR_SANDBOX_URL = "https://sandbox.sslcommerz.com/validator/api/";
    public static final int VERSION_CODE = 1;
    public static final String VERSION_NAME = "1.0";
}

