/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.util.Base64
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.security.Key
 *  java.security.spec.AlgorithmParameterSpec
 *  java.util.Random
 *  javax.crypto.Cipher
 *  javax.crypto.spec.IvParameterSpec
 *  javax.crypto.spec.SecretKeySpec
 */
package com.sslwireless.sslcommerzlibrary.viewmodel.encryption;

import android.util.Base64;
import java.security.Key;
import java.security.spec.AlgorithmParameterSpec;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class SSLCEncryptionController {
    public static String decrypt(String string, String string2, String string3) throws Exception {
        byte[] arrby = string.getBytes();
        byte[] arrby2 = string2.getBytes();
        byte[] arrby3 = Base64.decode((String)string3, (int)0);
        IvParameterSpec ivParameterSpec = new IvParameterSpec(arrby);
        SecretKeySpec secretKeySpec = new SecretKeySpec(arrby2, "AES/CBC/PKCS5Padding");
        Cipher cipher = Cipher.getInstance((String)"AES/CBC/PKCS5Padding");
        cipher.init(2, (Key)secretKeySpec, (AlgorithmParameterSpec)ivParameterSpec);
        return new String(cipher.doFinal(arrby3));
    }

    public static String encrypt(String string, String string2, String string3) throws Exception {
        byte[] arrby = string.getBytes();
        byte[] arrby2 = string2.getBytes();
        byte[] arrby3 = string3.getBytes();
        IvParameterSpec ivParameterSpec = new IvParameterSpec(arrby);
        SecretKeySpec secretKeySpec = new SecretKeySpec(arrby2, "AES/CBC/PKCS5Padding");
        Cipher cipher = Cipher.getInstance((String)"AES/CBC/PKCS5Padding");
        cipher.init(1, (Key)secretKeySpec, (AlgorithmParameterSpec)ivParameterSpec);
        return Base64.encodeToString((byte[])cipher.doFinal(arrby3), (int)0);
    }

    public static String getIvString(int n) {
        StringBuilder stringBuilder = new StringBuilder();
        Random random = new Random();
        while (stringBuilder.length() < n) {
            stringBuilder.append("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890~!@#%^&*()_+".charAt((int)(random.nextFloat() * (float)74)));
        }
        return stringBuilder.toString();
    }
}

