/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  java.lang.Object
 *  java.lang.String
 */
package com.sslwireless.sslcommerzlibrary.viewmodel.listener;

import android.graphics.Bitmap;

public interface SSLCDowloadImageListener {
    public void downloadFailed(String var1);

    public void downloadSuccess(Bitmap var1);
}

