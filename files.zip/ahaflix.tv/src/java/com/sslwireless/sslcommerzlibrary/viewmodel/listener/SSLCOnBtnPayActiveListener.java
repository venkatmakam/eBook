/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.lang.String
 */
package com.sslwireless.sslcommerzlibrary.viewmodel.listener;

public interface SSLCOnBtnPayActiveListener {
    public void onBtnPayActive(Boolean var1, String var2);
}

