/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.sslwireless.sslcommerzlibrary.viewmodel.listener;

import com.sslwireless.sslcommerzlibrary.model.response.SSLCTransactionInfo;

public interface SSLCPayWithStoredCardListener {
    public void payWithStoredCardInfoFail(String var1);

    public void payWithStoredCardInfoSuccess(SSLCTransactionInfo var1);

    public void payWithStoredCardInfoValidationError(String var1);
}

