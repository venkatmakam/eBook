/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 */
package com.sslwireless.sslcommerzlibrary.viewmodel.listener;

import java.util.ArrayList;

public interface SSLCOnOfferSelectListener {
    public void onOfferSelect(String var1, String var2, String var3, String var4, ArrayList<String> var5);
}

