/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.sslwireless.sslcommerzlibrary.viewmodel.listener;

import com.sslwireless.sslcommerzlibrary.model.response.SSLCSdkMainResponseModel;

public interface SSLCBaseSuccessResponseListener {
    public void failResponse(String var1);

    public void successResponse(SSLCSdkMainResponseModel var1);

    public void validationError(String var1);
}

