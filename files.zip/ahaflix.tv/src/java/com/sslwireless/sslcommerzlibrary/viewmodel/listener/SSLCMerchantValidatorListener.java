/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.sslwireless.sslcommerzlibrary.viewmodel.listener;

import com.sslwireless.sslcommerzlibrary.model.response.SSLCTransactionInfoModel;

public interface SSLCMerchantValidatorListener {
    public void merchantValidatorFail(String var1);

    public void merchantValidatorSuccess(SSLCTransactionInfoModel var1);
}

