/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.util.Base64
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.sslwireless.sslcommerzlibrary.viewmodel.encryption;

import android.util.Base64;
import com.sslwireless.sslcommerzlibrary.viewmodel.encryption.SSLCEncryptionController;

public class SSLCEncryptionHandler {
    private static final SSLCEncryptionHandler SSLC_ENCRYPTION_HANDLER = new SSLCEncryptionHandler();

    private SSLCEncryptionHandler() {
    }

    public static SSLCEncryptionHandler getInstance() {
        return SSLC_ENCRYPTION_HANDLER;
    }

    public String decryptData(String string, String string2) {
        String[] arrstring = new String(Base64.decode((String)string2, (int)0)).split("\\|\\|\\|");
        try {
            String string3 = SSLCEncryptionController.decrypt(arrstring[0], string, arrstring[1]);
            return string3;
        }
        catch (Exception exception) {
            return null;
        }
    }

    public String encryptData(String string, String string2) {
        String string3 = SSLCEncryptionController.getIvString(16);
        try {
            String string4 = SSLCEncryptionController.encrypt(string3, string, string2);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(string3);
            stringBuilder.append("|||");
            stringBuilder.append(string4);
            String string5 = Base64.encodeToString((byte[])stringBuilder.toString().getBytes(), (int)0);
            return string5;
        }
        catch (Exception exception) {
            return null;
        }
    }
}

