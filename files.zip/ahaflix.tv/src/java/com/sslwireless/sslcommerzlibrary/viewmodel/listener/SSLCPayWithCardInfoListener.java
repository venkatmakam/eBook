/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.sslwireless.sslcommerzlibrary.viewmodel.listener;

import com.sslwireless.sslcommerzlibrary.model.response.SSLCTransactionInfo;

public interface SSLCPayWithCardInfoListener {
    public void payWithCardInfoFail(String var1);

    public void payWithCardInfoSuccess(SSLCTransactionInfo var1);

    public void payWithCardInfoValidationError(String var1);
}

