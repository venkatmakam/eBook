/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.sslwireless.sslcommerzlibrary.viewmodel.listener;

import com.sslwireless.sslcommerzlibrary.model.response.SSLCGetDeviceTokenModel;

public interface SSLCGetDeviceTokenListener {
    public void deviceTokenFail(String var1);

    public void deviceTokenSuccess(SSLCGetDeviceTokenModel var1);
}

