/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.sslwireless.sslcommerzlibrary.viewmodel.listener;

import com.sslwireless.sslcommerzlibrary.model.response.SSLCOfferModel;

public interface SSLCGetOfferListener {
    public void resendOtpFail(String var1);

    public void resendOtpSuccess(SSLCOfferModel var1);
}

