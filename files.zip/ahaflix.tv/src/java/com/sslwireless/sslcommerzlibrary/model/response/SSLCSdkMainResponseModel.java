/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.gson.annotations.Expose
 *  com.google.gson.annotations.SerializedName
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.sslwireless.sslcommerzlibrary.model.response;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class SSLCSdkMainResponseModel {
    @Expose
    @SerializedName(value="CustomerName")
    private String CustomerName = "";
    @Expose
    @SerializedName(value="FAQURL")
    private String FAQURL;
    @Expose
    @SerializedName(value="activeColor")
    private String activeColor;
    @Expose
    @SerializedName(value="amount")
    private String amount;
    @Expose
    @SerializedName(value="currency")
    private String currency;
    @Expose
    @SerializedName(value="currency_amount")
    private String currencyAmount;
    @Expose
    @SerializedName(value="currency_rate")
    private String currencyRate;
    @Expose
    @SerializedName(value="currency_type")
    private String currencyType;
    @Expose
    @SerializedName(value="cust_mobile")
    private String cust_mobile = "";
    @Expose
    @SerializedName(value="default_tab")
    private String default_tab;
    @Expose
    @SerializedName(value="desc")
    private List<Desc> desc = null;
    @Expose
    @SerializedName(value="design")
    private Design design;
    @Expose
    @SerializedName(value="directPaymentURL")
    private String directPaymentURL;
    @Expose
    @SerializedName(value="emi_status")
    private Integer emiStatus;
    @Expose
    @SerializedName(value="existingMobile")
    private Integer existingMobile;
    @Expose
    @SerializedName(value="facebookPageURL")
    private String facebookPageURL;
    @Expose
    @SerializedName(value="failedreason")
    private String failedreason;
    @Expose
    @SerializedName(value="GatewayPageURL")
    private String gatewayPageURL;
    @Expose
    @SerializedName(value="gw")
    private Gw gw;
    @Expose
    @SerializedName(value="is_direct_pay_enable")
    private String isDirectPayEnable;
    @Expose
    @SerializedName(value="loginTransSession")
    private String loginTransSession;
    @Expose
    @SerializedName(value="moreInfoURL")
    private String moreInfoURL;
    @Expose
    @SerializedName(value="numberOfCardSaved")
    private Integer numberOfCardSaved;
    @Expose
    @SerializedName(value="offer_status")
    private Integer offerStatus;
    @Expose
    @SerializedName(value="primaryColor")
    private String primaryColor;
    @Expose
    @SerializedName(value="redirectGatewayURL")
    private String redirectGatewayURL;
    @Expose
    @SerializedName(value="sessionkey")
    private String sessionkey;
    @Expose
    @SerializedName(value="status")
    private String status;
    @Expose
    @SerializedName(value="storeBanner")
    private String storeBanner;
    @Expose
    @SerializedName(value="storeLogo")
    private String storeLogo;
    @Expose
    @SerializedName(value="store_name")
    private String storeName;
    @Expose
    @SerializedName(value="subscription_error")
    private String subscriptionError;
    @Expose
    @SerializedName(value="subscription_id")
    private String subscriptionId;
    @Expose
    @SerializedName(value="subscription_status")
    private String subscriptionStatus;
    @Expose
    @SerializedName(value="supportEmail")
    private String supportEmail;
    @Expose
    @SerializedName(value="supportPhone")
    private String supportPhone;
    @Expose
    @SerializedName(value="termsAndConditionURL")
    private String termsAndConditionURL;
    @Expose
    @SerializedName(value="timeoutinMin")
    private String timeoutinMin;
    @Expose
    @SerializedName(value="tran_id")
    private String tranId;

    /*
     * Exception decompiling
     */
    public SSLCSdkMainResponseModel fromJSON(String var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl605 : ACONST_NULL : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    public String getActiveColor() {
        String string2 = this.activeColor;
        if (string2 != null && string2.isEmpty()) {
            this.activeColor = "00FF00";
        }
        return this.activeColor;
    }

    public String getAmount() {
        return this.amount;
    }

    public String getCurrency() {
        return this.currency;
    }

    public String getCurrencyAmount() {
        return this.currencyAmount;
    }

    public String getCurrencyRate() {
        return this.currencyRate;
    }

    public String getCurrencyType() {
        return this.currencyType;
    }

    public String getCustMobile() {
        return this.cust_mobile;
    }

    public String getCustomerName() {
        return this.CustomerName;
    }

    public String getDefault_tab() {
        return this.default_tab;
    }

    public List<Desc> getDesc() {
        return this.desc;
    }

    public Design getDesign() {
        return this.design;
    }

    public String getDirectPaymentURL() {
        return this.directPaymentURL;
    }

    public Integer getEmiStatus() {
        return this.emiStatus;
    }

    public Integer getExistingMobile() {
        return this.existingMobile;
    }

    public String getFAQURL() {
        return this.FAQURL;
    }

    public String getFacebookPageURL() {
        return this.facebookPageURL;
    }

    public String getFailedreason() {
        return this.failedreason;
    }

    public String getGatewayPageURL() {
        return this.gatewayPageURL;
    }

    public Gw getGw() {
        return this.gw;
    }

    public String getIsDirectPayEnable() {
        return this.isDirectPayEnable;
    }

    public String getLoginTransSession() {
        return this.loginTransSession;
    }

    public String getMoreInfoURL() {
        return this.moreInfoURL;
    }

    public Integer getNumberOfCardSaved() {
        return this.numberOfCardSaved;
    }

    public Integer getOfferStatus() {
        return this.offerStatus;
    }

    public String getPrimaryColor() {
        String string2 = this.primaryColor;
        if (string2 != null && string2.isEmpty()) {
            this.primaryColor = "00FF00";
        }
        return this.primaryColor;
    }

    public String getRedirectGatewayURL() {
        return this.redirectGatewayURL;
    }

    public String getSessionkey() {
        return this.sessionkey;
    }

    public String getStatus() {
        return this.status;
    }

    public String getStoreBanner() {
        return this.storeBanner;
    }

    public String getStoreLogo() {
        return this.storeLogo;
    }

    public String getStoreName() {
        return this.storeName;
    }

    public String getSubscriptionError() {
        return this.subscriptionError;
    }

    public String getSubscriptionId() {
        return this.subscriptionId;
    }

    public String getSubscriptionStatus() {
        return this.subscriptionStatus;
    }

    public String getSupportEmail() {
        return this.supportEmail;
    }

    public String getSupportPhone() {
        return this.supportPhone;
    }

    public String getTermsAndConditionURL() {
        return this.termsAndConditionURL;
    }

    public String getTimeoutinMin() {
        return this.timeoutinMin;
    }

    public String getTranId() {
        return this.tranId;
    }

    public void setActiveColor(String string2) {
        this.activeColor = string2;
    }

    public void setAmount(String string2) {
        this.amount = string2;
    }

    public void setCurrency(String string2) {
        this.currency = string2;
    }

    public void setCurrencyAmount(String string2) {
        this.currencyAmount = string2;
    }

    public void setCurrencyRate(String string2) {
        this.currencyRate = string2;
    }

    public void setCurrencyType(String string2) {
        this.currencyType = string2;
    }

    public void setCustMobile(String string2) {
        this.cust_mobile = string2;
    }

    public void setCustomerName(String string2) {
        this.CustomerName = string2;
    }

    public void setDefault_tab(String string2) {
        this.default_tab = string2;
    }

    public void setDesc(List<Desc> list) {
        this.desc = list;
    }

    public void setDesign(Design design) {
        this.design = design;
    }

    public void setDirectPaymentURL(String string2) {
        this.directPaymentURL = string2;
    }

    public void setEmiStatus(Integer n) {
        this.emiStatus = n;
    }

    public void setExistingMobile(Integer n) {
        this.existingMobile = n;
    }

    public void setFAQURL(String string2) {
        this.FAQURL = string2;
    }

    public void setFacebookPageURL(String string2) {
        this.facebookPageURL = string2;
    }

    public void setFailedreason(String string2) {
        this.failedreason = string2;
    }

    public void setGatewayPageURL(String string2) {
        this.gatewayPageURL = string2;
    }

    public void setGw(Gw gw) {
        this.gw = gw;
    }

    public void setIsDirectPayEnable(String string2) {
        this.isDirectPayEnable = string2;
    }

    public void setLoginTransSession(String string2) {
        this.loginTransSession = string2;
    }

    public void setMoreInfoURL(String string2) {
        this.moreInfoURL = string2;
    }

    public void setNumberOfCardSaved(Integer n) {
        this.numberOfCardSaved = n;
    }

    public void setOfferStatus(Integer n) {
        this.offerStatus = n;
    }

    public void setPrimaryColor(String string2) {
        this.primaryColor = string2;
    }

    public void setRedirectGatewayURL(String string2) {
        this.redirectGatewayURL = string2;
    }

    public void setSessionkey(String string2) {
        this.sessionkey = string2;
    }

    public void setStatus(String string2) {
        this.status = string2;
    }

    public void setStoreBanner(String string2) {
        this.storeBanner = string2;
    }

    public void setStoreLogo(String string2) {
        this.storeLogo = string2;
    }

    public void setStoreName(String string2) {
        this.storeName = string2;
    }

    public void setSubscriptionError(String string2) {
        this.subscriptionError = string2;
    }

    public void setSubscriptionId(String string2) {
        this.subscriptionId = string2;
    }

    public void setSubscriptionStatus(String string2) {
        this.subscriptionStatus = string2;
    }

    public void setSupportEmail(String string2) {
        this.supportEmail = string2;
    }

    public void setSupportPhone(String string2) {
        this.supportPhone = string2;
    }

    public void setTermsAndConditionURL(String string2) {
        this.termsAndConditionURL = string2;
    }

    public void setTimeoutinMin(String string2) {
        this.timeoutinMin = string2;
    }

    public void setTranId(String string2) {
        this.tranId = string2;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public String toJSON() {
        JSONObject jSONObject = new JSONObject();
        try {
            Gw gw;
            jSONObject.put("cust_mobile", (Object)this.getCustMobile());
            jSONObject.put("CustomerName", (Object)this.getCustomerName());
            jSONObject.put("sessionkey", (Object)this.getSessionkey());
            jSONObject.put("amount", (Object)this.getAmount());
            jSONObject.put("existingMobile", (Object)this.getExistingMobile());
            jSONObject.put("numberOfCardSaved", (Object)this.getNumberOfCardSaved());
            jSONObject.put("emi_status", (Object)this.getEmiStatus());
            jSONObject.put("offer_status", (Object)this.getOfferStatus());
            jSONObject.put("loginTransSession", (Object)this.getLoginTransSession());
            jSONObject.put("storeLogo", (Object)this.getStoreLogo());
            jSONObject.put("store_name", (Object)this.getStoreName());
            jSONObject.put("timeoutinMin", (Object)this.getTimeoutinMin());
            jSONObject.put("termsAndConditionURL", (Object)this.getTermsAndConditionURL());
            jSONObject.put("FAQURL", (Object)this.getFAQURL());
            jSONObject.put("moreInfoURL", (Object)this.getMoreInfoURL());
            jSONObject.put("facebookPageURL", (Object)this.getFacebookPageURL());
            jSONObject.put("currency_type", (Object)this.getCurrencyType());
            jSONObject.put("currency_amount", (Object)this.getCurrencyAmount());
            jSONObject.put("currency_rate", (Object)this.getCurrencyRate());
            jSONObject.put("supportEmail", (Object)this.getSupportEmail());
            jSONObject.put("supportPhone", (Object)this.getSupportPhone());
            jSONObject.put("activeColor", (Object)this.getActiveColor());
            jSONObject.put("primaryColor", (Object)this.getPrimaryColor());
            jSONObject.put("default_tab", (Object)this.getDefault_tab());
            Design design = this.getDesign();
            if (design != null) {
                JSONObject jSONObject2 = new JSONObject();
                jSONObject2.put("main_bk_img", (Object)design.getMainBkImg());
                jSONObject2.put("main_bk_color", (Object)design.getMainBkColor());
                jSONObject2.put("main_font_color", (Object)design.getMainFontColor());
                jSONObject2.put("title_bk_color", (Object)design.getTitleBkColor());
                jSONObject2.put("title_font_color", (Object)design.getTitleFontColor());
                jSONObject2.put("btn_yes_bk_color", (Object)design.getBtnYesBkColor());
                jSONObject2.put("btn_yes_font_color", (Object)design.getBtnYesFontColor());
                jSONObject2.put("btn_no_bk_color", (Object)design.getBtnNoBkColor());
                jSONObject2.put("btn_no_font_color", (Object)design.getBtnNoFontColor());
                jSONObject.put("design", (Object)jSONObject2);
            }
            if ((gw = this.getGw()) != null) {
                JSONObject jSONObject3 = new JSONObject();
                jSONObject3.put("visa", (Object)gw.getVisa());
                jSONObject3.put("master", (Object)gw.getMaster());
                jSONObject3.put("amex", (Object)gw.getAmex());
                jSONObject3.put("othercards", (Object)gw.getOthercards());
                jSONObject3.put("internetbanking", (Object)gw.getInternetbanking());
                jSONObject3.put("mobilebanking", (Object)gw.getMobilebanking());
                jSONObject.put("gw", (Object)jSONObject3);
            }
            JSONArray jSONArray = new JSONArray();
            List<Desc> list = this.getDesc();
            if (list != null) {
                for (Desc desc : list) {
                    JSONObject jSONObject4 = new JSONObject();
                    jSONObject4.put("name", (Object)desc.getName());
                    jSONObject4.put("type", (Object)desc.getType());
                    jSONObject4.put("logo", (Object)desc.getLogo());
                    jSONObject4.put("transAmt", (Object)desc.getTransAmt());
                    jSONObject4.put("payableAmt", (Object)desc.getPayableAmt());
                    jSONObject4.put("charge", (Object)desc.getCharge());
                    jSONObject4.put("rFlag", (Object)desc.getRFlag());
                    jSONObject4.put("redirectGatewayURL", (Object)desc.getRedirectGatewayURL());
                    jSONObject4.put("autoselect", (Object)desc.getAutoselect());
                    jSONArray.put((Object)jSONObject4);
                }
            }
            jSONObject.put("desc", (Object)jSONArray);
            return jSONObject.toString();
        }
        catch (JSONException jSONException) {
            jSONException.printStackTrace();
            return "";
        }
    }

    public class Desc {
        @Expose
        @SerializedName(value="autoselect")
        private String autoselect;
        @Expose
        @SerializedName(value="charge")
        private String charge;
        @Expose
        @SerializedName(value="gw")
        private String gw;
        @Expose
        @SerializedName(value="logo")
        private String logo;
        @Expose
        @SerializedName(value="name")
        private String name;
        @Expose
        @SerializedName(value="payableAmt")
        private String payableAmt;
        @Expose
        @SerializedName(value="r_flag")
        private String rFlag;
        @Expose
        @SerializedName(value="redirectGatewayURL")
        private String redirectGatewayURL;
        private boolean setStatus;
        @Expose
        @SerializedName(value="transAmt")
        private String transAmt;
        @Expose
        @SerializedName(value="type")
        private String type;

        public String getAutoselect() {
            return this.autoselect;
        }

        public String getCharge() {
            return this.charge;
        }

        public String getGw() {
            return this.gw;
        }

        public String getLogo() {
            return this.logo;
        }

        public String getName() {
            return this.name;
        }

        public String getPayableAmt() {
            return this.payableAmt;
        }

        public String getRFlag() {
            return this.rFlag;
        }

        public String getRedirectGatewayURL() {
            return this.redirectGatewayURL;
        }

        public String getTransAmt() {
            return this.transAmt;
        }

        public String getType() {
            return this.type;
        }

        public boolean isSetStatus() {
            return this.setStatus;
        }

        public void setAutoselect(String string2) {
            this.autoselect = string2;
        }

        public void setCharge(String string2) {
            this.charge = string2;
        }

        public void setGw(String string2) {
            this.gw = string2;
        }

        public void setLogo(String string2) {
            this.logo = string2;
        }

        public void setName(String string2) {
            this.name = string2;
        }

        public void setPayableAmt(String string2) {
            this.payableAmt = string2;
        }

        public void setRFlag(String string2) {
            this.rFlag = string2;
        }

        public void setRedirectGatewayURL(String string2) {
            this.redirectGatewayURL = string2;
        }

        public void setSetStatus(boolean bl) {
            this.setStatus = bl;
        }

        public void setTransAmt(String string2) {
            this.transAmt = string2;
        }

        public void setType(String string2) {
            this.type = string2;
        }

        public String toJSON() {
            JSONObject jSONObject = new JSONObject();
            try {
                jSONObject.put("name", (Object)this.getName());
                jSONObject.put("type", (Object)this.getType());
                jSONObject.put("logo", (Object)this.getLogo());
                jSONObject.put("rFlag", (Object)this.getRFlag());
                String string2 = jSONObject.toString();
                return string2;
            }
            catch (JSONException jSONException) {
                jSONException.printStackTrace();
                return "";
            }
        }
    }

    public class Design {
        @Expose
        @SerializedName(value="btn_no_bk_color")
        private String btnNoBkColor;
        @Expose
        @SerializedName(value="btn_no_font_color")
        private String btnNoFontColor;
        @Expose
        @SerializedName(value="btn_yes_bk_color")
        private String btnYesBkColor;
        @Expose
        @SerializedName(value="btn_yes_font_color")
        private String btnYesFontColor;
        @Expose
        @SerializedName(value="main_bk_color")
        private String mainBkColor;
        @Expose
        @SerializedName(value="main_bk_img")
        private String mainBkImg;
        @Expose
        @SerializedName(value="main_font_color")
        private String mainFontColor;
        @Expose
        @SerializedName(value="title_bk_color")
        private String titleBkColor;
        @Expose
        @SerializedName(value="title_font_color")
        private String titleFontColor;

        public String getBtnNoBkColor() {
            return this.btnNoBkColor;
        }

        public String getBtnNoFontColor() {
            return this.btnNoFontColor;
        }

        public String getBtnYesBkColor() {
            return this.btnYesBkColor;
        }

        public String getBtnYesFontColor() {
            return this.btnYesFontColor;
        }

        public String getMainBkColor() {
            return this.mainBkColor;
        }

        public String getMainBkImg() {
            return this.mainBkImg;
        }

        public String getMainFontColor() {
            return this.mainFontColor;
        }

        public String getTitleBkColor() {
            return this.titleBkColor;
        }

        public String getTitleFontColor() {
            return this.titleFontColor;
        }

        public void setBtnNoBkColor(String string2) {
            this.btnNoBkColor = string2;
        }

        public void setBtnNoFontColor(String string2) {
            this.btnNoFontColor = string2;
        }

        public void setBtnYesBkColor(String string2) {
            this.btnYesBkColor = string2;
        }

        public void setBtnYesFontColor(String string2) {
            this.btnYesFontColor = string2;
        }

        public void setMainBkColor(String string2) {
            this.mainBkColor = string2;
        }

        public void setMainBkImg(String string2) {
            this.mainBkImg = string2;
        }

        public void setMainFontColor(String string2) {
            this.mainFontColor = string2;
        }

        public void setTitleBkColor(String string2) {
            this.titleBkColor = string2;
        }

        public void setTitleFontColor(String string2) {
            this.titleFontColor = string2;
        }
    }

    public class Gw {
        @Expose
        @SerializedName(value="amex")
        private String amex;
        @Expose
        @SerializedName(value="internetbanking")
        private String internetbanking;
        @Expose
        @SerializedName(value="master")
        private String master;
        @Expose
        @SerializedName(value="mobilebanking")
        private String mobilebanking;
        @Expose
        @SerializedName(value="othercards")
        private String othercards;
        @Expose
        @SerializedName(value="visa")
        private String visa;

        public String getAmex() {
            return this.amex;
        }

        public String getInternetbanking() {
            return this.internetbanking;
        }

        public String getMaster() {
            return this.master;
        }

        public String getMobilebanking() {
            return this.mobilebanking;
        }

        public String getOthercards() {
            return this.othercards;
        }

        public String getVisa() {
            return this.visa;
        }

        public void setAmex(String string2) {
            this.amex = string2;
        }

        public void setInternetbanking(String string2) {
            this.internetbanking = string2;
        }

        public void setMaster(String string2) {
            this.master = string2;
        }

        public void setMobilebanking(String string2) {
            this.mobilebanking = string2;
        }

        public void setOthercards(String string2) {
            this.othercards = string2;
        }

        public void setVisa(String string2) {
            this.visa = string2;
        }
    }

}

