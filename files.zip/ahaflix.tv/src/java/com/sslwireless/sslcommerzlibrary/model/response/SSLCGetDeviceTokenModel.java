/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.gson.annotations.Expose
 *  com.google.gson.annotations.SerializedName
 *  java.lang.Object
 *  java.lang.String
 */
package com.sslwireless.sslcommerzlibrary.model.response;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class SSLCGetDeviceTokenModel {
    @Expose
    @SerializedName(value="data")
    private Data data;
    @Expose
    @SerializedName(value="message")
    private String message;
    @Expose
    @SerializedName(value="status")
    private String status;

    public Data getData() {
        return this.data;
    }

    public String getMessage() {
        return this.message;
    }

    public String getStatus() {
        return this.status;
    }

    public void setData(Data data) {
        this.data = data;
    }

    public void setMessage(String string2) {
        this.message = string2;
    }

    public void setStatus(String string2) {
        this.status = string2;
    }

    public class Data {
        @Expose
        @SerializedName(value="enc_key")
        private String encKey;
        @Expose
        @SerializedName(value="reg_id")
        private String regId;

        public String getEncKey() {
            return this.encKey;
        }

        public String getRegId() {
            return this.regId;
        }

        public void setEncKey(String string2) {
            this.encKey = string2;
        }

        public void setRegId(String string2) {
            this.regId = string2;
        }
    }

}

