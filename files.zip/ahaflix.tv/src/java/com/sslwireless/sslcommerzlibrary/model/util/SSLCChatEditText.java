/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.util.AttributeSet
 *  android.view.KeyEvent
 *  androidx.appcompat.widget.AppCompatEditText
 *  com.sslwireless.sslcommerzlibrary.model.util.SSLCChatEditText$KeyImeChange
 */
package com.sslwireless.sslcommerzlibrary.model.util;

import android.content.Context;
import android.util.AttributeSet;
import android.view.KeyEvent;
import androidx.appcompat.widget.AppCompatEditText;
import com.sslwireless.sslcommerzlibrary.model.util.SSLCChatEditText;

public class SSLCChatEditText
extends AppCompatEditText {
    private KeyImeChange keyImeChangeListener;

    public SSLCChatEditText(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public boolean onKeyPreIme(int n, KeyEvent keyEvent) {
        KeyImeChange keyImeChange = this.keyImeChangeListener;
        if (keyImeChange != null) {
            keyImeChange.onKeyIme(n, keyEvent);
        }
        return false;
    }

    public void setKeyImeChangeListener(KeyImeChange keyImeChange) {
        this.keyImeChangeListener = keyImeChange;
    }
}

