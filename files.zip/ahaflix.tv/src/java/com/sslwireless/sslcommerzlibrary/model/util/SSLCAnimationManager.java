/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.animation.Animator
 *  android.animation.Animator$AnimatorListener
 *  android.animation.ValueAnimator
 *  android.animation.ValueAnimator$AnimatorUpdateListener
 *  android.view.View
 *  android.view.View$MeasureSpec
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  java.lang.Integer
 *  java.lang.Object
 */
package com.sslwireless.sslcommerzlibrary.model.util;

import android.animation.Animator;
import android.animation.ValueAnimator;
import android.view.View;
import android.view.ViewGroup;

public class SSLCAnimationManager {
    public static SSLCAnimationManager instance = new SSLCAnimationManager();

    private SSLCAnimationManager() {
    }

    public static SSLCAnimationManager getInstance() {
        SSLCAnimationManager sSLCAnimationManager = instance;
        if (sSLCAnimationManager == null) {
            sSLCAnimationManager = new SSLCAnimationManager();
        }
        return sSLCAnimationManager;
    }

    public void collapse(final View view) {
        ValueAnimator valueAnimator = this.slideAnimator(view.getHeight(), 0, view);
        valueAnimator.addListener(new Animator.AnimatorListener(){

            public void onAnimationCancel(Animator animator2) {
            }

            public void onAnimationEnd(Animator animator2) {
                view.setVisibility(8);
            }

            public void onAnimationRepeat(Animator animator2) {
            }

            public void onAnimationStart(Animator animator2) {
            }
        });
        valueAnimator.start();
    }

    public void expand(View view) {
        view.setVisibility(0);
        view.measure(View.MeasureSpec.makeMeasureSpec((int)0, (int)0), View.MeasureSpec.makeMeasureSpec((int)0, (int)0));
        this.slideAnimator(0, view.getMeasuredHeight(), view).start();
    }

    public ValueAnimator slideAnimator(int n, int n2, final View view) {
        ValueAnimator valueAnimator = ValueAnimator.ofInt((int[])new int[]{n, n2});
        valueAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener(){

            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                int n = (Integer)valueAnimator.getAnimatedValue();
                ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
                layoutParams.height = n;
                view.setLayoutParams(layoutParams);
            }
        });
        return valueAnimator;
    }

}

