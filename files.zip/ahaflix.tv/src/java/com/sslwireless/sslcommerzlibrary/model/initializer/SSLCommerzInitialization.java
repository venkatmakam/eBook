/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.Serializable
 *  java.lang.Object
 *  java.lang.String
 */
package com.sslwireless.sslcommerzlibrary.model.initializer;

import java.io.Serializable;

public class SSLCommerzInitialization
implements Serializable {
    private String allowed_bin = "";
    private String cancel_url = "";
    private String currency = "";
    private String fail_url = "";
    private String ipn_url = "";
    private String multi_card_name = "";
    private String product_category = "";
    private String sdkType = "";
    private String store_id = "";
    private String store_passwd = "";
    private String success_url = "";
    private double total_amount;
    private String tran_id = "";

    public SSLCommerzInitialization(String string2, String string3, double d, String string4, String string5, String string6, String string7) {
        this.store_id = string2;
        this.store_passwd = string3;
        this.total_amount = d;
        this.currency = string4;
        this.tran_id = string5;
        this.product_category = string6;
        this.sdkType = string7;
    }

    public SSLCommerzInitialization addIpnUrl(String string2) {
        this.ipn_url = string2;
        return this;
    }

    public SSLCommerzInitialization addMultiCardName(String string2) {
        this.multi_card_name = string2;
        return this;
    }

    public SSLCommerzInitialization addSAllowedBin(String string2) {
        this.allowed_bin = string2;
        return this;
    }

    public String getAllowed_bin() {
        return this.allowed_bin;
    }

    public String getCancel_url() {
        return this.cancel_url;
    }

    public String getCurrency() {
        return this.currency;
    }

    public String getFail_url() {
        return this.fail_url;
    }

    public String getIpn_url() {
        return this.ipn_url;
    }

    public String getMulti_card_name() {
        return this.multi_card_name;
    }

    public String getProduct_category() {
        return this.product_category;
    }

    public String getSdkType() {
        return this.sdkType;
    }

    public String getStore_id() {
        return this.store_id;
    }

    public String getStore_passwd() {
        return this.store_passwd;
    }

    public String getSuccess_url() {
        return this.success_url;
    }

    public double getTotal_amount() {
        return this.total_amount;
    }

    public String getTran_id() {
        return this.tran_id;
    }

    public void setAllowed_bin(String string2) {
        this.allowed_bin = string2;
    }

    public void setCancel_url(String string2) {
        this.cancel_url = string2;
    }

    public void setCurrency(String string2) {
        this.currency = string2;
    }

    public void setFail_url(String string2) {
        this.fail_url = string2;
    }

    public void setIpn_url(String string2) {
        this.ipn_url = string2;
    }

    public void setMulti_card_name(String string2) {
        this.multi_card_name = string2;
    }

    public void setProduct_category(String string2) {
        this.product_category = string2;
    }

    public void setSdkType(String string2) {
        this.sdkType = string2;
    }

    public void setStore_id(String string2) {
        this.store_id = string2;
    }

    public void setStore_passwd(String string2) {
        this.store_passwd = string2;
    }

    public void setSuccess_url(String string2) {
        this.success_url = string2;
    }

    public void setTotal_amount(double d) {
        this.total_amount = d;
    }

    public void setTran_id(String string2) {
        this.tran_id = string2;
    }
}

