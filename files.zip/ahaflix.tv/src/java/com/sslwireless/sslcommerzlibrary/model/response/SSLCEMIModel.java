/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.gson.annotations.Expose
 *  java.io.Serializable
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 */
package com.sslwireless.sslcommerzlibrary.model.response;

import com.google.gson.annotations.Expose;
import java.io.Serializable;
import java.util.List;

public class SSLCEMIModel
implements Serializable {
    @Expose
    private Data data;
    @Expose
    private String message;
    @Expose
    private String status;

    public Data getData() {
        return this.data;
    }

    public String getMessage() {
        return this.message;
    }

    public String getStatus() {
        return this.status;
    }

    public void setData(Data data) {
        this.data = data;
    }

    public void setMessage(String string2) {
        this.message = string2;
    }

    public void setStatus(String string2) {
        this.status = string2;
    }

    public class Data {
        @Expose
        private String actionStatus;
        @Expose
        private Data data;
        @Expose
        private List<Emi> emi;
        @Expose
        private String msgToDisplay;
        @Expose
        private String status;
        @Expose
        private String systemMesg;

        public String getActionStatus() {
            return this.actionStatus;
        }

        public Data getData() {
            return this.data;
        }

        public List<Emi> getEmi() {
            return this.emi;
        }

        public String getMsgToDisplay() {
            return this.msgToDisplay;
        }

        public String getStatus() {
            return this.status;
        }

        public String getSystemMesg() {
            return this.systemMesg;
        }

        public void setActionStatus(String string2) {
            this.actionStatus = string2;
        }

        public void setData(Data data) {
            this.data = data;
        }

        public void setEmi(List<Emi> list) {
            this.emi = list;
        }

        public void setMsgToDisplay(String string2) {
            this.msgToDisplay = string2;
        }

        public void setStatus(String string2) {
            this.status = string2;
        }

        public void setSystemMesg(String string2) {
            this.systemMesg = string2;
        }
    }

    public class Emi {
        @Expose
        private String bankLogo;
        @Expose
        private String bankName;
        @Expose
        private List<String> binList;
        @Expose
        private String emiBankID;
        @Expose
        private List<EmiBankTenureDesc> emiBankTenureDesc;
        @Expose
        private List<EmiBankTenureList> emiBankTenureList;
        @Expose
        private String redirectGWPath;

        public String getBankLogo() {
            return this.bankLogo;
        }

        public String getBankName() {
            return this.bankName;
        }

        public List<String> getBinList() {
            return this.binList;
        }

        public String getEmiBankID() {
            return this.emiBankID;
        }

        public List<EmiBankTenureDesc> getEmiBankTenureDesc() {
            return this.emiBankTenureDesc;
        }

        public List<EmiBankTenureList> getEmiBankTenureList() {
            return this.emiBankTenureList;
        }

        public String getRedirectGWPath() {
            return this.redirectGWPath;
        }

        public void setBankLogo(String string2) {
            this.bankLogo = string2;
        }

        public void setBankName(String string2) {
            this.bankName = string2;
        }

        public void setBinList(List<String> list) {
            this.binList = list;
        }

        public void setEmiBankID(String string2) {
            this.emiBankID = string2;
        }

        public void setEmiBankTenureDesc(List<EmiBankTenureDesc> list) {
            this.emiBankTenureDesc = list;
        }

        public void setEmiBankTenureList(List<EmiBankTenureList> list) {
            this.emiBankTenureList = list;
        }

        public void setRedirectGWPath(String string2) {
            this.redirectGWPath = string2;
        }
    }

    public class EmiBankTenureDesc {
        @Expose
        private String desc;
        @Expose
        private Long tenure;

        public String getDesc() {
            return this.desc;
        }

        public Long getTenure() {
            return this.tenure;
        }

        public void setDesc(String string2) {
            this.desc = string2;
        }

        public void setTenure(Long l) {
            this.tenure = l;
        }
    }

    public class EmiBankTenureList {
        @Expose
        private Long tenure;

        public Long getTenure() {
            return this.tenure;
        }

        public void setTenure(Long l) {
            this.tenure = l;
        }
    }

}

