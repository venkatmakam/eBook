/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.gson.annotations.Expose
 *  com.google.gson.annotations.SerializedName
 *  java.lang.Object
 *  java.lang.String
 */
package com.sslwireless.sslcommerzlibrary.model.response;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class SSLCTransactionInfoModel {
    @Expose
    @SerializedName(value="APIConnect")
    private String aPIConnect;
    @Expose
    @SerializedName(value="amount")
    private String amount;
    @Expose
    @SerializedName(value="bank_tran_id")
    private String bankTranId;
    @Expose
    @SerializedName(value="base_fair")
    private String baseFair;
    @Expose
    @SerializedName(value="card_brand")
    private String cardBrand;
    @Expose
    @SerializedName(value="card_issuer")
    private String cardIssuer;
    @Expose
    @SerializedName(value="card_issuer_country")
    private String cardIssuerCountry;
    @Expose
    @SerializedName(value="card_issuer_country_code")
    private String cardIssuerCountryCode;
    @Expose
    @SerializedName(value="card_no")
    private String cardNo;
    @Expose
    @SerializedName(value="card_type")
    private String cardType;
    @Expose
    @SerializedName(value="currency_amount")
    private String currencyAmount;
    @Expose
    @SerializedName(value="currency_rate")
    private String currencyRate;
    @Expose
    @SerializedName(value="currency_type")
    private String currencyType;
    @Expose
    @SerializedName(value="gw_version")
    private String gwVersion;
    @Expose
    @SerializedName(value="risk_level")
    private String riskLevel;
    @Expose
    @SerializedName(value="risk_title")
    private String riskTitle;
    @Expose
    @SerializedName(value="sessionkey")
    private String sessionkey;
    @Expose
    @SerializedName(value="status")
    private String status;
    @Expose
    @SerializedName(value="store_amount")
    private String storeAmount;
    @Expose
    @SerializedName(value="tran_date")
    private String tranDate;
    @Expose
    @SerializedName(value="tran_id")
    private String tranId;
    @Expose
    @SerializedName(value="val_id")
    private String valId;
    @Expose
    @SerializedName(value="validated_on")
    private String validatedOn;
    @Expose
    @SerializedName(value="value_a")
    private String valueA;
    @Expose
    @SerializedName(value="value_b")
    private String valueB;
    @Expose
    @SerializedName(value="value_c")
    private String valueC;
    @Expose
    @SerializedName(value="value_d")
    private String valueD;

    public String getAPIConnect() {
        return this.aPIConnect;
    }

    public String getAmount() {
        return this.amount;
    }

    public String getBankTranId() {
        return this.bankTranId;
    }

    public String getBaseFair() {
        return this.baseFair;
    }

    public String getCardBrand() {
        return this.cardBrand;
    }

    public String getCardIssuer() {
        return this.cardIssuer;
    }

    public String getCardIssuerCountry() {
        return this.cardIssuerCountry;
    }

    public String getCardIssuerCountryCode() {
        return this.cardIssuerCountryCode;
    }

    public String getCardNo() {
        return this.cardNo;
    }

    public String getCardType() {
        return this.cardType;
    }

    public String getCurrencyAmount() {
        return this.currencyAmount;
    }

    public String getCurrencyRate() {
        return this.currencyRate;
    }

    public String getCurrencyType() {
        return this.currencyType;
    }

    public String getGwVersion() {
        return this.gwVersion;
    }

    public String getRiskLevel() {
        return this.riskLevel;
    }

    public String getRiskTitle() {
        return this.riskTitle;
    }

    public String getSessionkey() {
        return this.sessionkey;
    }

    public String getStatus() {
        return this.status;
    }

    public String getStoreAmount() {
        return this.storeAmount;
    }

    public String getTranDate() {
        return this.tranDate;
    }

    public String getTranId() {
        return this.tranId;
    }

    public String getValId() {
        return this.valId;
    }

    public String getValidatedOn() {
        return this.validatedOn;
    }

    public String getValueA() {
        return this.valueA;
    }

    public String getValueB() {
        return this.valueB;
    }

    public String getValueC() {
        return this.valueC;
    }

    public String getValueD() {
        return this.valueD;
    }

    public void setAPIConnect(String string2) {
        this.aPIConnect = string2;
    }

    public void setAmount(String string2) {
        this.amount = string2;
    }

    public void setBankTranId(String string2) {
        this.bankTranId = string2;
    }

    public void setBaseFair(String string2) {
        this.baseFair = string2;
    }

    public void setCardBrand(String string2) {
        this.cardBrand = string2;
    }

    public void setCardIssuer(String string2) {
        this.cardIssuer = string2;
    }

    public void setCardIssuerCountry(String string2) {
        this.cardIssuerCountry = string2;
    }

    public void setCardIssuerCountryCode(String string2) {
        this.cardIssuerCountryCode = string2;
    }

    public void setCardNo(String string2) {
        this.cardNo = string2;
    }

    public void setCardType(String string2) {
        this.cardType = string2;
    }

    public void setCurrencyAmount(String string2) {
        this.currencyAmount = string2;
    }

    public void setCurrencyRate(String string2) {
        this.currencyRate = string2;
    }

    public void setCurrencyType(String string2) {
        this.currencyType = string2;
    }

    public void setGwVersion(String string2) {
        this.gwVersion = string2;
    }

    public void setRiskLevel(String string2) {
        this.riskLevel = string2;
    }

    public void setRiskTitle(String string2) {
        this.riskTitle = string2;
    }

    public void setSessionkey(String string2) {
        this.sessionkey = string2;
    }

    public void setStatus(String string2) {
        this.status = string2;
    }

    public void setStoreAmount(String string2) {
        this.storeAmount = string2;
    }

    public void setTranDate(String string2) {
        this.tranDate = string2;
    }

    public void setTranId(String string2) {
        this.tranId = string2;
    }

    public void setValId(String string2) {
        this.valId = string2;
    }

    public void setValidatedOn(String string2) {
        this.validatedOn = string2;
    }

    public void setValueA(String string2) {
        this.valueA = string2;
    }

    public void setValueB(String string2) {
        this.valueB = string2;
    }

    public void setValueC(String string2) {
        this.valueC = string2;
    }

    public void setValueD(String string2) {
        this.valueD = string2;
    }
}

