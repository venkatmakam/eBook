/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.gson.annotations.Expose
 *  com.google.gson.annotations.SerializedName
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 */
package com.sslwireless.sslcommerzlibrary.model.response;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import java.util.List;

public class SSLCVerifyLoginSessionModel {
    @Expose
    @SerializedName(value="data")
    private Data data;
    @Expose
    @SerializedName(value="message")
    private String message;
    @Expose
    @SerializedName(value="status")
    private String status;

    public Data getData() {
        return this.data;
    }

    public String getMessage() {
        return this.message;
    }

    public String getStatus() {
        return this.status;
    }

    public void setData(Data data) {
        this.data = data;
    }

    public void setMessage(String string2) {
        this.message = string2;
    }

    public void setStatus(String string2) {
        this.status = string2;
    }

    public class CardNo {
        @Expose
        @SerializedName(value="MOTOEnable")
        private String MOTOEnable;
        @Expose
        @SerializedName(value="bankName")
        private String bankName;
        @Expose
        @SerializedName(value="cardNo")
        private String cardNo;
        @Expose
        @SerializedName(value="cardindex")
        private String cardindex;
        @Expose
        @SerializedName(value="friendlyName")
        private String friendlyName;
        @Expose
        @SerializedName(value="type")
        private String type;
        @Expose
        @SerializedName(value="withoutOTP")
        private String withoutOTP;

        public String getBankName() {
            return this.bankName;
        }

        public String getCardNo() {
            return this.cardNo;
        }

        public String getCardindex() {
            return this.cardindex;
        }

        public String getFriendlyName() {
            return this.friendlyName;
        }

        public String getMOTOEnable() {
            return this.MOTOEnable;
        }

        public String getType() {
            return this.type;
        }

        public String getWithoutOTP() {
            return this.withoutOTP;
        }

        public void setBankName(String string2) {
            this.bankName = string2;
        }

        public void setCardNo(String string2) {
            this.cardNo = string2;
        }

        public void setCardindex(String string2) {
            this.cardindex = string2;
        }

        public void setFriendlyName(String string2) {
            this.friendlyName = string2;
        }

        public void setMOTOEnable(String string2) {
            this.MOTOEnable = string2;
        }

        public void setType(String string2) {
            this.type = string2;
        }

        public void setWithoutOTP(String string2) {
            this.withoutOTP = string2;
        }
    }

    public class Data {
        @Expose
        @SerializedName(value="data")
        private Data_ data;
        @Expose
        @SerializedName(value="status")
        private String status;

        public Data_ getData() {
            return this.data;
        }

        public String getStatus() {
            return this.status;
        }

        public void setData(Data_ data_) {
            this.data = data_;
        }

        public void setStatus(String string2) {
            this.status = string2;
        }
    }

    public class Data_ {
        @Expose
        @SerializedName(value="actionStatus")
        private String actionStatus;
        @Expose
        @SerializedName(value="cardNos")
        private List<CardNo> cardNos = null;
        @Expose
        @SerializedName(value="custFName")
        private String custFName;
        @Expose
        @SerializedName(value="custLName")
        private String custLName;
        @Expose
        @SerializedName(value="custSession")
        private String custSession;
        @Expose
        @SerializedName(value="isMobileNoVerified")
        private String isMobileNoVerified;
        @Expose
        @SerializedName(value="mobileNo")
        private String mobileNo;
        @Expose
        @SerializedName(value="msgToDisplay")
        private String msgToDisplay;
        @Expose
        @SerializedName(value="systemMesg")
        private String systemMesg;

        public String getActionStatus() {
            return this.actionStatus;
        }

        public List<CardNo> getCardNos() {
            return this.cardNos;
        }

        public String getCustFName() {
            return this.custFName;
        }

        public String getCustLName() {
            return this.custLName;
        }

        public String getCustSession() {
            return this.custSession;
        }

        public String getIsMobileNoVerified() {
            return this.isMobileNoVerified;
        }

        public String getMobileNo() {
            return this.mobileNo;
        }

        public String getMsgToDisplay() {
            return this.msgToDisplay;
        }

        public String getSystemMesg() {
            return this.systemMesg;
        }

        public void setActionStatus(String string2) {
            this.actionStatus = string2;
        }

        public void setCardNos(List<CardNo> list) {
            this.cardNos = list;
        }

        public void setCustFName(String string2) {
            this.custFName = string2;
        }

        public void setCustLName(String string2) {
            this.custLName = string2;
        }

        public void setCustSession(String string2) {
            this.custSession = string2;
        }

        public void setIsMobileNoVerified(String string2) {
            this.isMobileNoVerified = string2;
        }

        public void setMobileNo(String string2) {
            this.mobileNo = string2;
        }

        public void setMsgToDisplay(String string2) {
            this.msgToDisplay = string2;
        }

        public void setSystemMesg(String string2) {
            this.systemMesg = string2;
        }
    }

}

