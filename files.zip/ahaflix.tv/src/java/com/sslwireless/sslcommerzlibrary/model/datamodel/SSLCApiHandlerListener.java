/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  org.json.JSONObject
 */
package com.sslwireless.sslcommerzlibrary.model.datamodel;

import org.json.JSONObject;

public interface SSLCApiHandlerListener {
    public void fail(String var1);

    public void success(JSONObject var1);
}

