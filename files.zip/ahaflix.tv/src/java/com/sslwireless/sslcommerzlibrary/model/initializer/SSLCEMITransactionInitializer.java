/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.sslwireless.sslcommerzlibrary.model.initializer;

public class SSLCEMITransactionInitializer {
    public int emi_max_list_options;
    public int emi_options;
    public int emi_selected_inst;

    public SSLCEMITransactionInitializer(int n) {
        this.emi_options = n;
    }

    public SSLCEMITransactionInitializer addEmiMaxListOptions(int n) {
        this.emi_max_list_options = n;
        return this;
    }

    public SSLCEMITransactionInitializer addEmiSelectedInst(int n) {
        this.emi_selected_inst = n;
        return this;
    }

    public int getEmi_max_list_options() {
        return this.emi_max_list_options;
    }

    public int getEmi_options() {
        return this.emi_options;
    }

    public int getEmi_selected_inst() {
        return this.emi_selected_inst;
    }

    public void setEmi_max_list_options(int n) {
        this.emi_max_list_options = n;
    }

    public void setEmi_options(int n) {
        this.emi_options = n;
    }

    public void setEmi_selected_inst(int n) {
        this.emi_selected_inst = n;
    }
}

