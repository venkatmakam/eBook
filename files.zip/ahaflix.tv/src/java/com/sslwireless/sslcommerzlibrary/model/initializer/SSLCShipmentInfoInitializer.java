/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.sslwireless.sslcommerzlibrary.model.initializer;

public class SSLCShipmentInfoInitializer {
    private int numOfItems;
    private String shipAddress2;
    private String shipState;
    private ShipmentDetails shipmentDetails;
    private String shipmentMethod;

    public SSLCShipmentInfoInitializer(String string2, int n, ShipmentDetails shipmentDetails) {
        this.shipmentMethod = string2;
        this.numOfItems = n;
        if (string2.equalsIgnoreCase("yes")) {
            this.shipmentDetails = shipmentDetails;
            return;
        }
        this.shipmentDetails = null;
    }

    public SSLCShipmentInfoInitializer addShipAddress2(String string2) {
        this.shipAddress2 = string2;
        return this;
    }

    public SSLCShipmentInfoInitializer addShipState(String string2) {
        this.shipState = string2;
        return this;
    }

    public int getNumOfItems() {
        return this.numOfItems;
    }

    public String getShipAddress2() {
        return this.shipAddress2;
    }

    public String getShipState() {
        return this.shipState;
    }

    public ShipmentDetails getShipmentDetails() {
        return this.shipmentDetails;
    }

    public String getShipmentMethod() {
        return this.shipmentMethod;
    }

    public void setNumOfItems(int n) {
        this.numOfItems = n;
    }

    public void setShipAddress2(String string2) {
        this.shipAddress2 = string2;
    }

    public void setShipState(String string2) {
        this.shipState = string2;
    }

    public void setShipmentDetails(ShipmentDetails shipmentDetails) {
        this.shipmentDetails = shipmentDetails;
    }

    public void setShipmentMethod(String string2) {
        this.shipmentMethod = string2;
    }

    public static class ShipmentDetails {
        private String shipAddress1;
        private String shipCity;
        private String shipCountry;
        private String shipName;
        private String shipPostCode;

        public ShipmentDetails(String string2, String string3, String string4, String string5, String string6) {
            this.shipName = string2;
            this.shipAddress1 = string3;
            this.shipCity = string4;
            this.shipPostCode = string5;
            this.shipCountry = string6;
        }

        public String getShipAddress1() {
            return this.shipAddress1;
        }

        public String getShipCity() {
            return this.shipCity;
        }

        public String getShipCountry() {
            return this.shipCountry;
        }

        public String getShipName() {
            return this.shipName;
        }

        public String getShipPostCode() {
            return this.shipPostCode;
        }

        public void setShipAddress1(String string2) {
            this.shipAddress1 = string2;
        }

        public void setShipCity(String string2) {
            this.shipCity = string2;
        }

        public void setShipCountry(String string2) {
            this.shipCountry = string2;
        }

        public void setShipName(String string2) {
            this.shipName = string2;
        }

        public void setShipPostCode(String string2) {
            this.shipPostCode = string2;
        }
    }

}

