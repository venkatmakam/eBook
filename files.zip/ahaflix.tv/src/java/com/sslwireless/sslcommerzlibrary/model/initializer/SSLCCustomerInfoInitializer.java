/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.sslwireless.sslcommerzlibrary.model.initializer;

public class SSLCCustomerInfoInitializer {
    private String customerAddress1;
    private String customerAddress2;
    private String customerCity;
    private String customerCountry;
    private String customerEmail;
    private String customerFax;
    private String customerName;
    private String customerPhone;
    private String customerPostCode;
    private String customerState;

    public SSLCCustomerInfoInitializer(String string2, String string3, String string4, String string5, String string6, String string7, String string8) {
        this.customerName = string2;
        this.customerEmail = string3;
        this.customerAddress1 = string4;
        this.customerCity = string5;
        this.customerPostCode = string6;
        this.customerCountry = string7;
        this.customerPhone = string8;
    }

    public SSLCCustomerInfoInitializer addAddress2(String string2) {
        this.customerAddress2 = string2;
        return this;
    }

    public SSLCCustomerInfoInitializer addFax(String string2) {
        this.customerFax = string2;
        return this;
    }

    public SSLCCustomerInfoInitializer addState(String string2) {
        this.customerState = string2;
        return this;
    }

    public String getCustomerAddress1() {
        return this.customerAddress1;
    }

    public String getCustomerAddress2() {
        return this.customerAddress2;
    }

    public String getCustomerCity() {
        return this.customerCity;
    }

    public String getCustomerCountry() {
        return this.customerCountry;
    }

    public String getCustomerEmail() {
        return this.customerEmail;
    }

    public String getCustomerFax() {
        return this.customerFax;
    }

    public String getCustomerName() {
        return this.customerName;
    }

    public String getCustomerPhone() {
        return this.customerPhone;
    }

    public String getCustomerPostCode() {
        return this.customerPostCode;
    }

    public String getCustomerState() {
        return this.customerState;
    }

    public void setCustomerAddress1(String string2) {
        this.customerAddress1 = string2;
    }

    public void setCustomerAddress2(String string2) {
        this.customerAddress2 = string2;
    }

    public void setCustomerCity(String string2) {
        this.customerCity = string2;
    }

    public void setCustomerCountry(String string2) {
        this.customerCountry = string2;
    }

    public void setCustomerEmail(String string2) {
        this.customerEmail = string2;
    }

    public void setCustomerFax(String string2) {
        this.customerFax = string2;
    }

    public void setCustomerName(String string2) {
        this.customerName = string2;
    }

    public void setCustomerPhone(String string2) {
        this.customerPhone = string2;
    }

    public void setCustomerPostCode(String string2) {
        this.customerPostCode = string2;
    }

    public void setCustomerState(String string2) {
        this.customerState = string2;
    }
}

