/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.sslwireless.sslcommerzlibrary.model.initializer;

public class SSLCProductInitializer {
    private ProductProfile.AirlinesTicket airlinesTicket;
    private String cart;
    private double convenienceFee;
    private double discountAmount;
    private ProductProfile.General general;
    private ProductProfile.NonPhysicalGoods nonPhysicalGoods;
    private ProductProfile.PhysicalGoods physicalGoods;
    private double productAmount;
    private String productCategory;
    private String productName;
    private ProductProfile productProfile;
    private ProductProfile.TelecomVertical telecomVertical;
    private ProductProfile.TravelVertical travelVertical;
    private double vat;

    public SSLCProductInitializer(String string2, String string3, ProductProfile.AirlinesTicket airlinesTicket) {
        this.productName = string2;
        this.productCategory = string3;
        this.airlinesTicket = airlinesTicket;
    }

    public SSLCProductInitializer(String string2, String string3, ProductProfile.General general) {
        this.productName = string2;
        this.productCategory = string3;
        this.general = general;
    }

    public SSLCProductInitializer(String string2, String string3, ProductProfile.NonPhysicalGoods nonPhysicalGoods) {
        this.productName = string2;
        this.productCategory = string3;
        this.nonPhysicalGoods = nonPhysicalGoods;
    }

    public SSLCProductInitializer(String string2, String string3, ProductProfile.PhysicalGoods physicalGoods) {
        this.productName = string2;
        this.productCategory = string3;
        this.physicalGoods = physicalGoods;
    }

    public SSLCProductInitializer(String string2, String string3, ProductProfile.TelecomVertical telecomVertical) {
        this.productName = string2;
        this.productCategory = string3;
        this.telecomVertical = telecomVertical;
    }

    public SSLCProductInitializer(String string2, String string3, ProductProfile.TravelVertical travelVertical) {
        this.productName = string2;
        this.productCategory = string3;
        this.travelVertical = travelVertical;
    }

    public SSLCProductInitializer addCart(String string2) {
        this.cart = string2;
        return this;
    }

    public SSLCProductInitializer addConvenienceFee(double d) {
        this.convenienceFee = d;
        return this;
    }

    public SSLCProductInitializer addDiscountAmount(double d) {
        this.discountAmount = d;
        return this;
    }

    public SSLCProductInitializer addProductAmount(double d) {
        this.productAmount = d;
        return this;
    }

    public SSLCProductInitializer addVat(double d) {
        this.vat = d;
        return this;
    }

    public ProductProfile.AirlinesTicket getAirlinesTicket() {
        return this.airlinesTicket;
    }

    public String getCart() {
        return this.cart;
    }

    public double getConvenienceFee() {
        return this.convenienceFee;
    }

    public double getDiscountAmount() {
        return this.discountAmount;
    }

    public ProductProfile.General getGeneral() {
        return this.general;
    }

    public ProductProfile.NonPhysicalGoods getNonPhysicalGoods() {
        return this.nonPhysicalGoods;
    }

    public ProductProfile.PhysicalGoods getPhysicalGoods() {
        return this.physicalGoods;
    }

    public double getProductAmount() {
        return this.productAmount;
    }

    public String getProductCategory() {
        return this.productCategory;
    }

    public String getProductName() {
        return this.productName;
    }

    public ProductProfile getProductProfile() {
        return this.productProfile;
    }

    public ProductProfile.TelecomVertical getTelecomVertical() {
        return this.telecomVertical;
    }

    public ProductProfile.TravelVertical getTravelVertical() {
        return this.travelVertical;
    }

    public double getVat() {
        return this.vat;
    }

    public void setAirlinesTicket(ProductProfile.AirlinesTicket airlinesTicket) {
        this.airlinesTicket = airlinesTicket;
    }

    public void setCart(String string2) {
        this.cart = string2;
    }

    public void setConvenienceFee(double d) {
        this.convenienceFee = d;
    }

    public void setDiscountAmount(double d) {
        this.discountAmount = d;
    }

    public void setGeneral(ProductProfile.General general) {
        this.general = general;
    }

    public void setNonPhysicalGoods(ProductProfile.NonPhysicalGoods nonPhysicalGoods) {
        this.nonPhysicalGoods = nonPhysicalGoods;
    }

    public void setPhysicalGoods(ProductProfile.PhysicalGoods physicalGoods) {
        this.physicalGoods = physicalGoods;
    }

    public void setProductAmount(double d) {
        this.productAmount = d;
    }

    public void setProductCategory(String string2) {
        this.productCategory = string2;
    }

    public void setProductName(String string2) {
        this.productName = string2;
    }

    public void setProductProfile(ProductProfile productProfile) {
        this.productProfile = productProfile;
    }

    public void setTelecomVertical(ProductProfile.TelecomVertical telecomVertical) {
        this.telecomVertical = telecomVertical;
    }

    public void setTravelVertical(ProductProfile.TravelVertical travelVertical) {
        this.travelVertical = travelVertical;
    }

    public void setVat(double d) {
        this.vat = d;
    }

    public static class ProductProfile {

        public static class AirlinesTicket {
            private String flightType;
            private String hoursTillDeparture;
            private String journeyFromTo;
            private String pnr;
            private String productProfile;
            private String thirdPartyBooking;

            public AirlinesTicket(String string2, String string3, String string4, String string5, String string6, String string7) {
                this.productProfile = string2;
                this.hoursTillDeparture = string3;
                this.flightType = string4;
                this.pnr = string5;
                this.journeyFromTo = string6;
                this.thirdPartyBooking = string7;
            }

            public String getFlightType() {
                return this.flightType;
            }

            public String getHoursTillDeparture() {
                return this.hoursTillDeparture;
            }

            public String getJourneyFromTo() {
                return this.journeyFromTo;
            }

            public String getPnr() {
                return this.pnr;
            }

            public String getProductProfile() {
                return this.productProfile;
            }

            public String getThirdPartyBooking() {
                return this.thirdPartyBooking;
            }

            public void setFlightType(String string2) {
                this.flightType = string2;
            }

            public void setHoursTillDeparture(String string2) {
                this.hoursTillDeparture = string2;
            }

            public void setJourneyFromTo(String string2) {
                this.journeyFromTo = string2;
            }

            public void setPnr(String string2) {
                this.pnr = string2;
            }

            public void setProductProfile(String string2) {
                this.productProfile = string2;
            }

            public void setThirdPartyBooking(String string2) {
                this.thirdPartyBooking = string2;
            }
        }

        public static class General {
            private String general;
            private String productProfile;

            public General(String string2, String string3) {
                this.productProfile = string2;
                this.general = string3;
            }

            public String getGeneral() {
                return this.general;
            }

            public String getProductProfile() {
                return this.productProfile;
            }

            public void setGeneral(String string2) {
                this.general = string2;
            }

            public void setProductProfile(String string2) {
                this.productProfile = string2;
            }
        }

        public static class NonPhysicalGoods {
            private String nonPhysicalGoods;
            private String productProfile;

            public NonPhysicalGoods(String string2, String string3) {
                this.productProfile = string2;
                this.nonPhysicalGoods = string3;
            }

            public String getNonPhysicalGoods() {
                return this.nonPhysicalGoods;
            }

            public String getProductProfile() {
                return this.productProfile;
            }

            public void setNonPhysicalGoods(String string2) {
                this.nonPhysicalGoods = string2;
            }

            public void setProductProfile(String string2) {
                this.productProfile = string2;
            }
        }

        public static class PhysicalGoods {
            private String physicalGoods;
            private String productProfile;

            public PhysicalGoods(String string2, String string3) {
                this.productProfile = string2;
                this.physicalGoods = string3;
            }

            public String getPhysicalGoods() {
                return this.physicalGoods;
            }

            public String getProductProfile() {
                return this.productProfile;
            }

            public void setPhysicalGoods(String string2) {
                this.physicalGoods = string2;
            }

            public void setProductProfile(String string2) {
                this.productProfile = string2;
            }
        }

        public static class TelecomVertical {
            private String countryTopUp;
            private String productProfile;
            private String productType;
            private String topUpNumber;

            public TelecomVertical(String string2, String string3, String string4, String string5) {
                this.productProfile = string2;
                this.productType = string3;
                this.topUpNumber = string4;
                this.countryTopUp = string5;
            }

            public String getCountryTopUp() {
                return this.countryTopUp;
            }

            public String getProductProfile() {
                return this.productProfile;
            }

            public String getProductType() {
                return this.productType;
            }

            public String getTopUpNumber() {
                return this.topUpNumber;
            }

            public void setCountryTopUp(String string2) {
                this.countryTopUp = string2;
            }

            public void setProductProfile(String string2) {
                this.productProfile = string2;
            }

            public void setProductType(String string2) {
                this.productType = string2;
            }

            public void setTopUpNumber(String string2) {
                this.topUpNumber = string2;
            }
        }

        public static class TravelVertical {
            private String checkInTime;
            private String hotelCity;
            private String hotelName;
            private String lengthOfStay;
            private String productProfile;

            public TravelVertical(String string2, String string3, String string4, String string5, String string6) {
                this.productProfile = string2;
                this.hotelName = string3;
                this.lengthOfStay = string4;
                this.checkInTime = string5;
                this.hotelCity = string6;
            }

            public String getCheckInTime() {
                return this.checkInTime;
            }

            public String getHotelCity() {
                return this.hotelCity;
            }

            public String getHotelName() {
                return this.hotelName;
            }

            public String getLengthOfStay() {
                return this.lengthOfStay;
            }

            public String getProductProfile() {
                return this.productProfile;
            }

            public void setCheckInTime(String string2) {
                this.checkInTime = string2;
            }

            public void setHotelCity(String string2) {
                this.hotelCity = string2;
            }

            public void setHotelName(String string2) {
                this.hotelName = string2;
            }

            public void setLengthOfStay(String string2) {
                this.lengthOfStay = string2;
            }

            public void setProductProfile(String string2) {
                this.productProfile = string2;
            }
        }

    }

}

