/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.gson.annotations.Expose
 *  com.google.gson.annotations.SerializedName
 *  java.lang.Object
 *  java.lang.String
 */
package com.sslwireless.sslcommerzlibrary.model.response;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class SSLCResendOtpModel {
    @Expose
    @SerializedName(value="data")
    private Data data;
    @Expose
    @SerializedName(value="message")
    private String message;
    @Expose
    @SerializedName(value="status")
    private String status;

    public Data getData() {
        return this.data;
    }

    public String getMessage() {
        return this.message;
    }

    public String getStatus() {
        return this.status;
    }

    public void setData(Data data) {
        this.data = data;
    }

    public void setMessage(String string2) {
        this.message = string2;
    }

    public void setStatus(String string2) {
        this.status = string2;
    }

    public class Data {
        @Expose
        @SerializedName(value="data")
        private Data_ data;
        @Expose
        @SerializedName(value="status")
        private String status;

        public Data_ getData() {
            return this.data;
        }

        public String getStatus() {
            return this.status;
        }

        public void setData(Data_ data_) {
            this.data = data_;
        }

        public void setStatus(String string2) {
            this.status = string2;
        }

        public class Data_ {
            @Expose
            @SerializedName(value="actionStatus")
            private String actionStatus;
            @Expose
            @SerializedName(value="msgToDisplay")
            private String msgToDisplay;
            @Expose
            @SerializedName(value="systemMesg")
            private String systemMesg;

            public String getActionStatus() {
                return this.actionStatus;
            }

            public String getMsgToDisplay() {
                return this.msgToDisplay;
            }

            public String getSystemMesg() {
                return this.systemMesg;
            }

            public void setActionStatus(String string2) {
                this.actionStatus = string2;
            }

            public void setMsgToDisplay(String string2) {
                this.msgToDisplay = string2;
            }

            public void setSystemMesg(String string2) {
                this.systemMesg = string2;
            }
        }

    }

}

