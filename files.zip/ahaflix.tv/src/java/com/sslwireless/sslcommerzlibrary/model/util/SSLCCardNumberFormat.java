/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.text.Editable
 *  android.text.TextWatcher
 *  android.widget.EditText
 *  e.a.a.a.a
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.sslwireless.sslcommerzlibrary.model.util;

import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import e.a.a.a.a;

public class SSLCCardNumberFormat
implements TextWatcher {
    private String previousValue;
    private EditText view;

    public SSLCCardNumberFormat(EditText editText) {
        this.view = editText;
        this.previousValue = new String(" ");
    }

    private String addSpace(String string2, int n) {
        String string3 = new String();
        char[] arrc = string2.toCharArray();
        for (int i = 0; i < arrc.length; ++i) {
            if (n == i) {
                string3 = a.h1((String)string3, (String)" ");
            }
            StringBuilder stringBuilder = a.F1((String)string3);
            stringBuilder.append(arrc[i]);
            string3 = stringBuilder.toString();
        }
        return string3;
    }

    private String removeSpace(String string2, int n) {
        String string3 = new String();
        char[] arrc = string2.toCharArray();
        for (int i = 0; i < n; ++i) {
            StringBuilder stringBuilder = a.F1((String)string3);
            stringBuilder.append(arrc[i]);
            string3 = stringBuilder.toString();
        }
        return string3;
    }

    public void afterTextChanged(Editable editable) {
        String string2 = editable.toString();
        if (this.previousValue.length() < string2.length() && this.previousValue.length() > 2) {
            if (!this.previousValue.substring(0, 2).equals((Object)"34") && !this.previousValue.substring(0, 2).equals((Object)"37")) {
                if (string2.length() == 5) {
                    this.view.setText((CharSequence)this.addSpace(string2, 4));
                } else if (string2.length() == 10) {
                    this.view.setText((CharSequence)this.addSpace(string2, 9));
                } else if (string2.length() == 15) {
                    this.view.setText((CharSequence)this.addSpace(string2, 14));
                }
            } else if (string2.length() == 5) {
                this.view.setText((CharSequence)this.addSpace(string2, 4));
            } else if (string2.length() == 12) {
                this.view.setText((CharSequence)this.addSpace(string2, 11));
            }
        }
        EditText editText = this.view;
        editText.setSelection(editText.getText().toString().length());
        this.previousValue = this.view.getText().toString();
    }

    public void beforeTextChanged(CharSequence charSequence, int n, int n2, int n3) {
    }

    public void onTextChanged(CharSequence charSequence, int n, int n2, int n3) {
    }
}

