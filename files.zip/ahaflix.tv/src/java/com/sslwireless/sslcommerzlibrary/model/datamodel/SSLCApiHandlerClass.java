/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.net.http.X509TrustManagerExtensions
 *  android.os.AsyncTask
 *  android.util.Base64
 *  com.google.firebase.perf.network.FirebasePerfUrlConnection
 *  e.a.a.a.a
 *  java.io.BufferedReader
 *  java.io.BufferedWriter
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.InputStreamReader
 *  java.io.OutputStream
 *  java.io.OutputStreamWriter
 *  java.io.Reader
 *  java.io.Writer
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuffer
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.lang.Void
 *  java.net.HttpURLConnection
 *  java.net.URL
 *  java.net.URLConnection
 *  java.net.URLEncoder
 *  java.nio.charset.Charset
 *  java.nio.charset.StandardCharsets
 *  java.security.MessageDigest
 *  java.security.NoSuchAlgorithmException
 *  java.security.Principal
 *  java.security.PublicKey
 *  java.security.cert.Certificate
 *  java.security.cert.CertificateException
 *  java.security.cert.X509Certificate
 *  java.util.Arrays
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 *  javax.net.ssl.HttpsURLConnection
 *  javax.net.ssl.SSLException
 *  javax.net.ssl.SSLPeerUnverifiedException
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.sslwireless.sslcommerzlibrary.model.datamodel;

import android.content.Context;
import android.net.http.X509TrustManagerExtensions;
import android.util.Base64;
import com.google.firebase.perf.network.FirebasePerfUrlConnection;
import com.sslwireless.sslcommerzlibrary.model.datamodel.SSLCApiHandlerListener;
import e.a.a.a.a;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Writer;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.Principal;
import java.security.PublicKey;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLException;
import javax.net.ssl.SSLPeerUnverifiedException;
import org.json.JSONException;
import org.json.JSONObject;

public class SSLCApiHandlerClass {
    private Context mContext;
    private boolean mDataEncryption;
    private String mEndPoint;
    private Map<String, Object> mHashMap;
    private String mMethodType;
    private String mRequestType;
    private SSLCApiHandlerListener mSSLCApiHandlerListener;
    private String mbaseUrl;
    private URL url;

    public SSLCApiHandlerClass(Context context) {
        this.mContext = context;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private String callGetMethod(HttpURLConnection httpURLConnection) {
        try {
            BufferedReader bufferedReader = new BufferedReader((Reader)new InputStreamReader(httpURLConnection.getInputStream()));
            StringBuffer stringBuffer = new StringBuffer();
            do {
                String string2;
                if ((string2 = bufferedReader.readLine()) == null) {
                    httpURLConnection.disconnect();
                    bufferedReader.close();
                    return stringBuffer.toString();
                }
                stringBuffer.append(string2);
                stringBuffer.append("\n");
            } while (true);
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
            return null;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private String callPostMethod(HttpURLConnection httpURLConnection, Map<String, Object> map) {
        try {
            OutputStream outputStream = httpURLConnection.getOutputStream();
            BufferedWriter bufferedWriter = new BufferedWriter((Writer)new OutputStreamWriter(outputStream, StandardCharsets.UTF_8));
            if (bufferedWriter != null) {
                bufferedWriter.write(this.getPostDataString(map));
                bufferedWriter.flush();
                bufferedWriter.close();
            }
            outputStream.close();
            BufferedReader bufferedReader = new BufferedReader((Reader)new InputStreamReader(httpURLConnection.getInputStream()));
            StringBuffer stringBuffer = new StringBuffer();
            String string2 = bufferedReader.readLine();
            if (string2 != null) {
                stringBuffer.append(string2);
            }
            bufferedReader.close();
            httpURLConnection.disconnect();
            return stringBuffer.toString();
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return null;
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
        }
        return null;
    }

    private String getPostDataString(Map<String, Object> map) throws Exception {
        StringBuilder stringBuilder = new StringBuilder();
        for (Map.Entry entry : map.entrySet()) {
            if (stringBuilder.length() != 0) {
                stringBuilder.append('&');
            }
            stringBuilder.append(URLEncoder.encode((String)((String)entry.getKey()), (String)"UTF-8"));
            stringBuilder.append('=');
            stringBuilder.append(URLEncoder.encode((String)String.valueOf((Object)entry.getValue()), (String)"UTF-8"));
        }
        return stringBuilder.toString();
    }

    private List<X509Certificate> trustedChain(X509TrustManagerExtensions x509TrustManagerExtensions, HttpsURLConnection httpsURLConnection) throws SSLException {
        Object[] arrobject = httpsURLConnection.getServerCertificates();
        X509Certificate[] arrx509Certificate = (X509Certificate[])Arrays.copyOf((Object[])arrobject, (int)arrobject.length, X509Certificate[].class);
        String string2 = httpsURLConnection.getURL().getHost();
        try {
            List list = x509TrustManagerExtensions.checkServerTrusted(arrx509Certificate, "RSA", string2);
            return list;
        }
        catch (CertificateException certificateException) {
            throw new SSLException((Throwable)certificateException);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void validatePinning(X509TrustManagerExtensions x509TrustManagerExtensions, HttpsURLConnection httpsURLConnection, Set<String> set) throws SSLException {
        try {
            String string2;
            boolean bl;
            MessageDigest messageDigest = MessageDigest.getInstance((String)"SHA-256");
            Iterator iterator = this.trustedChain(x509TrustManagerExtensions, httpsURLConnection).iterator();
            String string3 = "";
            do {
                if (!iterator.hasNext()) throw new SSLPeerUnverifiedException(a.h1((String)"Certificate pinning failure\n  Peer certificate chain:\n", (String)string3));
                X509Certificate x509Certificate = (X509Certificate)iterator.next();
                byte[] arrby = x509Certificate.getPublicKey().getEncoded();
                messageDigest.update(arrby, 0, arrby.length);
                string2 = Base64.encodeToString((byte[])messageDigest.digest(), (int)2);
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(string3);
                stringBuilder.append("    sha256/");
                stringBuilder.append(string2);
                stringBuilder.append(" : ");
                stringBuilder.append(x509Certificate.getSubjectDN().toString());
                stringBuilder.append("\n");
                string3 = stringBuilder.toString();
            } while (!(bl = set.contains((Object)string2)));
            return;
        }
        catch (NoSuchAlgorithmException noSuchAlgorithmException) {
            throw new SSLException((Throwable)noSuchAlgorithmException);
        }
    }

    public void sslCommerzRequest(Context context, String string2, String string3, String string4, String string5, Map<String, Object> map, boolean bl, SSLCApiHandlerListener sSLCApiHandlerListener) {
        this.mContext = context;
        this.mbaseUrl = string2;
        this.mEndPoint = string3;
        this.mMethodType = string4;
        this.mRequestType = string5;
        this.mHashMap = map;
        this.mDataEncryption = bl;
        this.mSSLCApiHandlerListener = sSLCApiHandlerListener;
        new AsyncTask().execute((Object[])new String[0]);
    }

    public class AsyncTask
    extends android.os.AsyncTask<String, Void, String> {
        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        public /* varargs */ String doInBackground(String ... arrstring) {
            try {
                boolean bl = SSLCApiHandlerClass.this.mMethodType.equals((Object)"POST");
                if (bl) {
                    SSLCApiHandlerClass sSLCApiHandlerClass = SSLCApiHandlerClass.this;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(SSLCApiHandlerClass.this.mbaseUrl);
                    stringBuilder.append(SSLCApiHandlerClass.this.mEndPoint);
                    sSLCApiHandlerClass.url = new URL(stringBuilder.toString());
                } else if (SSLCApiHandlerClass.this.mMethodType.equals((Object)"GET")) {
                    SSLCApiHandlerClass sSLCApiHandlerClass = SSLCApiHandlerClass.this;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(SSLCApiHandlerClass.this.mbaseUrl);
                    stringBuilder.append(SSLCApiHandlerClass.this.mEndPoint);
                    stringBuilder.append("?");
                    SSLCApiHandlerClass sSLCApiHandlerClass2 = SSLCApiHandlerClass.this;
                    stringBuilder.append(sSLCApiHandlerClass2.getPostDataString((Map<String, Object>)sSLCApiHandlerClass2.mHashMap));
                    sSLCApiHandlerClass.url = new URL(stringBuilder.toString());
                }
                HttpsURLConnection httpsURLConnection = (HttpsURLConnection)((URLConnection)FirebasePerfUrlConnection.instrument((Object)SSLCApiHandlerClass.this.url.openConnection()));
                httpsURLConnection.setReadTimeout(30000);
                httpsURLConnection.setConnectTimeout(30000);
                httpsURLConnection.setRequestMethod(SSLCApiHandlerClass.this.mMethodType);
                httpsURLConnection.setDoInput(true);
                httpsURLConnection.connect();
                if (!SSLCApiHandlerClass.this.mMethodType.equals((Object)"POST")) {
                    if (!SSLCApiHandlerClass.this.mMethodType.equals((Object)"GET")) return null;
                    return SSLCApiHandlerClass.this.callGetMethod((HttpURLConnection)httpsURLConnection);
                }
                HashMap hashMap = new HashMap();
                SSLCApiHandlerClass sSLCApiHandlerClass = SSLCApiHandlerClass.this;
                if (sSLCApiHandlerClass.mDataEncryption) {
                    return sSLCApiHandlerClass.callPostMethod((HttpURLConnection)httpsURLConnection, (Map<String, Object>)((Map)hashMap));
                }
                hashMap = SSLCApiHandlerClass.this.mHashMap;
                return sSLCApiHandlerClass.callPostMethod((HttpURLConnection)httpsURLConnection, (Map<String, Object>)((Map)hashMap));
            }
            catch (Exception exception) {
                StringBuilder stringBuilder = a.F1((String)"Exception: ");
                stringBuilder.append(exception.getMessage());
                return stringBuilder.toString();
            }
        }

        public void onPostExecute(String string2) {
            if (string2 != null && !string2.isEmpty()) {
                try {
                    SSLCApiHandlerClass.this.mSSLCApiHandlerListener.success(new JSONObject(string2));
                    return;
                }
                catch (JSONException jSONException) {
                    jSONException.printStackTrace();
                    SSLCApiHandlerClass.this.mSSLCApiHandlerListener.fail(jSONException.getMessage());
                    return;
                }
            }
            SSLCApiHandlerClass.this.mSSLCApiHandlerListener.fail("something went wrong");
        }

        public void onPreExecute() {
        }
    }

}

