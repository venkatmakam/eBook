/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.gson.annotations.Expose
 *  com.google.gson.annotations.SerializedName
 *  java.io.Serializable
 *  java.lang.Object
 *  java.lang.String
 */
package com.sslwireless.sslcommerzlibrary.model.response;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import java.io.Serializable;

public class SSLCTransactionInfo
implements Serializable {
    @Expose
    @SerializedName(value="APIConnect")
    private String APIConnect;
    @Expose
    @SerializedName(value="amount")
    private String amount;
    @Expose
    private Data data;
    @Expose
    @SerializedName(value="message")
    private String message;
    @Expose
    @SerializedName(value="status")
    private String status;

    public String getAPIConnect() {
        return this.APIConnect;
    }

    public String getAmount() {
        return this.amount;
    }

    public Data getData() {
        return this.data;
    }

    public String getMessage() {
        return this.message;
    }

    public String getStatus() {
        return this.status;
    }

    public void setAPIConnect(String string2) {
        this.APIConnect = string2;
    }

    public void setAmount(String string2) {
        this.amount = string2;
    }

    public void setMessage(String string2) {
        this.message = string2;
    }

    public void setStatus(String string2) {
        this.status = string2;
    }

    public class Data {
        @Expose
        private String status;
        @Expose
        private String type;
        @Expose
        private String url;

        public String getStatus() {
            return this.status;
        }

        public String getType() {
            return this.type;
        }

        public String getUrl() {
            return this.url;
        }

        public void setStatus(String string2) {
            this.status = string2;
        }

        public void setType(String string2) {
            this.type = string2;
        }

        public void setUrl(String string2) {
            this.url = string2;
        }
    }

}

