/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.gson.annotations.Expose
 *  com.google.gson.annotations.SerializedName
 *  java.io.Serializable
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 */
package com.sslwireless.sslcommerzlibrary.model.response;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import java.io.Serializable;
import java.util.List;

public class SSLCOfferModel
implements Serializable {
    @Expose
    @SerializedName(value="data")
    private Data data;
    @Expose
    @SerializedName(value="message")
    private String message;
    @Expose
    @SerializedName(value="status")
    private String status;

    public Data getData() {
        return this.data;
    }

    public String getMessage() {
        return this.message;
    }

    public String getStatus() {
        return this.status;
    }

    public void setData(Data data) {
        this.data = data;
    }

    public void setMessage(String string2) {
        this.message = string2;
    }

    public void setStatus(String string2) {
        this.status = string2;
    }

    public class Data {
        @Expose
        @SerializedName(value="data")
        private Data_ data;
        @Expose
        @SerializedName(value="status")
        private String status;

        public Data_ getData() {
            return this.data;
        }

        public String getStatus() {
            return this.status;
        }

        public void setData(Data_ data_) {
            this.data = data_;
        }

        public void setStatus(String string2) {
            this.status = string2;
        }
    }

    public class Data_ {
        @Expose
        @SerializedName(value="actionStatus")
        private String actionStatus;
        @Expose
        @SerializedName(value="discountList")
        private List<DiscountList> discountList = null;
        @Expose
        @SerializedName(value="msgToDisplay")
        private String msgToDisplay;
        @Expose
        @SerializedName(value="systemMesg")
        private String systemMesg;

        public String getActionStatus() {
            return this.actionStatus;
        }

        public List<DiscountList> getDiscountList() {
            return this.discountList;
        }

        public String getMsgToDisplay() {
            return this.msgToDisplay;
        }

        public String getSystemMesg() {
            return this.systemMesg;
        }

        public void setActionStatus(String string2) {
            this.actionStatus = string2;
        }

        public void setDiscountList(List<DiscountList> list) {
            this.discountList = list;
        }

        public void setMsgToDisplay(String string2) {
            this.msgToDisplay = string2;
        }

        public void setSystemMesg(String string2) {
            this.systemMesg = string2;
        }
    }

    public class DiscountList {
        @Expose
        @SerializedName(value="allowedBIN")
        private List<String> allowedBIN = null;
        @Expose
        @SerializedName(value="AvailDiscountId")
        private String availDiscountId;
        @Expose
        @SerializedName(value="disIMGPath")
        private String disIMGPath;
        @Expose
        @SerializedName(value="disPercentage")
        private String disPercentage;
        @Expose
        @SerializedName(value="discountTitle")
        private String discountTitle;
        @Expose
        @SerializedName(value="firstDigitAllowed")
        private List<Object> firstDigitAllowed = null;
        @Expose
        @SerializedName(value="gateway")
        private List<Object> gateway = null;
        @Expose
        @SerializedName(value="is_amex")
        private String isAmex;
        @Expose
        @SerializedName(value="isCouponEnable")
        private Integer isCouponEnable;
        @Expose
        @SerializedName(value="is_ib")
        private String isIb;
        @Expose
        @SerializedName(value="is_master")
        private String isMaster;
        @Expose
        @SerializedName(value="is_other_card")
        private String isOtherCard;
        @Expose
        @SerializedName(value="is_visa")
        private String isVisa;
        @Expose
        @SerializedName(value="is_wallet")
        private String isWallet;
        @Expose
        @SerializedName(value="MaxDisAmt")
        private String maxDisAmt;
        @Expose
        @SerializedName(value="offerDesc")
        private String offerDesc;
        @Expose
        @SerializedName(value="offerEndOnDate")
        private String offerEndOnDate;
        @Expose
        @SerializedName(value="offerStartOnDate")
        private String offerStartOnDate;
        @Expose
        @SerializedName(value="payableAMT")
        private String payableAMT;
        @Expose
        @SerializedName(value="priority")
        private Integer priority;
        @Expose
        @SerializedName(value="redirectGWPath")
        private String redirectGWPath;
        @Expose
        @SerializedName(value="regularPrice")
        private String regularPrice;
        @Expose
        @SerializedName(value="termNConditionURL")
        private String termNConditionURL;

        public List<String> getAllowedBIN() {
            return this.allowedBIN;
        }

        public String getAvailDiscountId() {
            return this.availDiscountId;
        }

        public String getDisIMGPath() {
            return this.disIMGPath;
        }

        public String getDisPercentage() {
            return this.disPercentage;
        }

        public String getDiscountTitle() {
            return this.discountTitle;
        }

        public List<Object> getFirstDigitAllowed() {
            return this.firstDigitAllowed;
        }

        public List<Object> getGateway() {
            return this.gateway;
        }

        public String getIsAmex() {
            return this.isAmex;
        }

        public Integer getIsCouponEnable() {
            return this.isCouponEnable;
        }

        public String getIsIb() {
            return this.isIb;
        }

        public String getIsMaster() {
            return this.isMaster;
        }

        public String getIsOtherCard() {
            return this.isOtherCard;
        }

        public String getIsVisa() {
            return this.isVisa;
        }

        public String getIsWallet() {
            return this.isWallet;
        }

        public String getMaxDisAmt() {
            return this.maxDisAmt;
        }

        public String getOfferDesc() {
            return this.offerDesc;
        }

        public String getOfferEndOnDate() {
            return this.offerEndOnDate;
        }

        public String getOfferStartOnDate() {
            return this.offerStartOnDate;
        }

        public String getPayableAMT() {
            return this.payableAMT;
        }

        public Integer getPriority() {
            return this.priority;
        }

        public String getRedirectGWPath() {
            return this.redirectGWPath;
        }

        public String getRegularPrice() {
            return this.regularPrice;
        }

        public String getTermNConditionURL() {
            return this.termNConditionURL;
        }

        public void setAllowedBIN(List<String> list) {
            this.allowedBIN = list;
        }

        public void setAvailDiscountId(String string2) {
            this.availDiscountId = string2;
        }

        public void setDisIMGPath(String string2) {
            this.disIMGPath = string2;
        }

        public void setDisPercentage(String string2) {
            this.disPercentage = string2;
        }

        public void setDiscountTitle(String string2) {
            this.discountTitle = string2;
        }

        public void setFirstDigitAllowed(List<Object> list) {
            this.firstDigitAllowed = list;
        }

        public void setGateway(List<Object> list) {
            this.gateway = list;
        }

        public void setIsAmex(String string2) {
            this.isAmex = string2;
        }

        public void setIsCouponEnable(Integer n) {
            this.isCouponEnable = n;
        }

        public void setIsIb(String string2) {
            this.isIb = string2;
        }

        public void setIsMaster(String string2) {
            this.isMaster = string2;
        }

        public void setIsOtherCard(String string2) {
            this.isOtherCard = string2;
        }

        public void setIsVisa(String string2) {
            this.isVisa = string2;
        }

        public void setIsWallet(String string2) {
            this.isWallet = string2;
        }

        public void setMaxDisAmt(String string2) {
            this.maxDisAmt = string2;
        }

        public void setOfferDesc(String string2) {
            this.offerDesc = string2;
        }

        public void setOfferEndOnDate(String string2) {
            this.offerEndOnDate = string2;
        }

        public void setOfferStartOnDate(String string2) {
            this.offerStartOnDate = string2;
        }

        public void setPayableAMT(String string2) {
            this.payableAMT = string2;
        }

        public void setPriority(Integer n) {
            this.priority = n;
        }

        public void setRedirectGWPath(String string2) {
            this.redirectGWPath = string2;
        }

        public void setRegularPrice(String string2) {
            this.regularPrice = string2;
        }

        public void setTermNConditionURL(String string2) {
            this.termNConditionURL = string2;
        }
    }

}

