/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.sslwireless.sslcommerzlibrary.model.initializer;

public class SSLCAdditionalInitializer {
    private String valueA;
    private String valueB;
    private String valueC;
    private String valueD;

    public String getValueA() {
        return this.valueA;
    }

    public String getValueB() {
        return this.valueB;
    }

    public String getValueC() {
        return this.valueC;
    }

    public String getValueD() {
        return this.valueD;
    }

    public void setValueA(String string2) {
        this.valueA = string2;
    }

    public void setValueB(String string2) {
        this.valueB = string2;
    }

    public void setValueC(String string2) {
        this.valueC = string2;
    }

    public void setValueD(String string2) {
        this.valueD = string2;
    }
}

