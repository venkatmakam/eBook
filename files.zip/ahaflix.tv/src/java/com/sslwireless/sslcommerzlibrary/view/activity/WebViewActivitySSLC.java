/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.IntentFilter
 *  android.os.Bundle
 *  android.os.CountDownTimer
 *  android.view.MenuItem
 *  android.view.View
 *  android.webkit.WebChromeClient
 *  android.webkit.WebSettings
 *  android.webkit.WebView
 *  android.webkit.WebViewClient
 *  android.widget.LinearLayout
 *  android.widget.ProgressBar
 *  androidx.annotation.Nullable
 *  androidx.appcompat.app.ActionBar
 *  androidx.appcompat.app.AppCompatActivity
 *  androidx.appcompat.widget.Toolbar
 *  androidx.localbroadcastmanager.content.LocalBroadcastManager
 *  com.sslwireless.sslcommerzlibrary.R
 *  com.sslwireless.sslcommerzlibrary.R$id
 *  com.sslwireless.sslcommerzlibrary.R$layout
 *  com.sslwireless.sslcommerzlibrary.model.initializer.SSLCommerzInitialization
 *  com.sslwireless.sslcommerzlibrary.model.response.SSLCTransactionInfoModel
 *  com.sslwireless.sslcommerzlibrary.model.util.SSLCShareInfo
 *  com.sslwireless.sslcommerzlibrary.view.activity.WebViewActivitySSLC$1
 *  com.sslwireless.sslcommerzlibrary.view.activity.WebViewActivitySSLC$2
 *  com.sslwireless.sslcommerzlibrary.view.activity.WebViewActivitySSLC$3
 *  com.sslwireless.sslcommerzlibrary.view.singleton.IntegrateSSLCommerz
 *  com.sslwireless.sslcommerzlibrary.viewmodel.SSLCMerchantValidatorViewModel
 *  com.sslwireless.sslcommerzlibrary.viewmodel.listener.SSLCMerchantValidatorListener
 *  com.sslwireless.sslcommerzlibrary.viewmodel.listener.SSLCTransactionResponseListener
 *  java.io.Serializable
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Map
 */
package com.sslwireless.sslcommerzlibrary.view.activity;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import com.sslwireless.sslcommerzlibrary.R;
import com.sslwireless.sslcommerzlibrary.model.initializer.SSLCommerzInitialization;
import com.sslwireless.sslcommerzlibrary.model.response.SSLCTransactionInfoModel;
import com.sslwireless.sslcommerzlibrary.model.util.SSLCShareInfo;
import com.sslwireless.sslcommerzlibrary.view.activity.SSLCBaseActivity;
import com.sslwireless.sslcommerzlibrary.view.activity.WebViewActivitySSLC;
import com.sslwireless.sslcommerzlibrary.view.custom.SSLCCustomTextView;
import com.sslwireless.sslcommerzlibrary.view.singleton.IntegrateSSLCommerz;
import com.sslwireless.sslcommerzlibrary.viewmodel.SSLCMerchantValidatorViewModel;
import com.sslwireless.sslcommerzlibrary.viewmodel.listener.SSLCMerchantValidatorListener;
import com.sslwireless.sslcommerzlibrary.viewmodel.listener.SSLCTransactionResponseListener;
import java.io.Serializable;
import java.util.Map;

public class WebViewActivitySSLC
extends SSLCBaseActivity
implements SSLCMerchantValidatorListener {
    private int OTP_RESEND_TIMER = 30;
    private SSLCMerchantValidatorViewModel SSLCMerchantValidatorViewModel;
    private WebView bankPage;
    private ProgressBar bankPageProgress;
    private BroadcastReceiver mMessageReceiver = new 1(this);
    private LinearLayout mainLyout1;
    private String merchantName;
    private SSLCommerzInitialization mobileSslCommerzInitialization;
    public boolean motoEnable = false;
    private String redirectUrl;
    private String savedCardIndex = "";
    private String sessionKey;
    private String timeOutValue;
    private CountDownTimer timer;
    private SSLCCustomTextView timerText;

    public static /* synthetic */ SSLCommerzInitialization access$000(WebViewActivitySSLC webViewActivitySSLC) {
        return webViewActivitySSLC.mobileSslCommerzInitialization;
    }

    public static /* synthetic */ String access$100(WebViewActivitySSLC webViewActivitySSLC) {
        return webViewActivitySSLC.sessionKey;
    }

    public static /* synthetic */ SSLCMerchantValidatorViewModel access$200(WebViewActivitySSLC webViewActivitySSLC) {
        return webViewActivitySSLC.SSLCMerchantValidatorViewModel;
    }

    public static /* synthetic */ ProgressBar access$300(WebViewActivitySSLC webViewActivitySSLC) {
        return webViewActivitySSLC.bankPageProgress;
    }

    private void showTheWebsite(String string2) {
        2 var2_2 = new 2(this);
        this.bankPage.getSettings().setLoadsImagesAutomatically(true);
        this.bankPage.getSettings().setJavaScriptEnabled(true);
        this.bankPage.getSettings().setDomStorageEnabled(true);
        this.bankPage.setScrollBarStyle(0);
        this.bankPage.setWebViewClient((WebViewClient)var2_2);
        if (SSLCShareInfo.getInstance().isURLString(this.redirectUrl)) {
            this.bankPage.loadUrl(string2);
        } else {
            this.bankPage.loadData(string2, "text/html;", "UTF-8");
        }
        this.bankPage.setWebChromeClient((WebChromeClient)new 3(this));
    }

    public void merchantValidatorFail(String string2) {
        IntegrateSSLCommerz.SSLCTransactionResponseListener.transactionFail(string2);
        this.finish();
    }

    public void merchantValidatorSuccess(SSLCTransactionInfoModel sSLCTransactionInfoModel) {
        if (!sSLCTransactionInfoModel.getStatus().toLowerCase().equalsIgnoreCase("valid") && !sSLCTransactionInfoModel.getStatus().toLowerCase().equalsIgnoreCase("validated")) {
            IntegrateSSLCommerz.SSLCTransactionResponseListener.transactionFail("Transaction Failed");
            if (this.motoEnable) {
                SSLCShareInfo.motoMap.put((Object)this.savedCardIndex, (Object)Boolean.TRUE);
            }
        } else {
            SSLCShareInfo.getInstance().showToast((Context)this, "Transaction successful");
            IntegrateSSLCommerz.SSLCTransactionResponseListener.transactionSuccess(sSLCTransactionInfoModel);
            this.setResult(-1, this.getIntent());
        }
        this.finish();
    }

    @Override
    public void onCreate(@Nullable Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(R.layout.activity_ssl_web_view);
        LocalBroadcastManager.getInstance((Context)this).registerReceiver(this.mMessageReceiver, new IntentFilter("custom-event-name"));
    }

    public void onDestroy() {
        LocalBroadcastManager.getInstance((Context)this).unregisterReceiver(this.mMessageReceiver);
        AppCompatActivity.super.onDestroy();
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == 16908332) {
            this.finish();
            return true;
        }
        return Activity.super.onOptionsItemSelected(menuItem);
    }

    @Override
    public void viewRelatedTask() {
        this.timerText = (SSLCCustomTextView)this.findViewById(R.id.timerText);
        this.mainLyout1 = (LinearLayout)this.findViewById(R.id.mainLyout1);
        this.redirectUrl = this.getIntent().getStringExtra("redirectUrl");
        this.merchantName = this.getIntent().getStringExtra("merchantName");
        this.sessionKey = this.getIntent().getStringExtra("session_key");
        this.timeOutValue = this.getIntent().getStringExtra("timeOutValue");
        if (this.getIntent().hasExtra("motoEnable")) {
            this.motoEnable = this.getIntent().getBooleanExtra("motoEnable", false);
            this.savedCardIndex = this.getIntent().getStringExtra("savedCardIndex");
        }
        this.mobileSslCommerzInitialization = (SSLCommerzInitialization)this.getIntent().getSerializableExtra("sdkMainResponse");
        this.bankPage = (WebView)this.findViewById(R.id.bankPage);
        this.bankPageProgress = (ProgressBar)this.findViewById(R.id.bankPageProgress);
        this.setSupportActionBar((Toolbar)this.findViewById(R.id.toolbar));
        if (this.getSupportActionBar() != null) {
            this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            this.getSupportActionBar().setHomeButtonEnabled(true);
            this.getSupportActionBar().setTitle((CharSequence)this.merchantName);
        }
        this.SSLCMerchantValidatorViewModel = new SSLCMerchantValidatorViewModel((Context)this);
        this.showTheWebsite(this.redirectUrl);
    }
}

