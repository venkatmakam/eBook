/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.IntentFilter
 *  android.os.Bundle
 *  android.view.MenuItem
 *  android.view.View
 *  android.widget.TextView
 *  androidx.annotation.Nullable
 *  androidx.appcompat.app.ActionBar
 *  androidx.appcompat.app.AppCompatActivity
 *  androidx.appcompat.widget.Toolbar
 *  androidx.localbroadcastmanager.content.LocalBroadcastManager
 *  androidx.recyclerview.widget.LinearLayoutManager
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.recyclerview.widget.RecyclerView$LayoutManager
 *  com.google.gson.Gson
 *  com.sslwireless.sslcommerzlibrary.R
 *  com.sslwireless.sslcommerzlibrary.R$id
 *  com.sslwireless.sslcommerzlibrary.R$layout
 *  com.sslwireless.sslcommerzlibrary.model.initializer.SSLCommerzInitialization
 *  com.sslwireless.sslcommerzlibrary.model.response.SSLCOfferModel
 *  com.sslwireless.sslcommerzlibrary.model.response.SSLCOfferModel$Data
 *  com.sslwireless.sslcommerzlibrary.model.response.SSLCOfferModel$Data_
 *  com.sslwireless.sslcommerzlibrary.model.response.SSLCSdkMainResponseModel
 *  com.sslwireless.sslcommerzlibrary.view.activity.SSLOffersActivitySSLC$1
 *  com.sslwireless.sslcommerzlibrary.view.adapter.SSLCOffersRecyclerAdapter
 *  com.sslwireless.sslcommerzlibrary.view.adapter.SSLCOffersRecyclerAdapter$ClickListener
 *  java.io.Serializable
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 */
package com.sslwireless.sslcommerzlibrary.view.activity;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.gson.Gson;
import com.sslwireless.sslcommerzlibrary.R;
import com.sslwireless.sslcommerzlibrary.model.initializer.SSLCommerzInitialization;
import com.sslwireless.sslcommerzlibrary.model.response.SSLCOfferModel;
import com.sslwireless.sslcommerzlibrary.model.response.SSLCSdkMainResponseModel;
import com.sslwireless.sslcommerzlibrary.view.activity.SSLCBaseActivity;
import com.sslwireless.sslcommerzlibrary.view.activity.SSLOffersActivitySSLC;
import com.sslwireless.sslcommerzlibrary.view.adapter.SSLCOffersRecyclerAdapter;
import java.io.Serializable;
import java.util.List;

public class SSLOffersActivitySSLC
extends SSLCBaseActivity {
    public SSLCOfferModel SSLCOfferModel;
    public SSLCSdkMainResponseModel SSLCSdkMainResponseModel;
    private Context context;
    private BroadcastReceiver mMessageReceiver = new 1(this);
    public RecyclerView recyclerView;
    private SSLCommerzInitialization sslCommerzInitialization;
    public TextView tvDataNotFound;

    public static /* synthetic */ Context access$000(SSLOffersActivitySSLC sSLOffersActivitySSLC) {
        return sSLOffersActivitySSLC.context;
    }

    public static /* synthetic */ SSLCommerzInitialization access$100(SSLOffersActivitySSLC sSLOffersActivitySSLC) {
        return sSLOffersActivitySSLC.sslCommerzInitialization;
    }

    private void getData() {
        if (this.SSLCOfferModel == null) {
            this.tvDataNotFound.setVisibility(0);
            return;
        }
        this.recyclerView.setHasFixedSize(true);
        SSLCOffersRecyclerAdapter sSLCOffersRecyclerAdapter = new SSLCOffersRecyclerAdapter((Context)this, this.SSLCOfferModel.getData().getData().getDiscountList());
        this.recyclerView.setLayoutManager((RecyclerView.LayoutManager)new LinearLayoutManager((Context)this));
        this.recyclerView.setAdapter((RecyclerView.Adapter)sSLCOffersRecyclerAdapter);
        sSLCOffersRecyclerAdapter.setClickListener(new SSLCOffersRecyclerAdapter.ClickListener(this){
            public final /* synthetic */ SSLOffersActivitySSLC this$0;
            {
                this.this$0 = sSLOffersActivitySSLC;
            }

            public void itemClicked(View view, int n) {
                com.sslwireless.sslcommerzlibrary.model.response.SSLCOfferModel$DiscountList discountList = (com.sslwireless.sslcommerzlibrary.model.response.SSLCOfferModel$DiscountList)this.this$0.SSLCOfferModel.getData().getData().getDiscountList().get(n);
                if (!discountList.getRedirectGWPath().isEmpty()) {
                    Intent intent = new Intent(SSLOffersActivitySSLC.access$000(this.this$0), com.sslwireless.sslcommerzlibrary.view.activity.WebViewActivitySSLC.class);
                    intent.putExtra("redirectUrl", discountList.getRedirectGWPath());
                    intent.putExtra("session_key", this.this$0.SSLCSdkMainResponseModel.getSessionkey());
                    intent.putExtra("sdkMainResponse", (Serializable)SSLOffersActivitySSLC.access$100(this.this$0));
                    this.this$0.startActivity(intent);
                    return;
                }
                Intent intent = this.this$0.getIntent();
                intent.putExtra("id", discountList.getAvailDiscountId());
                intent.putExtra("image", discountList.getDisIMGPath());
                intent.putExtra("title", discountList.getDiscountTitle());
                intent.putExtra("max_discount", discountList.getMaxDisAmt());
                intent.putStringArrayListExtra("offer_bins", com.sslwireless.sslcommerzlibrary.model.util.SSLCShareInfo.getInstance().convertListToArrayList(discountList.getAllowedBIN()));
                this.this$0.setResult(-1, intent);
                this.this$0.finish();
            }
        });
    }

    @Override
    public void onCreate(@Nullable Bundle bundle) {
        TextView textView;
        super.onCreate(bundle);
        this.setContentView(R.layout.activity_ssl_offers);
        this.context = this;
        this.tvDataNotFound = textView = (TextView)this.findViewById(R.id.tv_data_not_found);
        textView.setVisibility(8);
        this.sslCommerzInitialization = (SSLCommerzInitialization)this.getIntent().getSerializableExtra("sslCommerzInitialerData");
        Bundle bundle2 = this.getIntent().getExtras();
        if (this.getIntent().hasExtra("main_response")) {
            SSLCSdkMainResponseModel sSLCSdkMainResponseModel;
            this.SSLCSdkMainResponseModel = sSLCSdkMainResponseModel = new SSLCSdkMainResponseModel();
            this.SSLCSdkMainResponseModel = sSLCSdkMainResponseModel.fromJSON(bundle2.getString("main_response"));
        }
        this.SSLCOfferModel = (SSLCOfferModel)new Gson().fromJson(this.getIntent().getExtras().getString("offer_model"), SSLCOfferModel.class);
        LocalBroadcastManager.getInstance((Context)this).registerReceiver(this.mMessageReceiver, new IntentFilter("custom-event-name"));
    }

    public void onDestroy() {
        LocalBroadcastManager.getInstance((Context)this).unregisterReceiver(this.mMessageReceiver);
        AppCompatActivity.super.onDestroy();
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == 16908332) {
            this.finish();
            return true;
        }
        return Activity.super.onOptionsItemSelected(menuItem);
    }

    @Override
    public void viewRelatedTask() {
        this.recyclerView = (RecyclerView)this.findViewById(R.id.offersRecycler);
        this.setSupportActionBar((Toolbar)this.findViewById(R.id.toolbar));
        if (this.getSupportActionBar() != null) {
            this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            this.getSupportActionBar().setHomeButtonEnabled(true);
            this.getSupportActionBar().setTitle((CharSequence)"Offers");
        }
        this.getData();
    }
}

