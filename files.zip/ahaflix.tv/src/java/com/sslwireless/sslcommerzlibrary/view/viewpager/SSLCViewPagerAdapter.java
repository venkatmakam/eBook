/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.fragment.app.Fragment
 *  androidx.fragment.app.FragmentManager
 *  androidx.fragment.app.FragmentPagerAdapter
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 */
package com.sslwireless.sslcommerzlibrary.view.viewpager;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import java.util.ArrayList;
import java.util.List;

public class SSLCViewPagerAdapter
extends FragmentPagerAdapter {
    private final List<Fragment> mFragmentList = new ArrayList();
    private final List<String> mFragmentTitleList = new ArrayList();

    public SSLCViewPagerAdapter(FragmentManager fragmentManager) {
        super(fragmentManager);
    }

    public void addFrag(Fragment fragment, String string) {
        this.mFragmentList.add((Object)fragment);
        this.mFragmentTitleList.add((Object)string);
    }

    public int getCount() {
        return this.mFragmentList.size();
    }

    public Fragment getItem(int n) {
        return (Fragment)this.mFragmentList.get(n);
    }

    public CharSequence getPageTitle(int n) {
        return (CharSequence)this.mFragmentTitleList.get(n);
    }

    public void removeFrag(int n) {
        this.mFragmentList.remove(n);
    }
}

