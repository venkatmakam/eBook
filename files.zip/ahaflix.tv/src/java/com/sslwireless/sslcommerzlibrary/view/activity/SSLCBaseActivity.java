/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.ProgressDialog
 *  android.content.ClipData
 *  android.content.ClipboardManager
 *  android.content.Context
 *  android.content.Intent
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.content.pm.PackageInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.content.res.Resources
 *  android.os.Bundle
 *  android.os.IBinder
 *  android.preference.PreferenceManager
 *  android.text.TextUtils
 *  android.util.DisplayMetrics
 *  android.view.Display
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.WindowManager
 *  android.view.inputmethod.InputMethodManager
 *  android.widget.TextView
 *  android.widget.Toast
 *  androidx.activity.ComponentActivity
 *  androidx.annotation.Nullable
 *  androidx.appcompat.app.AppCompatActivity
 *  com.sslwireless.sslcommerzlibrary.R
 *  com.sslwireless.sslcommerzlibrary.R$id
 *  com.sslwireless.sslcommerzlibrary.R$layout
 *  com.sslwireless.sslcommerzlibrary.R$style
 *  com.sslwireless.sslcommerzlibrary.model.util.SSLCShareInfo
 *  com.sslwireless.sslcommerzlibrary.viewmodel.listener.SSLCEditTextUpdateListener
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.util.regex.Matcher
 *  java.util.regex.Pattern
 */
package com.sslwireless.sslcommerzlibrary.view.activity;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.IBinder;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.ComponentActivity;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import com.sslwireless.sslcommerzlibrary.R;
import com.sslwireless.sslcommerzlibrary.model.util.SSLCShareInfo;
import com.sslwireless.sslcommerzlibrary.viewmodel.listener.SSLCEditTextUpdateListener;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public abstract class SSLCBaseActivity
extends AppCompatActivity {
    public SSLCEditTextUpdateListener SSLCEditTextUpdateListener;
    private Context context;
    private ProgressDialog dialogs;
    public DisplayMetrics displayMetrics = new DisplayMetrics();

    public static boolean isEmailValid(String string) {
        return Pattern.compile((String)"^[\\w\\.-]+@([\\w\\-]+\\.)+[A-Z]{2,4}$", (int)2).matcher((CharSequence)string).matches();
    }

    public int getStatusBarHeight() {
        int n = this.getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (n > 0) {
            return this.getResources().getDimensionPixelSize(n);
        }
        return 0;
    }

    public String getUserType(Context context) {
        return PreferenceManager.getDefaultSharedPreferences((Context)context).getString("type", "");
    }

    public void hideKeyboard() {
        View view = this.getCurrentFocus();
        if (view != null) {
            ((InputMethodManager)this.getSystemService("input_method")).hideSoftInputFromWindow(view.getWindowToken(), 2);
        }
    }

    public void hideProgressDialog() {
        ProgressDialog progressDialog;
        if (!this.isFinishing() && (progressDialog = this.dialogs) != null && progressDialog.isShowing()) {
            this.dialogs.dismiss();
        }
    }

    public boolean isAppInstalled(String string) {
        PackageManager packageManager = this.getPackageManager();
        try {
            packageManager.getPackageInfo(string, 1);
            return true;
        }
        catch (PackageManager.NameNotFoundException nameNotFoundException) {
            return false;
        }
    }

    public void makeClipboard(String string, String string2) {
        ((ClipboardManager)this.getSystemService("clipboard")).setPrimaryClip(ClipData.newPlainText((CharSequence)string, (CharSequence)string2));
    }

    public void onBackPressed() {
        ComponentActivity.super.onBackPressed();
        SSLCShareInfo.goPreviousPage((Context)this);
    }

    public void onCreate(@Nullable Bundle bundle) {
        super.onCreate(bundle);
        this.getWindowManager().getDefaultDisplay().getMetrics(this.displayMetrics);
        this.context = this;
    }

    public void onPostCreate(@Nullable Bundle bundle) {
        super.onPostCreate(bundle);
        this.viewRelatedTask();
    }

    public void progressDialog(String string) {
        if (this.dialogs == null) {
            ProgressDialog progressDialog;
            this.dialogs = progressDialog = new ProgressDialog(this.context, R.style.alertDialogStyle);
            progressDialog.setProgress(0);
        }
        if (TextUtils.isEmpty((CharSequence)string)) {
            this.dialogs.setMessage((CharSequence)"");
        } else {
            this.dialogs.setMessage((CharSequence)string);
        }
        ProgressDialog progressDialog = this.dialogs;
        if (progressDialog != null && !progressDialog.isShowing()) {
            this.dialogs.setCancelable(false);
            this.dialogs.show();
        }
    }

    public void saveUserType(String string, Context context) {
        SharedPreferences.Editor editor = PreferenceManager.getDefaultSharedPreferences((Context)context).edit();
        editor.putString("type", string);
        editor.commit();
    }

    public void setEditClickListener(SSLCEditTextUpdateListener sSLCEditTextUpdateListener) {
        this.SSLCEditTextUpdateListener = sSLCEditTextUpdateListener;
    }

    public void showToast(Context context, String string) {
        Toast toast = new Toast(context);
        toast.setDuration(1);
        View view = ((LayoutInflater)context.getSystemService("layout_inflater")).inflate(R.layout.custom_toast_layout_sslc, null);
        ((TextView)view.findViewById(R.id.toastText)).setText((CharSequence)string);
        toast.setView(view);
        toast.show();
    }

    public void startActivity(Intent intent) {
        Activity.super.startActivity(intent);
        SSLCShareInfo.goNextPage((Context)this);
    }

    public abstract void viewRelatedTask();
}

