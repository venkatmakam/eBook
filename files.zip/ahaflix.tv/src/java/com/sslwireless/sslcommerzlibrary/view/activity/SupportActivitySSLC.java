/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.IntentFilter
 *  android.content.res.Resources
 *  android.os.Bundle
 *  android.view.MenuItem
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.LinearLayout
 *  androidx.annotation.Nullable
 *  androidx.appcompat.app.ActionBar
 *  androidx.appcompat.app.AppCompatActivity
 *  androidx.appcompat.widget.Toolbar
 *  androidx.localbroadcastmanager.content.LocalBroadcastManager
 *  com.sslwireless.sslcommerzlibrary.R
 *  com.sslwireless.sslcommerzlibrary.R$id
 *  com.sslwireless.sslcommerzlibrary.R$layout
 *  com.sslwireless.sslcommerzlibrary.R$string
 *  com.sslwireless.sslcommerzlibrary.view.activity.SupportActivitySSLC$1
 *  com.sslwireless.sslcommerzlibrary.view.activity.SupportActivitySSLC$2
 *  com.sslwireless.sslcommerzlibrary.view.activity.SupportActivitySSLC$3
 *  com.sslwireless.sslcommerzlibrary.view.activity.SupportActivitySSLC$4
 *  java.lang.CharSequence
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.sslwireless.sslcommerzlibrary.view.activity;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import com.sslwireless.sslcommerzlibrary.R;
import com.sslwireless.sslcommerzlibrary.view.activity.SSLCBaseActivity;
import com.sslwireless.sslcommerzlibrary.view.activity.SupportActivitySSLC;
import com.sslwireless.sslcommerzlibrary.view.custom.SSLCCustomTextView;

public class SupportActivitySSLC
extends SSLCBaseActivity {
    private LinearLayout clickCallSupport;
    private LinearLayout clickEmail;
    private LinearLayout clickMessenger;
    private Context context;
    private SSLCCustomTextView customerCareText;
    private String email;
    private String fbMessenger;
    private BroadcastReceiver mMessageReceiver = new 1(this);
    private String mobileNumber;

    public static /* synthetic */ String access$000(SupportActivitySSLC supportActivitySSLC) {
        return supportActivitySSLC.email;
    }

    public static /* synthetic */ String access$100(SupportActivitySSLC supportActivitySSLC) {
        return supportActivitySSLC.fbMessenger;
    }

    public static /* synthetic */ String access$200(SupportActivitySSLC supportActivitySSLC) {
        return supportActivitySSLC.mobileNumber;
    }

    @Override
    public void onCreate(@Nullable Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(R.layout.activity_ssl_support);
        this.context = this;
    }

    public void onDestroy() {
        LocalBroadcastManager.getInstance((Context)this).unregisterReceiver(this.mMessageReceiver);
        AppCompatActivity.super.onDestroy();
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == 16908332) {
            this.finish();
            return true;
        }
        return Activity.super.onOptionsItemSelected(menuItem);
    }

    @Override
    public void viewRelatedTask() {
        this.mobileNumber = this.getIntent().getStringExtra("mobileNumber");
        this.email = this.getIntent().getStringExtra("email");
        this.fbMessenger = this.getIntent().getStringExtra("fbMessenger");
        this.setSupportActionBar((Toolbar)this.findViewById(R.id.toolbar));
        if (this.getSupportActionBar() != null) {
            this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            this.getSupportActionBar().setHomeButtonEnabled(true);
            this.getSupportActionBar().setTitle((CharSequence)this.getResources().getString(R.string.support));
        }
        this.customerCareText = (SSLCCustomTextView)this.findViewById(R.id.customerCareText);
        this.clickMessenger = (LinearLayout)this.findViewById(R.id.clickMessenger);
        this.clickEmail = (LinearLayout)this.findViewById(R.id.clickEmail);
        this.clickCallSupport = (LinearLayout)this.findViewById(R.id.clickSupportCall);
        this.clickEmail.setOnClickListener((View.OnClickListener)new 2(this));
        SSLCCustomTextView sSLCCustomTextView = this.customerCareText;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.getResources().getString(R.string.custumer_care_text));
        stringBuilder.append(" ");
        stringBuilder.append(this.mobileNumber);
        sSLCCustomTextView.setText((CharSequence)stringBuilder.toString());
        this.clickMessenger.setOnClickListener((View.OnClickListener)new 3(this));
        this.clickCallSupport.setOnClickListener((View.OnClickListener)new 4(this));
        LocalBroadcastManager.getInstance((Context)this).registerReceiver(this.mMessageReceiver, new IntentFilter("custom-event-name"));
    }
}

