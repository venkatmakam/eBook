/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Dialog
 *  android.content.Context
 *  android.content.Intent
 *  android.content.res.ColorStateList
 *  android.content.res.Configuration
 *  android.content.res.Resources
 *  android.graphics.Color
 *  android.graphics.drawable.ColorDrawable
 *  android.graphics.drawable.Drawable
 *  android.graphics.drawable.StateListDrawable
 *  android.os.Bundle
 *  android.text.Editable
 *  android.text.TextWatcher
 *  android.util.DisplayMetrics
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.View$OnKeyListener
 *  android.view.ViewGroup
 *  android.view.Window
 *  android.widget.Button
 *  android.widget.CheckBox
 *  android.widget.CompoundButton
 *  android.widget.CompoundButton$OnCheckedChangeListener
 *  android.widget.EditText
 *  android.widget.ImageView
 *  android.widget.LinearLayout
 *  android.widget.RelativeLayout
 *  androidx.annotation.Nullable
 *  androidx.fragment.app.Fragment
 *  androidx.fragment.app.FragmentActivity
 *  androidx.recyclerview.widget.LinearLayoutManager
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.recyclerview.widget.RecyclerView$LayoutManager
 *  com.google.gson.Gson
 *  com.sslwireless.sslcommerzlibrary.R
 *  com.sslwireless.sslcommerzlibrary.R$color
 *  com.sslwireless.sslcommerzlibrary.R$drawable
 *  com.sslwireless.sslcommerzlibrary.R$id
 *  com.sslwireless.sslcommerzlibrary.R$layout
 *  com.sslwireless.sslcommerzlibrary.R$string
 *  com.sslwireless.sslcommerzlibrary.R$style
 *  com.sslwireless.sslcommerzlibrary.model.initializer.SSLCommerzInitialization
 *  com.sslwireless.sslcommerzlibrary.model.response.SSLCEMIModel
 *  com.sslwireless.sslcommerzlibrary.model.response.SSLCEMIModel$Data
 *  com.sslwireless.sslcommerzlibrary.model.response.SSLCEMIModel$Emi
 *  com.sslwireless.sslcommerzlibrary.model.response.SSLCEMIModel$EmiBankTenureDesc
 *  com.sslwireless.sslcommerzlibrary.model.response.SSLCOfferModel
 *  com.sslwireless.sslcommerzlibrary.model.response.SSLCSdkMainResponseModel
 *  com.sslwireless.sslcommerzlibrary.model.response.SSLCSdkMainResponseModel$Desc
 *  com.sslwireless.sslcommerzlibrary.model.response.SSLCSdkMainResponseModel$Gw
 *  com.sslwireless.sslcommerzlibrary.model.response.SSLCVerifyOtpAndLoginModel
 *  com.sslwireless.sslcommerzlibrary.model.response.SSLCVerifyOtpAndLoginModel$CardNo
 *  com.sslwireless.sslcommerzlibrary.model.util.SSLCChangeCursorColor
 *  com.sslwireless.sslcommerzlibrary.model.util.SSLCCreditCardUtils
 *  com.sslwireless.sslcommerzlibrary.model.util.SSLCEnums
 *  com.sslwireless.sslcommerzlibrary.model.util.SSLCEnums$CardType
 *  com.sslwireless.sslcommerzlibrary.model.util.SSLCPrefUtils
 *  com.sslwireless.sslcommerzlibrary.model.util.SSLCProgressBarHandler
 *  com.sslwireless.sslcommerzlibrary.model.util.SSLCShareInfo
 *  com.sslwireless.sslcommerzlibrary.view.activity.MainUIActivitySSLC
 *  com.sslwireless.sslcommerzlibrary.view.activity.WebViewActivitySSLC
 *  com.sslwireless.sslcommerzlibrary.view.adapter.SSLCOtherCardsAdapter
 *  com.sslwireless.sslcommerzlibrary.view.adapter.SSLCSaveCardsAdapter
 *  com.sslwireless.sslcommerzlibrary.view.adapter.SSLCSaveCardsAdapter$ClickListener
 *  com.sslwireless.sslcommerzlibrary.view.adapter.SSLCSaveCardsAdapter$DeleteListener
 *  com.sslwireless.sslcommerzlibrary.view.adapter.SSLCSaveCardsAdapter$EmiSelectListener
 *  com.sslwireless.sslcommerzlibrary.view.custom.SSLCCustomTextWatcher
 *  com.sslwireless.sslcommerzlibrary.view.fragment.SSLCCardFragment$1
 *  com.sslwireless.sslcommerzlibrary.view.fragment.SSLCCardFragment$10
 *  com.sslwireless.sslcommerzlibrary.view.fragment.SSLCCardFragment$11
 *  com.sslwireless.sslcommerzlibrary.view.fragment.SSLCCardFragment$12
 *  com.sslwireless.sslcommerzlibrary.view.fragment.SSLCCardFragment$13
 *  com.sslwireless.sslcommerzlibrary.view.fragment.SSLCCardFragment$14
 *  com.sslwireless.sslcommerzlibrary.view.fragment.SSLCCardFragment$15
 *  com.sslwireless.sslcommerzlibrary.view.fragment.SSLCCardFragment$16
 *  com.sslwireless.sslcommerzlibrary.view.fragment.SSLCCardFragment$17
 *  com.sslwireless.sslcommerzlibrary.view.fragment.SSLCCardFragment$18
 *  com.sslwireless.sslcommerzlibrary.view.fragment.SSLCCardFragment$19
 *  com.sslwireless.sslcommerzlibrary.view.fragment.SSLCCardFragment$2
 *  com.sslwireless.sslcommerzlibrary.view.fragment.SSLCCardFragment$20
 *  com.sslwireless.sslcommerzlibrary.view.fragment.SSLCCardFragment$21
 *  com.sslwireless.sslcommerzlibrary.view.fragment.SSLCCardFragment$22
 *  com.sslwireless.sslcommerzlibrary.view.fragment.SSLCCardFragment$23
 *  com.sslwireless.sslcommerzlibrary.view.fragment.SSLCCardFragment$24
 *  com.sslwireless.sslcommerzlibrary.view.fragment.SSLCCardFragment$25
 *  com.sslwireless.sslcommerzlibrary.view.fragment.SSLCCardFragment$26
 *  com.sslwireless.sslcommerzlibrary.view.fragment.SSLCCardFragment$27
 *  com.sslwireless.sslcommerzlibrary.view.fragment.SSLCCardFragment$28
 *  com.sslwireless.sslcommerzlibrary.view.fragment.SSLCCardFragment$29
 *  com.sslwireless.sslcommerzlibrary.view.fragment.SSLCCardFragment$3
 *  com.sslwireless.sslcommerzlibrary.view.fragment.SSLCCardFragment$30
 *  com.sslwireless.sslcommerzlibrary.view.fragment.SSLCCardFragment$31
 *  com.sslwireless.sslcommerzlibrary.view.fragment.SSLCCardFragment$32
 *  com.sslwireless.sslcommerzlibrary.view.fragment.SSLCCardFragment$33
 *  com.sslwireless.sslcommerzlibrary.view.fragment.SSLCCardFragment$34
 *  com.sslwireless.sslcommerzlibrary.view.fragment.SSLCCardFragment$35
 *  com.sslwireless.sslcommerzlibrary.view.fragment.SSLCCardFragment$36
 *  com.sslwireless.sslcommerzlibrary.view.fragment.SSLCCardFragment$37
 *  com.sslwireless.sslcommerzlibrary.view.fragment.SSLCCardFragment$38
 *  com.sslwireless.sslcommerzlibrary.view.fragment.SSLCCardFragment$39
 *  com.sslwireless.sslcommerzlibrary.view.fragment.SSLCCardFragment$4
 *  com.sslwireless.sslcommerzlibrary.view.fragment.SSLCCardFragment$40
 *  com.sslwireless.sslcommerzlibrary.view.fragment.SSLCCardFragment$41
 *  com.sslwireless.sslcommerzlibrary.view.fragment.SSLCCardFragment$42
 *  com.sslwireless.sslcommerzlibrary.view.fragment.SSLCCardFragment$43
 *  com.sslwireless.sslcommerzlibrary.view.fragment.SSLCCardFragment$44
 *  com.sslwireless.sslcommerzlibrary.view.fragment.SSLCCardFragment$5
 *  com.sslwireless.sslcommerzlibrary.view.fragment.SSLCCardFragment$6
 *  com.sslwireless.sslcommerzlibrary.view.fragment.SSLCCardFragment$7
 *  com.sslwireless.sslcommerzlibrary.view.fragment.SSLCCardFragment$8
 *  com.sslwireless.sslcommerzlibrary.view.fragment.SSLCCardFragment$9
 *  com.sslwireless.sslcommerzlibrary.viewmodel.SSLCPayWithCardInfoViewModel
 *  com.sslwireless.sslcommerzlibrary.viewmodel.SSLCPayWithStoredCardViewModel
 *  com.sslwireless.sslcommerzlibrary.viewmodel.SSLCVerifyLoginSessionViewModel
 *  com.sslwireless.sslcommerzlibrary.viewmodel.SSLCVerifyOtpAndLoginViewModel
 *  com.sslwireless.sslcommerzlibrary.viewmodel.listener.SSLCEditTextUpdateListener
 *  com.sslwireless.sslcommerzlibrary.viewmodel.listener.SSLCOfferToMainUIListener
 *  com.sslwireless.sslcommerzlibrary.viewmodel.listener.SSLCOnBtnPayActiveListener
 *  com.sslwireless.sslcommerzlibrary.viewmodel.listener.SSLCOnLogOutListener
 *  com.sslwireless.sslcommerzlibrary.viewmodel.listener.SSLCOnOfferSelectListener
 *  com.sslwireless.sslcommerzlibrary.viewmodel.listener.SSLCOnUserVerifyListener
 *  com.sslwireless.sslcommerzlibrary.viewmodel.listener.SSLCPayNowListener
 *  com.sslwireless.sslcommerzlibrary.viewmodel.listener.SSLCPayWithCardInfoListener
 *  com.sslwireless.sslcommerzlibrary.viewmodel.listener.SSLCPayWithStoredCardListener
 *  com.sslwireless.sslcommerzlibrary.viewmodel.listener.SSLCVerifyLoginSessionListener
 *  com.sslwireless.sslcommerzlibrary.viewmodel.listener.SSLCVerifyOtpAndLoginListener
 *  e.a.a.a.a
 *  java.io.Serializable
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Locale
 */
package com.sslwireless.sslcommerzlibrary.view.fragment;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.gson.Gson;
import com.sslwireless.sslcommerzlibrary.R;
import com.sslwireless.sslcommerzlibrary.model.initializer.SSLCommerzInitialization;
import com.sslwireless.sslcommerzlibrary.model.response.SSLCEMIModel;
import com.sslwireless.sslcommerzlibrary.model.response.SSLCOfferModel;
import com.sslwireless.sslcommerzlibrary.model.response.SSLCSdkMainResponseModel;
import com.sslwireless.sslcommerzlibrary.model.response.SSLCVerifyOtpAndLoginModel;
import com.sslwireless.sslcommerzlibrary.model.util.SSLCChangeCursorColor;
import com.sslwireless.sslcommerzlibrary.model.util.SSLCCreditCardUtils;
import com.sslwireless.sslcommerzlibrary.model.util.SSLCEnums;
import com.sslwireless.sslcommerzlibrary.model.util.SSLCPrefUtils;
import com.sslwireless.sslcommerzlibrary.model.util.SSLCProgressBarHandler;
import com.sslwireless.sslcommerzlibrary.model.util.SSLCShareInfo;
import com.sslwireless.sslcommerzlibrary.view.activity.MainUIActivitySSLC;
import com.sslwireless.sslcommerzlibrary.view.activity.WebViewActivitySSLC;
import com.sslwireless.sslcommerzlibrary.view.adapter.SSLCOtherCardsAdapter;
import com.sslwireless.sslcommerzlibrary.view.adapter.SSLCSaveCardsAdapter;
import com.sslwireless.sslcommerzlibrary.view.custom.SSLCCustomEdittext;
import com.sslwireless.sslcommerzlibrary.view.custom.SSLCCustomTextView;
import com.sslwireless.sslcommerzlibrary.view.custom.SSLCCustomTextWatcher;
import com.sslwireless.sslcommerzlibrary.view.fragment.SSLCCardFragment;
import com.sslwireless.sslcommerzlibrary.viewmodel.SSLCPayWithCardInfoViewModel;
import com.sslwireless.sslcommerzlibrary.viewmodel.SSLCPayWithStoredCardViewModel;
import com.sslwireless.sslcommerzlibrary.viewmodel.SSLCVerifyLoginSessionViewModel;
import com.sslwireless.sslcommerzlibrary.viewmodel.SSLCVerifyOtpAndLoginViewModel;
import com.sslwireless.sslcommerzlibrary.viewmodel.listener.SSLCEditTextUpdateListener;
import com.sslwireless.sslcommerzlibrary.viewmodel.listener.SSLCOfferToMainUIListener;
import com.sslwireless.sslcommerzlibrary.viewmodel.listener.SSLCOnBtnPayActiveListener;
import com.sslwireless.sslcommerzlibrary.viewmodel.listener.SSLCOnLogOutListener;
import com.sslwireless.sslcommerzlibrary.viewmodel.listener.SSLCOnOfferSelectListener;
import com.sslwireless.sslcommerzlibrary.viewmodel.listener.SSLCOnUserVerifyListener;
import com.sslwireless.sslcommerzlibrary.viewmodel.listener.SSLCPayNowListener;
import com.sslwireless.sslcommerzlibrary.viewmodel.listener.SSLCPayWithCardInfoListener;
import com.sslwireless.sslcommerzlibrary.viewmodel.listener.SSLCPayWithStoredCardListener;
import com.sslwireless.sslcommerzlibrary.viewmodel.listener.SSLCVerifyLoginSessionListener;
import com.sslwireless.sslcommerzlibrary.viewmodel.listener.SSLCVerifyOtpAndLoginListener;
import e.a.a.a.a;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

public class SSLCCardFragment
extends Fragment {
    private static SSLCEditTextUpdateListener mSSLCEditTextUpdateListener;
    private static SSLCOfferToMainUIListener mSSLCOfferToMainUIListener;
    private static SSLCommerzInitialization mobileSslCommerzInitialization;
    public SSLCCustomTextWatcher SSLCCustomTextWatcher;
    private SSLCEMIModel SSLCEMIModel;
    private SSLCOfferModel SSLCOfferModel;
    private SSLCOnBtnPayActiveListener SSLCOnBtnPayActiveListener;
    private SSLCOnLogOutListener SSLCOnLogOutListener;
    private SSLCOnUserVerifyListener SSLCOnUserVerifyListener;
    public SSLCOtherCardsAdapter SSLCOtherCardsAdapter;
    private SSLCProgressBarHandler SSLCProgressBarHandler;
    public SSLCSaveCardsAdapter SSLCSaveCardsAdapter;
    private SSLCSdkMainResponseModel SSLCSdkMainResponseModel;
    private boolean backPressed = false;
    private Button btnCardMobileVerify;
    private Button btnMobileVerify;
    private Context context;
    private Dialog dialog;
    private String emiBankId = "0";
    private SSLCCustomEdittext etCardCVC;
    private SSLCCustomEdittext etCardExpireDate;
    private SSLCCustomEdittext etCardMobileNumber;
    private SSLCCustomEdittext etCardName;
    private SSLCCustomEdittext etCardNumber;
    private SSLCCustomEdittext etMobileNumber;
    private EditText etSavedCVV;
    private boolean isFromCardInfoRemember = false;
    private ImageView ivCardAmex;
    private ImageView ivCardMaster;
    private ImageView ivCardVisa;
    private ImageView ivEMIInfo;
    private ImageView ivMoreInfo;
    private ImageView ivOfferCancel;
    private ImageView ivOtpCardType;
    private LinearLayout layoutCardField;
    private LinearLayout layoutCardInfo;
    public LinearLayout layoutCardLogin;
    public LinearLayout layoutEMI;
    private LinearLayout layoutEMIInfo;
    private LinearLayout layoutLogin;
    private LinearLayout layoutMobileOTP;
    private RelativeLayout layoutOTP;
    public LinearLayout layoutOffer;
    private LinearLayout layoutOtherCards;
    private LinearLayout layoutOtpExistingCard;
    public LinearLayout layoutSaveCards;
    public LinearLayout layoutSavedCVV;
    public boolean motoEnable = false;
    private String offerId = "0";
    private SSLCCustomEdittext pin1;
    private SSLCCustomEdittext pin2;
    private SSLCCustomEdittext pin3;
    private SSLCCustomEdittext pin4;
    private SSLCCustomEdittext pin5;
    private SSLCCustomEdittext pin6;
    private CheckBox rememberMeCv;
    private RecyclerView rvOtherCards;
    private RecyclerView rvSaveCards;
    private String savedCardEmiTenure = "0";
    private String savedCardIndex = "0";
    private String selectedCardType = "";
    private List<String> tenures;
    private SSLCCustomTextView tvAlreadyRegistered;
    private SSLCCustomTextView tvAvailEmi;
    private SSLCCustomTextView tvCardOfferTitle;
    private SSLCCustomTextView tvChangeNumber;
    private SSLCCustomTextView tvChangeNumberOtp;
    private SSLCCustomTextView tvCustomerName;
    private SSLCCustomTextView tvMyCards;
    private SSLCCustomTextView tvOtherCards;
    private SSLCCustomTextView tvOtpCardNumber;
    private SSLCCustomTextView tvOtpChangeCard;
    private SSLCCustomTextView tvOtpHasEmi;
    private SSLCCustomTextView tvOtpHeader;
    private SSLCCustomTextView tvRegistered;
    private SSLCCustomTextView tvResendOTP;
    private SSLCCustomTextView tvSkipLogin;
    private SSLCCustomTextView tvTermCondition;
    private SSLCCustomTextView tvWelcome;
    private View view1;

    public static /* synthetic */ SSLCProgressBarHandler access$000(SSLCCardFragment sSLCCardFragment) {
        return sSLCCardFragment.SSLCProgressBarHandler;
    }

    public static /* synthetic */ SSLCSdkMainResponseModel access$100(SSLCCardFragment sSLCCardFragment) {
        return sSLCCardFragment.SSLCSdkMainResponseModel;
    }

    public static /* synthetic */ void access$1000(SSLCCardFragment sSLCCardFragment, List list) {
        sSLCCardFragment.setRvSaveCards((List<SSLCVerifyOtpAndLoginModel.CardNo>)list);
    }

    public static /* synthetic */ RelativeLayout access$1100(SSLCCardFragment sSLCCardFragment) {
        return sSLCCardFragment.layoutOTP;
    }

    public static /* synthetic */ void access$1200(SSLCCardFragment sSLCCardFragment) {
        sSLCCardFragment.funPay();
    }

    public static /* synthetic */ LinearLayout access$1300(SSLCCardFragment sSLCCardFragment) {
        return sSLCCardFragment.layoutLogin;
    }

    public static /* synthetic */ CheckBox access$1400(SSLCCardFragment sSLCCardFragment) {
        return sSLCCardFragment.rememberMeCv;
    }

    public static /* synthetic */ SSLCCustomTextView access$1500(SSLCCardFragment sSLCCardFragment) {
        return sSLCCardFragment.tvMyCards;
    }

    public static /* synthetic */ String access$1602(SSLCCardFragment sSLCCardFragment, String string) {
        sSLCCardFragment.offerId = string;
        return string;
    }

    public static /* synthetic */ SSLCCustomEdittext access$1700(SSLCCardFragment sSLCCardFragment) {
        return sSLCCardFragment.etCardNumber;
    }

    public static /* synthetic */ SSLCCustomEdittext access$1800(SSLCCardFragment sSLCCardFragment) {
        return sSLCCardFragment.etCardCVC;
    }

    public static /* synthetic */ SSLCCustomEdittext access$1900(SSLCCardFragment sSLCCardFragment) {
        return sSLCCardFragment.etCardExpireDate;
    }

    public static /* synthetic */ SSLCCustomEdittext access$200(SSLCCardFragment sSLCCardFragment) {
        return sSLCCardFragment.etMobileNumber;
    }

    public static /* synthetic */ SSLCCustomEdittext access$2000(SSLCCardFragment sSLCCardFragment) {
        return sSLCCardFragment.etCardName;
    }

    public static /* synthetic */ SSLCCustomTextView access$2100(SSLCCardFragment sSLCCardFragment) {
        return sSLCCardFragment.tvCardOfferTitle;
    }

    public static /* synthetic */ LinearLayout access$2200(SSLCCardFragment sSLCCardFragment) {
        return sSLCCardFragment.layoutOtherCards;
    }

    public static /* synthetic */ LinearLayout access$2300(SSLCCardFragment sSLCCardFragment) {
        return sSLCCardFragment.layoutCardField;
    }

    public static /* synthetic */ void access$2400(SSLCCardFragment sSLCCardFragment) {
        sSLCCardFragment.funCheckCardField();
    }

    public static /* synthetic */ void access$2500(SSLCCardFragment sSLCCardFragment, String string) {
        sSLCCardFragment.funSetCardType(string);
    }

    public static /* synthetic */ List access$2600(SSLCCardFragment sSLCCardFragment) {
        return sSLCCardFragment.tenures;
    }

    public static /* synthetic */ List access$2602(SSLCCardFragment sSLCCardFragment, List list) {
        sSLCCardFragment.tenures = list;
        return list;
    }

    public static /* synthetic */ SSLCOfferModel access$2700(SSLCCardFragment sSLCCardFragment) {
        return sSLCCardFragment.SSLCOfferModel;
    }

    public static /* synthetic */ SSLCCustomTextView access$2800(SSLCCardFragment sSLCCardFragment) {
        return sSLCCardFragment.tvAvailEmi;
    }

    public static /* synthetic */ String access$2900(SSLCCardFragment sSLCCardFragment) {
        return sSLCCardFragment.selectedCardType;
    }

    public static /* synthetic */ SSLCCustomTextView access$300(SSLCCardFragment sSLCCardFragment) {
        return sSLCCardFragment.tvCustomerName;
    }

    public static /* synthetic */ SSLCCustomEdittext access$3000(SSLCCardFragment sSLCCardFragment) {
        return sSLCCardFragment.etCardMobileNumber;
    }

    public static /* synthetic */ Button access$3100(SSLCCardFragment sSLCCardFragment) {
        return sSLCCardFragment.btnCardMobileVerify;
    }

    public static /* synthetic */ SSLCCustomEdittext access$3200(SSLCCardFragment sSLCCardFragment) {
        return sSLCCardFragment.pin1;
    }

    public static /* synthetic */ SSLCCustomEdittext access$3300(SSLCCardFragment sSLCCardFragment) {
        return sSLCCardFragment.pin2;
    }

    public static /* synthetic */ SSLCCustomEdittext access$3400(SSLCCardFragment sSLCCardFragment) {
        return sSLCCardFragment.pin3;
    }

    public static /* synthetic */ SSLCCustomEdittext access$3500(SSLCCardFragment sSLCCardFragment) {
        return sSLCCardFragment.pin4;
    }

    public static /* synthetic */ SSLCCustomEdittext access$3600(SSLCCardFragment sSLCCardFragment) {
        return sSLCCardFragment.pin5;
    }

    public static /* synthetic */ SSLCCustomEdittext access$3700(SSLCCardFragment sSLCCardFragment) {
        return sSLCCardFragment.pin6;
    }

    public static /* synthetic */ SSLCCustomTextView access$3800(SSLCCardFragment sSLCCardFragment) {
        return sSLCCardFragment.tvResendOTP;
    }

    public static /* synthetic */ SSLCCustomTextView access$3900(SSLCCardFragment sSLCCardFragment) {
        return sSLCCardFragment.tvChangeNumberOtp;
    }

    public static /* synthetic */ Button access$400(SSLCCardFragment sSLCCardFragment) {
        return sSLCCardFragment.btnMobileVerify;
    }

    public static /* synthetic */ SSLCCustomTextView access$4000(SSLCCardFragment sSLCCardFragment) {
        return sSLCCardFragment.tvOtpChangeCard;
    }

    public static /* synthetic */ LinearLayout access$4100(SSLCCardFragment sSLCCardFragment) {
        return sSLCCardFragment.layoutOtpExistingCard;
    }

    public static /* synthetic */ SSLCCustomTextView access$4200(SSLCCardFragment sSLCCardFragment) {
        return sSLCCardFragment.tvOtpCardNumber;
    }

    public static /* synthetic */ SSLCCustomTextView access$4300(SSLCCardFragment sSLCCardFragment) {
        return sSLCCardFragment.tvOtpHasEmi;
    }

    public static /* synthetic */ ImageView access$4400(SSLCCardFragment sSLCCardFragment) {
        return sSLCCardFragment.ivOtpCardType;
    }

    public static /* synthetic */ ImageView access$4500(SSLCCardFragment sSLCCardFragment) {
        return sSLCCardFragment.ivMoreInfo;
    }

    public static /* synthetic */ View access$4600(SSLCCardFragment sSLCCardFragment) {
        return sSLCCardFragment.view1;
    }

    public static /* synthetic */ SSLCOnBtnPayActiveListener access$4700(SSLCCardFragment sSLCCardFragment) {
        return sSLCCardFragment.SSLCOnBtnPayActiveListener;
    }

    public static /* synthetic */ SSLCCustomTextView access$4800(SSLCCardFragment sSLCCardFragment) {
        return sSLCCardFragment.tvChangeNumber;
    }

    public static /* synthetic */ RecyclerView access$4900(SSLCCardFragment sSLCCardFragment) {
        return sSLCCardFragment.rvOtherCards;
    }

    public static /* synthetic */ SSLCCustomTextView access$500(SSLCCardFragment sSLCCardFragment) {
        return sSLCCardFragment.tvWelcome;
    }

    public static /* synthetic */ SSLCEMIModel access$5000(SSLCCardFragment sSLCCardFragment) {
        return sSLCCardFragment.SSLCEMIModel;
    }

    public static /* synthetic */ SSLCommerzInitialization access$5100() {
        return mobileSslCommerzInitialization;
    }

    public static /* synthetic */ Dialog access$5200(SSLCCardFragment sSLCCardFragment) {
        return sSLCCardFragment.dialog;
    }

    public static /* synthetic */ String access$5302(SSLCCardFragment sSLCCardFragment, String string) {
        sSLCCardFragment.savedCardEmiTenure = string;
        return string;
    }

    public static /* synthetic */ String access$5400(SSLCCardFragment sSLCCardFragment) {
        return sSLCCardFragment.savedCardIndex;
    }

    public static /* synthetic */ String access$5402(SSLCCardFragment sSLCCardFragment, String string) {
        sSLCCardFragment.savedCardIndex = string;
        return string;
    }

    public static /* synthetic */ EditText access$5500(SSLCCardFragment sSLCCardFragment) {
        return sSLCCardFragment.etSavedCVV;
    }

    public static /* synthetic */ EditText access$5502(SSLCCardFragment sSLCCardFragment, EditText editText) {
        sSLCCardFragment.etSavedCVV = editText;
        return editText;
    }

    public static /* synthetic */ void access$5600(SSLCCardFragment sSLCCardFragment, boolean bl) {
        sSLCCardFragment.funOtpVerify(bl);
    }

    public static /* synthetic */ LinearLayout access$600(SSLCCardFragment sSLCCardFragment) {
        return sSLCCardFragment.layoutCardInfo;
    }

    public static /* synthetic */ LinearLayout access$700(SSLCCardFragment sSLCCardFragment) {
        return sSLCCardFragment.layoutMobileOTP;
    }

    public static /* synthetic */ SSLCOnUserVerifyListener access$800(SSLCCardFragment sSLCCardFragment) {
        return sSLCCardFragment.SSLCOnUserVerifyListener;
    }

    public static /* synthetic */ Context access$900(SSLCCardFragment sSLCCardFragment) {
        return sSLCCardFragment.context;
    }

    private void funCheckCardField() {
        Boolean bl = Boolean.FALSE;
        if (!(this.etCardNumber.getText().toString().isEmpty() || this.etCardExpireDate.getText().toString().isEmpty() || this.etCardCVC.getText().toString().isEmpty() || this.etCardName.getText().toString().isEmpty())) {
            String string;
            SSLCEnums.CardType cardType;
            if (this.etCardExpireDate.getText().length() == 5 && SSLCShareInfo.getInstance().validateCardExpiryDate(this.etCardExpireDate.getText().toString()) && SSLCCreditCardUtils.getInstance().isValid(this.etCardNumber.getText().toString()) && ((string = this.selectedCardType.toLowerCase()).contains((CharSequence)(cardType = SSLCEnums.CardType.Amex).name().toLowerCase()) && this.etCardCVC.length() >= 4 || !this.selectedCardType.toLowerCase().contains((CharSequence)cardType.name().toLowerCase()) || this.etCardCVC.length() < 3)) {
                this.rememberMeCv.setEnabled(true);
                CheckBox checkBox = this.rememberMeCv;
                StringBuilder stringBuilder = a.F1((String)"#");
                stringBuilder.append(this.SSLCSdkMainResponseModel.getPrimaryColor());
                checkBox.setButtonTintList(ColorStateList.valueOf((int)Color.parseColor((String)stringBuilder.toString())));
                this.rememberMeCv.setChecked(false);
                this.layoutCardLogin.setVisibility(8);
                this.SSLCOnBtnPayActiveListener.onBtnPayActive(Boolean.TRUE, this.etCardNumber.getText().toString());
                return;
            }
            this.rememberMeCv.setEnabled(false);
            this.rememberMeCv.setChecked(false);
            this.layoutCardLogin.setVisibility(8);
            this.SSLCOnBtnPayActiveListener.onBtnPayActive(bl, "");
            this.rememberMeCv.setButtonTintList(ColorStateList.valueOf((int)this.getResources().getColor(R.color.grey)));
            return;
        }
        this.rememberMeCv.setEnabled(false);
        this.rememberMeCv.setChecked(false);
        this.layoutCardLogin.setVisibility(8);
        this.SSLCOnBtnPayActiveListener.onBtnPayActive(bl, "");
        this.rememberMeCv.setButtonTintList(ColorStateList.valueOf((int)this.getResources().getColor(R.color.grey)));
    }

    private void funOtpVerify(boolean bl) {
        String string2 = this.rememberMeCv.isChecked() ? this.etCardMobileNumber.getText().toString() : this.etMobileNumber.getText().toString();
        String string3 = string2;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.pin1.getText().toString());
        stringBuilder.append(this.pin2.getText().toString());
        stringBuilder.append(this.pin3.getText().toString());
        stringBuilder.append(this.pin4.getText().toString());
        stringBuilder.append(this.pin5.getText().toString());
        stringBuilder.append(this.pin6.getText().toString());
        String string4 = stringBuilder.toString();
        if (string4.length() == 6) {
            this.SSLCProgressBarHandler.show();
            new SSLCVerifyOtpAndLoginViewModel((Context)this.getActivity()).verifyOtpAndLogin(string3, SSLCShareInfo.getInstance().getRegKey((Context)this.getActivity()), SSLCShareInfo.getInstance().getEncKey((Context)this.getActivity()), this.SSLCSdkMainResponseModel.getSessionkey(), string4, (SSLCVerifyOtpAndLoginListener)new 44(this));
            return;
        }
        if (bl) {
            SSLCShareInfo.getInstance().showToast((Context)this.getActivity(), this.getResources().getString(R.string.pin_length_must_be));
        }
    }

    private void funPay() {
        if (this.layoutOtherCards.getVisibility() == 0) {
            ArrayList arrayList = SSLCShareInfo.getInstance().getOtherCards(this.SSLCSdkMainResponseModel);
            Intent intent = new Intent(this.context, WebViewActivitySSLC.class);
            intent.putExtra("redirectUrl", ((SSLCSdkMainResponseModel.Desc)arrayList.get(this.SSLCOtherCardsAdapter.currentPosition)).getRedirectGatewayURL());
            intent.putExtra("merchantName", ((SSLCSdkMainResponseModel.Desc)arrayList.get(this.SSLCOtherCardsAdapter.currentPosition)).getName());
            intent.putExtra("session_key", this.SSLCSdkMainResponseModel.getSessionkey());
            intent.putExtra("timeOutValue", this.SSLCSdkMainResponseModel.getTimeoutinMin());
            intent.putExtra("sdkMainResponse", (Serializable)mobileSslCommerzInitialization);
            FragmentActivity fragmentActivity = this.getActivity();
            fragmentActivity.startActivityForResult(intent, 3);
            return;
        }
        if (this.layoutCardInfo.getVisibility() == 0) {
            String string2;
            String string3;
            String string4 = this.etCardNumber.getText().toString().replaceAll("\\s+", "");
            String string5 = this.etCardExpireDate.getText().toString();
            String string6 = this.etCardCVC.getText().toString();
            String string7 = this.etCardName.getText().toString();
            if (this.SSLCSdkMainResponseModel.getEmiStatus() == 1) {
                String string8 = SSLCShareInfo.getInstance().getDigitFromString(this.tvAvailEmi.getText().toString());
                boolean bl = string8.isEmpty();
                string2 = string8;
                string3 = !bl ? "1" : "0";
            } else {
                string2 = string3 = "0";
            }
            String string9 = !this.offerId.equalsIgnoreCase("0") ? "1" : "0";
            String string10 = this.rememberMeCv.isChecked() ? "1" : "0";
            if (string4.isEmpty()) {
                SSLCShareInfo.getInstance().showToast((Context)this.getActivity(), "enter card number");
                return;
            }
            if (!SSLCCreditCardUtils.getInstance().isValid(string4)) {
                SSLCShareInfo.getInstance().showToast((Context)this.getActivity(), this.getResources().getString(R.string.invalid_card));
                return;
            }
            if (string5.isEmpty()) {
                SSLCShareInfo.getInstance().showToast((Context)this.getActivity(), "enter expire date");
                return;
            }
            if (string6.isEmpty()) {
                SSLCShareInfo.getInstance().showToast((Context)this.getActivity(), "enter cvc");
                return;
            }
            if (string7.isEmpty()) {
                SSLCShareInfo.getInstance().showToast((Context)this.getActivity(), "enter card name");
                return;
            }
            this.SSLCProgressBarHandler.show();
            new SSLCPayWithCardInfoViewModel((Context)this.getActivity()).payWithCard(SSLCShareInfo.getInstance().getRegKey((Context)this.getActivity()), SSLCShareInfo.getInstance().getEncKey((Context)this.getActivity()), SSLCShareInfo.getInstance().getCustSession((Context)this.getActivity()), this.SSLCSdkMainResponseModel.getSessionkey(), string4, string5, string6, string7, string10, this.SSLCSdkMainResponseModel.getLoginTransSession(), string3, string2, this.emiBankId, this.offerId, string9, (SSLCPayWithCardInfoListener)new 42(this));
            return;
        }
        if (this.layoutSaveCards.getVisibility() == 0) {
            EditText editText;
            if (!this.motoEnable && ((editText = this.etSavedCVV) == null || editText.getText().toString().isEmpty())) {
                SSLCShareInfo.getInstance().showToast((Context)this.getActivity(), "Enter CVV");
                return;
            }
            String string11 = this.SSLCSdkMainResponseModel.getEmiStatus() == 1 && !this.savedCardEmiTenure.isEmpty() ? "1" : "0";
            String string12 = !this.offerId.equalsIgnoreCase("0") ? "1" : "0";
            this.SSLCProgressBarHandler.show();
            SSLCPayWithStoredCardViewModel sSLCPayWithStoredCardViewModel = new SSLCPayWithStoredCardViewModel((Context)this.getActivity());
            String string13 = SSLCShareInfo.getInstance().getRegKey((Context)this.getActivity());
            String string14 = SSLCShareInfo.getInstance().getEncKey((Context)this.getActivity());
            String string15 = SSLCShareInfo.getInstance().getCustSession((Context)this.getActivity());
            String string16 = this.SSLCSdkMainResponseModel.getSessionkey();
            String string17 = this.motoEnable ? "xxxx" : this.etSavedCVV.getText().toString();
            sSLCPayWithStoredCardViewModel.payWithStoredCard(string13, string14, string15, string16, string17, this.savedCardIndex, this.SSLCSdkMainResponseModel.getLoginTransSession(), string11, this.savedCardEmiTenure, this.emiBankId, this.offerId, string12, (SSLCPayWithStoredCardListener)new 43(this));
        }
    }

    private void funSetCardType(String string2) {
        boolean bl;
        ArrayList arrayList = SSLCCreditCardUtils.getInstance().cardTypeValidate();
        int n = 0;
        do {
            int n2 = arrayList.size();
            bl = false;
            if (n >= n2) break;
            if (string2.matches((String)arrayList.get(n))) {
                if (n == 0) {
                    this.selectedCardType = SSLCEnums.CardType.Visa.name().toLowerCase();
                    this.ivCardVisa.setImageDrawable(this.getActivity().getResources().getDrawable(R.drawable.ic_visa_new));
                    this.ivCardMaster.setImageDrawable(this.getActivity().getResources().getDrawable(R.drawable.ic_master_grey));
                    this.ivCardAmex.setImageDrawable(this.getActivity().getResources().getDrawable(R.drawable.ic_amex_grey));
                    SSLCShareInfo.getInstance().setEditTextMaxLength((EditText)this.etCardCVC, 3);
                } else if (n != 1 && n != 3) {
                    if (n == 2) {
                        this.selectedCardType = SSLCEnums.CardType.Amex.name().toLowerCase();
                        this.ivCardVisa.setImageDrawable(this.getActivity().getResources().getDrawable(R.drawable.ic_visa_grey));
                        this.ivCardMaster.setImageDrawable(this.getActivity().getResources().getDrawable(R.drawable.ic_master_grey));
                        this.ivCardAmex.setImageDrawable(this.getActivity().getResources().getDrawable(R.drawable.ic_amex_new));
                        SSLCShareInfo.getInstance().setEditTextMaxLength((EditText)this.etCardCVC, 4);
                    } else {
                        this.selectedCardType = "";
                        this.ivCardVisa.setImageDrawable(this.getActivity().getResources().getDrawable(R.drawable.ic_visa_new));
                        this.ivCardMaster.setImageDrawable(this.getActivity().getResources().getDrawable(R.drawable.ic_mastercard_new));
                        this.ivCardAmex.setImageDrawable(this.getActivity().getResources().getDrawable(R.drawable.ic_amex_new));
                        SSLCShareInfo.getInstance().setEditTextMaxLength((EditText)this.etCardCVC, 4);
                    }
                } else {
                    this.selectedCardType = SSLCEnums.CardType.Master.name().toLowerCase();
                    this.ivCardVisa.setImageDrawable(this.getActivity().getResources().getDrawable(R.drawable.ic_visa_grey));
                    this.ivCardMaster.setImageDrawable(this.getActivity().getResources().getDrawable(R.drawable.ic_mastercard_new));
                    this.ivCardAmex.setImageDrawable(this.getActivity().getResources().getDrawable(R.drawable.ic_amex_grey));
                    SSLCShareInfo.getInstance().setEditTextMaxLength((EditText)this.etCardCVC, 3);
                }
                bl = true;
                break;
            }
            ++n;
        } while (true);
        if (!bl) {
            this.selectedCardType = "";
            this.ivCardVisa.setImageDrawable(this.getActivity().getResources().getDrawable(R.drawable.ic_visa_new));
            this.ivCardMaster.setImageDrawable(this.getActivity().getResources().getDrawable(R.drawable.ic_mastercard_new));
            this.ivCardAmex.setImageDrawable(this.getActivity().getResources().getDrawable(R.drawable.ic_amex_new));
        }
    }

    private void initViews() {
        this.rememberMeCv = (CheckBox)this.getActivity().findViewById(R.id.remember_me_cv);
        this.layoutLogin = (LinearLayout)this.getActivity().findViewById(R.id.layout_login);
        this.layoutMobileOTP = (LinearLayout)this.getActivity().findViewById(R.id.layout_mobile_otp);
        this.layoutOtherCards = (LinearLayout)this.getActivity().findViewById(R.id.layout_other_cards);
        this.layoutCardInfo = (LinearLayout)this.getActivity().findViewById(R.id.layout_card_info);
        this.layoutCardField = (LinearLayout)this.getActivity().findViewById(R.id.layout_card_field);
        this.layoutOTP = (RelativeLayout)this.getActivity().findViewById(R.id.layout_otp);
        this.layoutEMIInfo = (LinearLayout)this.getActivity().findViewById(R.id.layout_emi_info);
        this.layoutOtpExistingCard = (LinearLayout)this.getActivity().findViewById(R.id.layout_otp_existing_card);
        this.tvOtpCardNumber = (SSLCCustomTextView)this.getActivity().findViewById(R.id.tv_otp_card_number);
        this.ivOtpCardType = (ImageView)this.getActivity().findViewById(R.id.iv_otp_card_type);
        this.tvOtpHasEmi = (SSLCCustomTextView)this.getActivity().findViewById(R.id.tv_otp_has_emi);
        this.layoutEMI = (LinearLayout)this.getActivity().findViewById(R.id.layout_emi);
        this.btnMobileVerify = (Button)this.getActivity().findViewById(R.id.btn_verify);
        this.btnCardMobileVerify = (Button)this.getActivity().findViewById(R.id.btn_card_mobile_verify);
        this.tvChangeNumber = (SSLCCustomTextView)this.getActivity().findViewById(R.id.tv_change_number);
        this.tvSkipLogin = (SSLCCustomTextView)this.getActivity().findViewById(R.id.tv_skip_login);
        this.etMobileNumber = (SSLCCustomEdittext)this.getActivity().findViewById(R.id.et_mobile_number_ssl);
        this.etCardMobileNumber = (SSLCCustomEdittext)this.getActivity().findViewById(R.id.et_card_mobile_number);
        this.tvCustomerName = (SSLCCustomTextView)this.getActivity().findViewById(R.id.tv_customer_name);
        this.tvResendOTP = (SSLCCustomTextView)this.getActivity().findViewById(R.id.tv_resend_otp);
        this.tvMyCards = (SSLCCustomTextView)this.getActivity().findViewById(R.id.tv_my_cards);
        this.tvWelcome = (SSLCCustomTextView)this.getActivity().findViewById(R.id.tv_welcome);
        this.tvAvailEmi = (SSLCCustomTextView)this.getActivity().findViewById(R.id.tv_avail_emi);
        this.tvTermCondition = (SSLCCustomTextView)this.getActivity().findViewById(R.id.tv_term_condition);
        this.etCardNumber = (SSLCCustomEdittext)this.getActivity().findViewById(R.id.et_card_number_ssl);
        this.tvAlreadyRegistered = (SSLCCustomTextView)this.getActivity().findViewById(R.id.tv_already_registered);
        this.tvRegistered = (SSLCCustomTextView)this.getActivity().findViewById(R.id.tv_registered);
        this.tvOtpHeader = (SSLCCustomTextView)this.getActivity().findViewById(R.id.tv_otp_header);
        this.ivMoreInfo = (ImageView)this.getActivity().findViewById(R.id.iv_more_info);
        this.tvOtpChangeCard = (SSLCCustomTextView)this.getActivity().findViewById(R.id.tv_otp_change_card);
        this.view1 = this.getActivity().findViewById(R.id.view1);
        this.etCardNumber.isInputTypeCard(true);
        this.etCardName = (SSLCCustomEdittext)this.getActivity().findViewById(R.id.et_card_holder_name_ssl);
        this.etCardExpireDate = (SSLCCustomEdittext)this.getActivity().findViewById(R.id.et_card_expiry_date);
        this.etCardCVC = (SSLCCustomEdittext)this.getActivity().findViewById(R.id.et_card_cvc_cvv);
        this.ivCardVisa = (ImageView)this.getActivity().findViewById(R.id.iv_card_visa);
        this.ivCardAmex = (ImageView)this.getActivity().findViewById(R.id.iv_card_amex);
        this.ivCardMaster = (ImageView)this.getActivity().findViewById(R.id.iv_card_master);
        if (this.SSLCSdkMainResponseModel.getGw().getVisa().equals((Object)"")) {
            this.ivCardVisa.setVisibility(8);
        }
        if (this.SSLCSdkMainResponseModel.getGw().getMaster().equals((Object)"")) {
            this.ivCardMaster.setVisibility(8);
        }
        if (this.SSLCSdkMainResponseModel.getGw().getAmex().equals((Object)"")) {
            this.ivCardAmex.setVisibility(8);
        }
        this.rvOtherCards = (RecyclerView)this.getActivity().findViewById(R.id.rv_other_cards);
        this.rvSaveCards = (RecyclerView)this.getActivity().findViewById(R.id.rv_save_cards);
        this.layoutSaveCards = (LinearLayout)this.getActivity().findViewById(R.id.layout_save_cards);
        this.layoutOffer = (LinearLayout)this.getActivity().findViewById(R.id.layout_card_offer);
        this.tvCardOfferTitle = (SSLCCustomTextView)this.getActivity().findViewById(R.id.tv_offer_title);
        this.layoutCardLogin = (LinearLayout)this.getActivity().findViewById(R.id.layout_card_login);
        this.ivEMIInfo = (ImageView)this.getActivity().findViewById(R.id.iv_emi_info);
        this.layoutSaveCards.setVisibility(8);
        this.layoutOffer.setVisibility(8);
        this.tvMyCards.setVisibility(8);
        this.rememberMeCv.setEnabled(false);
        this.tvOtherCards = (SSLCCustomTextView)this.getActivity().findViewById(R.id.tv_other_cards);
        if (this.SSLCSdkMainResponseModel.getGw().getOthercards().equals((Object)"")) {
            this.tvOtherCards.setVisibility(8);
        }
        this.pin1 = (SSLCCustomEdittext)this.getActivity().findViewById(R.id.pin1);
        this.pin2 = (SSLCCustomEdittext)this.getActivity().findViewById(R.id.pin2);
        this.pin3 = (SSLCCustomEdittext)this.getActivity().findViewById(R.id.pin3);
        this.pin4 = (SSLCCustomEdittext)this.getActivity().findViewById(R.id.pin4);
        this.pin5 = (SSLCCustomEdittext)this.getActivity().findViewById(R.id.pin5);
        this.pin6 = (SSLCCustomEdittext)this.getActivity().findViewById(R.id.pin6);
        this.tvChangeNumberOtp = (SSLCCustomTextView)this.getActivity().findViewById(R.id.tv_change_number_otp);
        SSLCCustomTextView sSLCCustomTextView = this.tvSkipLogin;
        StringBuilder stringBuilder = a.F1((String)"#");
        stringBuilder.append(this.SSLCSdkMainResponseModel.getPrimaryColor());
        sSLCCustomTextView.setTextColor(Color.parseColor((String)stringBuilder.toString()));
        SSLCCustomTextView sSLCCustomTextView2 = this.tvChangeNumber;
        StringBuilder stringBuilder2 = a.F1((String)"#");
        stringBuilder2.append(this.SSLCSdkMainResponseModel.getPrimaryColor());
        sSLCCustomTextView2.setTextColor(Color.parseColor((String)stringBuilder2.toString()));
        SSLCCustomTextView sSLCCustomTextView3 = this.tvChangeNumberOtp;
        Resources resources = this.getResources();
        int n = R.color.grey;
        sSLCCustomTextView3.setTextColor(resources.getColor(n));
        this.tvOtpChangeCard.setTextColor(this.getResources().getColor(n));
        SSLCCustomTextView sSLCCustomTextView4 = this.tvResendOTP;
        StringBuilder stringBuilder3 = a.F1((String)"#");
        stringBuilder3.append(this.SSLCSdkMainResponseModel.getPrimaryColor());
        sSLCCustomTextView4.setTextColor(Color.parseColor((String)stringBuilder3.toString()));
        SSLCCustomTextView sSLCCustomTextView5 = this.tvOtherCards;
        StringBuilder stringBuilder4 = a.F1((String)"#");
        stringBuilder4.append(this.SSLCSdkMainResponseModel.getPrimaryColor());
        sSLCCustomTextView5.setTextColor(Color.parseColor((String)stringBuilder4.toString()));
        SSLCCustomTextView sSLCCustomTextView6 = this.tvMyCards;
        StringBuilder stringBuilder5 = a.F1((String)"#");
        stringBuilder5.append(this.SSLCSdkMainResponseModel.getPrimaryColor());
        sSLCCustomTextView6.setTextColor(Color.parseColor((String)stringBuilder5.toString()));
        SSLCCustomTextView sSLCCustomTextView7 = (SSLCCustomTextView)this.getActivity().findViewById(R.id.tv_card_mobile_format);
        StringBuilder stringBuilder6 = a.F1((String)"#");
        stringBuilder6.append(this.SSLCSdkMainResponseModel.getPrimaryColor());
        sSLCCustomTextView7.setTextColor(Color.parseColor((String)stringBuilder6.toString()));
        LinearLayout linearLayout = this.layoutEMI;
        SSLCShareInfo sSLCShareInfo = SSLCShareInfo.getInstance();
        StringBuilder stringBuilder7 = a.F1((String)"#");
        stringBuilder7.append(this.SSLCSdkMainResponseModel.getActiveColor());
        int n2 = Color.parseColor((String)stringBuilder7.toString());
        StringBuilder stringBuilder8 = a.F1((String)"#");
        stringBuilder8.append(this.SSLCSdkMainResponseModel.getPrimaryColor());
        int n3 = Color.parseColor((String)stringBuilder8.toString());
        Resources resources2 = this.getResources();
        int n4 = R.color.very_light_grey;
        linearLayout.setBackground((Drawable)sSLCShareInfo.setBackgroundColor(n2, n3, resources2.getColor(n4)));
        Button button = this.btnMobileVerify;
        SSLCShareInfo sSLCShareInfo2 = SSLCShareInfo.getInstance();
        StringBuilder stringBuilder9 = a.F1((String)"#");
        stringBuilder9.append(this.SSLCSdkMainResponseModel.getActiveColor());
        int n5 = Color.parseColor((String)stringBuilder9.toString());
        StringBuilder stringBuilder10 = a.F1((String)"#");
        stringBuilder10.append(this.SSLCSdkMainResponseModel.getPrimaryColor());
        button.setBackground((Drawable)sSLCShareInfo2.setBackgroundColor(n5, Color.parseColor((String)stringBuilder10.toString()), this.getResources().getColor(n4)));
        Button button2 = this.btnCardMobileVerify;
        SSLCShareInfo sSLCShareInfo3 = SSLCShareInfo.getInstance();
        StringBuilder stringBuilder11 = a.F1((String)"#");
        stringBuilder11.append(this.SSLCSdkMainResponseModel.getActiveColor());
        int n6 = Color.parseColor((String)stringBuilder11.toString());
        StringBuilder stringBuilder12 = a.F1((String)"#");
        stringBuilder12.append(this.SSLCSdkMainResponseModel.getPrimaryColor());
        button2.setBackground((Drawable)sSLCShareInfo3.setBackgroundColor(n6, Color.parseColor((String)stringBuilder12.toString()), this.getResources().getColor(n4)));
        this.tvChangeNumberOtp.setEnabled(false);
        this.tvOtpChangeCard.setEnabled(false);
        SSLCChangeCursorColor sSLCChangeCursorColor = new SSLCChangeCursorColor(this.context);
        SSLCCustomEdittext sSLCCustomEdittext = this.etMobileNumber;
        StringBuilder stringBuilder13 = a.F1((String)"#");
        stringBuilder13.append(this.SSLCSdkMainResponseModel.getPrimaryColor());
        sSLCChangeCursorColor.setCursorColor((EditText)sSLCCustomEdittext, Color.parseColor((String)stringBuilder13.toString()));
        SSLCCustomEdittext sSLCCustomEdittext2 = this.etCardMobileNumber;
        StringBuilder stringBuilder14 = a.F1((String)"#");
        stringBuilder14.append(this.SSLCSdkMainResponseModel.getPrimaryColor());
        sSLCChangeCursorColor.setCursorColor((EditText)sSLCCustomEdittext2, Color.parseColor((String)stringBuilder14.toString()));
        SSLCCustomEdittext sSLCCustomEdittext3 = this.etCardNumber;
        StringBuilder stringBuilder15 = a.F1((String)"#");
        stringBuilder15.append(this.SSLCSdkMainResponseModel.getPrimaryColor());
        sSLCChangeCursorColor.setCursorColor((EditText)sSLCCustomEdittext3, Color.parseColor((String)stringBuilder15.toString()));
        SSLCCustomEdittext sSLCCustomEdittext4 = this.etCardExpireDate;
        StringBuilder stringBuilder16 = a.F1((String)"#");
        stringBuilder16.append(this.SSLCSdkMainResponseModel.getPrimaryColor());
        sSLCChangeCursorColor.setCursorColor((EditText)sSLCCustomEdittext4, Color.parseColor((String)stringBuilder16.toString()));
        SSLCCustomEdittext sSLCCustomEdittext5 = this.etCardMobileNumber;
        StringBuilder stringBuilder17 = a.F1((String)"#");
        stringBuilder17.append(this.SSLCSdkMainResponseModel.getPrimaryColor());
        sSLCChangeCursorColor.setCursorColor((EditText)sSLCCustomEdittext5, Color.parseColor((String)stringBuilder17.toString()));
        SSLCCustomEdittext sSLCCustomEdittext6 = this.etCardCVC;
        StringBuilder stringBuilder18 = a.F1((String)"#");
        stringBuilder18.append(this.SSLCSdkMainResponseModel.getPrimaryColor());
        sSLCChangeCursorColor.setCursorColor((EditText)sSLCCustomEdittext6, Color.parseColor((String)stringBuilder18.toString()));
        SSLCCustomEdittext sSLCCustomEdittext7 = this.etCardName;
        StringBuilder stringBuilder19 = a.F1((String)"#");
        stringBuilder19.append(this.SSLCSdkMainResponseModel.getPrimaryColor());
        sSLCChangeCursorColor.setCursorColor((EditText)sSLCCustomEdittext7, Color.parseColor((String)stringBuilder19.toString()));
        SSLCCustomEdittext sSLCCustomEdittext8 = this.pin1;
        StringBuilder stringBuilder20 = a.F1((String)"#");
        stringBuilder20.append(this.SSLCSdkMainResponseModel.getPrimaryColor());
        sSLCChangeCursorColor.setCursorColor((EditText)sSLCCustomEdittext8, Color.parseColor((String)stringBuilder20.toString()));
        SSLCCustomEdittext sSLCCustomEdittext9 = this.pin2;
        StringBuilder stringBuilder21 = a.F1((String)"#");
        stringBuilder21.append(this.SSLCSdkMainResponseModel.getPrimaryColor());
        sSLCChangeCursorColor.setCursorColor((EditText)sSLCCustomEdittext9, Color.parseColor((String)stringBuilder21.toString()));
        SSLCCustomEdittext sSLCCustomEdittext10 = this.pin3;
        StringBuilder stringBuilder22 = a.F1((String)"#");
        stringBuilder22.append(this.SSLCSdkMainResponseModel.getPrimaryColor());
        sSLCChangeCursorColor.setCursorColor((EditText)sSLCCustomEdittext10, Color.parseColor((String)stringBuilder22.toString()));
        SSLCCustomEdittext sSLCCustomEdittext11 = this.pin4;
        StringBuilder stringBuilder23 = a.F1((String)"#");
        stringBuilder23.append(this.SSLCSdkMainResponseModel.getPrimaryColor());
        sSLCChangeCursorColor.setCursorColor((EditText)sSLCCustomEdittext11, Color.parseColor((String)stringBuilder23.toString()));
        SSLCCustomEdittext sSLCCustomEdittext12 = this.pin5;
        StringBuilder stringBuilder24 = a.F1((String)"#");
        stringBuilder24.append(this.SSLCSdkMainResponseModel.getPrimaryColor());
        sSLCChangeCursorColor.setCursorColor((EditText)sSLCCustomEdittext12, Color.parseColor((String)stringBuilder24.toString()));
        SSLCCustomEdittext sSLCCustomEdittext13 = this.pin6;
        StringBuilder stringBuilder25 = a.F1((String)"#");
        stringBuilder25.append(this.SSLCSdkMainResponseModel.getPrimaryColor());
        sSLCChangeCursorColor.setCursorColor((EditText)sSLCCustomEdittext13, Color.parseColor((String)stringBuilder25.toString()));
    }

    public static SSLCCardFragment newInstance(String string2, SSLCommerzInitialization sSLCommerzInitialization, String string3, String string4) {
        mobileSslCommerzInitialization = sSLCommerzInitialization;
        SSLCCardFragment sSLCCardFragment = new SSLCCardFragment();
        Bundle bundle = new Bundle();
        bundle.putSerializable("offer_model", (Serializable)string3);
        bundle.putSerializable("emi_model", (Serializable)string4);
        bundle.putString("main_response", string2);
        sSLCCardFragment.setArguments(bundle);
        return sSLCCardFragment;
    }

    private void pinFocusChangeListener() {
        this.pin1.addTextChangedListener((TextWatcher)new 30(this));
        this.pin2.addTextChangedListener((TextWatcher)new 31(this));
        this.pin2.setOnKeyListener((View.OnKeyListener)new 32(this));
        this.pin3.addTextChangedListener((TextWatcher)new 33(this));
        this.pin3.setOnKeyListener((View.OnKeyListener)new 34(this));
        this.pin4.addTextChangedListener((TextWatcher)new 35(this));
        this.pin4.setOnKeyListener((View.OnKeyListener)new 36(this));
        this.pin5.addTextChangedListener((TextWatcher)new 37(this));
        this.pin5.setOnKeyListener((View.OnKeyListener)new 38(this));
        this.pin6.addTextChangedListener((TextWatcher)new 39(this));
        this.pin6.setOnKeyListener((View.OnKeyListener)new 40(this));
    }

    private void setRvSaveCards(List<SSLCVerifyOtpAndLoginModel.CardNo> list) {
        SSLCSaveCardsAdapter sSLCSaveCardsAdapter;
        SSLCVerifyOtpAndLoginModel.CardNo cardNo = new SSLCVerifyOtpAndLoginModel.CardNo(new SSLCVerifyOtpAndLoginModel());
        cardNo.setCardNo(this.getActivity().getResources().getString(R.string.pay_using_another_card));
        cardNo.setType("another");
        list.add((Object)cardNo);
        this.rvSaveCards.setHasFixedSize(true);
        this.SSLCSaveCardsAdapter = sSLCSaveCardsAdapter = new SSLCSaveCardsAdapter((Context)this.getActivity(), list, this.SSLCSdkMainResponseModel, this.offerId, this.SSLCOfferModel);
        this.rvSaveCards.setLayoutManager((RecyclerView.LayoutManager)new LinearLayoutManager((Context)this.getActivity()));
        this.rvSaveCards.setAdapter((RecyclerView.Adapter)this.SSLCSaveCardsAdapter);
        this.SSLCSaveCardsAdapter.setClickListener((SSLCSaveCardsAdapter.ClickListener)new 27(this, list));
        this.SSLCSaveCardsAdapter.setDeleteClickListener((SSLCSaveCardsAdapter.DeleteListener)new 28(this, list));
        this.SSLCSaveCardsAdapter.setEMIClickListener((SSLCSaveCardsAdapter.EmiSelectListener)new 29(this));
    }

    public List<String> getTenures(String string2) {
        ArrayList arrayList = new ArrayList();
        arrayList.add((Object)this.getResources().getString(R.string.avail_emi));
        SSLCEMIModel sSLCEMIModel = this.SSLCEMIModel;
        if (sSLCEMIModel != null) {
            for (SSLCEMIModel.Emi emi : sSLCEMIModel.getData().getData().getEmi()) {
                Iterator iterator = emi.getBinList().iterator();
                while (iterator.hasNext()) {
                    if (!((String)iterator.next()).contains((CharSequence)string2)) continue;
                    Iterator iterator2 = emi.getEmiBankTenureDesc().iterator();
                    while (iterator2.hasNext()) {
                        arrayList.add((Object)((SSLCEMIModel.EmiBankTenureDesc)iterator2.next()).getDesc().replace((CharSequence)"&nbsp;", (CharSequence)""));
                    }
                    break block1;
                }
                if (arrayList.size() <= 1) continue;
                this.emiBankId = emi.getEmiBankID();
                break;
            }
        }
        return arrayList;
    }

    public void initDialog(String string2, String string3) {
        Dialog dialog;
        this.dialog = dialog = new Dialog((Context)this.getActivity(), R.style.customDialog);
        dialog.requestWindowFeature(1);
        this.dialog.getWindow().setBackgroundDrawable((Drawable)new ColorDrawable(0));
        this.dialog.setContentView(R.layout.tooltip_view_sslc);
        ((SSLCCustomTextView)this.dialog.findViewById(R.id.moreInfo)).setOnClickListener((View.OnClickListener)new 26(this));
        this.dialog.show();
    }

    public void onActivityCreated(@Nullable Bundle bundle) {
        super.onActivityCreated(bundle);
        this.initViews();
        this.layoutOffer.setVisibility(8);
        this.layoutOTP.setVisibility(8);
        this.layoutEMIInfo.setVisibility(8);
        this.layoutCardLogin.setVisibility(8);
        this.layoutOtherCards.setVisibility(8);
        if (!this.SSLCSdkMainResponseModel.getCustMobile().isEmpty()) {
            this.etMobileNumber.setText((CharSequence)this.SSLCSdkMainResponseModel.getCustMobile());
            this.etMobileNumber.setEnabled(false);
            this.btnMobileVerify.setEnabled(true);
        } else {
            this.etMobileNumber.setEnabled(true);
            this.btnMobileVerify.setEnabled(false);
        }
        if (this.SSLCSdkMainResponseModel.getEmiStatus() == 1) {
            this.layoutEMIInfo.setVisibility(0);
            this.layoutEMI.setEnabled(false);
        }
        if (SSLCShareInfo.getInstance().getMobileNo((Context)this.getActivity()).equalsIgnoreCase(this.SSLCSdkMainResponseModel.getCustMobile()) && !SSLCShareInfo.getInstance().getCustSession((Context)this.getActivity()).isEmpty()) {
            this.SSLCProgressBarHandler.show();
            new SSLCVerifyLoginSessionViewModel((Context)this.getActivity()).verifyOtpAndLogin(SSLCShareInfo.getInstance().getRegKey((Context)this.getActivity()), SSLCShareInfo.getInstance().getEncKey((Context)this.getActivity()), this.SSLCSdkMainResponseModel.getSessionkey(), SSLCShareInfo.getInstance().getCustSession((Context)this.getActivity()), (SSLCVerifyLoginSessionListener)new 1(this));
        } else {
            SSLCShareInfo.getInstance().saveCustSession((Context)this.getActivity(), "");
            SSLCShareInfo.getInstance().saveMobileNo((Context)this.getActivity(), "");
            if (!this.SSLCSdkMainResponseModel.getCustMobile().isEmpty()) {
                this.etMobileNumber.setText((CharSequence)this.SSLCSdkMainResponseModel.getCustMobile());
                this.btnMobileVerify.setEnabled(true);
            } else {
                this.btnMobileVerify.setEnabled(false);
            }
            if (!this.SSLCSdkMainResponseModel.getCustomerName().isEmpty()) {
                this.tvCustomerName.setText((CharSequence)this.SSLCSdkMainResponseModel.getCustomerName());
            }
            this.tvWelcome.setText((CharSequence)this.getActivity().getResources().getString(R.string.welcome_back_coma));
            this.layoutCardInfo.setVisibility(8);
            this.layoutMobileOTP.setVisibility(0);
            this.layoutOTP.setVisibility(8);
            if (this.SSLCSdkMainResponseModel.getExistingMobile() > 0) {
                if (this.SSLCSdkMainResponseModel.getNumberOfCardSaved() > 0) {
                    this.layoutSaveCards.setVisibility(8);
                    this.layoutCardInfo.setVisibility(8);
                    this.layoutMobileOTP.setVisibility(0);
                    this.layoutOTP.setVisibility(8);
                } else {
                    this.layoutCardInfo.setVisibility(8);
                    this.layoutMobileOTP.setVisibility(0);
                    this.layoutOTP.setVisibility(8);
                }
            } else if (this.SSLCSdkMainResponseModel.getExistingMobile() == 0) {
                this.layoutCardInfo.setVisibility(0);
                this.layoutMobileOTP.setVisibility(8);
                this.layoutOTP.setVisibility(8);
            }
        }
        ((MainUIActivitySSLC)this.getActivity()).setOnPayClickListener((SSLCPayNowListener)new 2(this));
        ((MainUIActivitySSLC)this.getActivity()).setOnLogoutClickListener((SSLCOnLogOutListener)new 3(this));
        ((MainUIActivitySSLC)this.getActivity()).setOnOfferSelectListener((SSLCOnOfferSelectListener)new 4(this));
        this.etCardNumber.addTextChangedListener((TextWatcher)new 5(this));
        this.etCardExpireDate.addTextChangedListener((TextWatcher)new 6(this));
        this.etCardCVC.addTextChangedListener((TextWatcher)new 7(this));
        this.etCardName.addTextChangedListener((TextWatcher)new 8(this));
        this.etMobileNumber.addTextChangedListener((TextWatcher)new 9(this));
        this.etCardMobileNumber.addTextChangedListener((TextWatcher)new 10(this));
        this.tvChangeNumberOtp.setOnClickListener((View.OnClickListener)new 11(this));
        this.tvOtpChangeCard.setOnClickListener((View.OnClickListener)new 12(this));
        this.btnMobileVerify.setOnClickListener((View.OnClickListener)new 13(this));
        this.btnCardMobileVerify.setOnClickListener((View.OnClickListener)new 14(this));
        this.tvResendOTP.setOnClickListener((View.OnClickListener)new 15(this));
        this.rememberMeCv.setOnCheckedChangeListener((CompoundButton.OnCheckedChangeListener)new 16(this));
        this.getActivity().findViewById(R.id.iv_other_cards_go_back).setOnClickListener((View.OnClickListener)new 17(this));
        this.tvSkipLogin.setOnClickListener((View.OnClickListener)new 18(this));
        this.tvChangeNumber.setOnClickListener((View.OnClickListener)new 19(this));
        this.tvMyCards.setOnClickListener((View.OnClickListener)new 20(this));
        this.tvOtherCards.setOnClickListener((View.OnClickListener)new 21(this));
        this.layoutEMI.setOnClickListener((View.OnClickListener)new 22(this));
        this.ivEMIInfo.setOnClickListener((View.OnClickListener)new 23(this));
        this.ivMoreInfo.setOnClickListener((View.OnClickListener)new 24(this));
        this.tvTermCondition.setOnClickListener((View.OnClickListener)new 25(this));
        this.pinFocusChangeListener();
    }

    public void onAttach(Context context2) {
        super.onAttach(context2);
        if (context2 instanceof SSLCOnUserVerifyListener) {
            this.SSLCOnUserVerifyListener = (SSLCOnUserVerifyListener)context2;
            this.SSLCOnBtnPayActiveListener = (SSLCOnBtnPayActiveListener)context2;
            return;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(context2.toString());
        stringBuilder.append(" must implement OnFragmentInteractionListener");
        throw new RuntimeException(stringBuilder.toString());
    }

    public void onConfigurationChanged(Configuration configuration) {
        SSLCCustomTextView sSLCCustomTextView;
        SSLCCustomEdittext sSLCCustomEdittext;
        CheckBox checkBox;
        SSLCCustomTextView sSLCCustomTextView2;
        SSLCCustomTextView sSLCCustomTextView3;
        SSLCCustomEdittext sSLCCustomEdittext2;
        SSLCCustomTextView sSLCCustomTextView4;
        SSLCCustomTextView sSLCCustomTextView5;
        SSLCCustomEdittext sSLCCustomEdittext3;
        SSLCSaveCardsAdapter sSLCSaveCardsAdapter;
        SSLCCustomTextView sSLCCustomTextView6;
        SSLCCustomTextView sSLCCustomTextView7;
        SSLCCustomTextView sSLCCustomTextView8;
        SSLCOtherCardsAdapter sSLCOtherCardsAdapter;
        SSLCCustomTextView sSLCCustomTextView9;
        Button button;
        SSLCCustomTextView sSLCCustomTextView10;
        SSLCCustomTextView sSLCCustomTextView11;
        SSLCCustomTextView sSLCCustomTextView12;
        Button button2;
        SSLCCustomEdittext sSLCCustomEdittext4;
        SSLCCustomTextView sSLCCustomTextView13;
        SSLCCustomEdittext sSLCCustomEdittext5;
        SSLCCustomTextView sSLCCustomTextView14;
        SSLCCustomEdittext sSLCCustomEdittext6 = this.etCardNumber;
        if (sSLCCustomEdittext6 != null) {
            sSLCCustomEdittext6.setHint(R.string.enter_card_number);
        }
        if ((sSLCCustomEdittext2 = this.etCardCVC) != null) {
            sSLCCustomEdittext2.setHint(R.string.cvc);
        }
        if ((sSLCCustomEdittext5 = this.etCardExpireDate) != null) {
            sSLCCustomEdittext5.setHint(R.string.enter_expire_date);
        }
        if ((sSLCCustomEdittext3 = this.etCardName) != null) {
            sSLCCustomEdittext3.setHint(R.string.card_holder_name);
        }
        if ((checkBox = this.rememberMeCv) != null) {
            checkBox.setText(R.string.remember_me);
        }
        if ((sSLCCustomTextView4 = this.tvMyCards) != null) {
            sSLCCustomTextView4.setText(R.string.my_cards);
        }
        if ((sSLCCustomTextView13 = this.tvOtherCards) != null) {
            sSLCCustomTextView13.setText(R.string.other_cards);
        }
        if ((sSLCCustomTextView8 = this.tvOtpChangeCard) != null) {
            sSLCCustomTextView8.setText(R.string.change_card);
        }
        if ((sSLCCustomTextView9 = this.tvAvailEmi) != null) {
            sSLCCustomTextView9.setText(R.string.avail_emi);
        }
        if ((sSLCCustomTextView = this.tvTermCondition) != null) {
            sSLCCustomTextView.setText(R.string.remember_me_warning);
        }
        if ((sSLCCustomTextView10 = this.tvAlreadyRegistered) != null) {
            sSLCCustomTextView10.setText(R.string.already_registered_so_verify);
        }
        if ((sSLCCustomTextView5 = this.tvRegistered) != null) {
            sSLCCustomTextView5.setText(R.string.registered_so_verify);
        }
        if ((sSLCCustomTextView14 = this.tvChangeNumber) != null) {
            sSLCCustomTextView14.setText(R.string.change_number);
        }
        if ((sSLCCustomTextView7 = this.tvChangeNumberOtp) != null) {
            sSLCCustomTextView7.setText(R.string.change_number);
        }
        if ((sSLCCustomTextView3 = this.tvWelcome) != null) {
            sSLCCustomTextView3.setText(R.string.welcome_back_coma);
        }
        if ((sSLCCustomTextView11 = this.tvSkipLogin) != null) {
            sSLCCustomTextView11.setText(R.string.skip_this_step);
        }
        if ((button2 = this.btnMobileVerify) != null) {
            button2.setText(R.string.verify);
        }
        if ((button = this.btnCardMobileVerify) != null) {
            button.setText(R.string.verify);
        }
        if ((sSLCCustomEdittext4 = this.etMobileNumber) != null) {
            sSLCCustomEdittext4.setHint(R.string.enter_mobile_number);
        }
        if ((sSLCCustomEdittext = this.etCardMobileNumber) != null) {
            sSLCCustomEdittext.setHint(R.string.enter_mobile_number);
        }
        if ((sSLCCustomTextView2 = this.tvResendOTP) != null) {
            sSLCCustomTextView2.setText(R.string.resend_otp);
        }
        if ((sSLCCustomTextView6 = this.tvOtpHasEmi) != null) {
            sSLCCustomTextView6.setText(R.string.no_emi);
        }
        if ((sSLCCustomTextView12 = this.tvOtpHeader) != null) {
            sSLCCustomTextView12.setText(R.string.verification_code);
        }
        if ((sSLCSaveCardsAdapter = this.SSLCSaveCardsAdapter) != null) {
            sSLCSaveCardsAdapter.notifyDataSetChanged();
        }
        if ((sSLCOtherCardsAdapter = this.SSLCOtherCardsAdapter) != null) {
            sSLCOtherCardsAdapter.notifyDataSetChanged();
        }
        super.onConfigurationChanged(configuration);
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.context = this.getActivity().getApplicationContext();
        if (this.getArguments() != null) {
            SSLCSdkMainResponseModel sSLCSdkMainResponseModel;
            this.SSLCSdkMainResponseModel = sSLCSdkMainResponseModel = new SSLCSdkMainResponseModel();
            this.SSLCSdkMainResponseModel = sSLCSdkMainResponseModel.fromJSON(this.getArguments().getString("main_response"));
            this.SSLCOfferModel = (SSLCOfferModel)new Gson().fromJson(this.getArguments().getString("offer_model"), SSLCOfferModel.class);
            this.SSLCEMIModel = (SSLCEMIModel)new Gson().fromJson(this.getArguments().getString("emi_model"), SSLCEMIModel.class);
        }
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View view = layoutInflater.inflate(R.layout.fragment_card_sslc, viewGroup, false);
        FragmentActivity fragmentActivity = this.getActivity();
        StringBuilder stringBuilder = a.F1((String)"#");
        stringBuilder.append(this.SSLCSdkMainResponseModel.getPrimaryColor());
        this.SSLCProgressBarHandler = new SSLCProgressBarHandler((Context)fragmentActivity, Color.parseColor((String)stringBuilder.toString()));
        return view;
    }

    public void onDetach() {
        super.onDetach();
        this.SSLCOnUserVerifyListener = null;
        this.SSLCOnBtnPayActiveListener = null;
    }

    public void onResume() {
        super.onResume();
    }

    public void setLocale() {
        Locale locale = new Locale(SSLCPrefUtils.getPreferenceLanguageValue((Context)this.context));
        Configuration configuration = this.getResources().getConfiguration();
        configuration.setLocale(locale);
        this.getResources().updateConfiguration(configuration, this.getResources().getDisplayMetrics());
        this.onConfigurationChanged(configuration);
    }

    public void setUserVisibleHint(boolean bl) {
        super.setUserVisibleHint(true);
        if (this.isVisible() && bl) {
            this.layoutOffer.setVisibility(8);
            this.etCardCVC.setText((CharSequence)"");
            EditText editText = this.etSavedCVV;
            if (editText != null) {
                editText.setText((CharSequence)"");
            }
            if (this.layoutSaveCards.getVisibility() == 0) {
                SSLCSaveCardsAdapter sSLCSaveCardsAdapter = this.SSLCSaveCardsAdapter;
                sSLCSaveCardsAdapter.notifyItemChanged(sSLCSaveCardsAdapter.currentlySelectedPosition);
                this.SSLCSaveCardsAdapter.previousSelectedPosition = -1;
            }
            this.SSLCOnBtnPayActiveListener.onBtnPayActive(Boolean.FALSE, "");
            ((MainUIActivitySSLC)this.getActivity()).setOnPayClickListener((SSLCPayNowListener)new 41(this));
        }
    }
}

