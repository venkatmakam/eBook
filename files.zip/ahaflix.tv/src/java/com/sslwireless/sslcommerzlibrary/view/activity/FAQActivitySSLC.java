/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.IntentFilter
 *  android.os.Bundle
 *  android.view.MenuItem
 *  android.view.View
 *  android.webkit.WebChromeClient
 *  android.webkit.WebSettings
 *  android.webkit.WebView
 *  android.webkit.WebViewClient
 *  android.widget.ProgressBar
 *  androidx.annotation.Nullable
 *  androidx.appcompat.app.ActionBar
 *  androidx.appcompat.app.AppCompatActivity
 *  androidx.appcompat.widget.Toolbar
 *  androidx.localbroadcastmanager.content.LocalBroadcastManager
 *  com.sslwireless.sslcommerzlibrary.R
 *  com.sslwireless.sslcommerzlibrary.R$id
 *  com.sslwireless.sslcommerzlibrary.R$layout
 *  com.sslwireless.sslcommerzlibrary.view.activity.FAQActivitySSLC$1
 *  com.sslwireless.sslcommerzlibrary.view.activity.FAQActivitySSLC$2
 *  com.sslwireless.sslcommerzlibrary.view.activity.FAQActivitySSLC$3
 *  java.lang.CharSequence
 *  java.lang.String
 */
package com.sslwireless.sslcommerzlibrary.view.activity;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import com.sslwireless.sslcommerzlibrary.R;
import com.sslwireless.sslcommerzlibrary.view.activity.FAQActivitySSLC;
import com.sslwireless.sslcommerzlibrary.view.activity.SSLCBaseActivity;

public class FAQActivitySSLC
extends SSLCBaseActivity {
    private ProgressBar bankPageProgress;
    private int checker = 0;
    private Context context;
    private WebView faqWebView;
    private BroadcastReceiver mMessageReceiver = new 1(this);
    private String url;

    public static /* synthetic */ ProgressBar access$000(FAQActivitySSLC fAQActivitySSLC) {
        return fAQActivitySSLC.bankPageProgress;
    }

    private void showTheWebsite(String string) {
        2 var2_2 = new 2(this);
        this.faqWebView.getSettings().setLoadsImagesAutomatically(true);
        this.faqWebView.getSettings().setJavaScriptEnabled(true);
        this.faqWebView.getSettings().setDomStorageEnabled(true);
        this.faqWebView.setScrollBarStyle(0);
        this.faqWebView.setWebViewClient((WebViewClient)var2_2);
        this.faqWebView.loadUrl(string);
        this.faqWebView.setWebChromeClient((WebChromeClient)new 3(this));
    }

    @Override
    public void onCreate(@Nullable Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(R.layout.activity_ssl_faq);
        this.context = this;
        LocalBroadcastManager.getInstance((Context)this).registerReceiver(this.mMessageReceiver, new IntentFilter("custom-event-name"));
    }

    public void onDestroy() {
        LocalBroadcastManager.getInstance((Context)this).unregisterReceiver(this.mMessageReceiver);
        AppCompatActivity.super.onDestroy();
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == 16908332) {
            this.finish();
            return true;
        }
        return Activity.super.onOptionsItemSelected(menuItem);
    }

    @Override
    public void viewRelatedTask() {
        this.url = this.getIntent().getStringExtra("url");
        this.checker = this.getIntent().getIntExtra("checker", 0);
        this.setSupportActionBar((Toolbar)this.findViewById(R.id.toolbar));
        if (this.getSupportActionBar() != null) {
            this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            this.getSupportActionBar().setHomeButtonEnabled(true);
            int n = this.checker;
            if (n == 1) {
                this.getSupportActionBar().setTitle((CharSequence)"Support");
            } else if (n == 2) {
                this.getSupportActionBar().setTitle((CharSequence)"More Info");
            } else {
                this.getSupportActionBar().setTitle((CharSequence)"FAQ");
            }
        }
        this.faqWebView = (WebView)this.findViewById(R.id.faqWebView);
        this.bankPageProgress = (ProgressBar)this.findViewById(R.id.bankPageProgress);
        this.showTheWebsite(this.url);
    }
}

