/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Bundle
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.ImageView
 *  androidx.annotation.NonNull
 *  androidx.annotation.Nullable
 *  androidx.fragment.app.Fragment
 *  androidx.fragment.app.FragmentActivity
 *  androidx.recyclerview.widget.GridLayoutManager
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.recyclerview.widget.RecyclerView$LayoutManager
 *  com.sslwireless.sslcommerzlibrary.R
 *  com.sslwireless.sslcommerzlibrary.R$id
 *  com.sslwireless.sslcommerzlibrary.R$layout
 *  com.sslwireless.sslcommerzlibrary.model.initializer.SSLCommerzInitialization
 *  com.sslwireless.sslcommerzlibrary.model.response.SSLCSdkMainResponseModel
 *  com.sslwireless.sslcommerzlibrary.model.response.SSLCSdkMainResponseModel$Desc
 *  com.sslwireless.sslcommerzlibrary.model.util.SSLCShareInfo
 *  com.sslwireless.sslcommerzlibrary.view.activity.MainUIActivitySSLC
 *  com.sslwireless.sslcommerzlibrary.view.adapter.SSLCNetBankingRecyclerAdapter
 *  com.sslwireless.sslcommerzlibrary.view.adapter.SSLCNetBankingRecyclerAdapter$ClickListener
 *  com.sslwireless.sslcommerzlibrary.view.fragment.SSLCNetBankingFragment$1
 *  com.sslwireless.sslcommerzlibrary.view.fragment.SSLCNetBankingFragment$2
 *  com.sslwireless.sslcommerzlibrary.viewmodel.listener.SSLCOnBtnPayActiveListener
 *  com.sslwireless.sslcommerzlibrary.viewmodel.listener.SSLCOnUserVerifyListener
 *  com.sslwireless.sslcommerzlibrary.viewmodel.listener.SSLCPayNowListener
 *  e.a.a.a.a
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.List
 */
package com.sslwireless.sslcommerzlibrary.view.fragment;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.sslwireless.sslcommerzlibrary.R;
import com.sslwireless.sslcommerzlibrary.model.initializer.SSLCommerzInitialization;
import com.sslwireless.sslcommerzlibrary.model.response.SSLCSdkMainResponseModel;
import com.sslwireless.sslcommerzlibrary.model.util.SSLCShareInfo;
import com.sslwireless.sslcommerzlibrary.view.activity.MainUIActivitySSLC;
import com.sslwireless.sslcommerzlibrary.view.adapter.SSLCNetBankingRecyclerAdapter;
import com.sslwireless.sslcommerzlibrary.view.fragment.SSLCNetBankingFragment;
import com.sslwireless.sslcommerzlibrary.viewmodel.listener.SSLCOnBtnPayActiveListener;
import com.sslwireless.sslcommerzlibrary.viewmodel.listener.SSLCOnUserVerifyListener;
import com.sslwireless.sslcommerzlibrary.viewmodel.listener.SSLCPayNowListener;
import e.a.a.a.a;
import java.util.ArrayList;
import java.util.List;

public class SSLCNetBankingFragment
extends Fragment
implements SSLCNetBankingRecyclerAdapter.ClickListener {
    private static SSLCommerzInitialization mobileSslCommerzInitialization;
    private SSLCOnBtnPayActiveListener SSLCOnBtnPayActiveListener;
    private SSLCOnUserVerifyListener SSLCOnUserVerifyListener;
    private SSLCSdkMainResponseModel SSLCSdkMainResponseModel;
    private SSLCNetBankingRecyclerAdapter adapter;
    private ArrayList<String> arrayList = new ArrayList();
    private Context context;
    private ImageView imageView;
    private List<SSLCSdkMainResponseModel.Desc> itemClickData;
    private List<SSLCSdkMainResponseModel.Desc> netBankingList = new ArrayList();
    private RecyclerView netBankingRecycler;
    private int pos = -1;

    public static /* synthetic */ Context access$000(SSLCNetBankingFragment sSLCNetBankingFragment) {
        return sSLCNetBankingFragment.context;
    }

    public static /* synthetic */ SSLCSdkMainResponseModel access$100(SSLCNetBankingFragment sSLCNetBankingFragment) {
        return sSLCNetBankingFragment.SSLCSdkMainResponseModel;
    }

    public static /* synthetic */ SSLCommerzInitialization access$200() {
        return mobileSslCommerzInitialization;
    }

    private void hideView(ImageView imageView) {
        imageView.setVisibility(8);
    }

    public static SSLCNetBankingFragment newInstance(String string2, SSLCommerzInitialization sSLCommerzInitialization) {
        SSLCNetBankingFragment sSLCNetBankingFragment = new SSLCNetBankingFragment();
        Bundle bundle = a.n((String)"main_response", (String)string2);
        mobileSslCommerzInitialization = sSLCommerzInitialization;
        sSLCNetBankingFragment.setArguments(bundle);
        return sSLCNetBankingFragment;
    }

    public void itemClicked(View view, int n, List<SSLCSdkMainResponseModel.Desc> list, boolean bl) {
        this.imageView = (ImageView)view.findViewById(R.id.selectedContentArea);
        this.pos = n;
        this.itemClickData = list;
        if (bl) {
            if (this.netBankingList.size() > n) {
                this.SSLCOnBtnPayActiveListener.onBtnPayActive(Boolean.TRUE, ((SSLCSdkMainResponseModel.Desc)this.netBankingList.get(n)).getName());
            }
        } else {
            this.SSLCOnBtnPayActiveListener.onBtnPayActive(Boolean.FALSE, "");
        }
        ((MainUIActivitySSLC)this.getActivity()).setOnPayClickListener((SSLCPayNowListener)new 1(this, list, n));
    }

    public void onAttach(Context context2) {
        super.onAttach(context2);
        if (context2 instanceof SSLCOnUserVerifyListener) {
            this.SSLCOnUserVerifyListener = (SSLCOnUserVerifyListener)context2;
            this.SSLCOnBtnPayActiveListener = (SSLCOnBtnPayActiveListener)context2;
            return;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(context2.toString());
        stringBuilder.append(" must implement OnFragmentInteractionListener");
        throw new RuntimeException(stringBuilder.toString());
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        if (this.getArguments() != null) {
            SSLCSdkMainResponseModel sSLCSdkMainResponseModel;
            this.SSLCSdkMainResponseModel = sSLCSdkMainResponseModel = new SSLCSdkMainResponseModel();
            this.SSLCSdkMainResponseModel = sSLCSdkMainResponseModel.fromJSON(this.getArguments().getString("main_response"));
        }
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View view = layoutInflater.inflate(R.layout.fragment_net_banking_sslc, viewGroup, false);
        this.context = this.getActivity().getApplicationContext();
        this.netBankingRecycler = (RecyclerView)view.findViewById(R.id.netBankingRecycler);
        return view;
    }

    public void onDetach() {
        super.onDetach();
        this.SSLCOnUserVerifyListener = null;
        this.SSLCOnBtnPayActiveListener = null;
    }

    public void onViewCreated(@NonNull View view, @Nullable Bundle bundle) {
        super.onViewCreated(view, bundle);
        for (SSLCSdkMainResponseModel.Desc desc : this.SSLCSdkMainResponseModel.getDesc()) {
            if (!desc.getType().equalsIgnoreCase("internetbanking")) continue;
            this.netBankingList.add((Object)desc);
        }
        this.netBankingRecycler.setHasFixedSize(true);
        this.adapter = new SSLCNetBankingRecyclerAdapter(this.context, this.netBankingList);
        this.netBankingRecycler.setLayoutManager((RecyclerView.LayoutManager)new GridLayoutManager(this.context, 3));
        this.netBankingRecycler.setAdapter((RecyclerView.Adapter)this.adapter);
        this.adapter.setClickListener((SSLCNetBankingRecyclerAdapter.ClickListener)this);
    }

    public void setUserVisibleHint(boolean bl) {
        super.setUserVisibleHint(true);
        if (this.isVisible()) {
            this.SSLCOnBtnPayActiveListener.onBtnPayActive(Boolean.FALSE, "");
            SSLCShareInfo.getInstance().hideKeyboardFrom(this.getView());
            int n = this.pos;
            if (n != -1) {
                ((SSLCSdkMainResponseModel.Desc)this.itemClickData.get(n)).setSetStatus(false);
                this.adapter.updateView(this.imageView, this.pos);
            }
            if (bl) {
                ((MainUIActivitySSLC)this.getActivity()).setOnPayClickListener((SSLCPayNowListener)new 2(this));
            }
        }
    }
}

