/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.TypedArray
 *  android.graphics.Typeface
 *  android.util.AttributeSet
 *  android.widget.TextView
 *  androidx.appcompat.widget.AppCompatTextView
 *  com.sslwireless.sslcommerzlibrary.R
 *  com.sslwireless.sslcommerzlibrary.R$styleable
 *  com.sslwireless.sslcommerzlibrary.view.custom.SSLCUserTypeFace
 *  java.lang.String
 */
package com.sslwireless.sslcommerzlibrary.view.custom;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.widget.TextView;
import androidx.appcompat.widget.AppCompatTextView;
import com.sslwireless.sslcommerzlibrary.R;
import com.sslwireless.sslcommerzlibrary.view.custom.SSLCUserTypeFace;

public class SSLCCustomTextView
extends AppCompatTextView {
    public static final String ANDROID_SCHEMA = "http://schemas.android.com/apk/res/android";

    public SSLCCustomTextView(Context context) {
        super(context, null);
    }

    public SSLCCustomTextView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.init(context, attributeSet);
    }

    public SSLCCustomTextView(Context context, AttributeSet attributeSet, int n) {
        super(context, attributeSet, n);
        this.init(context, attributeSet);
    }

    private void init(Context context, AttributeSet attributeSet) {
        if (!this.isInEditMode()) {
            int n = context.obtainStyledAttributes(attributeSet, R.styleable.custom).getInteger(R.styleable.custom_textStyle, 0);
            if (n == 0) {
                SSLCUserTypeFace.SetNormal((TextView)this);
                return;
            }
            this.setStyle(n);
            return;
        }
        this.setTypeface(Typeface.DEFAULT, 0);
    }

    private void setStyle(int n) {
        if (n != 0) {
            if (n != 1) {
                if (n != 2) {
                    if (n != 3) {
                        if (n != 4) {
                            SSLCUserTypeFace.SetNormal((TextView)this);
                            return;
                        }
                        SSLCUserTypeFace.SetMedium((TextView)this);
                        return;
                    }
                    SSLCUserTypeFace.SetLight((TextView)this);
                    return;
                }
                SSLCUserTypeFace.SetItalic((TextView)this);
                return;
            }
            SSLCUserTypeFace.SetBold((TextView)this);
            return;
        }
        SSLCUserTypeFace.SetNormal((TextView)this);
    }
}

