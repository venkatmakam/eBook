/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.res.Configuration
 *  android.content.res.Resources
 *  android.graphics.Color
 *  android.os.Build
 *  android.os.Bundle
 *  android.os.CountDownTimer
 *  android.provider.Settings
 *  android.provider.Settings$Secure
 *  android.util.DisplayMetrics
 *  android.view.MenuItem
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.ImageView
 *  android.widget.LinearLayout
 *  android.widget.RelativeLayout
 *  android.widget.TextView
 *  androidx.annotation.Nullable
 *  androidx.appcompat.app.ActionBar
 *  androidx.appcompat.app.AppCompatActivity
 *  androidx.appcompat.widget.Toolbar
 *  androidx.fragment.app.Fragment
 *  androidx.fragment.app.FragmentActivity
 *  androidx.fragment.app.FragmentManager
 *  androidx.viewpager.widget.PagerAdapter
 *  androidx.viewpager.widget.ViewPager
 *  com.google.android.material.appbar.CollapsingToolbarLayout
 *  com.google.android.material.tabs.TabLayout
 *  com.google.android.material.tabs.TabLayout$Tab
 *  com.google.gson.Gson
 *  com.sslwireless.sslcommerzlibrary.R
 *  com.sslwireless.sslcommerzlibrary.R$color
 *  com.sslwireless.sslcommerzlibrary.R$drawable
 *  com.sslwireless.sslcommerzlibrary.R$id
 *  com.sslwireless.sslcommerzlibrary.R$layout
 *  com.sslwireless.sslcommerzlibrary.R$string
 *  com.sslwireless.sslcommerzlibrary.model.initializer.SSLCommerzInitialization
 *  com.sslwireless.sslcommerzlibrary.model.response.SSLCEMIModel
 *  com.sslwireless.sslcommerzlibrary.model.response.SSLCGetDeviceTokenModel
 *  com.sslwireless.sslcommerzlibrary.model.response.SSLCGetDeviceTokenModel$Data
 *  com.sslwireless.sslcommerzlibrary.model.response.SSLCOfferModel
 *  com.sslwireless.sslcommerzlibrary.model.response.SSLCSdkMainResponseModel
 *  com.sslwireless.sslcommerzlibrary.model.response.SSLCSdkMainResponseModel$Desc
 *  com.sslwireless.sslcommerzlibrary.model.response.SSLCSdkMainResponseModel$Design
 *  com.sslwireless.sslcommerzlibrary.model.response.SSLCSdkMainResponseModel$Gw
 *  com.sslwireless.sslcommerzlibrary.model.util.SSLCCreditCardUtils
 *  com.sslwireless.sslcommerzlibrary.model.util.SSLCDownloadImageTask
 *  com.sslwireless.sslcommerzlibrary.model.util.SSLCEnums
 *  com.sslwireless.sslcommerzlibrary.model.util.SSLCEnums$StatusType
 *  com.sslwireless.sslcommerzlibrary.model.util.SSLCPrefUtils
 *  com.sslwireless.sslcommerzlibrary.model.util.SSLCProgressBarHandler
 *  com.sslwireless.sslcommerzlibrary.model.util.SSLCShareInfo
 *  com.sslwireless.sslcommerzlibrary.view.activity.MainUIActivitySSLC$1
 *  com.sslwireless.sslcommerzlibrary.view.activity.MainUIActivitySSLC$2
 *  com.sslwireless.sslcommerzlibrary.view.activity.MainUIActivitySSLC$3
 *  com.sslwireless.sslcommerzlibrary.view.activity.MainUIActivitySSLC$4
 *  com.sslwireless.sslcommerzlibrary.view.activity.MainUIActivitySSLC$5
 *  com.sslwireless.sslcommerzlibrary.view.activity.MainUIActivitySSLC$7
 *  com.sslwireless.sslcommerzlibrary.view.activity.MainUIActivitySSLC$8
 *  com.sslwireless.sslcommerzlibrary.viewmodel.SSLCEMIViewModel
 *  com.sslwireless.sslcommerzlibrary.viewmodel.SSLCGetDeviceTokenViewModel
 *  com.sslwireless.sslcommerzlibrary.viewmodel.SSLCGetOfferViewModel
 *  com.sslwireless.sslcommerzlibrary.viewmodel.listener.SSLCDowloadImageListener
 *  com.sslwireless.sslcommerzlibrary.viewmodel.listener.SSLCEMIListener
 *  com.sslwireless.sslcommerzlibrary.viewmodel.listener.SSLCGetDeviceTokenListener
 *  com.sslwireless.sslcommerzlibrary.viewmodel.listener.SSLCGetOfferListener
 *  com.sslwireless.sslcommerzlibrary.viewmodel.listener.SSLCOnBtnPayActiveListener
 *  com.sslwireless.sslcommerzlibrary.viewmodel.listener.SSLCOnLogOutListener
 *  com.sslwireless.sslcommerzlibrary.viewmodel.listener.SSLCOnOfferSelectListener
 *  com.sslwireless.sslcommerzlibrary.viewmodel.listener.SSLCOnUserVerifyListener
 *  com.sslwireless.sslcommerzlibrary.viewmodel.listener.SSLCPayNowListener
 *  e.a.a.a.a
 *  java.io.Serializable
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.util.ArrayList
 *  java.util.List
 *  java.util.Locale
 *  java.util.Map
 */
package com.sslwireless.sslcommerzlibrary.view.activity;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;
import com.google.android.material.appbar.CollapsingToolbarLayout;
import com.google.android.material.tabs.TabLayout;
import com.google.gson.Gson;
import com.sslwireless.sslcommerzlibrary.R;
import com.sslwireless.sslcommerzlibrary.model.initializer.SSLCommerzInitialization;
import com.sslwireless.sslcommerzlibrary.model.response.SSLCEMIModel;
import com.sslwireless.sslcommerzlibrary.model.response.SSLCGetDeviceTokenModel;
import com.sslwireless.sslcommerzlibrary.model.response.SSLCOfferModel;
import com.sslwireless.sslcommerzlibrary.model.response.SSLCSdkMainResponseModel;
import com.sslwireless.sslcommerzlibrary.model.util.SSLCCreditCardUtils;
import com.sslwireless.sslcommerzlibrary.model.util.SSLCDownloadImageTask;
import com.sslwireless.sslcommerzlibrary.model.util.SSLCEnums;
import com.sslwireless.sslcommerzlibrary.model.util.SSLCPrefUtils;
import com.sslwireless.sslcommerzlibrary.model.util.SSLCProgressBarHandler;
import com.sslwireless.sslcommerzlibrary.model.util.SSLCShareInfo;
import com.sslwireless.sslcommerzlibrary.view.activity.MainUIActivitySSLC;
import com.sslwireless.sslcommerzlibrary.view.activity.SSLCBaseActivity;
import com.sslwireless.sslcommerzlibrary.view.activity.WebViewActivitySSLC;
import com.sslwireless.sslcommerzlibrary.view.custom.SSLCCustomTextView;
import com.sslwireless.sslcommerzlibrary.view.fragment.SSLCCardFragment;
import com.sslwireless.sslcommerzlibrary.view.fragment.SSLCMobileBankingFragment;
import com.sslwireless.sslcommerzlibrary.view.fragment.SSLCNetBankingFragment;
import com.sslwireless.sslcommerzlibrary.view.viewpager.SSLCViewPagerAdapter;
import com.sslwireless.sslcommerzlibrary.viewmodel.SSLCEMIViewModel;
import com.sslwireless.sslcommerzlibrary.viewmodel.SSLCGetDeviceTokenViewModel;
import com.sslwireless.sslcommerzlibrary.viewmodel.SSLCGetOfferViewModel;
import com.sslwireless.sslcommerzlibrary.viewmodel.listener.SSLCDowloadImageListener;
import com.sslwireless.sslcommerzlibrary.viewmodel.listener.SSLCEMIListener;
import com.sslwireless.sslcommerzlibrary.viewmodel.listener.SSLCGetDeviceTokenListener;
import com.sslwireless.sslcommerzlibrary.viewmodel.listener.SSLCGetOfferListener;
import com.sslwireless.sslcommerzlibrary.viewmodel.listener.SSLCOnBtnPayActiveListener;
import com.sslwireless.sslcommerzlibrary.viewmodel.listener.SSLCOnLogOutListener;
import com.sslwireless.sslcommerzlibrary.viewmodel.listener.SSLCOnOfferSelectListener;
import com.sslwireless.sslcommerzlibrary.viewmodel.listener.SSLCOnUserVerifyListener;
import com.sslwireless.sslcommerzlibrary.viewmodel.listener.SSLCPayNowListener;
import e.a.a.a.a;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class MainUIActivitySSLC
extends SSLCBaseActivity
implements SSLCGetDeviceTokenListener,
SSLCOnUserVerifyListener,
SSLCOnBtnPayActiveListener {
    public SSLCEMIModel SSLCEMIModel;
    public SSLCOfferModel SSLCOfferModel;
    public SSLCOnLogOutListener SSLCOnLogOutListener;
    public SSLCOnOfferSelectListener SSLCOnOfferSelectListener;
    public SSLCProgressBarHandler SSLCProgressBarHandler;
    public SSLCSdkMainResponseModel SSLCSdkMainResponseModel;
    private SSLCViewPagerAdapter adapter;
    private SSLCCustomTextView badge;
    private LinearLayout badgeLayout;
    private LinearLayout clickFAQ;
    private LinearLayout clickSupport;
    private CollapsingToolbarLayout collapsingToolbar;
    private Context context;
    private int counterTab = -1;
    public ImageView ivLanguage;
    public ImageView ivPay;
    private long lastBackPressTime = 0L;
    public RelativeLayout layoutAmount;
    public LinearLayout layoutPay;
    private LinearLayout mainLyout1;
    public ImageView merchantLogo;
    private boolean oneTimeFlag = false;
    public SSLCPayNowListener payClickListener;
    private SSLCommerzInitialization sslCommerzInitialization;
    private TabLayout.Tab tab;
    private TabLayout tabLayout;
    private CountDownTimer timer;
    private SSLCCustomTextView timerText;
    private int totalTabCount = -1;
    public TextView tvAmount;
    public TextView tvAmountHeader;
    public TextView tvBng;
    public TextView tvCharge;
    public TextView tvChargeHeader;
    private SSLCCustomTextView tvFaq;
    public TextView tvLogout;
    public TextView tvMerchantName;
    private SSLCCustomTextView tvOffer;
    public TextView tvPay;
    private SSLCCustomTextView tvSupport;
    public TextView tvUserName;
    private ViewPager viewPager;

    public static /* synthetic */ TabLayout access$000(MainUIActivitySSLC mainUIActivitySSLC) {
        return mainUIActivitySSLC.tabLayout;
    }

    public static /* synthetic */ Context access$100(MainUIActivitySSLC mainUIActivitySSLC) {
        return mainUIActivitySSLC.context;
    }

    public static /* synthetic */ SSLCCustomTextView access$200(MainUIActivitySSLC mainUIActivitySSLC) {
        return mainUIActivitySSLC.timerText;
    }

    public static /* synthetic */ SSLCommerzInitialization access$300(MainUIActivitySSLC mainUIActivitySSLC) {
        return mainUIActivitySSLC.sslCommerzInitialization;
    }

    public static /* synthetic */ LinearLayout access$400(MainUIActivitySSLC mainUIActivitySSLC) {
        return mainUIActivitySSLC.badgeLayout;
    }

    public static /* synthetic */ SSLCCustomTextView access$500(MainUIActivitySSLC mainUIActivitySSLC) {
        return mainUIActivitySSLC.badge;
    }

    public static /* synthetic */ void access$600(MainUIActivitySSLC mainUIActivitySSLC) {
        mainUIActivitySSLC.loadEmiModel();
    }

    public static /* synthetic */ ViewPager access$700(MainUIActivitySSLC mainUIActivitySSLC) {
        return mainUIActivitySSLC.viewPager;
    }

    private void loadEmiModel() {
        if (this.SSLCSdkMainResponseModel.getEmiStatus() == 1) {
            this.SSLCProgressBarHandler.show();
            new SSLCEMIViewModel((Context)this).getEMI(this.SSLCSdkMainResponseModel.getLoginTransSession(), SSLCShareInfo.getInstance().getRegKey((Context)this), SSLCShareInfo.getInstance().getEncKey((Context)this), new SSLCEMIListener(this){
                public final /* synthetic */ MainUIActivitySSLC this$0;
                {
                    this.this$0 = mainUIActivitySSLC;
                }

                public void emiFail(String string2) {
                    this.this$0.SSLCProgressBarHandler.hide();
                    SSLCShareInfo.getInstance().showToast((Context)this.this$0, string2);
                    this.this$0.finish();
                }

                public void emiSuccess(SSLCEMIModel sSLCEMIModel) {
                    this.this$0.SSLCProgressBarHandler.hide();
                    if (sSLCEMIModel.getStatus().toLowerCase().contains((CharSequence)SSLCEnums.StatusType.SUCCESS.name().toLowerCase())) {
                        MainUIActivitySSLC mainUIActivitySSLC = this.this$0;
                        mainUIActivitySSLC.SSLCEMIModel = sSLCEMIModel;
                        mainUIActivitySSLC.setupViewPager(MainUIActivitySSLC.access$700(mainUIActivitySSLC));
                        return;
                    }
                    SSLCShareInfo.getInstance().showToast((Context)this.this$0, sSLCEMIModel.getMessage());
                    this.this$0.finish();
                }
            });
            return;
        }
        this.setupViewPager(this.viewPager);
    }

    private void loadOfferModel() {
        if (this.SSLCSdkMainResponseModel.getOfferStatus() == 1) {
            this.SSLCProgressBarHandler.show();
            new SSLCGetOfferViewModel((Context)this).getGetOffer(this.SSLCSdkMainResponseModel.getLoginTransSession(), SSLCShareInfo.getInstance().getRegKey((Context)this), SSLCShareInfo.getInstance().getEncKey((Context)this), new SSLCGetOfferListener(this){
                public final /* synthetic */ MainUIActivitySSLC this$0;
                {
                    this.this$0 = mainUIActivitySSLC;
                }

                public void resendOtpFail(String string2) {
                    this.this$0.SSLCProgressBarHandler.hide();
                    SSLCShareInfo.getInstance().showToast((Context)this.this$0, string2);
                    this.this$0.finish();
                }

                public void resendOtpSuccess(SSLCOfferModel sSLCOfferModel) {
                    this.this$0.SSLCProgressBarHandler.hide();
                    if (sSLCOfferModel.getStatus().toLowerCase().contains((CharSequence)SSLCEnums.StatusType.SUCCESS.toString().toLowerCase())) {
                        this.this$0.SSLCOfferModel = sSLCOfferModel;
                        if (sSLCOfferModel.getData().getData().getDiscountList().size() > 0) {
                            MainUIActivitySSLC.access$400(this.this$0).setVisibility(0);
                            MainUIActivitySSLC.access$500(this.this$0).setText((CharSequence)String.valueOf((int)this.this$0.SSLCOfferModel.getData().getData().getDiscountList().size()));
                            android.graphics.drawable.Drawable drawable2 = MainUIActivitySSLC.access$400(this.this$0).getBackground();
                            StringBuilder stringBuilder = a.F1((String)"#");
                            stringBuilder.append(this.this$0.SSLCSdkMainResponseModel.getPrimaryColor());
                            int n = Color.parseColor((String)stringBuilder.toString());
                            if (drawable2 instanceof android.graphics.drawable.GradientDrawable) {
                                ((android.graphics.drawable.GradientDrawable)drawable2).setColor(n);
                            }
                        } else {
                            MainUIActivitySSLC.access$400(this.this$0).setVisibility(8);
                        }
                        MainUIActivitySSLC.access$600(this.this$0);
                        return;
                    }
                    this.this$0.finish();
                    SSLCShareInfo.getInstance().showToast((Context)this.this$0, sSLCOfferModel.getMessage());
                }
            });
            return;
        }
        this.loadEmiModel();
    }

    public void deviceTokenFail(String string) {
        SSLCShareInfo.getInstance().showToast((Context)this, "Transaction Failed");
        this.finish();
    }

    public void deviceTokenSuccess(SSLCGetDeviceTokenModel sSLCGetDeviceTokenModel) {
        if (sSLCGetDeviceTokenModel.getStatus().toLowerCase().contains((CharSequence)SSLCEnums.StatusType.SUCCESS.toString().toLowerCase())) {
            SSLCShareInfo.getInstance().saveRegId((Context)this, sSLCGetDeviceTokenModel.getData().getRegId());
            SSLCShareInfo.getInstance().saveEncKey((Context)this, sSLCGetDeviceTokenModel.getData().getEncKey());
            this.loadOfferModel();
            return;
        }
        this.finish();
    }

    public void onActivityResult(int n, int n2, Intent intent) {
        FragmentActivity.super.onActivityResult(n, n2, intent);
        if (n == 2 && n2 == -1) {
            this.viewPager.setCurrentItem(0);
            String string = intent.getStringExtra("id");
            String string2 = intent.getStringExtra("image");
            String string3 = intent.getStringExtra("title");
            String string4 = intent.getStringExtra("max_discount");
            ArrayList arrayList = intent.getStringArrayListExtra("offer_bins");
            this.SSLCOnOfferSelectListener.onOfferSelect(string, string2, string3, string4, arrayList);
            return;
        }
        if (n == 3 && n2 == -1) {
            this.finish();
        }
    }

    @Override
    public void onBackPressed() {
        if (this.lastBackPressTime < System.currentTimeMillis() - 4000L) {
            SSLCShareInfo.getInstance().showToast((Context)this, "Press once again to exit");
            this.lastBackPressTime = System.currentTimeMillis();
            return;
        }
        super.onBackPressed();
        this.timer.cancel();
    }

    public void onBtnPayActive(Boolean bl, String string2) {
        if (bl.booleanValue()) {
            this.layoutPay.setEnabled(true);
            LinearLayout linearLayout = this.layoutPay;
            StringBuilder stringBuilder = a.F1((String)"#");
            stringBuilder.append(this.SSLCSdkMainResponseModel.getPrimaryColor());
            linearLayout.setBackgroundColor(Color.parseColor((String)stringBuilder.toString()));
            this.tvPay.setTextColor(-1);
            SSLCShareInfo.getInstance().disableGray(this.ivPay);
            this.tvAmount.setText((CharSequence)"0.00 BDT");
            this.tvCharge.setText((CharSequence)"0.00 BDT");
            TextView textView = this.tvPay;
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append(this.getResources().getString(R.string.pay));
            stringBuilder2.append(" 0.00 BDT");
            textView.setText((CharSequence)stringBuilder2.toString());
            if (string2.matches("[0-9 X]+")) {
                for (SSLCSdkMainResponseModel.Desc desc : this.SSLCSdkMainResponseModel.getDesc()) {
                    if (!desc.getName().toLowerCase().contains((CharSequence)SSLCCreditCardUtils.getInstance().cardType(string2).toLowerCase())) continue;
                    TextView textView2 = this.tvAmount;
                    StringBuilder stringBuilder3 = new StringBuilder();
                    stringBuilder3.append(desc.getTransAmt());
                    stringBuilder3.append(" BDT");
                    textView2.setText((CharSequence)stringBuilder3.toString());
                    TextView textView3 = this.tvCharge;
                    StringBuilder stringBuilder4 = new StringBuilder();
                    stringBuilder4.append(desc.getCharge());
                    stringBuilder4.append(" BDT");
                    textView3.setText((CharSequence)stringBuilder4.toString());
                    TextView textView4 = this.tvPay;
                    StringBuilder stringBuilder5 = new StringBuilder();
                    stringBuilder5.append(this.getResources().getString(R.string.pay));
                    stringBuilder5.append(" ");
                    stringBuilder5.append(desc.getPayableAmt());
                    stringBuilder5.append(" BDT");
                    textView4.setText((CharSequence)stringBuilder5.toString());
                }
            } else {
                for (SSLCSdkMainResponseModel.Desc desc : this.SSLCSdkMainResponseModel.getDesc()) {
                    if (!desc.getName().contains((CharSequence)string2)) continue;
                    TextView textView5 = this.tvAmount;
                    StringBuilder stringBuilder6 = new StringBuilder();
                    stringBuilder6.append(desc.getTransAmt());
                    stringBuilder6.append(" BDT");
                    textView5.setText((CharSequence)stringBuilder6.toString());
                    TextView textView6 = this.tvCharge;
                    StringBuilder stringBuilder7 = new StringBuilder();
                    stringBuilder7.append(desc.getCharge());
                    stringBuilder7.append(" BDT");
                    textView6.setText((CharSequence)stringBuilder7.toString());
                    TextView textView7 = this.tvPay;
                    StringBuilder stringBuilder8 = new StringBuilder();
                    stringBuilder8.append(this.getResources().getString(R.string.pay));
                    stringBuilder8.append(" ");
                    stringBuilder8.append(desc.getPayableAmt());
                    stringBuilder8.append(" BDT");
                    textView7.setText((CharSequence)stringBuilder8.toString());
                }
            }
            if (!this.tvCharge.getText().equals((Object)"0 BDT") && !this.tvCharge.getText().equals((Object)"0.00 BDT")) {
                this.layoutAmount.setVisibility(0);
                return;
            }
            this.layoutAmount.setVisibility(8);
            return;
        }
        SSLCShareInfo.getInstance().setToGray(this.ivPay);
        this.tvPay.setTextColor(-7829368);
        this.layoutPay.setBackgroundColor(this.getResources().getColor(R.color.white_off));
        this.layoutPay.setEnabled(false);
        this.layoutAmount.setVisibility(8);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public void onConfigurationChanged(Configuration configuration) {
        TabLayout.Tab tab;
        TabLayout.Tab tab2;
        TabLayout.Tab tab3;
        int n;
        AppCompatActivity.super.onConfigurationChanged(configuration);
        this.counterTab = -1;
        this.tvSupport.setText(R.string.support);
        this.tvFaq.setText(R.string.faq);
        this.tvOffer.setText(R.string.offers);
        this.tvAmountHeader.setText(R.string.amount_colon);
        this.tvChargeHeader.setText(R.string.additional_fees_colon);
        if (SSLCPrefUtils.isLoggedIn((Context)this.context)) {
            this.tvLogout.setText(R.string.sdk_logout);
        } else {
            this.tvLogout.setText(R.string.sdk_login);
        }
        this.tvMerchantName.setText((CharSequence)this.SSLCSdkMainResponseModel.getStoreName());
        TextView textView = this.tvPay;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.getResources().getString(R.string.pay));
        stringBuilder.append(" ");
        stringBuilder.append(this.SSLCSdkMainResponseModel.getAmount());
        textView.setText((CharSequence)stringBuilder.toString());
        this.totalTabCount = n = this.tabLayout.getTabCount();
        if (n == 1) {
            this.tab = this.tabLayout.getTabAt(0);
            if (this.SSLCSdkMainResponseModel.getGw().getAmex().equals((Object)"") && this.SSLCSdkMainResponseModel.getGw().getMaster().equals((Object)"") && this.SSLCSdkMainResponseModel.getGw().getVisa().equals((Object)"")) {
                if (!this.SSLCSdkMainResponseModel.getGw().getMobilebanking().equals((Object)"")) {
                    this.tab.setText(R.string.mobile_banking);
                    return;
                }
                if (this.SSLCSdkMainResponseModel.getGw().getInternetbanking().equals((Object)"")) return;
                this.tab.setText(R.string.net_banking);
                return;
            }
            this.tab.setText(R.string.cards);
            return;
        }
        if (n == 2) {
            TabLayout.Tab tab4;
            int n2;
            if (!(this.SSLCSdkMainResponseModel.getGw().getAmex().equals((Object)"") && this.SSLCSdkMainResponseModel.getGw().getMaster().equals((Object)"") && this.SSLCSdkMainResponseModel.getGw().getVisa().equals((Object)""))) {
                TabLayout.Tab tab5;
                int n3;
                TabLayout tabLayout = this.tabLayout;
                this.counterTab = n3 = 1 + this.counterTab;
                this.tab = tab5 = tabLayout.getTabAt(n3);
                tab5.setText(R.string.cards);
            }
            if (!this.SSLCSdkMainResponseModel.getGw().getMobilebanking().equals((Object)"")) {
                TabLayout.Tab tab6;
                int n4;
                TabLayout tabLayout = this.tabLayout;
                this.counterTab = n4 = 1 + this.counterTab;
                this.tab = tab6 = tabLayout.getTabAt(n4);
                tab6.setText(R.string.mobile_banking);
            }
            if (this.SSLCSdkMainResponseModel.getGw().getInternetbanking().equals((Object)"")) return;
            TabLayout tabLayout = this.tabLayout;
            this.counterTab = n2 = 1 + this.counterTab;
            this.tab = tab4 = tabLayout.getTabAt(n2);
            tab4.setText(R.string.net_banking);
            return;
        }
        if (n != 3) return;
        this.tab = tab = this.tabLayout.getTabAt(0);
        tab.setText(R.string.cards);
        this.tab = tab2 = this.tabLayout.getTabAt(1);
        tab2.setText(R.string.mobile_banking);
        this.tab = tab3 = this.tabLayout.getTabAt(2);
        tab3.setText(R.string.net_banking);
    }

    @Override
    public void onCreate(@Nullable Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(R.layout.activity_ssl_sdk_main);
        this.context = this;
        this.sslCommerzInitialization = (SSLCommerzInitialization)this.getIntent().getSerializableExtra("sslCommerzInitialerData");
        Bundle bundle2 = this.getIntent().getExtras();
        if (this.getIntent().hasExtra("main_response")) {
            SSLCSdkMainResponseModel sSLCSdkMainResponseModel;
            this.SSLCSdkMainResponseModel = sSLCSdkMainResponseModel = new SSLCSdkMainResponseModel();
            this.SSLCSdkMainResponseModel = sSLCSdkMainResponseModel.fromJSON(bundle2.getString("main_response"));
        }
        StringBuilder stringBuilder = a.F1((String)"#");
        stringBuilder.append(this.SSLCSdkMainResponseModel.getPrimaryColor());
        this.SSLCProgressBarHandler = new SSLCProgressBarHandler((Context)this, Color.parseColor((String)stringBuilder.toString()));
        this.setSupportActionBar((Toolbar)this.findViewById(R.id.toolbar));
        if (this.getSupportActionBar() != null) {
            this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            this.getSupportActionBar().setHomeButtonEnabled(true);
            this.getSupportActionBar().setTitle((CharSequence)"");
        }
        this.layoutPay = (LinearLayout)this.findViewById(R.id.layout_pay);
        this.ivPay = (ImageView)this.findViewById(R.id.iv_pay);
        this.tvPay = (TextView)this.findViewById(R.id.tv_pay);
        this.viewPager = (ViewPager)this.findViewById(R.id.viewPager);
        this.tabLayout = (TabLayout)this.findViewById(R.id.tabs);
        this.ivLanguage = (ImageView)this.findViewById(R.id.iv_language);
        this.tvMerchantName = (TextView)this.findViewById(R.id.tv_merchant_name);
        this.tvLogout = (TextView)this.findViewById(R.id.tv_logout);
        this.merchantLogo = (ImageView)this.findViewById(R.id.merchant_logo_iv);
        this.clickFAQ = (LinearLayout)this.findViewById(R.id.clickFAQ);
        this.clickSupport = (LinearLayout)this.findViewById(R.id.clickSupport);
        this.badgeLayout = (LinearLayout)this.findViewById(R.id.badgeLayout);
        this.badge = (SSLCCustomTextView)this.findViewById(R.id.badge);
        this.tvUserName = (TextView)this.findViewById(R.id.tv_user_name);
        this.layoutAmount = (RelativeLayout)this.findViewById(R.id.layout_amount);
        this.tvAmount = (TextView)this.findViewById(R.id.tv_amount);
        this.tvCharge = (TextView)this.findViewById(R.id.tv_charge);
        this.tvAmountHeader = (TextView)this.findViewById(R.id.tv_amount_header);
        this.tvChargeHeader = (TextView)this.findViewById(R.id.tv_charge_header);
        this.tvSupport = (SSLCCustomTextView)this.findViewById(R.id.tv_support);
        this.tvFaq = (SSLCCustomTextView)this.findViewById(R.id.tv_faq);
        this.tvOffer = (SSLCCustomTextView)this.findViewById(R.id.tv_offer);
        this.timerText = (SSLCCustomTextView)this.findViewById(R.id.timerText);
        this.mainLyout1 = (LinearLayout)this.findViewById(R.id.mainLyout1);
        this.collapsingToolbar = (CollapsingToolbarLayout)this.findViewById(R.id.collapsingToolbar);
        this.tvUserName.setVisibility(8);
        this.layoutAmount.setVisibility(8);
        this.layoutPay.setEnabled(false);
        SSLCShareInfo.getInstance().setToGray(this.ivPay);
        this.tvPay.setTextColor(-7829368);
        SSLCCustomTextView sSLCCustomTextView = this.tvSupport;
        StringBuilder stringBuilder2 = a.F1((String)"#");
        stringBuilder2.append(this.SSLCSdkMainResponseModel.getPrimaryColor());
        sSLCCustomTextView.setTextColor(Color.parseColor((String)stringBuilder2.toString()));
        SSLCCustomTextView sSLCCustomTextView2 = this.tvFaq;
        StringBuilder stringBuilder3 = a.F1((String)"#");
        stringBuilder3.append(this.SSLCSdkMainResponseModel.getPrimaryColor());
        sSLCCustomTextView2.setTextColor(Color.parseColor((String)stringBuilder3.toString()));
        SSLCCustomTextView sSLCCustomTextView3 = this.tvOffer;
        StringBuilder stringBuilder4 = a.F1((String)"#");
        stringBuilder4.append(this.SSLCSdkMainResponseModel.getPrimaryColor());
        sSLCCustomTextView3.setTextColor(Color.parseColor((String)stringBuilder4.toString()));
        TextView textView = this.tvLogout;
        StringBuilder stringBuilder5 = a.F1((String)"#");
        stringBuilder5.append(this.SSLCSdkMainResponseModel.getPrimaryColor());
        textView.setTextColor(Color.parseColor((String)stringBuilder5.toString()));
        TextView textView2 = this.tvChargeHeader;
        StringBuilder stringBuilder6 = a.F1((String)"#");
        stringBuilder6.append(this.SSLCSdkMainResponseModel.getPrimaryColor());
        textView2.setTextColor(Color.parseColor((String)stringBuilder6.toString()));
        TextView textView3 = this.tvCharge;
        StringBuilder stringBuilder7 = a.F1((String)"#");
        stringBuilder7.append(this.SSLCSdkMainResponseModel.getPrimaryColor());
        textView3.setTextColor(Color.parseColor((String)stringBuilder7.toString()));
        TextView textView4 = this.tvAmountHeader;
        StringBuilder stringBuilder8 = a.F1((String)"#");
        stringBuilder8.append(this.SSLCSdkMainResponseModel.getPrimaryColor());
        textView4.setTextColor(Color.parseColor((String)stringBuilder8.toString()));
        TextView textView5 = this.tvAmount;
        StringBuilder stringBuilder9 = a.F1((String)"#");
        stringBuilder9.append(this.SSLCSdkMainResponseModel.getPrimaryColor());
        textView5.setTextColor(Color.parseColor((String)stringBuilder9.toString()));
        this.clickFAQ.setOnClickListener((View.OnClickListener)new 1(this));
        this.clickSupport.setOnClickListener((View.OnClickListener)new 2(this));
        this.findViewById(R.id.layout_top_login).setOnClickListener((View.OnClickListener)new 3(this));
        if (SSLCPrefUtils.getPreferenceLanguageValue((Context)this.context).contains((CharSequence)"en")) {
            this.ivLanguage.setImageResource(R.drawable.ic_eng);
        } else {
            this.ivLanguage.setImageResource(R.drawable.ic_bng);
        }
        this.onConfigurationChanged(SSLCShareInfo.getInstance().updateLanguage((Context)this));
        this.ivLanguage.setOnClickListener((View.OnClickListener)new 4(this));
        if (!SSLCShareInfo.getInstance().getlastHitSDKType(this.context).equals((Object)this.sslCommerzInitialization.getSdkType())) {
            SSLCShareInfo.getInstance().saveCustSession(this.context, "");
            SSLCShareInfo.getInstance().saveMobileNo(this.context, "");
            SSLCShareInfo.getInstance().saveRegId(this.context, "");
            SSLCShareInfo.getInstance().saveEncKey(this.context, "");
        }
        if (!SSLCShareInfo.getInstance().getRegKey((Context)this).isEmpty() && !SSLCShareInfo.getInstance().getEncKey((Context)this).isEmpty()) {
            this.loadOfferModel();
        } else {
            String string2 = Settings.Secure.getString((ContentResolver)this.getContentResolver(), (String)"android_id");
            String string3 = Build.MANUFACTURER;
            SSLCShareInfo.getInstance().lastHitSDKType(this.context, this.sslCommerzInitialization.getSdkType());
            new SSLCGetDeviceTokenViewModel((Context)this).submitDeviceToken("Android", string2, "no device id", SSLCShareInfo.getInstance().getDeviceName((Context)this), string3, (SSLCGetDeviceTokenListener)this);
        }
        this.mainLyout1.setVisibility(0);
        this.startCountDown();
    }

    public void onDestroy() {
        AppCompatActivity.super.onDestroy();
        SSLCPrefUtils.setLoggedIn((Context)this.context, (boolean)false);
        SSLCShareInfo.motoMap.clear();
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() != 16908332) {
            return Activity.super.onOptionsItemSelected(menuItem);
        }
        if (this.lastBackPressTime < System.currentTimeMillis() - 4000L) {
            SSLCShareInfo.getInstance().showToast((Context)this, "Press once again to exit");
            this.lastBackPressTime = System.currentTimeMillis();
        } else {
            this.timer.cancel();
            this.finish();
        }
        return true;
    }

    public void onResume() {
        FragmentActivity.super.onResume();
        if (!SSLCShareInfo.getInstance().isNetworkAvailable((Context)this)) {
            SSLCShareInfo.getInstance().showToast((Context)this, this.getResources().getString(R.string.internet_connection));
        }
    }

    public void onUserVerify(String string2) {
        this.tvUserName.setText((CharSequence)string2);
        this.tvLogout.setText(R.string.sdk_logout);
        this.tvUserName.setVisibility(0);
    }

    public void setLocale() {
        Locale locale = new Locale(SSLCPrefUtils.getPreferenceLanguageValue((Context)this.context));
        Configuration configuration = this.getResources().getConfiguration();
        configuration.setLocale(locale);
        this.getResources().updateConfiguration(configuration, this.getResources().getDisplayMetrics());
        this.onConfigurationChanged(configuration);
    }

    public void setOnLogoutClickListener(SSLCOnLogOutListener sSLCOnLogOutListener) {
        this.SSLCOnLogOutListener = sSLCOnLogOutListener;
    }

    public void setOnOfferSelectListener(SSLCOnOfferSelectListener sSLCOnOfferSelectListener) {
        this.SSLCOnOfferSelectListener = sSLCOnOfferSelectListener;
    }

    public void setOnPayClickListener(SSLCPayNowListener sSLCPayNowListener) {
        this.payClickListener = sSLCPayNowListener;
    }

    public void setupViewPager(ViewPager viewPager) {
        this.adapter = new SSLCViewPagerAdapter(this.getSupportFragmentManager());
        if (this.SSLCSdkMainResponseModel.getGw().getAmex().equals((Object)"") && this.SSLCSdkMainResponseModel.getGw().getMaster().equals((Object)"") && this.SSLCSdkMainResponseModel.getGw().getVisa().equals((Object)"")) {
            this.findViewById(R.id.layout_top_login).setVisibility(8);
            this.findViewById(R.id.layout_offer).setVisibility(8);
        } else {
            this.adapter.addFrag(SSLCCardFragment.newInstance(this.SSLCSdkMainResponseModel.toJSON(), this.sslCommerzInitialization, new Gson().toJson((Object)this.SSLCOfferModel), new Gson().toJson((Object)this.SSLCEMIModel)), this.getResources().getString(R.string.cards));
        }
        if (!this.SSLCSdkMainResponseModel.getGw().getMobilebanking().equals((Object)"")) {
            this.adapter.addFrag(SSLCMobileBankingFragment.newInstance(this.SSLCSdkMainResponseModel.toJSON(), this.sslCommerzInitialization), this.getResources().getString(R.string.mobile_banking));
        }
        if (!this.SSLCSdkMainResponseModel.getGw().getInternetbanking().equals((Object)"")) {
            this.adapter.addFrag(SSLCNetBankingFragment.newInstance(this.SSLCSdkMainResponseModel.toJSON(), this.sslCommerzInitialization), this.getResources().getString(R.string.net_banking));
        }
        if (!this.SSLCSdkMainResponseModel.getGw().getMobilebanking().equals((Object)"") && !this.SSLCSdkMainResponseModel.getGw().getInternetbanking().equals((Object)"")) {
            viewPager.setOffscreenPageLimit(3);
        } else if (this.SSLCSdkMainResponseModel.getGw().getMobilebanking().equals((Object)"") && !this.SSLCSdkMainResponseModel.getGw().getInternetbanking().equals((Object)"")) {
            viewPager.setOffscreenPageLimit(2);
        } else if (!this.SSLCSdkMainResponseModel.getGw().getMobilebanking().equals((Object)"") && this.SSLCSdkMainResponseModel.getGw().getInternetbanking().equals((Object)"")) {
            viewPager.setOffscreenPageLimit(2);
        }
        this.tabLayout.setTabGravity(0);
        this.tabLayout.setupWithViewPager(viewPager);
        viewPager.setAdapter((PagerAdapter)this.adapter);
        if (!this.SSLCSdkMainResponseModel.getGw().getMobilebanking().equals((Object)"") && this.SSLCSdkMainResponseModel.getDefault_tab().equals((Object)"m")) {
            viewPager.setCurrentItem(1);
        }
        if (!this.SSLCSdkMainResponseModel.getGw().getInternetbanking().equals((Object)"") && this.SSLCSdkMainResponseModel.getDefault_tab().equals((Object)"i")) {
            viewPager.setCurrentItem(2);
        }
        if (this.SSLCSdkMainResponseModel.getGw().getAmex().equals((Object)"") && this.SSLCSdkMainResponseModel.getGw().getMaster().equals((Object)"") && this.SSLCSdkMainResponseModel.getGw().getVisa().equals((Object)"") && this.SSLCSdkMainResponseModel.getDesc().size() == 1) {
            this.tabLayout.setVisibility(8);
            Intent intent = new Intent(this.context, WebViewActivitySSLC.class);
            intent.putExtra("redirectUrl", ((SSLCSdkMainResponseModel.Desc)this.SSLCSdkMainResponseModel.getDesc().get(0)).getRedirectGatewayURL());
            intent.putExtra("merchantName", ((SSLCSdkMainResponseModel.Desc)this.SSLCSdkMainResponseModel.getDesc().get(0)).getName());
            intent.putExtra("session_key", this.SSLCSdkMainResponseModel.getSessionkey());
            intent.putExtra("sdkMainResponse", (Serializable)this.sslCommerzInitialization);
            intent.putExtra("timeOutValue", this.SSLCSdkMainResponseModel.getTimeoutinMin());
            this.startActivityForResult(intent, 3);
        }
        TabLayout tabLayout = this.tabLayout;
        StringBuilder stringBuilder = a.F1((String)"#");
        stringBuilder.append(this.SSLCSdkMainResponseModel.getPrimaryColor());
        tabLayout.setBackgroundColor(Color.parseColor((String)stringBuilder.toString()));
        TabLayout tabLayout2 = this.tabLayout;
        StringBuilder stringBuilder2 = a.F1((String)"#");
        stringBuilder2.append(this.SSLCSdkMainResponseModel.getDesign().getTitleFontColor());
        int n = Color.parseColor((String)stringBuilder2.toString());
        StringBuilder stringBuilder3 = a.F1((String)"#");
        stringBuilder3.append(this.SSLCSdkMainResponseModel.getDesign().getTitleFontColor());
        tabLayout2.setTabTextColors(n, Color.parseColor((String)stringBuilder3.toString()));
        this.tabLayout.setSelectedTabIndicatorHeight(140);
        TabLayout tabLayout3 = this.tabLayout;
        StringBuilder stringBuilder4 = a.F1((String)"#");
        stringBuilder4.append(this.SSLCSdkMainResponseModel.getActiveColor());
        tabLayout3.setSelectedTabIndicatorColor(Color.parseColor((String)stringBuilder4.toString()));
    }

    public void startCountDown() {
        5 var1_1 = new 5(this, 1000L * (60L * Long.valueOf((String)this.SSLCSdkMainResponseModel.getTimeoutinMin())), 1000L);
        this.timer = var1_1.start();
    }

    @Override
    public void viewRelatedTask() {
        new SSLCDownloadImageTask(this.context, this.merchantLogo, this.SSLCSdkMainResponseModel.getStoreLogo(), new SSLCDowloadImageListener(this){
            public final /* synthetic */ MainUIActivitySSLC this$0;
            {
                this.this$0 = mainUIActivitySSLC;
            }

            public void downloadFailed(String string2) {
                SSLCShareInfo.getInstance().showToast(MainUIActivitySSLC.access$100(this.this$0), string2);
            }

            public void downloadSuccess(android.graphics.Bitmap bitmap) {
                this.this$0.merchantLogo.setImageBitmap(bitmap);
            }
        });
        this.tvMerchantName.setText((CharSequence)this.SSLCSdkMainResponseModel.getStoreName());
        TextView textView = this.tvPay;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.getResources().getString(R.string.pay));
        stringBuilder.append(" ");
        stringBuilder.append(this.SSLCSdkMainResponseModel.getAmount());
        textView.setText((CharSequence)stringBuilder.toString());
        this.layoutPay.setOnClickListener((View.OnClickListener)new 7(this));
        this.findViewById(R.id.layout_offer).setOnClickListener((View.OnClickListener)new 8(this));
    }
}

