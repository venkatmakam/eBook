/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.ColorStateList
 *  android.content.res.TypedArray
 *  android.graphics.Color
 *  android.graphics.Typeface
 *  android.graphics.drawable.Drawable
 *  android.text.TextWatcher
 *  android.util.AttributeSet
 *  android.widget.EditText
 *  android.widget.TextView
 *  androidx.appcompat.widget.AppCompatEditText
 *  com.sslwireless.sslcommerzlibrary.R
 *  com.sslwireless.sslcommerzlibrary.R$styleable
 *  com.sslwireless.sslcommerzlibrary.model.util.SSLCCardNumberFormat
 *  com.sslwireless.sslcommerzlibrary.view.custom.SSLCCustomEdittext$TextDrawable
 *  com.sslwireless.sslcommerzlibrary.view.custom.SSLCUserTypeFace
 *  java.lang.String
 */
package com.sslwireless.sslcommerzlibrary.view.custom;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.widget.AppCompatEditText;
import com.sslwireless.sslcommerzlibrary.R;
import com.sslwireless.sslcommerzlibrary.model.util.SSLCCardNumberFormat;
import com.sslwireless.sslcommerzlibrary.view.custom.SSLCCustomEdittext;
import com.sslwireless.sslcommerzlibrary.view.custom.SSLCUserTypeFace;

/*
 * Exception performing whole class analysis.
 */
public class SSLCCustomEdittext
extends AppCompatEditText {
    public static final String ANDROID_SCHEMA = "http://schemas.android.com/apk/res/android";
    private ColorStateList mPrefixTextColor;
    private float mPrefixTextSize;

    public SSLCCustomEdittext(Context context) {
        this(context, null);
    }

    public SSLCCustomEdittext(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 16842862);
        this.init(context, attributeSet);
    }

    public SSLCCustomEdittext(Context context, AttributeSet attributeSet, int n) {
        super(context, attributeSet, n);
        this.init(context, attributeSet);
        this.mPrefixTextColor = this.getTextColors();
        this.mPrefixTextSize = this.getTextSize();
    }

    public static /* synthetic */ float access$000(SSLCCustomEdittext sSLCCustomEdittext) {
        return sSLCCustomEdittext.mPrefixTextSize;
    }

    public static /* synthetic */ ColorStateList access$100(SSLCCustomEdittext sSLCCustomEdittext) {
        return sSLCCustomEdittext.mPrefixTextColor;
    }

    private void init(Context context, AttributeSet attributeSet) {
        if (!this.isInEditMode()) {
            int n = context.obtainStyledAttributes(attributeSet, R.styleable.custom).getInteger(R.styleable.custom_textStyle, 0);
            if (n == 0) {
                SSLCUserTypeFace.SetNormal((TextView)this);
                return;
            }
            this.setStyle(n);
            return;
        }
        this.setTypeface(Typeface.DEFAULT, 0);
    }

    private void setStyle(int n) {
        if (n != 0) {
            if (n != 1) {
                if (n != 2) {
                    if (n != 3) {
                        if (n != 4) {
                            SSLCUserTypeFace.SetNormal((TextView)this);
                            return;
                        }
                        SSLCUserTypeFace.SetMedium((TextView)this);
                        return;
                    }
                    SSLCUserTypeFace.SetLight((TextView)this);
                    return;
                }
                SSLCUserTypeFace.SetItalic((TextView)this);
                return;
            }
            SSLCUserTypeFace.SetBold((TextView)this);
            return;
        }
        SSLCUserTypeFace.SetNormal((TextView)this);
    }

    public void isInputTypeCard(boolean bl) {
        if (bl) {
            this.addTextChangedListener((TextWatcher)new SSLCCardNumberFormat((EditText)this));
        }
    }

    public void setPrefix(String string, boolean bl) {
        this.setCompoundDrawables((Drawable)new /* Unavailable Anonymous Inner Class!! */, null, null, null);
        if (bl) {
            this.setPrefixTextColor(Color.parseColor((String)"#969696"));
            return;
        }
        this.setPrefixTextColor(Color.parseColor((String)"#494949"));
    }

    public void setPrefixAndSuffix(String string, Drawable drawable) {
        int n = drawable.getIntrinsicHeight();
        drawable.setBounds(0, 0, drawable.getIntrinsicWidth(), n);
        this.setCompoundDrawables((Drawable)new /* Unavailable Anonymous Inner Class!! */, null, drawable, null);
    }

    public void setPrefixTextColor(int n) {
        this.mPrefixTextColor = ColorStateList.valueOf((int)n);
    }

    public void setPrefixTextColor(ColorStateList colorStateList) {
        this.mPrefixTextColor = colorStateList;
    }

    public void setPrefixTextSize(float f) {
        this.mPrefixTextSize = f;
    }

    public void setSuffix(String string) {
        this.setCompoundDrawables(null, null, (Drawable)new /* Unavailable Anonymous Inner Class!! */, null);
    }
}

